# 2IIM Blitzkrieg (no account for PDF download)

Source: https://online.2iim.com/blitzkrieg
PDFs are public direct links. Timed "Take Test" at https://learn.2iim.com/learn/Blitzkrieg-Series needs free signup.

| Ep | Topic | Date | Local PDF | Size | YouTube |
|---:|---|---|---|---:|---|
| 1 | Percentages | 2022-06-12 | `Blitzkrieg-Series-Ep-1.pdf` | 444,771 | [watch](https://www.youtube.com/watch?v=BaBpzV3DwEE) |
| 2 | Permutations and Combinations | 2022-06-19 | `Blitzkrieg-Series-Ep-2.pdf` | 393,766 | [watch](https://www.youtube.com/watch?v=RAJrd_CARtU) |
| 3 | Geometry | 2022-06-26 | `Blitzkrieg-Series-Ep-3.pdf` | 448,545 | [watch](https://www.youtube.com/watch?v=8fK8Kengr9o) |
| 4 | Progressions | 2022-07-03 | `Blitzkrieg-Series-Ep-4.pdf` | 465,272 | [watch](https://www.youtube.com/watch?v=XP098K63oAI) |
| 5 | Profit & Loss | 2022-07-10 | `Blitzkrieg-Series-Ep-5.pdf` | 1,116,524 | [watch](https://www.youtube.com/watch?v=ESMlSSsB368) |
| 6 | Logarithms | 2022-07-17 | `Blitzkrieg-Series-Ep-6.pdf` | 473,650 | [watch](https://www.youtube.com/watch?v=W4uKD3Pp47k) |
| 7 | Number Theory | 2022-07-24 | `Blitzkrieg-Series-Ep-7.pdf` | 423,422 | [watch](https://www.youtube.com/watch?v=2OGI3fCaSXI) |
| 8 | Alligations and mixtures | 2022-07-31 | `Blitzkrieg-Series-Ep-8.pdf` | 441,147 | [watch](https://www.youtube.com/watch?v=hu-S5nNufCs) |
| 9 | Speed, Time & Distance | 2022-08-07 | `Blitzkrieg-Series-Ep-9.pdf` | 1,093,552 | [watch](https://www.youtube.com/watch?v=EPLrK2RWVME) |
| 10 | Averages | 2022-08-14 | `Blitzkrieg-Series-Ep-10.pdf` | 1,630,852 | [watch](https://www.youtube.com/watch?v=0xvx3q17jZs) |
| 11 | Ratio & Proportion | 2022-08-21 | `Blitzkrieg-Series-Ep-11.pdf` | 1,111,866 | [watch](https://www.youtube.com/watch?v=X0E_S5awePs) |
| 12 | Geometry-2 | 2022-08-28 | `Blitzkrieg-Series-Ep-12.pdf` | 1,081,392 | [watch](https://www.youtube.com/watch?v=SK__8E7NcdU) |
| 13 | Speed, Time & Distance - 2 | 2022-09-04 | `Blitzkrieg-Series-Ep-13.pdf` | 813,378 | [watch](https://www.youtube.com/watch?v=AYjT9Z2l2So) |
| 14 | Permutation & Combination & Probability | 2022-09-11 | `Blitzkrieg-Series-Ep-14.pdf` | 1,082,072 | [watch](https://www.youtube.com/watch?v=wf4dsDIrZsM) |
| 15 | Time & Work | 2022-09-18 | `Blitzkrieg-Series-Ep-15.pdf` | 1,372,404 | [watch](https://www.youtube.com/watch?v=CgNjuFqom7s) |
| 16 | Simple & Compound Interest | 2022-09-25 | `Blitzkrieg-Series-Ep-16.pdf` | 1,023,699 | [watch](https://www.youtube.com/watch?v=Q9fwZ_wAN7s) |
| 17 | VARC Para Jumbles CAT 2021 | 2022-10-02 | `Blitzkrieg-Series-Ep-17.pdf` | 1,116,236 | [watch](https://www.youtube.com/watch?v=OJl3F3u36kY) |
| 18 | Number Theory - 2 | 2022-10-09 | `Blitzkrieg-Series-Ep-18.pdf` | 904,618 | [watch](https://www.youtube.com/watch?v=Ng1sat83StA) |

Saved **18/18** PDFs (~15.4 MB).
