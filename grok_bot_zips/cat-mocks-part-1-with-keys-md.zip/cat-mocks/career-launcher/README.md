# Career Launcher — free mocks & CAT 2025 slots

**Source hub:** https://www.careerlauncher.com/cat-mba/freecatmock/  
**MyZone:** https://myzone.careerlauncher.com/

## Keys status

**No answer keys in this pack** for Free Mock 1–2.

| File | What it actually is |
| --- | --- |
| `free-mock-1-answers.md` | Status/scorecard notes only — blank submit, **score 0.0**; CL says solutions appear ~1 day later. **Not a key file.** |
| `free-mock-2-answers.md` | Status notes only — MyZone session expired (`login.jsp?msg=DST`) before review. **Not a key file.** |

Do not invent keys. Prefer `../with-keys/` for keyed CAT 2025 PYQs.

## Free Mock questions (full length)

Both free mocks are **complete question captures** (not VARC-only). Early header notes that said “DILR/QA pending” were stale and have been corrected.

| File | Contents |
| --- | --- |
| `free-mock-1.md` | Free CAT Mock 01 — VARC 24 + DILR 22 + QA 22 |
| `free-mock-2.md` | Free CAT Mock 02 — VARC 24 + DILR 22 + QA 22 |

**Caveats:** some DILR embedded tables/grids did not render in MyZone’s text Question Paper view (called out in-file).

## Other files

| File | Role |
| --- | --- |
| `cat-2025-slot-1.md` … `slot-3.md` | CAT 2025 actual-paper slot captures (questions only) |
| `CATALOG.md` | Topic/sectional instruction URL catalog |
| `UNLOCKED.md` | What Free Zone showed unlocked (30 Sep 2026) |

Copies of catalog/unlocked notes also live under `../docs/`.

## Incomplete / follow-ups

- Retrieve Free Mock 1–2 solutions from MyZone after the delay window (login required).
- Topic tests in catalog: not dumped here.
