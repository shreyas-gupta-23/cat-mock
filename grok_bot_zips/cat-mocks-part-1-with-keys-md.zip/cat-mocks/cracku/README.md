# Cracku — Free CAT Mock 1–3 + public PYQ PDFs

**Source hub:** https://cracku.in/cat-mock-test  
**Keys status:** Free Mock 1–3 **have keys** (captured from post-submit review). Public PDFs under `pyq-public/` include solutions.

## Naming pattern (canonical)

| File | Role |
| --- | --- |
| `free-mock-1.md` | Mock 1 questions/options (LRDI + Quant primary; see file header for VARC note) |
| `free-mock-1-answers.md` | Mock 1 keys, text solutions, scorecard |
| `free-mock-2.md` | Mock 2 questions (VARC paper + options; some review blocks) |
| `free-mock-2-answers.md` | Mock 2 keys / solutions / scorecard |
| `free-mock-3.md` | Mock 3 questions/options (68 entries) |
| `free-mock-3-answers.md` | Mock 3 keys / solutions / scorecard |
| `pyq-public/*.pdf` | Public solved PYQ downloads (no login) |
| `INVENTORY.md` | Detailed Cracku catalog (login gates, PDF IDs) |

Pattern: **`free-mock-N.md` + `free-mock-N-answers.md`** (no zero-padding). Duplicate capture partials and HTML dumps were removed; content lives in these six files.

## pyq-public/

| Files | Notes |
| --- | --- |
| `CAT-2025-Slot{1,2,3}-{VARC,Quant}-solved.pdf` | 6 solved sectionals |
| `CAT-1999-Question-Paper.pdf`, `CAT-2001-Question-Paper.pdf` | Older papers with solutions |

Login-gated (not saved): CAT 2025 full slots, DILR sectionals, most older PYQ download IDs. See `INVENTORY.md`.

## Related docs

- Login field refs: `../docs/cracku-secure-form.md`
- Mock 3 session notes: `../docs/cracku-free-mock-3-status.md`

Paid DashCAT / Head Start: skipped.
