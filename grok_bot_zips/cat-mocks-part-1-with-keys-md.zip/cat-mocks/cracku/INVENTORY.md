# Cracku free CAT mocks — inventory (1 Oct 2026, IST)

Only free / publicly linked material. **Paid DashCAT / Head Start not scraped.**

See also `README.md` in this folder for naming and agent quick-start.

## Summary

| Item | Status |
| --- | --- |
| Free full-length mocks (3) | **Captured** — `free-mock-{1,2,3}.md` + `*-answers.md` |
| Free sectionals (VARC / Quant / LRDI) | Login required — not saved |
| Free mock question PDFs | Not public without login |
| CAT 2025 solved sectionals (VARC+QA × 3 slots) | **Saved** in `pyq-public/` |
| Older CAT papers (1999, 2001) | **Saved** in `pyq-public/` |
| CAT 2025 full-slot PDFs + DILR sectionals | Login-gated — not saved |
| Paid DashCAT / Head Start | Skipped |

## Free full-length mocks

Hub: https://cracku.in/cat-mock-test

| Mock | Files | Notes |
| --- | --- | --- |
| Free Mock 1 | `free-mock-1.md`, `free-mock-1-answers.md` | 68Q; blank submit; keys exposed |
| Free Mock 2 | `free-mock-2.md`, `free-mock-2-answers.md` | 68Q; blank submit; keys exposed |
| Free Mock 3 | `free-mock-3.md`, `free-mock-3-answers.md` | 68Q; blank submit; some entries without marked option labeled as such |

Login field refs: `../docs/cracku-secure-form.md`. Mock 3 session: `../docs/cracku-free-mock-3-status.md`.

## pyq-public/ (public S3, with solutions)

| File | Notes |
| --- | --- |
| `CAT-2025-Slot1-VARC-solved.pdf` | Public |
| `CAT-2025-Slot1-Quant-solved.pdf` | Public |
| `CAT-2025-Slot2-VARC-solved.pdf` | Public |
| `CAT-2025-Slot2-Quant-solved.pdf` | Public |
| `CAT-2025-Slot3-VARC-solved.pdf` | Public |
| `CAT-2025-Slot3-Quant-solved.pdf` | Public |
| `CAT-1999-Question-Paper.pdf` | Public |
| `CAT-2001-Question-Paper.pdf` | Public |

Login-gated (not downloaded): CAT 2025 Slot 1–3 full papers; Slot 1–3 DILR sectionals.

## Cleanup note

HTML dumps, `download-probe.txt`, and per-section capture partials were removed after merge into the six canonical mock files above.
