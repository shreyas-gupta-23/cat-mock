# MISSING-KEYS.md

Papers / mocks under `/workspace/cat-mocks` that lack a **complete, usable answer key** in `with-keys/`. Answers were **not invented**.

Generated: 1 Oct 2026 (IST).

---

## CAT 2022–2025 (2iim-html)

**None missing.** All 36 section extracts (4 years × 3 slots × VARC/DILR/Quant) contain on-page `Correct Answer` / `Correct Answer Choice` labels. Combined files are in `with-keys/`.

| Year | Slots | Answers per slot (VARC+DILR+QA) | Status |
| --- | --- | --- | --- |
| 2022 | 1, 2, 3 | 24+20+22 = 66 | Complete on-page keys |
| 2023 | 1, 2, 3 | 24+20+22 = 66 | Complete on-page keys |
| 2024 | 1, 2, 3 | 24+22+22 = 68 | Complete on-page keys |
| 2025 | 1, 2, 3 | 24+22+22 = 68 | Complete on-page keys |

---

## CAT 2017–2021 (2iim-pyq PDFs)

Full clean Q+A markdown like 2022–2025 was **not** built: MCQ keys are often color-marked or behind PDF “click to see answer”, and text extraction only reliably yields **partial** keys (mostly TITA / some verbal).

PDF key/solutions packs (and partial `*-TEXT-ANSWERS.md`) are under `with-keys/earlier-years/`. Open the PDF for full MCQ keys where present.

### Incomplete / missing as clean combined keys

| Item | What’s on disk | Why listed as missing/incomplete |
| --- | --- | --- |
| CAT 2017 Slot 1–2 | Section “With Video/Text Solutions” PDFs + full papers | Plain-text answers partial (Quants ~11 TITA; VARC ~7; DILR 0 text). Solutions often video/image. |
| CAT 2018 Slot 1–2 | `CAT-Answer-Key-CAT-2018-Slot-*.pdf` + section solution PDFs | Official key marks correct options in **green** — not recoverable as plain text (0 text answers). Solution PDFs: partial text answers only. |
| CAT 2019 Slot 1–2 | `CAT-2019-slot*-answer-key.pdf` + section/verbal PDFs | Response-sheet style: TITA `Possible Answer` fields extractable (~24–29); MCQ correct options not fully available as plain text (do not use candidate `Chosen Option` as key). |
| CAT 2020 Slot 1–3 | Section PDFs in `2iim-pyq/` | Only partial `Correct Answer:` lines (mostly TITA). MCQ via click-to-reveal. **Verbal Slot 1 PDF missing** (0-byte / not saved per inventory). |
| CAT 2021 Slot 1–3 | Section PDFs in `2iim-pyq/` | Only partial `Correct Answer:` lines (mostly TITA). MCQ via click-to-reveal / video links. |

### Earlier-year text-extract counts (not full papers)

- `CAT-2017-Slot-1-DILR-2IIM-With-Video-Solutions.pdf` → `CAT-2017-Slot-1-DILR-2IIM-With-Video-Solutions-TEXT-ANSWERS.md` — **0** plain-text answer lines
- `CAT-2017-Slot-1-VARC-2IIM-With-Text-Solutions.pdf` → `CAT-2017-Slot-1-VARC-2IIM-With-Text-Solutions-TEXT-ANSWERS.md` — **7** plain-text answer lines
- `CAT-2017-Slot-1-quants-2IIM-With-Video-Solutions.pdf` → `CAT-2017-Slot-1-quants-2IIM-With-Video-Solutions-TEXT-ANSWERS.md` — **11** plain-text answer lines
- `CAT-2017-Slot-2-DILR-2IIM-With-Video-Solutions.pdf` → `CAT-2017-Slot-2-DILR-2IIM-With-Video-Solutions-TEXT-ANSWERS.md` — **0** plain-text answer lines
- `CAT-2017-Slot-2-VARC-2IIM-With-Text-Solutions.pdf` → `CAT-2017-Slot-2-VARC-2IIM-With-Text-Solutions-TEXT-ANSWERS.md` — **7** plain-text answer lines
- `CAT-2017-Slot-2-quants-2IIM-With-Video-Solutions.pdf` → `CAT-2017-Slot-2-quants-2IIM-With-Video-Solutions-TEXT-ANSWERS.md` — **11** plain-text answer lines
- `CAT-2018-Question-Paper-Slot-1-DILR-2IIM-With-Video-Solutions.pdf` → `CAT-2018-Question-Paper-Slot-1-DILR-2IIM-With-Video-Solutions-TEXT-ANSWERS.md` — **7** plain-text answer lines
- `CAT-2018-Question-Paper-Slot-1-Quants-2IIM-With-Video-Solutions.pdf` → `CAT-2018-Question-Paper-Slot-1-Quants-2IIM-With-Video-Solutions-TEXT-ANSWERS.md` — **12** plain-text answer lines
- `CAT-2018-Question-Paper-Slot-2-DILR-2IIM-With-Video-Solutions.pdf` → `CAT-2018-Question-Paper-Slot-2-DILR-2IIM-With-Video-Solutions-TEXT-ANSWERS.md` — **8** plain-text answer lines
- `CAT-2018-Question-Paper-Slot-2-Quants-2IIM-With-Video-Solutions.pdf` → `CAT-2018-Question-Paper-Slot-2-Quants-2IIM-With-Video-Solutions-TEXT-ANSWERS.md` — **11** plain-text answer lines
- `CAT-2018-Verbal-solutions-slot1.pdf` → `CAT-2018-Verbal-solutions-slot1-TEXT-ANSWERS.md` — **7** plain-text answer lines
- `CAT-2018-Verbal-solutions-slot2.pdf` → `CAT-2018-Verbal-solutions-slot2-TEXT-ANSWERS.md` — **5** plain-text answer lines
- `CAT-2019-DILR-Slot1.pdf` → `CAT-2019-DILR-Slot1-TEXT-ANSWERS.md` — **7** plain-text answer lines
- `CAT-2019-DILR-Slot2.pdf` → `CAT-2019-DILR-Slot2-TEXT-ANSWERS.md` — **8** plain-text answer lines
- `CAT-2019-Quants-Slot1.pdf` → `CAT-2019-Quants-Slot1-TEXT-ANSWERS.md` — **11** plain-text answer lines
- `CAT-2019-Quants-Slot2.pdf` → `CAT-2019-Quants-Slot2-TEXT-ANSWERS.md` — **11** plain-text answer lines
- `CAT-2019-Verbal-Solutions-Slot1.pdf` → `CAT-2019-Verbal-Solutions-Slot1-TEXT-ANSWERS.md` — **6** plain-text answer lines
- `CAT-2019-Verbal-Solutions-Slot2.pdf` → `CAT-2019-Verbal-Solutions-Slot2-TEXT-ANSWERS.md` — **7** plain-text answer lines
- `CAT-2019-slot1-answer-key.pdf` → `CAT-2019-slot1-answer-key-TEXT-ANSWERS.md` — **24** plain-text answer lines
- `CAT-2019-slot2-answer-key.pdf` → `CAT-2019-slot2-answer-key-TEXT-ANSWERS.md` — **29** plain-text answer lines
- `CAT-2020-DILR-Slot1.pdf` → `CAT-2020-DILR-Slot1-TEXT-ANSWERS.md` — **6** plain-text answer lines
- `CAT-2020-DILR-Slot2.pdf` → `CAT-2020-DILR-Slot2-TEXT-ANSWERS.md` — **5** plain-text answer lines
- `CAT-2020-DILR-Slot3.pdf` → `CAT-2020-DILR-Slot3-TEXT-ANSWERS.md` — **5** plain-text answer lines
- `CAT-2020-Quants-Slot1.pdf` → `CAT-2020-Quants-Slot1-TEXT-ANSWERS.md` — **8** plain-text answer lines
- `CAT-2020-Quants-Slot2.pdf` → `CAT-2020-Quants-Slot2-TEXT-ANSWERS.md` — **8** plain-text answer lines
- `CAT-2020-Quants-Slot3.pdf` → `CAT-2020-Quants-Slot3-TEXT-ANSWERS.md` — **8** plain-text answer lines
- `CAT-2020-Verbal-Slot2.pdf` → `CAT-2020-Verbal-Slot2-TEXT-ANSWERS.md` — **6** plain-text answer lines
- `CAT-2020-Verbal-Slot3.pdf` → `CAT-2020-Verbal-Slot3-TEXT-ANSWERS.md` — **7** plain-text answer lines
- `CAT-2021-DILR-Slot1.pdf` → `CAT-2021-DILR-Slot1-TEXT-ANSWERS.md` — **5** plain-text answer lines
- `CAT-2021-DILR-Slot2.pdf` → `CAT-2021-DILR-Slot2-TEXT-ANSWERS.md` — **4** plain-text answer lines
- `CAT-2021-DILR-Slot3.pdf` → `CAT-2021-DILR-Slot3-TEXT-ANSWERS.md` — **5** plain-text answer lines
- `CAT-2021-Quants-Slot1.pdf` → `CAT-2021-Quants-Slot1-TEXT-ANSWERS.md` — **8** plain-text answer lines
- `CAT-2021-Quants-Slot2.pdf` → `CAT-2021-Quants-Slot2-TEXT-ANSWERS.md` — **8** plain-text answer lines
- `CAT-2021-Quants-Slot3.pdf` → `CAT-2021-Quants-Slot3-TEXT-ANSWERS.md` — **7** plain-text answer lines
- `CAT-2021-Verbal-Slot1.pdf` → `CAT-2021-Verbal-Slot1-TEXT-ANSWERS.md` — **3** plain-text answer lines
- `CAT-2021-Verbal-Slot2.pdf` → `CAT-2021-Verbal-Slot2-TEXT-ANSWERS.md` — **6** plain-text answer lines
- `CAT-2021-Verbal-Slot3.pdf` → `CAT-2021-Verbal-Slot3-TEXT-ANSWERS.md` — **5** plain-text answer lines
- `CAT-Answer-Key-CAT-2018-Slot-1.pdf` → `CAT-Answer-Key-CAT-2018-Slot-1-TEXT-ANSWERS.md` — **0** plain-text answer lines
- `CAT-Answer-Key-CAT-2018-Slot-2.pdf` → `CAT-Answer-Key-CAT-2018-Slot-2-TEXT-ANSWERS.md` — **0** plain-text answer lines

---

## Career Launcher free mocks

CL states that comprehensive analysis/solutions become available in MyZone **about one day after** the test window ends. **Do not fabricate keys.**

| Item | Questions saved? | Answer key? | Notes |
| --- | --- | --- | --- |
| Free CAT Mock - 01 | Yes — `career-launcher/free-mock-1.md` | **No** | `free-mock-1-answers.md`: score 0; solutions not shown at submit time. |
| Free CAT Mock - 02 | Yes — `career-launcher/free-mock-2.md` | **No** | `free-mock-2-answers.md`: session redirected to login; no key displayed. |
| CAT 2025 Actual Paper Slot 1–3 (CL capture) | Partial — `career-launcher/cat-2025-slot-*.md` (live Q paper view) | **No in CL capture** | Use `with-keys/CAT-2025-Slot-*-with-keys.md` from 2IIM on-page keys instead. |
| CL topic / sectional tests | Not saved as static Q+A | **No** | Interactive engine; instructions-only HTML on disk. |

---

## Other sources (no keys / no static papers)

| Source | Status |
| --- | --- |
| 2IIM Blitzkrieg Eps 1–18 | Question PDFs only; solutions via YouTube links in README — no answer key files built here. |
| InsideIIM mocks | Registration-gated interactive hub; no public PDFs. |
| Quantifiers TruCAT / PYQ | Interactive or TLS-blocked on box; `pyq-pdfs/` empty. |

