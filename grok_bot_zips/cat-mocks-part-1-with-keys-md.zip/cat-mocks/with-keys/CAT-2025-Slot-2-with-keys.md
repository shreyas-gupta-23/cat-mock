# CAT 2025 — Slot 2 (Questions + On-page Answer Key)

Combined from public 2IIM HTML question pages (`2iim-html/`).
Answers are the on-page **Correct Answer** / **Correct Answer Choice** labels. Not invented. Not an official IIM PDF unless cross-checked.

---

## VARC

- Source file: `2iim-html/CAT-2025-Question-Paper-Slot-2-VARC.txt`
- Page: https://online.2iim.com/CAT-question-paper/CAT-2025-Question-Paper-Slot-2-VARC/
- On-page answers found: 24
- Answer source: 2IIM on-page **Correct Answer** / **Correct Answer Choice** (not invented)

### Q1

CAT 2025 Question Paper | CAT VARC

 CAT Question Paper | CAT Previous Year Paper

 CAT 2025 Slot 2 - VA RC

 The given sentence is missing in the paragraph below. Decide where it best fits among the options 1, 2, 3, or 4 indicated in the paragraph.

Sentence: While taste is related to judgment, with thinkers at the time often writing, for example, about "judgments of taste" or using the two terms interchangeably, taste retains a vital link to pleasure, embodiment, and personal specificity that is too often elided in post-Kantian ideas about judgment—a link that Arendt herself was working to restore.

Paragraph: ____(1) ____. Denneny focused on taste rather than judgment in order to highlight what he believed was a crucial but neglected historical change. ____(2) ____. Over the course of the seventeenth century and early eighteenth century, across Western Europe, the word taste took on a new extension of meaning, no longer referring specifically to gustatory sensation and the delights of the palate but becoming, for a time, one of the central categories for aesthetic—and ethical—thinking. ____(3) ____. Tracing the history of taste in Spanish, French, and British aesthetic theory, as Denneny did, also provides a means to recover the compelling and relevant writing of a set of thinkers who have been largely neglected by professional philosophy. ____(4) ____.

 Option 3

 Option 4

 Option 1

 Option 2

**ANSWER:** Choice A

### Q2

Option 3

 The passage below is accompanied by four questions. Based on the passage, choose the best answer for each question.

This book takes the position that setting in literature is more than just backdrop, that important insight into literary texts can be made by paying close attention to how authors craft place, as well as to how place functions in a narrative. The authors included in this reference work engage deeply with either real or imagined geographies. They care about how human decisions have shaped landscapes and how landscapes have shaped human practices and values. Some of the best writing is highly vivid, employing the language of the senses because this is the primary means through which humans know physical space.

Literature can offer valuable perspectives on physical and cultural geography. Unlike scientific reports, a literary narrative can provide the emotional component missing from the scientific record. In human experience, geographical places have a spiritual or emotional component in addition to and as part of a physical layout and topography. This emotional component, although subjective, is no less "real" than a surveyor's map. Human consciousness of place is experienced in a multi-modal manner. Histories of places live on in many forms, one of which is the human memory or imagination.

Both real and imaginary landscapes provide insight into the human experience of place. The pursuit of such a topic speaks to the valuable knowledge produced from bridging disciplines and combining material from both the arts and the sciences to better understand the human condition. The perspectives that most concern cultural geographers are often those regarding movement and migration, cultivation of natural resources, and organization of space. The latter two reflect concerns of the built environment, a topic shared with the field of architectural study. Many of these concerns are also reflected in work sociologists do. Scholars from literary studies can contribute an aesthetic dimension to what might otherwise be a purely ideological approach.

Literature can bring together material that spans different branches of science. For example, a literary description of place may involve not only the environment and geography but the noises and quality of light, or how people from different races or classes can experience the same place in different ways linked to those racial or class disparities. Literary texts can also account for the way in which absence—of other people, animals, and so on—affects a human observer or inhabitant. Both literary and scientific approaches to place are necessary, working in unison, to achieve a complete record of an environment. It is important to note that the interdisciplinary nature of this work teaches us that landscapes are not static, that they are not unchanged by human culture. At least part of their identity derives from the people who inhabit them and from the way space can alter and inspire human perspective. The intersection of scientific and literary expression that happens in the study of literary geography is of prime importance due to the complexity of the personal and political ways that humans experience place.

 CAT 2025 Slot 2 - VA RC

 All of the following statements, if false, would contradict the arguments in the passage, EXCEPT that:

 highly vivid writing, employing the language of the senses, can capture the multi-modal manner in which humans experience places.

 descriptions of places do not need satellite imagery or other visual aids to give a "real" sense of the place.

 literature provides us with deep insights into the ways in which movement and migration affect physical geography.

 humans do not interact with places in subjective, emotional ways because places are only physical topography.

**ANSWER:** Choice D

### Q3

humans do not interact with places in subjective, emotional ways because places are only physical topography.

 CAT 2025 Slot 2 - VA RC

 Which one of the following is a valid conclusion to draw from the author's statement that, "The pursuit of such a topic speaks to the valuable knowledge produced from bridging disciplines and combining material from both the arts and the sciences to better understand the human condition."?

 A comprehensive understanding of the valuable knowledge produced by the arts and sciences can best be achieved by studying the human condition.

 The literary descriptions of the emotions we experience in the places we visit can contribute to our understanding of the arts and sciences.

 A comprehensive bridging of the human condition can best be achieved by a disciplined pursuit of human understanding.

 A comprehensive understanding of the human condition can best be achieved by combining the findings of disciplines from the arts and the sciences.

**ANSWER:** Choice D

### Q4

A comprehensive understanding of the human condition can best be achieved by combining the findings of disciplines from the arts and the sciences.

 CAT 2025 Slot 2 - VA RC

 Which one of the following is not true of the argument in the second paragraph?

 Literary accounts of places can be filled with histories, manifested as memory or imagination.

 The spiritual experience of a place may be considered as real as the physical experience of it.

 Analysing the literary descriptions of a place can give us a sense of how people relate emotionally to it.

 The emotional and spiritual experience of a place can replace a surveyor's map.

**ANSWER:** Choice D

### Q5

The emotional and spiritual experience of a place can replace a surveyor's map.

 CAT 2025 Slot 2 - VA RC

 The author uses the example of the literary description of place to illustrate that:

 literature can convey how different people experience the same place differently.

 architects use diverse methods to calibrate the noises and lights of a given place.

 the absence of other people, animals, and so on in a place can profoundly affect its inhabitants.

 scientific approaches to place are more accurate than literary ones.

**ANSWER:** Choice A

### Q6

literature can convey how different people experience the same place differently.

 CAT 2025 Slot 2 - VA RC

 Five jumbled sentences (labelled 1, 2, 3, 4, and 5), related to a topic, are given below. Four of them can be put together to form a coherent paragraph. Identify the odd sentence out and key in the number of that sentence as your answer.

1. Sporting a copper-coloured pixie cut and a pair of pink feather antlers, Torres himself resembles a child's doodle.
2. His casual millennial delivery, peppered with "um"s and "ah"s, makes surreal concepts sound like items on a brunch menu.
3. Though he may have failed so far in his colour-scouting mission (he hasn't yet found a new one, he admits), this hour leaves you tickled pink.
4. Like his previous show, My Favourite Shapes, this is an hour of sit-down comedy aided by an overhead camera which relays Torres's theories – illustrated with crayon squiggles – on to a screen behind him.
5. His inquisitive mind produces interconnected ideas about Catholicism, the blandness of Pixar and what orange sounds like, while his insights train us to spot "highly purple behaviour".

**ANSWER:** 3

### Q7

The passage below is accompanied by four questions. Based on the passage, choose the best answer for each question.

Time and again, whenever a population [of Mexican tetra fish] was swept into a cave and survived long enough for natural selection to have its way, the eyes disappeared. "But it's not that everything has been lost in cavefish . . . Many enhancements have also happened." . . . Studies have found that cave-dwelling fish can detect lower levels of amino acids than surface fish can. They also have more tastebuds and a higher density of sensitive cells alongside their bodies that let them sense water pressure and flow. . . .

Killing the processes that support the formation of the eye is quite literally what happens. Just like non-cave-dwelling members of the species, all cavefish embryos start making eyes. But after a few hours, cells in the developing eye start dying, until the entire structure has disappeared. [Developmental biologist Misty] Riddle thinks this apparent inefficiency may be unavoidable. "The early development of the brain and the eye are completely intertwined—they happen together," she says. That means the least disruptive way for eyelessness to evolve may be to start making an eye and then get rid of it. . . .

It's easy to see why cavefish would be at a disadvantage if they were to maintain expensive tissues they aren't using. Since relatively little lives or grows in their caves, the fish are likely surviving on a meager diet of mostly bat feces and organic waste that washes in during the rainy season. Researchers keeping cavefish in labs have discovered that, genetically, the creatures are exquisitely adapted to absorbing and storing nutrients. . . .

Fats can be toxic for tissues, [evolutionary physiologist Nicolas] Rohner explains, so they are stored in fat cells. "But when these cells get too big, they can burst, which is why we often see chronic inflammation in humans and other animals that have stored a lot of fat in their tissues." Yet a 2020 study by Rohner, Krishnan and their colleagues revealed that even very well-fed cavefish had fewer signs of inflammation in their fat tissues than surface fish do. Even in their sparse cave conditions, wild cavefish can sometimes get very fat, says Riddle. This is presumably because, whenever food ends up in the cave, the fish eat as much of it as possible, since there may be nothing else for a long time to come. Intriguingly, Riddle says, their fat is usually bright yellow, because of high levels of carotenoids, the substance in the carrots that your grandmother used to tell you were good for your…eyes.

"The first thing that came to our mind, of course, was that they were accumulating these because they don't have eyes," says Riddle. In this species, such ideas can be tested: Scientists can cross surface fish (with eyes) and cavefish (without eyes) and look at what their offspring are like. When that's done, Riddle says, researchers see no link between eye presence or size and the accumulation of carotenoids. Some eyeless cavefish had fat that was practically white, indicating lower carotenoid levels. Instead, Riddle thinks these carotenoids may be another adaptation to suppress inflammation, which might be important in the wild, as cavefish are likely overeating whenever food arrives.

 CAT 2025 Slot 2 - VA RC

 All of the following statements from the passage describe adaptation in Mexican tetra cavefish EXCEPT:

 "Since relatively little lives or grows in their caves, the fish are likely surviving on a meager diet of mostly bat feces and organic waste that washes in during the rainy season."

 "It's easy to see why cavefish would be at a disadvantage if they were to maintain expensive tissues they aren't using."

 "Even in their sparse cave conditions, wild cavefish can sometimes get very fat, says Riddle."

 "'But when these cells get too big, they can burst, which is why we often see chronic inflammation in humans and other animals that have stored a lot of fat in their tissues.'"

**ANSWER:** Choice D

### Q8

"'But when these cells get too big, they can burst, which is why we often see chronic inflammation in humans and other animals that have stored a lot of fat in their tissues.'"

 CAT 2025 Slot 2 - VA RC

 Which one of the following best explains why the "apparent inefficiency" is "unavoidable"?

 Mexican tetra cavefish are similar to non-cave-dwelling variants in their early stages of development.

 The inefficiency resulting from eyelessness is compensated by enhancements like more tastebuds in Mexican tetra cavefish.

 The lack of light in the caves kills the eye cells in the developing Mexican tetra cavefish embryo.

 The caves have poor and inconsistent availability of food and nutrition for Mexican tetra cavefish.

**ANSWER:** Choice A

### Q9

Mexican tetra cavefish are similar to non-cave-dwelling variants in their early stages of development.

 CAT 2025 Slot 2 - VA RC

 Which one of the following results for the cross between surface fish (with eyes) and cavefish (without eyes) would invalidate Riddle's inference from the experiment?

 Only eyeless offspring had yellow fat.

 Some offspring with eyes had white fat.

 Some eyeless offspring had white fat.

 Some offspring with eyes had yellow fat.

**ANSWER:** Choice A

### Q10

Only eyeless offspring had yellow fat.

 CAT 2025 Slot 2 - VA RC

 On the basis of the information in the passage, what is the most likely function of carotenoids in Mexican tetra cavefish?

 To help the fat cells store nutrients.

 To render bright yellow colour to the cavefish.

 To control inflammation from the bursting of fat cells.

 To act as a substitute for eyes.

**ANSWER:** Choice C

### Q11

To control inflammation from the bursting of fat cells.

 CAT 2025 Slot 2 - VA RC

 The four sentences (labelled 1, 2, 3, and 4) given below, when properly sequenced, would yield a coherent paragraph. Decide on the proper sequencing of the order of the sentences and key in the sequence of the four numbers as your answer.

1. As books age, the cellulose and lignin in the paper begin to break down, releasing a mix of volatile organic compounds into the air.
2. Old books carry a scent that many people instantly recognize—and even love.
3. These compounds are benzaldehyde, which gives off an almond-like scent, vanillin, which smells like vanilla, ethyl hexanol (floral scent), toluene (sweet), and furfural (which has a slightly bready scent).
4. This familiar aroma isn't just dust or mildew; it's actually a result of slow chemical changes happening inside the paper and ink.

**ANSWER:** 2413

### Q12

CAT 2025 Slot 2 - VA RC

 The given sentence is missing in the paragraph below. Decide where it best fits among the options 1, 2, 3, or 4 indicated in the paragraph.

Sentence- The region's Western customers found it hard to believe that Dhaka muslin could possibly have been made by human hands – there were rumour that it was woven by mermaids, fairies and even ghosts.

Once upon the silty banks of the Meghna River, a miracle was spun — a fabric so light it was called "baft-hawa", or woven air. This was Dhaka Muslin — the world's most coveted cloth. ____(1)____. Handspun from a rare cotton called Phuti Karpas, found nowhere else on Earth, and woven with a 16-step sacred ritual — beginning with cleaning the cotton using the teeth of a river catfish! ____(2)____. Every spring, the maple-like leaves pushed up through the grey, silty soil to produce a single daffodil-yellow flower twice a year, which gave way to a snowy floret of cotton fibres. ____(3)____. Spun at dawn on boats by sharp-eyed young women, its threads were so fine the elderly could barely see them. Motifs of wildflowers, river breeze, and soul were etched into each piece — some so light, a 91-metre bolt could pass through a ring, or a 60' length fit inside a snuffbox. It draped Greek goddesses, Roman nobles, Mughal emperors, and European aristocrats. Marie Antoinette, Empress Joséphine — even Jane Austen adored its floating grace. ____(4)____.

 Option 3

 Option 4

 Option 1

 Option 2

**ANSWER:** Choice C

### Q13

Option 1

 CAT 2025 Slot 2 - VA RC

 The passage given below is followed by four summaries. Choose the option that best captures the essence of the passage.

For millennia, in the process of opening up land for agriculture, gardens, grazing and hunting, humans have created ecological "mosaics", or "patchworks": landscapes holding a mixture of habitats, like meadows, gardens and forests. These were not designed as nature reserves, but often catered to hugely diverse animal life. Research indicates that European hay meadows cultivated for animal feed were actually more successful at preserving a vast array of species than meadows explicitly cultivated for biodiversity. Studying the early Holocene, researchers have found that human presence was about as likely to increase biodiversity as reduce it. Of course, not all human-created landscapes have the same value. A paved subdivision with astroturfed lawns is very different to a village with diverse vegetable and flower gardens. But scientists continue to find evidence that the old idea of humans as antithetical to nature is also wrong-headed, and that rosy visions of thriving, human-free environments are more imaginary than real.

 In our attempts to shape the world around us to our needs, humans have often created landscapes like meadows, gardens, and forests, which support hugely diverse species, and are more successful at preserving them, than parks created specifically for this.

 In terms of preserving biodiversity, scientists are finding increasing evidence that human action is not always antithetical to nature, but often assists the preservation of meadows, landscapes, and flourishing of species.

 Studying the early Holocene and human practices over millennia, researchers say that while agricultural meadows, gardens, and forests were not explicitly designed as nature reserves, they actually preserved a vast array of species, belying the idea that humans harm nature.

 Contrary to the idea that humans always hurt nature and that it thrives in their absence, a lot of human action across history has been equally likely to increase biodiversity than reduce it, often creating varied ecological landscapes that support a vast array of species.

**ANSWER:** Choice D

### Q14

Contrary to the idea that humans always hurt nature and that it thrives in their absence, a lot of human action across history has been equally likely to increase biodiversity than reduce it, often creating varied ecological landscapes that support a vast array of species.

 CAT 2025 Slot 2 - VA RC

 The passage given below is followed by four summaries. Choose the option that best captures the essence of the passage.

In 1903, left-wing feminist Elizabeth Magie invented The Landlord's Game, the original version of what became Monopoly. It was designed as a powerful teaching tool to illustrate the dangers of monopolies and how wealth could concentrate in the hands of a few. The game featured a circular path, properties, and a "Go to Jail" space. Magie created two rule sets: one "monopolist" version where players crushed opponents through accumulation, and another, more radical "Prosperity" version, where everyone shared in the wealth, promoting fairness and equity. Years later, unemployed Charles Darrow sold a simplified version to Parker Brothers. They paid Magie only $500 for her patent—without royalties—and credited Darrow as the sole inventor. For decades, his tale of inventing the game in his basement remained the official story, while Magie's name and her original, anti-capitalist message were left in the shadows.

 Parker Brothers' capitalist intent led to them acquiring from Charles Darrow a simplified version of Elizabeth Magie's original game, transforming it into a widespread commercial success while providing her only minimal financial compensation and granting scant public recognition.

 Celebrated icons of the gaming industry, Charles Darrow and Parker Brothers, snatched the feminist icon Elizabeth Magie's original design and transformed Monopoly into a worldwide phenomenon, while barely acknowledging her.

 It is ironical that a left-wing feminist lost credit for the Landlord's Game to an unemployed man, who plagiarised and sold one version of the twin game to Parker Brothers for a meagre sum, denying her royalties.

 Only one version of Monopoly became famous because of Charles Darrow's relentless basement work, carefully refining Elizabeth Magie's original idea into an engaging and entertaining pastime that he successfully patented and sold, symbolizing what many regarded as the ultimate triumph of individual ingenuity.

**ANSWER:** Choice C

### Q15

It is ironical that a left-wing feminist lost credit for the Landlord's Game to an unemployed man, who plagiarised and sold one version of the twin game to Parker Brothers for a meagre sum, denying her royalties.

 CAT 2025 Slot 2 - VA RC

 Five jumbled sentences (labelled 1, 2, 3, 4, and 5), related to a topic, are given below. Four of them can be put together to form a coherent paragraph. Identify the odd sentence out and key in the number of that sentence as your answer.

1. Pfas are a class of about 15,000 compounds most frequently used to make products water-, stain- and grease-resistant.
2. New research suggests exposure to some common perfluoroalkyl and polyfluoroalkyl substances (Pfas) cause changes to gene activity and that these changes are linked to health problems including multiple cancers, neurological disorders and autoimmune disease.
3. These Pfas compounds are dubbed "forever chemicals" because they do not naturally break down in the environment.
4. The research may also point toward other diseases potentially caused by Pfas that have not yet been identified.
5. The findings are a major step toward determining the mechanism by which the chemicals cause disease and could help doctors identify, detect and treat health problems for those exposed to Pfas before the issues advance.

**ANSWER:** 3

### Q16

The passage below is accompanied by four questions. Based on the passage, choose the best answer for each question.

In [my book "Searches"], I chronicle how big technology companies have exploited human language for their gain. We let this happen, I argue, because we also benefit somewhat from using the products. It's a dynamic that makes us complicit in big tech's accumulation of wealth and power: we're both victims and beneficiaries. I describe this complicity, but I also enact it, through my own internet archives: my Google searches, my Amazon product reviews and, yes, my ChatGPT dialogues. . . .

People often describe chatbots' textual output as "bland" or "generic" – the linguistic equivalent of a beige office building. OpenAI's products are built to "sound like a colleague", as OpenAI puts it, using language that, coming from a person, would sound "polite", "empathetic", "kind", "rationally optimistic" and "engaging", among other qualities. OpenAI describes these strategies as helping its products seem "professional" and "approachable". This appears to be bound up with making us feel safe . . .

Trust is a challenge for artificial intelligence (AI) companies, partly because their products regularly produce falsehoods and reify sexist, racist, US-centric cultural norms. While the companies are working on these problems, they persist: OpenAI found that its latest systems generate errors at a higher rate than its previous system. In the book, I wrote about the inaccuracies and biases and also demonstrated them with the products. When I prompted Microsoft's Bing Image Creator to produce a picture of engineers and space explorers, it gave me an entirely male cast of characters; when my father asked ChatGPT to edit his writing, it transmuted his perfectly correct Indian English into American English. Those weren't flukes. Research suggests that both tendencies are widespread.

In my own ChatGPT dialogues, I wanted to enact how the product's veneer of collegial neutrality could lull us into absorbing false or biased responses without much critical engagement. Over time, ChatGPT seemed to be guiding me to write a more positive book about big tech – including editing my description of OpenAI's CEO, Sam Altman, to call him "a visionary and a pragmatist". I'm not aware of research on whether ChatGPT tends to favor big tech, OpenAI or Altman, and I can only guess why it seemed that way in our conversation. OpenAI explicitly states that its products shouldn't attempt to influence users' thinking. When I asked ChatGPT about some of the issues, it blamed biases in its training data – though I suspect my arguably leading questions played a role too. When I queried ChatGPT about its rhetoric, it responded: "The way I communicate is designed to foster trust and confidence in my responses, which can be both helpful and potentially misleading.". . .

OpenAI has its own goals, of course. Among them, it emphasizes wanting to build AI that "benefits all of humanity". But while the company is controlled by a non-profit with that mission, its funders still seek a return on their investment. That will presumably require getting people using products such as ChatGPT even more than they already are – a goal that is easier to accomplish if people see those products as trustworthy collaborators.

 CAT 2025 Slot 2 - VA RC

 All of the following statements from the passage affirm the disjunct between the claims about AI made by tech companies and what AI actually does EXCEPT:

 "In my own ChatGPT dialogues, I wanted to enact how the product's veneer of collegial neutrality could lull us into absorbing false or biased responses without much critical engagement."

 "When I prompted Microsoft's Bing Image Creator to produce a picture of engineers and space explorers, it gave me an entirely male cast of characters . . ."

 "It's a dynamic that makes us complicit in big tech's accumulation of wealth and power: we're both victims and beneficiaries."

 "I'm not aware of research on whether ChatGPT tends to favor big tech, OpenAI or Altman, and I can only guess why it seemed that way in our conversation."

**ANSWER:** Choice D

### Q17

"I'm not aware of research on whether ChatGPT tends to favor big tech, OpenAI or Altman, and I can only guess why it seemed that way in our conversation."

 CAT 2025 Slot 2 - VA RC

 The author compares AI-generated texts with "a beige office building" for all of the following reasons EXCEPT:

 AI-generated texts often exhibit a warm, polite, and collegial tone.

 AI aims to foster a feeling of trust and credibility among its users.

 AI generates generalised responses that lack specificity and nuance.

 AI tends to blame its training data when scrutinised for its biases.

**ANSWER:** Choice D

### Q18

AI tends to blame its training data when scrutinised for its biases.

 CAT 2025 Slot 2 - VA RC

 On the basis of the purpose of the examples in the passage, pick the odd one out from the following AI-generated responses mentioned in the passage:

 "Over time, ChatGPT seemed to be guiding me to write a more positive book about big tech – including editing my description of OpenAI's CEO, Sam Altman, to call him 'a visionary and a pragmatist'."

 ". . . when my father asked ChatGPT to edit his writing, it transmuted his perfectly correct Indian English into American English."

 "When I prompted Microsoft's Bing Image Creator to produce a picture of engineers and space explorers, it gave me an entirely male cast of characters . . ."

 "When I queried ChatGPT about its rhetoric, it responded: 'The way I communicate is designed to foster trust and confidence in my responses, which can be both helpful and potentially misleading'."

**ANSWER:** Choice D

### Q19

"When I queried ChatGPT about its rhetoric, it responded: 'The way I communicate is designed to foster trust and confidence in my responses, which can be both helpful and potentially misleading'."

 CAT 2025 Slot 2 - VA RC

 The author of the passage is least likely to agree with which one of the following claims?

 ChatGPT favours AI companies and their officials, like Sam Altman, in its responses.

 The neutrality of AI is motivated by economic considerations.

 When we use AI, we become accomplices to the exploitative practices of big tech companies.

 The neutrality of AI is conducive to critical thinking.

**ANSWER:** Choice D

### Q20

The neutrality of AI is conducive to critical thinking.

 The passage below is accompanied by four questions. Based on the passage, choose the best answer for each question.

Different sciences exhibit different science cultures and practices. For example, in astronomy, observation – until what is today called the new astronomy – had always been limited to what could be seen within the limits of optical light. Indeed, until early modernity the limits to optical light were also limits of what humans could themselves see within their limited and relative perceptual spectrum of human vision. With early modernity and the invention of lensed optical instruments – telescopes – astronomers could begin to observe phenomena never seen before. Magnification and resolution began to allow what was previously imperceptible to be perceived – but within the familiar limits of optical vision. Galileo, having learned of the Dutch invention of a telescope by Hans Lippershey, went on to build some hundred of his own, improving from the Dutch 3x to nearly 30x telescopes – which turn out to be the limit of magnificational power without chromatic distortion. And it was with his own telescopes that he made the observations launching early modern astronomy (phases of Venus, satellites of Jupiter, etc.). Isaac Newton's later improvement with reflecting telescopes expanded upon the magnificational-resolution capacity of optical observation; and, from Newton to the twentieth century, improvement continued on to the later very large array of light telescopes today – following the usual technological trajectory of "more-is-better" but still remaining within the limits of the light spectrum. Today's astronomy has now had the benefit of some four centuries of optical telescopy. The "new astronomy," however, opens the full known electromagnetic spectrum to observation, beginning with the accidental discovery of radio astronomy early in the twentieth century, and leading today to the diverse variety of EMS telescopes which can explore the range from gamma to radio waves. Thus, astronomy, now outfitted with new instruments, "smart" adaptive optics, very large arrays, etc., illustrates one style of instrumentally embodied science – a technoscience. Of course astronomy, with the very recent exceptions of probes to solar system bodies (Moon, Mars, Venus, asteroids), remains largely a "receptive" science, dependent upon instrumentation which can detect and receive emissions.

Contemporary biology displays a quite different instrument array and, according to Evelyn Fox-Keller, also a different scientific culture. She cites her own experience, coming from mathematical physics into microbiology, and takes account of the distinctive instrumental culture in her Making Sense of Life (2002). Here, particularly with the development of biotechnology, instrumentation is far more interventional than in the astronomy case. Microscopic instrumentation can be and often is interventional in style: "gene-splicing" and other techniques of biotechnology, while still in their infancy, are clearly part of the interventional trajectory of biological instrumentation. Yet, in both disciplines, the sciences involved are today highly instrumentalized and could not progress successfully without constant improvements upon the respective instrumental trajectories. So, minimalistically, one may conclude that the sciences are technologically, instrumentally embodied. But the styles of embodiment differ, and perhaps the last of the scientific disciplines to move into such technical embodiment is mathematics, which only contemporarily has come to rely more and more upon the computational machinery now in common use.

 CAT 2025 Slot 2 - VA RC

 None of the following statements, if true, contradicts the arguments in the passage EXCEPT:

 Isaac Newton's discovery of gravity was accomplished without the help of instruments.

 because of the relatively recent entry of computational machinery in mathematics, the field is only now beginning to develop a scientific culture.

 like telescopy, microscopy has also sought to move beyond the visible spectrum to be able to detect objects that are invisible in that spectrum.

 some scientific instruments may be classified as both receptive and interventional in their functions.

**ANSWER:** Choice B

### Q21

because of the relatively recent entry of computational machinery in mathematics, the field is only now beginning to develop a scientific culture.

 CAT 2025 Slot 2 - VA RC

 All of the following statements may be rejected as valid inferences from the passage EXCEPT:

 Isaac Newton's experiments with reflecting telescopes were the earliest versions of the "new astronomy" referred to in the passage.

 interventionist instruments, or instruments that intervene directly in scientific inquiry, are different from embodied instruments, or instruments that embody scientific inquiry.

 the author distinguishes between the receptive and interventionist uses of instruments in the sciences by comparing astronomy and biology, respectively.

 the advances in telescopy made by Newton with reflecting telescopes allowed early modern astronomers to observe the phases of Venus and the satellites of Jupiter.

**ANSWER:** Choice C

### Q22

the author distinguishes between the receptive and interventionist uses of instruments in the sciences by comparing astronomy and biology, respectively.

 CAT 2025 Slot 2 - VA RC

 Which one of the following observations is a valid conclusion to draw from the statement that "the sciences involved are today highly instrumentalised and could not progress successfully without constant improvements upon the respective instrumental trajectories"?

 The use of instruments in scientific trajectories must be respected in order to see successful progress in them.

 In both astronomy and microbiology, progress has been the consequence of improvements in the instruments they use.

 The growth of scientific technologies has led to the embodiment of progress in the trajectories of improvement.

 Highly instrumentalised work in the sciences has resulted in the progressive improvement of scientific constants.

**ANSWER:** Choice B

### Q23

In both astronomy and microbiology, progress has been the consequence of improvements in the instruments they use.

 CAT 2025 Slot 2 - VA RC

 To which one of the following instruments would the characterisations of instruments in the passage be least applicable?

 Milestone

 Scalpel

 Kitchen oven

 Saxophone

**ANSWER:** Choice A

### Q24

Milestone

 CAT 2025 Slot 2 - VA RC

 The four sentences (labelled 1, 2, 3, and 4) given below, when properly sequenced, would yield a coherent paragraph. Decide on the proper sequencing of the order of the sentences and key in the sequence of the four numbers as your answer.

1. 'Literature on screen' suggests something more capacious and defining than citation: the possibility that literary adaptations are at once cinema and literature.
2. Even though a growing number of films eligible for Academy Awards for Best Screenplay Based on Material from Another Medium borrow that material from print journalism, franchise characters, television series, comic books, video games and toys, academic studies of adaptation remain stubbornly attached to literature as cinema's natural progenitor.
3. It is as if adaptation studies, by borrowing the cultural cachet of literature, sought to claim its institutional respectability and gravitas even while insuring adaptation's enduring aesthetic and methodological subordination to literature proper.
4. Beneath this contradictory notion of film adaptations as not merely hybrid texts but texts holding dual citizenship in two modes of presentation is an even more pervasive legacy that haunts adaptation studies: the assumption that the primary context within which adaptations are to be studied is literature.

**ANSWER:** 1423

---

## DILR

- Source file: `2iim-html/CAT-2025-Question-Paper-Slot-2-DILR.txt`
- Page: https://online.2iim.com/CAT-question-paper/CAT-2025-Question-Paper-Slot-2-DILR/
- On-page answers found: 22
- Answer source: 2IIM on-page **Correct Answer** / **Correct Answer Choice** (not invented)

### Q1

The two most populous cities and the non-urban region (NUR) of each of three states, Whimshire, Fogglia, and Humbleset, are assigned Pollution Measures (PMs). These nine PMs are all distinct multiples of 10, ranging from 10 to 90. The six cities in increasing order of their PMs are: Blusterburg, Noodleton, Splutterville, Quackford, Mumpypore, Zingaloo.

The Pollution Index (PI) of a state is a weighted average of the PMs of its NUR and cities, with a weight of 50% for the NUR, and 25% each for its two cities.

There is only one pair of an NUR and a city (considering all cities and all NURs) where the PM of the NUR is greater than that of the city. That NUR and the city both belong to Humbleset.

The PIs of all three states are distinct integers , with Humbleset and Fogglia having the highest and the lowest PI respectively.

 CAT 2025 Slot 2 - DI LR

 What is the PI of Whimshire?

**ANSWER:** 45

### Q2

CAT 2025 Slot 2 - DI LR

 What is the PI of Fogglia?

**ANSWER:** 35

### Q3

CAT 2025 Slot 2 - DI LR

 What is the PI of Humbleset?

**ANSWER:** 50

### Q4

CAT 2025 Slot 2 - DI LR

 Which pair of cities definitely belong to the same state?

 Blusterburg, Mumpypore

 Splutterville, Quackford

 Mumpypore, Zingaloo

 Noodleton, Quackford

**ANSWER:** Choice D

### Q5

Noodleton, Quackford

 CAT 2025 Slot 2 - DI LR

 For how many of the cities and NURs is it possible to identify their PM and the state they belong to?

**ANSWER:** 9

### Q6

There are six spherical balls, B1, B2, B3, B4, B5, and B6, and four circular hoops H1, H2, H3, and H4.

Each ball was tested on each hoop once, by attempting to pass the ball through the hoop. If the diameter of a ball is not larger than the diameter of the hoop, the ball passes through the hoop and makes a "ping". Any ball having a diameter larger than that of the hoop gets stuck on that hoop and does not make a ping.

The following additional information is known:
1. B1 and B6 each made a ping on H4, but B5 did not.
2. B4 made a ping on H3, but B1 did not.
3. All balls, except B3, made pings on H1.
4. None of the balls, except B2, made a ping on H2.

 CAT 2025 Slot 2 - DI LR

 What was the total number of pings made by B1, B2, and B3?

**ANSWER:** 6

### Q7

CAT 2025 Slot 2 - DI LR

 Which of the following statements about the relative sizes of the balls is NOT NECESSARILY true?

 B4 B1 B1 B2

**ANSWER:** Choice B

### Q8

B1

 CAT 2025 Slot 2 - DI LR

 Which of the following statements about the relative sizes of the hoops is true?

 H2 H1 H2 H1

**ANSWER:** Choice C

### Q9

H2

 CAT 2025 Slot 2 - DI LR

 What BEST can be said about the total number of pings from all the tests undertaken?

 13 or 14

 12 or 13

 At least 9

 12 or 13 or 14

**ANSWER:** Choice B

### Q10

12 or 13

 Ananya Raga, Bhaskar Tala, Charu Veena, and Devendra Sur are four musicians. Each of them started and completed their training as students under each of three Gurus — Pandit Meghnath, Ustad Samiran, and Acharya Raghunath between 2013 and 2024, including both the years. Each Guru trains any student for consecutive years only, for a span of 2, 3, or 4 years, with each Guru having a different span. During some of these years, a student may not have trained under these Gurus; however, they never trained under multiple Gurus in the same year.
In none of these years, any of these Gurus trained more than two of these students at the same time. When two students train under the same Guru at the same time, they are referred to as Gurubhai, irrespective of their gender.
The following additional facts are known.
1. Ustad Samiran never trained more than one of these students in the same year.
2. Acharya Raghunath did not train any of these students during 2015-2018, as well as during 2021-24.
3. Ananya and Devendra were never Gurubhai; neither were Bhaskar and Charu. All other pairs of musicians were Gurubhai for exactly 2 years.
4. In 2013, Ananya and Bhaskar started their trainings under Pandit Meghnath and under Ustad Samiran, respectively.

 CAT 2025 Slot 2 - DI LR

 In which of the following years were Ananya and Bhaskar Gurubhai?

 2018

 2014

 2021

 2020

**ANSWER:** Choice D

### Q11

2020

 CAT 2025 Slot 2 - DI LR

 In which year did Charu begin her training under Pandit Meghnath?

 2021

 2015

 2017

 2016

**ANSWER:** Choice B

### Q12

2015

 CAT 2025 Slot 2 - DI LR

 In which of the following years were Bhaskar and Devendra Gurubhai?

 2022

 2015

 2018

 2020

**ANSWER:** Choice A

### Q13

2022

 CAT 2025 Slot 2 - DI LR

 Which of the following statements is TRUE?

 Ananya was training under Ustad Samiran in 2015.

 Ananya was training under Ustad Samiran in 2018.

 Charu was training under Ustad Samiran in 2019.

 Charu was training under Ustad Samiran in 2018.

**ANSWER:** Choice C

### Q14

Charu was training under Ustad Samiran in 2019.

 CAT 2025 Slot 2 - DI LR

 In how many of the years between 2013-24, were only two of these four musicians training under these three Gurus?

**ANSWER:** 4

### Q15

The Sustainability Index (SI) of a country at a point in time is an integer between 1 and 100. This question is related to SI of six countries – A, B, C, D, E, and F – at three different points in time – 2016, 2020, and 2024. The plot represents the exact changes in their SI, with X-coordinate representing % increase in 2020 from 2016, i.e., (SI in 2020 minus SI in 2016) / (SI in 2016), and Y-coordinate representing % increase in 2024 from 2020. At any point in time, the country with highest SI is ranked 1, while the country with the lowest SI is ranked 6. The following additional facts are known.
1. In 2016, B, C, E, and A had ranks 1, 2, 3, and 4 respectively.
2. F had lower SI than any other country in 2016, 2020, and 2024.
3. In 2024, E was the only country with SI of 90.
4. The range of SI of the six countries was 60 in 2016 as well as in 2024.

 CAT 2025 Slot 2 - DI LR

 What was the SI of E in 2016?

**ANSWER:** 60

### Q16

CAT 2025 Slot 2 - DI LR

 What was the SI of F in 2020?

**ANSWER:** 40

### Q17

CAT 2025 Slot 2 - DI LR

 What was the SI of C in 2024?

**ANSWER:** 84

### Q18

CAT 2025 Slot 2 - DI LR

 What was the SI of B in 2024?

 54

 60

 80

 45

**ANSWER:** Choice D

### Q19

45

 The following charts depict details of research papers written by four authors, Arman, Brajen, Chintan, and Devon. The papers were of four types, single-author, two-author, three-author, and four-author, that is, written by one, two, three, or all four of these authors, respectively. No other authors were involved in writing these papers.

The following additional facts are known.
1. Each of the authors wrote at least one of each of the four types of papers.
2. The four authors wrote different numbers of single-author papers.
3. Both Chintan and Devon wrote more three-author papers than Brajen.
4. The number of single-author and two-author papers written by Brajen were the same.

 CAT 2025 Slot 2 - DI LR

 What was the total number of two-author and three-author papers written by Brajen?

**ANSWER:** 4

### Q20

CAT 2025 Slot 2 - DI LR

 Which of the following statements is/are NECESSARILY true?
i. Chintan wrote exactly three two-author papers.
ii. Chintan wrote more single-author papers than Devon.

 Neither i nor ii

 Only ii

 Both i and ii

 Only i

**ANSWER:** Choice A

### Q21

Neither i nor ii

 CAT 2025 Slot 2 - DI LR

 Which of the following statements is/are NECESSARILY true?
i. Arman wrote three-author papers only with Chintan and Devon.
ii. Brajen wrote three-author papers only with Chintan and Devon.

 Neither i or ii

 Only ii

 Only i

 Both i and ii

**ANSWER:** Choice D

### Q22

Both i and ii

 CAT 2025 Slot 2 - DI LR

 If Devon wrote more than one two-author papers, then how many two-author papers did Chintan write?

**ANSWER:** 3

---

## Quantitative Ability

- Source file: `2iim-html/CAT-2025-Question-Paper-Slot-2-Quant.txt`
- Page: https://online.2iim.com/CAT-question-paper/CAT-2025-Question-Paper-Slot-2-Quant/
- On-page answers found: 22
- Answer source: 2IIM on-page **Correct Answer** / **Correct Answer Choice** (not invented)

### Q1

CAT Question
 Paper / CAT-2025-Slot 2-Quants

 C AT 2025 Quant, unlike previous years was not dominated by
 Arithmetic. Though Arithematic was the most tested topic followed by Algebra. In Arithmetic, the
 questions were dominated by topics like Speed-time-distance , Mixture and Alligations . This year,
 there was a surprise. The questions from Geometry were relatively on the lower
 side as compared to the previous years. There were 8 TITA Qs this year. Overall this section was
 at a medium level of difficulty.

 CAT 2025 Slot 2 - QA

 If \( m \) and \( n \) are integers such that \( ( m + 2 n ) ( 2 m + n ) = 27 \), then the maximum
possible value of \( 2 m - 3 n \) is

**ANSWER:** 17

### Q2

CAT 2025 Slot 2 - QA

 If \( \log _ { 64 } x ^ { 2 } + \log _ { 8 } \sqrt { y } + 3 \log _ { 512 } ( \sqrt { y } z ) = 4 \), where \( x , y \) and \( z \) are positive real
numbers, then the minimum possible value of \( ( x + y + z ) \) is

 \( 96 \)

 \( 48 \)

 \( 36 \)

 \( 24 \)

**ANSWER:** Choice B

### Q3

\( 48 \)

 CAT 2025 Slot 2 - QA

 The average number of copies of a book sold per day by a shopkeeper is 60 in the initial seven days and 63 in the initial eight days, after the book launch. On the ninth day, she sells 11 copies less than the eighth day, and the average number of copies sold per day from second day to ninth day becomes 66. The number of copies sold on the first day of the book launch is

**ANSWER:** 49

### Q4

CAT 2025 Slot 2 - QA

 Let \( f ( x ) = \frac { x } { ( 2 x - 1 ) } \) and \( g ( x ) = \frac { x } { ( x - 1 ) } \). Then, the domain of the function
\( h ( x ) = f ( g ( x ) ) + g ( f ( x ) ) \) is all real numbers except

 \( - 1 , \frac { 1 } { 2 } \), and 1

 \( \frac { 1 } { 2 } , 1 \), and \( \frac { 3 } { 2 } \)

 \( - \frac { 1 } { 2 } , \frac { 1 } { 2 } \), and 1

 \( \frac { 1 } { 2 } \), and 1

**ANSWER:** Choice A

### Q5

\( - 1 , \frac { 1 } { 2 } \), and 1

 CAT 2025 Slot 2 - QA

 If \( 9 ^ { x ^ { 2 } + 2 x - 3 } - 4 \left( 3 ^ { x ^ { 2 } + 2 x - 2 } \right) + 27 = 0 \), then the product of all possible
values of \( x \) is

 \( 5 \)

 \( 20 \)

 \( 30 \)

 \( 15 \)

**ANSWER:** Choice B

### Q6

\( 20 \)

 CAT 2025 Slot 2 - QA

 Let ABCDEF be a regular hexagon and P and Q be the midpoints of AB and CD, respectively. Then, the ratio of the areas of trapezium PBCQ and hexagon ABCDEF is

 5 : 24

 7 : 24

 6 : 25

 6 : 19

**ANSWER:** Choice A

### Q7

5 : 24

 CAT 2025 Slot 2 - QA

 If \( a , b , c \) and \( d \) are integers such that their sum is 46 , then the minimum
possible value of \( ( a - b ) ^ { 2 } + ( a - c ) ^ { 2 } + ( a - d ) ^ { 2 } \) is

**ANSWER:** 2

### Q8

CAT 2025 Slot 2 - QA

 Let \( a _ { n } \) be the \( n ^ { \text {th } } \) term of a decreasing infinite geometric progression.
If \( a _ { 1 } + a _ { 2 } + a _ { 3 } = 52 \) and \( a _ { 1 } a _ { 2 } + a _ { 2 } a _ { 3 } + a _ { 3 } a _ { 1 } = 624 \), then the sum of
this geometric progression is

 \( 63 \)

 \( 60 \)

 \( 54 \)

 \( 57 \)

**ANSWER:** Choice C

### Q9

\( 54 \)

 CAT 2025 Slot 2 - QA

 Suppose \( a , b , c \) are three distinct natural numbers, such that \( 3 a c = 8 ( a + b ) \). Then, the smallest possible
value of \( 3 a + 2 b + c \) is

**ANSWER:** 12

### Q10

CAT 2025 Slot 2 - QA

 Two tangents drawn from a point \( P \) touch a circle with center \( O \) at points
\( Q \) and \( R \). Points \( A \) and \( B \) lie on \( P Q \) and \( P R \), respectively, such that \( A B \) is also
a tangent to the same circle. If \( \angle A O B = 50 ^ { \circ } \), then \( \angle A P B \), in degrees, equals

**ANSWER:** 80

### Q11

CAT 2025 Slot 2 - QA

 The number of divisors of \( \left( 2 ^ { 6 } \times 3 ^ { 5 } \times 5 ^ { 3 } \times 7 ^ { 2 } \right) \), which are of the form \( ( 3 r + 1 ) \), where \( r \) is a
non-negative integer, is

 \( 42 \)

 \( 36 \)

 \( 56 \)

 \( 24 \)

**ANSWER:** Choice A

### Q12

\( 42 \)

 CAT 2025 Slot 2 - QA

 Ankita is twice as efficient as Bipin, while Bipin is twice as efficient as Chandan. All three of them start together on a job, and Bipin leaves the job after 20 days. If the job got completed in 60 days, the number of days needed by Chandan to complete the job alone, is

**ANSWER:** 340

### Q13

CAT 2025 Slot 2 - QA

 The ratio of expenditures of Lakshmi and Meenakshi is 2 : 3, and the ratio of income of Lakshmi to expenditure of Meenakshi is 6 : 7. If excess of income over expenditure is saved by Lakshmi and Meenakshi, and the ratio of their savings is 4 : 9, then the ratio of their incomes is

 5 : 6

 3 : 5

 7 : 8

 2 : 1

**ANSWER:** Choice B

### Q14

3 : 5

 CAT 2025 Slot 2 - QA

 The set of all real values of \( x \) for which \( \left( x ^ { 2 } - | x + 9 | + x \right) > 0 \), is

 \( ( - \infty , - 9 ) \cup ( 9 , \infty ) \)

 \( ( - \infty , - 3 ) \cup ( 3 , \infty ) \)

 \( ( - 9 , - 3 ) \cup ( 3 , \infty ) \)

 \( ( - \infty , - 9 ) \cup ( 3 , \infty ) \)

**ANSWER:** Choice B

### Q15

\( ( - \infty , - 3 ) \cup ( 3 , \infty ) \)

 CAT 2025 Slot 2 - QA

 An item with a cost price of Rs. 1650 is sold at a certain discount on a fixed marked price to earn a profit of 20% on the cost price. If the discount was doubled, the profit would have been Rs. 110. The rate of discount, in percentage, at which the profit percentage would be equal to the rate of discount, is nearest to

 12

 14

 16

 18

**ANSWER:** Choice B

### Q16

14

 CAT 2025 Slot 2 - QA

 The equations \( 3 x ^ { 2 } - 5 x + p = 0 \) and \( 2 x ^ { 2 } - 2 x + q = 0 \) have one common
root. The sum of the other roots of these two equations is

 \( \frac { 2 } { 3 } - p + \frac { 3 } { 2 } q \)

 \( \frac { 8 } { 3 } + p + \frac { 1 } { 3 } q \)

 \( \frac { 2 } { 3 } - 2 p + \frac { 2 } { 3 } q \)

 \( \frac { 8 } { 3 } - p + \frac { 3 } { 2 } q \)

**ANSWER:** Choice D

### Q17

\( \frac { 8 } { 3 } - p + \frac { 3 } { 2 } q \)

 CAT 2025 Slot 2 - QA

 A mixture of coffee and cocoa, 16% of which is coffee, costs Rs 240 per kg. Another mixture of coffee and cocoa, of which 36% is coffee, costs Rs 320 per kg. If a new mixture of coffee and cocoa costs Rs 376 per kg, then the quantity, in kg, of coffee in 10 kg of this new mixture is

 4

 6

 2.5

 5

**ANSWER:** Choice D

### Q18

5

 CAT 2025 Slot 2 - QA

 A loan of Rs 1000 is fully repaid by two installments of Rs 530 and Rs 594, paid at the end of first and second year, respectively. If the interest is compounded annually, then the rate of interest, in percentage, is

 8

 10

 11

 9

**ANSWER:** Choice A

### Q19

8

 CAT 2025 Slot 2 - QA

 Rita and Sneha can row a boat at 5 km/h and 6 km/h in still water, respectively. In a river flowing with a constant velocity, Sneha takes 48 minutes more to row 14 km upstream than to row the same distance downstream. If Rita starts from a certain location in the river, and returns downstream to the same location, taking a total of 100 minutes, then the total distance, in km, Rita will cover is

**ANSWER:** 8

### Q20

CAT 2025 Slot 2 - QA

 The sum of digits of the number \( ( 625 ) ^ { 65 } \times ( 128 ) ^ { 36 } \), is

**ANSWER:** 25

### Q21

CAT 2025 Slot 2 - QA

 In a \( \triangle A B C \), points D and E are on the sides BC and AC , respectively. BE and
AD intersect at point T such that \( \mathrm { AD } : A T = 4 : 3 \), and \( \mathrm { BE } : \mathrm { BT } = 5 : 4 \). Point
F lies on AC such that DF is parallel to BE . Then, \( \mathrm { BD } : \mathrm { CD } \) is

 \( 9 : 4 \)

 \( 15 : 4 \)

 \( 11 : 4 \)

 \( 7 : 4 \)

**ANSWER:** Choice C

### Q22

\( 11 : 4 \)

 CAT 2025 Slot 2 - QA

 A certain amount of money was divided among Pinu, Meena, Rinu and Seema. Pinu received 20% of the total amount and Meena received 40% of the remaining amount. If Seema received 20% less than Pinu, the ratio of the amounts received by Pinu and Rinu is

 8 : 5

 5 : 8

 2 : 1

 1 : 2

**ANSWER:** Choice B

---
