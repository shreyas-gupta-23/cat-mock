# Text-extractable answers: CAT-2020-Verbal-Slot3.pdf

- Source PDF: `2iim-pyq/CAT-2020-Verbal-Slot3.pdf`
- Explicit plain-text answer lines: **7**
- Only `Correct Answer:`, `Answer:`, and official TITA `Possible Answer:` fields.
- **Not included:** candidate `Chosen Option` (not necessarily correct); color-marked MCQ keys; answers only visible via PDF link/button.
- Do not invent missing MCQ keys.

1. **Correct Answer:** B
2. **Correct Answer:** DABC
3. **Correct Answer:** B
4. **Correct Answer:** CADB
5. **Correct Answer:** B
6. **Correct Answer:** BCDA
7. **Correct Answer:** C
