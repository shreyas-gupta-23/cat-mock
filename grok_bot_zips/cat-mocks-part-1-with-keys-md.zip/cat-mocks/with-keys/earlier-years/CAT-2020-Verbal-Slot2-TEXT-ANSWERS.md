# Text-extractable answers: CAT-2020-Verbal-Slot2.pdf

- Source PDF: `2iim-pyq/CAT-2020-Verbal-Slot2.pdf`
- Explicit plain-text answer lines: **6**
- Only `Correct Answer:`, `Answer:`, and official TITA `Possible Answer:` fields.
- **Not included:** candidate `Chosen Option` (not necessarily correct); color-marked MCQ keys; answers only visible via PDF link/button.
- Do not invent missing MCQ keys.

1. **Correct Answer:** BDAC
2. **Correct Answer:** ACDB
3. **Correct Answer:** C
4. **Correct Answer:** B
5. **Correct Answer:** D
6. **Correct Answer:** BADC
