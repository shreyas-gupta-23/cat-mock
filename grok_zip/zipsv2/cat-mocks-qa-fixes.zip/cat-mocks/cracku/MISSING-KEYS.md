# Cracku — live recovery status

All three compact key tables are now complete from Cracku review/solutions (no invented answers):

| Mock | Filled | Still blank |
| --- | ---: | ---: |
| Free Mock 1 | 68/68 | 0 |
| Free Mock 2 | 68/68 | 0 |
| Free Mock 3 | 68/68 | 0 |

## Recovery notes

- Mock 3 priority blanks recovered via Solutions → Show answer: Q2=D, Q4=A, Q6=A, Q8=C, Q12=D, Q16=B, Q21=4, Q33=C, Q60=D. The corresponding `Correct Answer:` lines were appended to `free-mock-3-answers.md`.
- Mock 1 VARC passages for Q1–4, Q5–8, Q9–12, and Q13–16 were captured from live review and merged into `free-mock-1.md`; see `PASSAGES-MISSING.md`.
- Mock 1 and Mock 2 previously blank rows were filled from live Solutions → Show answer and merged into their compact key tables.
