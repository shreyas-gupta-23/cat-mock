#!/usr/bin/env python3
"""Normalize Cracku free-mock answer dumps into compact *-key.md files.
Does not invent keys — only extracts explicitly stated answers.
"""
from __future__ import annotations

import re
from pathlib import Path

ROOT = Path("/workspace/cat-mocks/cracku")


def section_for_global(q: int) -> str:
    if 1 <= q <= 24:
        return "VARC"
    if 25 <= q <= 46:
        return "LRDI"
    if 47 <= q <= 68:
        return "Quant"
    raise ValueError(q)


def clean_cell(s: str) -> str:
    if s is None:
        return ""
    s = s.replace("\u00a0", " ").replace("\r", "")
    s = re.sub(r"\s+", " ", s).strip()
    # escape pipes for markdown tables
    return s.replace("|", "\\|")


def truncate(s: str, n: int = 120) -> str:
    s = clean_cell(s)
    if len(s) <= n:
        return s
    return s[: n - 1] + "…"


ANSWER_PATTERNS = [
    # explicit
    (r"Correct Answer:\s*([^\n]+)", "explicit"),
    (r"\*\*Answer key shown by Cracku:\*\*\s*(?!Not exposed)([ABCD]|[^\n]+)", "cracku_key"),
    # solution prose — MCQ
    (r"Hence,?\s+Option\s+([ABCD])\s+is\s+the\s+correct\s+(?:choice|answer|option)", "hence_option"),
    (r"Hence,?\s+Option\s+([ABCD])\s+is\s+the\s+best\s+(?:choice|answer|option)", "hence_best"),
    (r"Option\s+([ABCD])\s+is\s+the\s+correct\s+(?:choice|answer|option)", "option_correct"),
    (r"Option\s+([ABCD])\s+is\s+the\s+best\s+(?:choice|answer|option)", "option_best"),
    (r"Option\s+([ABCD])\s+is\s+the\s+right\s+answer", "option_right"),
    (r"option\s+([ABCD])\s+is\s+the\s+right\s+answer", "option_right_l"),
    (r"Thus,?\s+the\s+correct\s+answer\s+is\s+([ABCD])\b", "thus_letter"),
    (r"The\s+correct\s+answer\s+is\s+([ABCD])\b", "the_letter"),
    (r"The\s+correct\s+option\s+is\s+([ABCD])\b", "the_option"),
    (r"correct\s+option\s+is\s+([ABCD])\b", "correct_option"),
    (r"Option\s+\(([ABCD])\)\s+is\s+the\s+right", "paren_right"),
    (r"Only\s+Option\s+([ABCD])\s+(?:presents|satisfies|correctly|is)", "only_option"),
    (r"Option\s+([ABCD])\s+correctly\s+(?:reflects|presents|summarised|summarized|summarizes|describes)", "correctly"),
    (r"Option\s+([ABCD])\s+best\s+(?:captures|describes|aligns|presents)", "best_captures"),
    (r"Option\s+([ABCD])\s+aptly\s+captures", "aptly"),
    (r"Option\s+([ABCD])\s+accurately\s+(?:describes|summarizes|summarises|reflects)", "accurately"),
    (r"among\s+the\s+given\s+choices,?\s+(?:only\s+)?Option\s+([ABCD])", "among"),
    (r"Therefore,?\s+Option\s+([ABCD])\b", "therefore"),
    (r"Thus,?\s+Option\s+([ABCD])\s+is\s+true", "thus_true"),
    (r"Option\s+([ABCD])\s+is\s+true", "is_true"),
    (r"Thus,?\s+option\s+([ABCD])\s+is\s+the\s+right", "thus_right_l"),
    # TITA numeric / sequence after "correct answer is"
    (r"Thus,?\s+the\s+correct\s+answer\s+is\s+([0-9][0-9.,/%]*)", "thus_num"),
    (r"The\s+correct\s+answer\s+is\s+([0-9][0-9.,/%]*)", "the_num"),
    (r"Hence,?\s+the\s+correct\s+answer\s+is\s+([0-9][0-9.,/%]*)", "hence_num"),
    (r"correct\s+answer\s+is\s+([0-9][0-9.,/%]*)", "ca_num"),
    (r"Hence,?\s+option\s+([ABCD])\s+is\s+the\s+right\s+choice", "right_choice"),
    (r"Hence,?\s+([ABCD])\s+is\s+the\s+answer", "hence_letter_answer"),
    (r"Hence,?\s+([ABCD])\s+is\s+the\s+correct\s+answer", "hence_letter_ca"),
    (r"Hence,?\s+option\s+([ABCD])\s+is\s+correct", "option_is_correct"),
    (r"fits best in Blank\s*([1-4])", "blank_n"),
    (r"does not support[^\n\[\]]{0,200}\[Option\s+([ABCD])\]", "not_support_option"),
    (r"Hence the price of[^\n]{0,80}\bwill be\s+([0-9]+)", "hence_price"),
    (r"Hence,\s*AC\s*=\s*([0-9]+)", "hence_ac"),
    (r"Hence,\s+the\s+required\s+number\s*=\s*[^=\n]*=\s*([0-9]+)", "hence_req"),
    (r"minimum number of people who prefer horror\s*=\s*[^\n]*=\s*([0-9]+)\s*$", "min_horror"),
    (r"Thus,?\s+we can definitely find at least\s+([0-9]+)", "at_least"),
    (r"Option\s+([ABCD])\s+comes closest", "comes_closest"),
    (r"The answer is option\s+([ABCD])", "answer_is_option"),
    (r"Thus,?\s+Option\s+([ABCD])\s+is\s+correct", "thus_option_correct"),
    (r"(?:^|\n)([ABCD])\s+is\s+the\s+correct\s+answer", "letter_is_ca"),
    (r"([0-9]+)\s+is\s+the\s+right\s+answer", "num_right_answer"),
    (r"Clearly option\s+([ABCD])\b", "clearly_option"),
    (r"Hence only\s+([1-5])\s+can be inferred", "only_inferred"),
    (r"Option\s+([ABCD])\s+cannot be answered", "cannot_answered"),
    (r"(?m)^Option\s+([ABCD])\s*$", "trailing_option"),
    (r"(?m)^([ABCD])\s+is the correct answer\s*$", "letter_line_ca"),
    (r"(?:they will finish in|total time taken is)\s+([0-9]+)\s+hours", "hours"),
]


def extract_answer_from_text(body: str) -> tuple[str | None, str]:
    """Return (answer, source_tag). Prefer Correct Answer / Cracku key over prose."""
    # Priority 1: Cracku marked key (not "Not exposed")
    m = re.search(r"\*\*Answer key shown by Cracku:\*\*\s*(.+)", body)
    if m:
        val = m.group(1).strip()
        if val and not val.lower().startswith("not exposed"):
            return clean_answer(val), "cracku_key"

    # Priority 2: Correct Answer: lines (take first unique)
    corrects = re.findall(r"Correct Answer:\s*([^\n]+)", body)
    corrects = [clean_answer(c) for c in corrects if c.strip()]
    corrects = list(dict.fromkeys(corrects))
    if corrects:
        return corrects[0], "correct_answer_line"

    # Priority 3: solution prose — search Text Solution region preferentially
    sol = body
    if "Text Solution" in body:
        sol = body.split("Text Solution", 1)[1]
    for stop in ("Previous Question", "\nVARC\n", "\nLRDI\n", "\nQUANT\n", "\n### ", "\n## Result Question"):
        if stop in sol:
            sol = sol.split(stop)[0]

    # Prefer matches near the end of the solution (final conclusion)
    best = None
    best_pos = -1
    best_tag = ""
    for pat, tag in ANSWER_PATTERNS:
        if tag in ("explicit", "cracku_key"):
            continue
        for m in re.finditer(pat, sol, re.I):
            if m.start() >= best_pos:
                best_pos = m.start()
                raw = m.group(1)
                if tag == "blank_n":
                    best = "ABCD"[int(raw) - 1]
                else:
                    best = clean_answer(raw)
                best_tag = tag
    if best:
        return best, best_tag
    return None, ""


def clean_answer(val: str) -> str:
    val = val.replace("\u00a0", " ").strip()
    val = re.sub(r"\s+", " ", val)
    # strip trailing punctuation from prose captures
    val = val.rstrip(".,;:")
    # normalize Option letter alone
    if re.fullmatch(r"[ABCD]", val, re.I):
        return val.upper()
    m = re.fullmatch(r"Option\s+([ABCD])", val, re.I)
    if m:
        return m.group(1).upper()
    return val


def extract_choices_labeled(block: str) -> dict[str, str]:
    """Extract A-D choices from a review-style block; fill missing letter from unlabeled gap."""
    # Isolate question options region
    m = re.search(r"^Question\s+\d+\s*$", block, re.M)
    if m:
        block = block[m.end() :]
    for stop in (
        "\nSolution\n",
        "\nText Solution\n",
        "\nCorrect Answer:",
        "\nPrevious Question",
        "\n**Cracku review",
        "\n** The moving watermark",
        "\nDid you like this video",
    ):
        idx = block.find(stop)
        if idx != -1:
            block = block[:idx]

    lines = block.splitlines()
    # Drop chrome
    chrome = {"Skipped", "Report", "Show answer", "Correct", "Incorrect", "Bookmark"}
    # Find first standalone A/B/C/D — before that is stem
    start = 0
    for i, line in enumerate(lines):
        if line.strip() in ("A", "B", "C", "D") and line.strip() == line.strip():
            # ensure it's really a label line (whole line)
            if line.strip() in "ABCD":
                start = i
                break
    else:
        return {}

    # Walk from start producing ordered choice texts with optional labels
    ordered: list[tuple[str | None, str]] = []
    i = start
    pending_label: str | None = None
    buf: list[str] = []

    def flush():
        nonlocal pending_label, buf
        text = " ".join(x.strip() for x in buf if x.strip()).strip()
        if text:
            ordered.append((pending_label, text))
        pending_label = None
        buf = []

    while i < len(lines):
        s = lines[i].strip()
        if s in chrome:
            i += 1
            continue
        if s in ("A", "B", "C", "D") and lines[i].strip() == s:
            flush()
            pending_label = s
            i += 1
            continue
        if s == "":
            # blank: if we have buf content, end this choice
            if buf:
                flush()
            i += 1
            continue
        # skip leftover stem-ish if somehow
        buf.append(s)
        i += 1
    flush()

    # Assign labels: use provided labels; fill missing in ABCD order
    choices: dict[str, str] = {}
    expected = list("ABCD")
    ei = 0
    for label, text in ordered:
        if label:
            choices[label] = text
            if label in expected:
                ei = expected.index(label) + 1
        else:
            # assign next missing letter
            while ei < 4 and expected[ei] in choices:
                ei += 1
            if ei < 4:
                choices[expected[ei]] = text
                ei += 1
    return choices


def extract_choices_from_mock1_mcq(block: str) -> dict[str, str]:
    """Mock1 LRDI/Quant questions section: unlabeled 4 options after Question No. N."""
    m = re.search(r"Question No\.\s*\d+\s*\n+(.*)", block, re.S)
    if not m:
        return {}
    rest = m.group(1)
    # cut at next ## Question
    if "\n## Question" in rest:
        rest = rest.split("\n## Question")[0]
    # TITA has Backspace keypad
    if "Backspace" in rest:
        return {}
    # Split on 2+ blank lines into chunks; first chunk may be stem line(s)
    chunks = re.split(r"\n\s*\n\s*\n+", rest.strip())
    # Often: stem paragraph, then 4 option chunks each separated by blank lines
    # Simpler: after first line (stem), remaining non-empty paragraphs
    paras = [p.strip() for p in re.split(r"\n\s*\n", rest.strip()) if p.strip()]
    if not paras:
        return {}
    # First para is stem question text; next up to 4 are options
    opts = paras[1:5]
    if len(opts) < 2:
        return {}
    letters = "ABCD"
    return {letters[i]: opts[i].replace("\n", " ") for i in range(len(opts))}


def parse_types_mock1() -> dict[int, str]:
    text = (ROOT / "free-mock-1.md").read_text()
    types: dict[int, str] = {}
    # VARC unknown from paper — leave unset
    sections = [
        ("# Free CAT Mock 1 — LRDI Question Paper", "# Free CAT Mock 1 — LRDI Questions", 24),
        ("# Free CAT Mock 1 — Quant Question Paper", "# Free CAT Mock 1 — Quant Questions", 46),
    ]
    for start, end, offset in sections:
        i, j = text.find(start), text.find(end)
        if i < 0 or j < 0:
            continue
        chunk = text[i:j]
        for m in re.finditer(
            r"Q\.(\d+)\)\s*\n\n(.*?)\n\n\tQuestion Type : (MCQ|TITA)", chunk, re.S
        ):
            types[offset + int(m.group(1))] = m.group(3)
    return types


def parse_types_mock2() -> dict[int, str]:
    text = (ROOT / "free-mock-2.md").read_text()
    types: dict[int, str] = {}
    # VARC paper
    i = text.find("# Free CAT Mock 2 — VARC Question Paper")
    chunk = text[i : i + 80000] if i >= 0 else ""
    for m in re.finditer(
        r"Q\.(\d+)\)\s*\n\n(.*?)\n\n\tQuestion Type : (MCQ|TITA)", chunk, re.S
    ):
        types[int(m.group(1))] = m.group(3)
    return types


def infer_type(answer: str | None, choices: dict[str, str], declared: str | None) -> str:
    if declared:
        return declared
    if answer and re.fullmatch(r"[ABCD]", answer):
        return "MCQ"
    if choices:
        return "MCQ"
    if answer and not re.fullmatch(r"[ABCD]", answer):
        return "TITA"
    return ""


def parse_result_questions(path: Path) -> dict[int, str]:
    text = path.read_text()
    parts = re.split(r"^## Result Question (\d+)\s*$", text, flags=re.M)
    out: dict[int, str] = {}
    for i in range(1, len(parts), 2):
        n = int(parts[i])
        body = parts[i + 1]
        # if duplicate Result Question headers, later wins only if more content
        if n in out and len(body) < len(out[n]):
            continue
        out[n] = body
    return out


def parse_mock3_questions(path: Path) -> dict[int, str]:
    text = path.read_text()
    parts = re.split(
        r"^### (VARC|LRDI|Quant) Question (\d+) \(review item (\d+)\)\s*$",
        text,
        flags=re.M,
    )
    out: dict[int, str] = {}
    for i in range(1, len(parts), 4):
        rev = int(parts[i + 2])
        out[rev] = parts[i + 3]
    return out


def choices_from_mock1_question_file() -> dict[int, dict[str, str]]:
    text = (ROOT / "free-mock-1.md").read_text()
    out: dict[int, dict[str, str]] = {}
    # LRDI Questions and Options
    for label, start, end, offset in [
        (
            "LRDI",
            "# Free CAT Mock 1 — LRDI Questions and Options",
            "# Free CAT Mock 1 — Quant Question Paper",
            24,
        ),
        (
            "Quant",
            "# Free CAT Mock 1 — Quant Questions and Options",
            "--- VARC Questions",
            46,
        ),
    ]:
        i, j = text.find(start), text.find(end)
        if i < 0:
            continue
        if j < 0:
            j = len(text)
        chunk = text[i:j]
        qparts = re.split(r"^## Question (\d+)\s*$", chunk, flags=re.M)
        for k in range(1, len(qparts), 2):
            local = int(qparts[k])
            body = qparts[k + 1]
            ch = extract_choices_from_mock1_mcq(body)
            if ch:
                out[offset + local] = ch
    # VARC from Result Question blocks in free-mock-1.md or answers
    return out


def build_rows_from_result(
    bodies: dict[int, str],
    types: dict[int, str],
    extra_choices: dict[int, dict[str, str]] | None = None,
) -> list[dict]:
    extra_choices = extra_choices or {}
    rows = []
    for q in range(1, 69):
        body = bodies.get(q, "")
        answer, src = extract_answer_from_text(body) if body else (None, "")
        choices = extract_choices_labeled(body) if body else {}
        if len(choices) < 4 and q in extra_choices:
            # merge
            for k, v in extra_choices[q].items():
                choices.setdefault(k, v)
        typ = infer_type(answer, choices, types.get(q))
        # If MCQ with numeric/text answer matching a choice, map to letter
        if answer and choices and not re.fullmatch(r"[ABCD]", answer):
            mapped = None
            for let, txt in choices.items():
                if clean_cell(txt) == clean_cell(answer) or clean_cell(txt).startswith(clean_cell(answer)):
                    mapped = let
                    break
                # numeric equality
                if re.fullmatch(r"[0-9.]+", answer):
                    mnum = re.match(r"^([0-9.]+)", clean_cell(txt) or "")
                    if mnum and mnum.group(1) == answer:
                        mapped = let
                        break
            if mapped:
                answer = mapped
                typ = "MCQ"
        typ = infer_type(answer, choices, types.get(q)) if not typ else typ
        # blank choices for TITA
        if typ == "TITA":
            choices = {}
        rows.append(
            {
                "Section": section_for_global(q),
                "Q": q,
                "Type": typ,
                "Answer": answer or "",
                "ChoiceA": choices.get("A", ""),
                "ChoiceB": choices.get("B", ""),
                "ChoiceC": choices.get("C", ""),
                "ChoiceD": choices.get("D", ""),
                "_src": src,
            }
        )
    return rows


def write_key_md(path: Path, mock_n: int, rows: list[dict]) -> None:
    lines = [
        f"# Cracku Free CAT Mock {mock_n} — Compact Answer Key",
        "",
        "One row per question (global Q 1–68). Extracted from existing answer/question markdown only; no invented keys.",
        "Choice columns blank for TITA. Choice text truncated for readability where long.",
        "",
        "| Section | Q | Type | Answer | ChoiceA | ChoiceB | ChoiceC | ChoiceD |",
        "| --- | ---: | --- | --- | --- | --- | --- | --- |",
    ]
    for r in rows:
        lines.append(
            "| {Section} | {Q} | {Type} | {Answer} | {A} | {B} | {C} | {D} |".format(
                Section=r["Section"],
                Q=r["Q"],
                Type=r["Type"] or "",
                Answer=clean_cell(r["Answer"]),
                A=truncate(r["ChoiceA"]),
                B=truncate(r["ChoiceB"]),
                C=truncate(r["ChoiceC"]),
                D=truncate(r["ChoiceD"]),
            )
        )
    lines.append("")
    path.write_text("\n".join(lines))


def main():
    # ---- Mock 1 ----
    m1_bodies = parse_result_questions(ROOT / "free-mock-1-answers.md")
    # Also merge content-richer bodies from free-mock-1.md VARC dump if longer
    m1_qfile = (ROOT / "free-mock-1.md").read_text()
    if "--- VARC Questions" in m1_qfile:
        varc_part = m1_qfile.split("--- VARC Questions", 1)[1]
        for n, body in parse_result_questions_from_text(varc_part).items():
            if len(body) > len(m1_bodies.get(n, "")):
                m1_bodies[n] = body
    m1_types = parse_types_mock1()
    m1_extra = choices_from_mock1_question_file()
    m1_rows = build_rows_from_result(m1_bodies, m1_types, m1_extra)
    write_key_md(ROOT / "free-mock-1-key.md", 1, m1_rows)

    # ---- Mock 2 ----
    m2_bodies = parse_result_questions(ROOT / "free-mock-2-answers.md")
    # Merge longer bodies from free-mock-2.md embedded Result Questions
    m2_q = parse_result_questions(ROOT / "free-mock-2.md")
    for n, body in m2_q.items():
        if len(body) > len(m2_bodies.get(n, "")):
            m2_bodies[n] = body
    m2_types = parse_types_mock2()
    m2_rows = build_rows_from_result(m2_bodies, m2_types)
    write_key_md(ROOT / "free-mock-2-key.md", 2, m2_rows)

    # ---- Mock 3 ----
    m3_ans = parse_mock3_questions(ROOT / "free-mock-3-answers.md")
    m3_q = parse_mock3_questions(ROOT / "free-mock-3.md")
    m3_bodies: dict[int, str] = {}
    for q in range(1, 69):
        # Prefer answers file (has keys); merge question file for choices if needed
        a = m3_ans.get(q, "")
        qbody = m3_q.get(q, "")
        m3_bodies[q] = a if len(a) >= len(qbody) else (a + "\n" + qbody)
    m3_rows = build_rows_from_result(m3_bodies, {})
    write_key_md(ROOT / "free-mock-3-key.md", 3, m3_rows)

    # MISSING-KEYS.md for mock3 (and summarize all)
    missing3 = [r for r in m3_rows if not r["Answer"]]
    missing1 = [r for r in m1_rows if not r["Answer"]]
    missing2 = [r for r in m2_rows if not r["Answer"]]

    miss_lines = [
        "# Missing keys after parse",
        "",
        "Keys are listed only when no explicit Cracku marking, `Correct Answer:` line, or clear solution conclusion naming the option/value was found. Nothing below was invented.",
        "",
        "## Free Mock 3",
        "",
        f"Missing: **{len(missing3)}** / 68",
        "",
    ]
    if missing3:
        miss_lines += [
            "| Section | Q | Notes |",
            "| --- | ---: | --- |",
        ]
        for r in missing3:
            miss_lines.append(
                f"| {r['Section']} | {r['Q']} | Answer key marked “Not exposed”; no `Correct Answer:` / conclusive Option letter in text solution |"
            )
    else:
        miss_lines.append("None.")
    miss_lines += [
        "",
        "## Free Mock 1 (for agent awareness)",
        "",
        f"Missing: **{len(missing1)}** / 68 — many Result Question captures are Loading stubs or solutions without an explicit final key phrase.",
        "",
        "Global Q missing answers: "
        + ", ".join(str(r["Q"]) for r in missing1),
        "",
        "## Free Mock 2 (for agent awareness)",
        "",
        f"Missing: **{len(missing2)}** / 68",
        "",
        "Global Q missing answers: "
        + ", ".join(str(r["Q"]) for r in missing2),
        "",
    ]
    (ROOT / "MISSING-KEYS.md").write_text("\n".join(miss_lines))

    # Update free-mock-3-answers.md with KEY SUMMARY at top
    ans3 = (ROOT / "free-mock-3-answers.md").read_text()
    if "KEY SUMMARY" not in ans3[:800]:
        summary = (
            "# KEY SUMMARY\n\n"
            "Compact per-question keys (Section | Q | Type | Answer | ChoiceA–D) are in "
            "`free-mock-3-key.md`. Prefer that file for parsing.\n\n"
            f"- Questions with extracted keys: **{68 - len(missing3)}** / 68\n"
            f"- Still missing after parse (see `MISSING-KEYS.md`): **{len(missing3)}** — "
            + (", ".join(f"{r['Section']} Q{r['Q']}" for r in missing3) if missing3 else "none")
            + "\n"
            "- When the review said “Not exposed as a marked option” but a `Correct Answer:` "
            "line appeared in the solution, that value was used as the key.\n\n"
            "---\n\n"
        )
        (ROOT / "free-mock-3-answers.md").write_text(summary + ans3)

    # PASSAGES-MISSING for Mock 1 VARC
    passages_note = analyze_mock1_passages()
    (ROOT / "PASSAGES-MISSING.md").write_text(passages_note)

    # Stats
    def stats(rows):
        with_ans = sum(1 for r in rows if r["Answer"])
        with_ch = sum(1 for r in rows if r["ChoiceA"] or r["Type"] == "TITA")
        return with_ans, 68 - with_ans, with_ch

    s1, s2, s3 = stats(m1_rows), stats(m2_rows), stats(m3_rows)
    report = {
        "mock1": {"keys": s1[0], "missing": s1[1], "rows": m1_rows},
        "mock2": {"keys": s2[0], "missing": s2[1], "rows": m2_rows},
        "mock3": {"keys": s3[0], "missing": s3[1], "missing_list": missing3},
    }
    # print machine-readable summary
    print("MOCK1 keys", s1[0], "missing", s1[1])
    print("MOCK2 keys", s2[0], "missing", s2[1])
    print("MOCK3 keys", s3[0], "missing", s3[1], [r["Q"] for r in missing3])
    # sample answers
    for label, rows in [("M1", m1_rows), ("M2", m2_rows), ("M3", m3_rows)]:
        filled = [f"Q{r['Q']}={r['Answer']}" for r in rows if r["Answer"]]
        print(label, "sample", filled[:15], "...", filled[-5:])


def parse_result_questions_from_text(text: str) -> dict[int, str]:
    parts = re.split(r"^## Result Question (\d+)\s*$", text, flags=re.M)
    out: dict[int, str] = {}
    for i in range(1, len(parts), 2):
        out[int(parts[i])] = parts[i + 1]
    return out


def analyze_mock1_passages() -> str:
    q = (ROOT / "free-mock-1.md").read_text()
    ans = (ROOT / "free-mock-1-answers.md").read_text()
    # LRDI/Quant also use "Instructions [Question Number]"; only trust explicit VARC paper heading
    has_varc_paper = bool(re.search(r"VARC Question Paper", q))
    # Detect RC-like stems in answers
    bodies = parse_result_questions(ROOT / "free-mock-1-answers.md")
    rc_need = []
    va_ok = []
    loading = []
    for n in range(1, 25):
        body = bodies.get(n, "")
        if "Loading..." in body[:600] and f"Question {n}" not in body[:400]:
            loading.append(n)
            continue
        m = re.search(rf"Question {n}\s*\n(.*?)(?:\nSolution\n|\nText Solution|\nCorrect Answer:)", body, re.S)
        stem = (m.group(1) if m else body)[:500].lower()
        if any(
            p in stem
            for p in (
                "according to the passage",
                "based on the passage",
                "in the passage",
                "the author",
                "fourth paragraph of the passage",
                "information presented in the passage",
                "discussed in the passage",
            )
        ):
            rc_need.append(n)
        elif any(
            p in stem
            for p in (
                "four sentences",
                "five sentences",
                "sentence that is missing",
                "alternate summaries",
                "passage given below is followed by four alternate",
            )
        ):
            va_ok.append(n)
        else:
            # unknown / possibly RC
            if n <= 16:
                rc_need.append(n)
            else:
                va_ok.append(n)

    # Confirm no full passage blocks in answers (Instructions with long prose before Q)
    passage_blocks_in_answers = bool(
        re.search(r"Instructions \[Question Number.*?passage below", ans, re.I | re.S)
    )
    lines = [
        "# Mock 1 VARC passages — MISSING",
        "",
        "Checked: `free-mock-1.md`, `free-mock-1-answers.md`, and `pyq-public/` (unrelated CAT year PDFs).",
        "",
        "**Full VARC Reading Comprehension passages are not present** in the offline captures.",
        "`free-mock-1.md` header already notes passages were left on the live Cracku review page.",
        "Solution dumps discuss passages but do **not** reproduce the full passage text usable as question paper.",
        "Browser scraping from Cracku while logged in was **not** done here (per task: document gap and stop).",
        "",
        "## Status",
        "",
        f"- VARC Question Paper / passage Instructions in `free-mock-1.md`: **{'yes' if has_varc_paper else 'no'}**",
        f"- Passage Instruction blocks in `free-mock-1-answers.md`: **{'yes' if passage_blocks_in_answers else 'no'}**",
        f"- Passages merged into `free-mock-1.md`: **no** (source text unavailable offline)",
        "",
        "## Question numbers needing passages (RC stems / likely RC)",
        "",
        "Global VARC Q (1–24):",
        "",
        f"- **Loading stubs only (no stem/options/passage):** {', '.join(f'Q{n}' for n in loading) or 'none'}",
        f"- **RC-style items without passage text:** {', '.join(f'Q{n}' for n in rc_need) or 'none'}",
        f"- **VA / self-contained items (passage not required or embedded in stem):** {', '.join(f'Q{n}' for n in va_ok) or 'none'}",
        "",
        "## Exact list for re-scrape",
        "",
        "Re-capture from Cracku Free CAT Mock 1 review / Question Paper modal:",
        "",
    ]
    all_missing = sorted(set(loading + rc_need))
    lines.append(", ".join(f"VARC Q{n}" for n in all_missing))
    lines += [
        "",
        "Do not invent passage text.",
        "",
    ]
    return "\n".join(lines)


if __name__ == "__main__":
    main()
