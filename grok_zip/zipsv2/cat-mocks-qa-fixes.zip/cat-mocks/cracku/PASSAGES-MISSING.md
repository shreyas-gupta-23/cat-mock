# Mock 1 VARC passages — RECOVERED

Checked: `free-mock-1.md` and live Cracku review.

The four Reading Comprehension passages covering VARC Q1–4, Q5–8, Q9–12, and Q13–16 were captured from the live Solutions review and merged into `free-mock-1.md`. Passage text was not invented.

Self-contained VA questions Q18–24 do not require separate passage blocks.
