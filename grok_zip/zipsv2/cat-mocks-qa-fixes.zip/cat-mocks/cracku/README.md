# Cracku — Free CAT Mock 1–3 + public PYQ PDFs

**Source hub:** https://cracku.in/cat-mock-test  
**Keys status:** Free Mock 1–3 have post-submit review dumps; compact parseable keys are in `*-key.md` (offline extract; blanks mean not exposed in the dump).

## Naming pattern (canonical)

| File | Role |
| --- | --- |
| `free-mock-1.md` | Mock 1 questions/options (LRDI + Quant primary; VARC stems/options partial — **passages missing**, see `PASSAGES-MISSING.md`) |
| `free-mock-1-answers.md` | Mock 1 solutions / scorecard (long dump) |
| `free-mock-1-key.md` | **Compact key** — one row per Q (Section | Q | Type | Answer | ChoiceA–D) |
| `free-mock-2.md` | Mock 2 questions (VARC paper + options; some review blocks) |
| `free-mock-2-answers.md` | Mock 2 solutions / scorecard (long dump) |
| `free-mock-2-key.md` | **Compact key** (same columns) |
| `free-mock-3.md` | Mock 3 questions/options (68 entries) |
| `free-mock-3-answers.md` | Mock 3 solutions / scorecard; header **KEY SUMMARY** points to key file |
| `free-mock-3-key.md` | **Compact key** (same columns); uses `Correct Answer:` when mark was “Not exposed” |
| `MISSING-KEYS.md` | Global Q still blank after offline parse (browser merge list) |
| `PASSAGES-MISSING.md` | Mock 1 VARC RC passages not in offline files |
| `pyq-public/*.pdf` | Public solved PYQ downloads (no login) |
| `INVENTORY.md` | Detailed Cracku catalog (login gates, PDF IDs) |

Pattern: **`free-mock-N.md` + `free-mock-N-answers.md` + `free-mock-N-key.md`** (no zero-padding).

### Compact key format

Markdown table, exactly one data row per global question (aim 68):

`Section | Q | Type (MCQ/TITA) | Answer | ChoiceA | ChoiceB | ChoiceC | ChoiceD`

- **Q** is global 1–68 (VARC 1–24, LRDI 25–46, Quant 47–68).
- Choice columns blank for TITA; choice text truncated when long.
- Empty **Answer** = not found in offline dump (see `MISSING-KEYS.md`); do not invent.

Offline key counts (this folder, after parse): Mock1 **44/68**, Mock2 **45/68**, Mock3 **59/68**.

## pyq-public/

| Files | Notes |
| --- | --- |
| `CAT-2025-Slot{1,2,3}-{VARC,Quant}-solved.pdf` | 6 solved sectionals |
| `CAT-1999-Question-Paper.pdf`, `CAT-2001-Question-Paper.pdf` | Older papers with solutions |

Login-gated (not saved): CAT 2025 full slots, DILR sectionals, most older PYQ download IDs. See `INVENTORY.md`.

## Related docs

- Login field refs: `../docs/cracku-secure-form.md`
- Mock 3 session notes: `../docs/cracku-free-mock-3-status.md`

Paid DashCAT / Head Start: skipped.
