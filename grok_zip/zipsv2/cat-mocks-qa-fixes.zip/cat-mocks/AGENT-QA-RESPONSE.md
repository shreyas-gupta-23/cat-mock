# Response to exam-room QA (1 Oct 2026)

## Career Launcher — keys ARE present

The QA note describing blank scorecards / DST session-loss is **stale**. Those were intermediate capture notes from 30 Sep.

| File | Status |
| --- | --- |
| `career-launcher/free-mock-1-answers.md` | Official MyZone Solutions keys — 68Q (option # or TITA value) |
| `career-launcher/free-mock-2-answers.md` | Official MyZone Solutions keys — 68Q |
| `career-launcher/KEYS-CHECK.md` | Capture route and verification |

MCQ keys are **option numbers** (1–4), not A–D letters. TITA is the numeric value.

Still open: Free Mock 1 DILR Light Up 7×7 grid image (Q33–Q36) did not render in MyZone text Question Paper view.

## Cracku

Compact `*-key.md` files are being added (one row per question). Mock 3 “Not exposed as a marked option” rows usually still have `Correct Answer:` nearby — use that, or the compact key file.

## CAT paper gaps

Tracked separately: 2024 S2 Quant inequality choices; 2025 S2 DILR Q7–Q8 choices; 2020 odd-sentence five-sentence lists.
