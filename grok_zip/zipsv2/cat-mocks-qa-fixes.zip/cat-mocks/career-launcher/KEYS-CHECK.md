# Career Launcher keys check

- **Checked:** 1 Oct 2026 afternoon IST.
- **Route:** MyZone dashboard → Tests → Mock Tests → Mocks and Analysis → CAT Online Mocks.
- The Mocks table listed both attempts with **View Analysis** (not just Take Test):
  - **Free CAT Mock - 02** — Date of Test 23-JUN-2025; Analysis Date 23-JUN-2025.
  - **Free CAT Mock - 01** — Date of Test 23-JUN-2025; Analysis Date 23-JUN-2025.
- **Free CAT Mock - 01:** analysis opened; scorecard showed “Free CAT Mock - 01 : Percentile: 3.79 Overall score: 0.0”. Solutions opened successfully. Every question had **View Solution**; the solution modal showed **Correct Answer** plus explanation. Keys saved in `free-mock-1-answers.md`.
- **Free CAT Mock - 02:** analysis opened; scorecard showed “Free CAT Mock - 02 : Percentile: 2.95 Overall score: 0.0”. Solutions opened successfully. Every question had **View Solution**; the solution modal showed **Correct Answer** plus explanation. Keys saved in `free-mock-2-answers.md`.
- **Unlock/expiry text:** none was shown on the live Mocks, analysis, or Solutions pages. No text specifying an unlock delay or how long solutions remain available was found.
- **Question text:** the live Solutions view displayed full question/passage text and answer explanations. Existing mock files already contain the captured question stems/options; Mock 02’s live VARC solution view also showed fuller passage text than the compact existing capture.
- No new timed **Take Test** was started.
