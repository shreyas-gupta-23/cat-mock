# Career Launcher CAT Free Zone — inventory

Source: https://www.careerlauncher.com/cat-mba/freecatmock/  
Checked: 30 Sep 2026 (browser session).  
No test was started; no form was filled.

## Full-length mocks

All five cards were visible with a `Start Test` control. The page shows 120 minutes and 68 questions for each:

1. **Free CAT Mock Test 1** — 120 min; 68 questions — **Unlocked**
2. **Free CAT Mock Test 2** — 120 min; 68 questions — **Unlocked**
3. **CAT 2025 Actual Paper Slot 1** — 120 min; 68 questions — **Unlocked**
4. **CAT 2025 Actual Paper Slot 2** — 120 min; 68 questions — **Unlocked**
5. **CAT 2025 Actual Paper Slot 3** — 120 min; 68 questions — **Unlocked**

## Actual CAT papers (sectional PYQ cards)

The PYQ section exposes VARC, LRDI and QA links for every listed year/slot:

- **CAT 2025 — Slot 1:** VARC, LRDI, QA — **Unlocked**
- **CAT 2025 — Slot 2:** VARC, LRDI, QA — **Unlocked**
- **CAT 2025 — Slot 3:** VARC, LRDI, QA — **Unlocked**
- **CAT 2024 — Slot 1:** VARC, LRDI, QA — **Unlocked**
- **CAT 2024 — Slot 2:** VARC, LRDI, QA — **Unlocked**
- **CAT 2024 — Slot 3:** VARC, LRDI, QA — **Unlocked**

## Sectionals by section

- **VARC:** CAT 2025 Slot 1, Slot 2, Slot 3; CAT 2024 Slot 1, Slot 2, Slot 3 — **6 unlocked sectionals**
- **LRDI:** CAT 2025 Slot 1, Slot 2, Slot 3; CAT 2024 Slot 1, Slot 2, Slot 3 — **6 unlocked sectionals**
- **QA:** CAT 2025 Slot 1, Slot 2, Slot 3; CAT 2024 Slot 1, Slot 2, Slot 3 — **6 unlocked sectionals**

The landing page did not display duration or question count for these sectional cards.

## Topic tests — Basic tab

Every item below was visible as an unlocked test link:

- **Arithmetic:** Test 1, Test 2, Test 3
- **Number System:** Test 1, Test 2, Test 3
- **Algebra:** Test 1, Test 2, Test 3
- **Geometry:** Test 1, Test 2, Test 3
- **Modern Maths:** Test 1, Test 2, Test 3
- **Logical Reasoning:** Test 1, Test 2
- **Data Interpretation:** Test 1, Test 2, Test 3
- **Reading Comprehension:** Test 1, Test 2, Test 3
- **Grammar & Vocabulary:** Test 1, Test 2, Test 3
- **Para-Jumbles:** Test 1, Test 2, Test 3
- **Critical Reasoning:** Test 1, Test 2, Test 3
- **Para-Summary:** Test 1, Test 2, Test 3

**Basic subtotal: 35 tests**

## Topic tests — Advanced tab

- **Arithmetic:** Test 1, Test 2
- **Number System:** Test 1, Test 2
- **Algebra:** Test 1, Test 2
- **Geometry:** Test 1, Test 2
- **Modern Maths:** Test 1, Test 2
- **Logical Reasoning:** Test 1, Test 2
- **Data Interpretation:** Test 1, Test 2
- **Reading Comprehension:** Test 1, Test 2
- **Grammar & Vocabulary:** Test 1, Test 2
- **Para-Jumbles:** Test 1, Test 2
- **Critical Reasoning:** Test 1, Test 2
- **Para-Summary:** Test 1, Test 2

**Advanced subtotal: 24 tests**

## Topic tests — Expert tab

- **Arithmetic:** Test 1, Test 2
- **Number System:** Test 1, Test 2
- **Algebra:** Test 1, Test 2
- **Geometry:** Test 1, Test 2
- **Modern Maths:** Test 1, Test 2
- **Logical Reasoning:** Test 1, Test 2
- **Data Interpretation:** Test
- **Reading Comprehension:** Test
- **Grammar & Vocabulary:** Test 1, Test 2
- **Para-Jumbles:** Test 1, Test 2
- **Critical Reasoning:** Test 1, Test 2
- **Para-Summary:** Test 1, Test 2

**Expert subtotal: 22 tests**

## Locked / paid items shown

- **LOCKED — CAT Mentors Curated Test Series:** the page shows an “Unlock CAT Mentors Curated Test Series” CTA linking to the paid test-series page. It is not included in the unlocked counts above.
- **LOCKED / paid promotion — IIM Expert Curated Test Series:** the full-length section shows an “Explore IIM Expert Curated Test Series” CTA. It is not an unlocked free-card item and is not included above.

No individual free mock, actual-paper sectional, or topic-test card displayed a `Locked` label; each listed card had a Start Test or test-instructions link.

## Totals

- Full-length cards: **5 unlocked**
- Actual-paper sectional cards: **18 unlocked** (6 slots × 3 sections)
- Topic tests: **81 unlocked** (Basic 35 + Advanced 24 + Expert 22)
- **Total listed unlocked test entries: 104**
