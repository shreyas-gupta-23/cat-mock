# Career Launcher — CAT 2025 Actual Paper Slot 1

- Source: MyZone → Mock Tests → CAT Online Mocks → CAT 2025 Actual Paper Slot 1
- Captured from the live in-test **Question Paper** view (VARC; 24 questions).
- The live test was started and the section timer was running. Answers were left unattempted.

## VARC

### Q1
The four sentences (labelled 1, 2, 3, and 4) given below, when properly sequenced, would yield a coherent paragraph. Decide on the proper sequencing of the order of the sentences and key in the sequence of the four numbers as your answer.

1. But man, woman or otherwise, there is no denying that the quality of our life and character will be significantly shaped by the way we handle our anger.
2. Once the taboos have been broken, women usually experience letting their fists fly as intensely liberating.
3. Though this might seem a stereotype, women— unlike men, who are frequently applauded for unbridled aggression—are often socialized to keep a lid on their ire.
4. Many of them are so at odds with their aggressive feelings that, as a coach, I often have to stop them from pulling their punches and encourage them to extend their arms so their blows might actually reach their fleshy target.

### Q2
The given sentence is missing in the paragraph below. Decide where it best fits among the options 1, 2, 3, or 4 indicated in the paragraph.

Sentence: Historically, silver has been, and still is, an important element in the business of ‘show’ visible in private houses, churches, government and diplomacy.

Paragraph: ____(1) ____. Timothy Schroder put it succinctly in suggesting that electric light and eating in the kitchen eroded this need. As he explained to the author, ‘Silver, when illuminated by flickering candlelight, comes alive and almost dances before the eyes, but when lit by electric light it becomes flat and dead.’ ____(2) ____. Domestic and economic changes may have worked against the market, but the London silver trade remained buoyant, thanks to the competition of collectors seeking grand display silver at the top end, and the buyers of ‘collectables’, like spoons and wine labels and ‘novelties’, at the bottom. ____(3) ____. Another factor that came into play was the systematic collection building of certain American museums over the period. Boston, Huntington Art Gallery and Williamsburg, among others, were largely supplied by London dealers. ____(4) ____.

1) Option 2
2) Option 4
3) Option 1
4) Option 3

### Q3
The four sentences (labelled 1, 2, 3, and 4) given below, when properly sequenced, would yield a coherent paragraph. Decide on the proper sequencing of the order of the sentences and key in the sequence of the four numbers as your answer.

1. It can in fact be integrated into any function (education, medical treatment, production, punishment); it can increase the effect of this function, by being linked closely with it; it can constitute a mixed mechanism in which relations of power (and of knowledge) may be precisely adjusted, in the smallest detail, to the processes that are to be supervised; it can establish a direct proportion between ‘surplus power’ and ‘surplus production’.
2. It’s a case of ‘it’s easy once you’ve thought of it’ in the political sphere.
3. The panoptic mechanism is not simply a hinge, a point of exchange between a mechanism of power and a function; it is a way of making power relations function in a function, and of making a function function through these power relations.
4. In short, it arranges things in such a way that the exercise of power is not added on from the outside, like a rigid, heavy constraint, to the functions it invests, but is so subtly present in them as to increase their efficiency by itself increasing its own points of contact.

### Q4
Five jumbled sentences (labelled 1, 2, 3, 4, and 5), related to a topic, are given below. Four of them can be put together to form a coherent paragraph. Identify the odd sentence out and key in the number of that sentence as your answer.

1. Developments both technological and sociocultural have afforded us far greater freedom over death than we had in the past, and while we are still adapting ourselves to that freedom, we now appreciate the moral importance of this freedom.
2. But I believe that a type of freedom we can call freedom over death – that is, a freedom in which we shape the timing and circumstances of how we die – should be central to this conversation.
3. Legalising assisted dying is but a further step in realising this freedom over death.
4. Many people endorse, through their opinions or their choices, our freedom over death encompassing a right to medical assistance in hastening our deaths.
5. Freedom is a notoriously complex and contested philosophical notion, and I won’t pretend to settle any of the big controversies it raises.

### Directions for Q5–Q8
The passage below is accompanied by four questions. Based on the passage, choose the best answer for each question.

Understanding the key properties of complex systems can help us clarify and deal with many new and existing global challenges, from pandemics to poverty . . . A recent study in Nature Physics found transitions to orderly states such as schooling in fish (all fish swimming in the same direction), can be caused, paradoxically, by randomness, or ‘noise’ feeding back on itself. That is, a misalignment among the fish causes further misalignment, eventually inducing a transition to schooling. Most of us wouldn’t guess that noise can produce predictable behaviour. The result invites us to consider how technology such as contact-tracing apps, although informing us locally, might negatively impact our collective movement. If each of us changes our behaviour to avoid the infected, we might generate a collective pattern we had aimed to avoid: higher levels of interaction between the infected and susceptible, or high levels of interaction among the asymptomatic.

Complex systems also suffer from a special vulnerability to events that don’t follow a normal distribution or ‘bell curve’. When events are distributed normally, most outcomes are familiar and don’t seem particularly striking. Height is a good example: it’s pretty unusual for a man to be over 7 feet tall; most adults are between 5 and 6 feet, and there is no known person over 9 feet tall. But in collective settings where contagion shapes behaviour – a run on the banks, a scramble to buy toilet paper – the probability distributions for possible events are often heavy-tailed. There is a much higher probability of extreme events, such as a stock market crash or a massive surge in infections. These events are still unlikely, but they occur more frequently and are larger than would be expected under normal distributions.

What’s more, once a rare but hugely significant ‘tail’ event takes place, this raises the probability of further tail events. We might call them second-order tail events; they include stock market gyrations after a big fall and earthquake aftershocks. The initial probability of secondorder tail events is so tiny it’s almost impossible to calculate – but once a first-order tail event occurs, the rules change, and the probability of a second-order tail event increases.

The dynamics of tail events are complicated by the fact that they result from cascades of other unlikely events. When COVID-19 first struck, the stock market suffered stunning losses followed by an equally stunning recovery. Some of these dynamics are potentially attributable to former sports bettors, with no sports to bet on, entering the market as speculators rather than investors. The arrival of these new players might have increased inefficiencies and allowed savvy long-term investors to gain an edge over bettors with different goals. . . .

One reason a first-order tail event can induce further tail events is that it changes the perceived costs of our actions and changes the rules that we play by. This game-change is an example of another key complex systems concept: nonstationarity. A second, canonical example of nonstationarity is adaptation, as illustrated by the arms race involved in the coevolution of hosts and parasites [in which] each has to ‘run’ faster, just to keep up with the novel solutions the other one presents as they battle it out in evolutionary time.

### Q5
Which one of the options below best summarises the passage?
1) The passage explains how noise can create order, then shows why complex systems with contagion are vulnerable to heavy-tailed cascades. It also explains why early shocks change rules through nonstationarity with a market illustration during the COVID-19 disruption.
2) The passage explains how social outcomes generally follow normal distributions. So, extreme events are negligible, and policy should stabilise averages rather than learn from large shocks in fast-changing collective settings.
3) The passage explains how nonstationarity works in evolutionary biology and rejects applications in markets or public health because adaptation is exclusive to parasite-host systems and cannot arise in technology-mediated social dynamics.
4) The passage explains how speculative entrants always produce inefficiency after health shocks. Therefore, long-term investors invariably profit when new participants push prices away from fundamentals under pandemic conditions and comparable crises.

### Q6
The passage suggests that contact tracing apps could inadvertently raise risky interactions by altering local behaviour. Which one of the assumptions below is most necessary for that suggestion to hold?
1) Most users uninstall apps within a week, which leaves only highly exposed individuals participating. This neutralises any systematic bias in routing decisions and prevents any predictable change in aggregate contact patterns.
2) Urban networks have uniform traffic conditions at all hours, which allows perfectly predictable routing independent of personal choices, social signals, or crowd reactions and, therefore, makes interdependence negligible in city movement decisions.
3) App alerts always include precise location to within one metre and deliver real time updates for all users, which ensures that the data feed is perfectly accurate regardless of privacy settings, power limits, or network conditions.
4) Individuals base movement choices partly on observed infections and on the behaviour of others. So, local responses interact, which turns many small adjustments into large scale patterns that can frustrate the intended aim of risk reduction.

### Q7
All of the following inferences are supported by the passage EXCEPT that:
1) heavy-tailed events make extreme outcomes more frequent and larger than bell curve expectations. This complicates forecasting and risk management in collective settings shaped by contagion and copying behaviour.
2) the text attributes the COVID-19 pandemic rebound in financial markets solely to displaced sports bettors and treats their entry as the overriding cause of the rapid recovery across assets and time horizons.
3) examples like runs on banks and toilet paper scrambles illustrate how contagion can amplify local choices into system-wide cascades that surprise participants and lead to patterns they did not intend to create.
4) learning can change the rules that actors face. So, a rare shock can alter payoffs and raise the odds of subsequent large disturbances within the same system, which supports the idea of second-order tail events.

### Q8
Which one of the following observations would most strengthen the passage’s claim that a first-order tail event raises the probability of further tail events in complex systems?
1) River discharge records show water levels fit a normal distribution with thin tails that match laboratory data, regardless of storms or floods.
2) In epidemic networks, initial super-spreading episodes are isolated spikes after which outbreak sizes match the baseline distribution from independent contact models across comparable cities with no rise in the frequency or size of later extreme clusters.
3) Following large earthquakes, regional seismic activity returns to baseline within hours with no aftershock sequence once data are adjusted for reporting effects, which suggests independence across events rather than any elevation in subsequent tail probabilities.
4) After a major equity crash, researchers find dense clusters of large daily moves for several weeks, with extreme days occurring far more often than in normal circumstances for assets with customarily low volatility profiles.

### Q9
Five jumbled sentences (labelled 1, 2, 3, 4, and 5), related to a topic, are given below. Four of them can be put together to form a coherent paragraph. Identify the odd sentence out and key in the number of that sentence as your answer.

1. The Bayeux tapestry was, therefore, an obvious way to tell people about the downfall of the English and the rise of the Normans.
2. So if we take expert in Anglo-Saxon culture Gale Owen-Crocker’s idea that the tapestry was originally hung in a square with certain scenes facing each other, people would have stood in the centre.
3. Art historian Linda Neagley has argued that pre- Renaissance people interacted with art visually, kinaesthetically (sensory perception through bodily movement) and physically.
4. That would make it an 11th-century immersive space with scenes corresponding and echoing each other, drawing the viewer’s attention, playing on their senses and understanding of the story they thought they knew.
5. The Bayeux tapestry would have been hung at eye level to enable this.

### Q10
The passage given below is followed by four summaries. Choose the option that best captures the essence of the passage.

Zombie cells may contribute to age-related chronic inflammation: this finding could help scientists understand more about the aging process and why the immune system becomes less effective as we get older. Zombie or “senescent” cells are damaged cells that can no longer divide and grow like normal cells. Scientists think that these cells can contribute to chronic health problems when they accumulate in the body. In younger people, the immune system is more effective at clearing senescent cells from the body through a process called apoptosis, but as we age this process becomes less efficient. As a result, there is an accumulation of senescent cells in different organs in the body, either through increased production or reduced clearance by the immune system. The zombie cells continue to use energy though they do not divide, and often secrete chemicals that cause inflammation, which if persistent for longer periods of time can damage healthy cells leading to chronic diseases.

1) Dead cells accelerate chronic inflammation weakening the immune system and lead to aging.
2) Senescent “zombie” cells are inactive or malfunctioning cells that can be found throughout the body.
3) A younger person’s immune system is healthy and is able to clear the damaged cells, but as people age, the zombie cells resist apoptosis, and start accumulating in the body.
4) Aging leads to less effective apoptosis, and therefore zombie cells start to accumulate in the body, causing inflammation, which accelerates aging and leads to chronic diseases.

### Q11
The given sentence is missing in the paragraph below. Decide where it best fits among the options 1, 2, 3, or 4 indicated in the paragraph.

Sentence: “Everything is old-world, traditional techniques from Mexico,” Ava emphasizes.

Paragraph: The sisters embrace the ways their great-grandfather built and repaired instruments.
____(1) ____. When crafting a Mexican guitarrón used in mariachi music, they use tacote wood for the top of the instrument. Once the wood is cut, they carve the neck and heel from a single block using tools like hand saws, chisels and sandpaper rather than modern power tools — and believe that this traditional method improves the tone of the instrument. ____(2) ____. Their store has a threeyear waitlist for instruments that take months to create. ____(3) ____. The family’s artisanship has attracted stars like Los Lobos, who own custom guitars made by all three generations of the Delgado family. ____(4) ____. For the sisters, involvement in the family business started at an early age. They each built their first instruments at age 9.

1) Option 1
2) Option 3
3) Option 2
4) Option 4

### Q12
The passage given below is followed by four summaries. Choose the option that best captures the essence of the passage.

In the dynamic realm of creativity, artists often find themselves at the crossroads between drawing inspiration from diverse cultures and inadvertently crossing into the territory of cultural appropriation. Inspiration is the lifeblood of creativity, driving artists to create works that resonate across borders. The globalized nature of the modern world invites artists to draw from a vast array of cultural influences. When approached respectfully, inspiration becomes a bridge, fostering understanding and appreciation of cultural diversity. However, the line between inspiration and cultural appropriation can be thin and easily blurred. Cultural appropriation occurs when elements from a particular culture are borrowed without proper understanding, respect, or acknowledgment. This leads to the commodification of sacred symbols, the reinforcement of stereotypes, and the erasure of the cultural context from which these elements originated. It’s essential to recognize that the impact of cultural appropriation extends beyond the realm of artistic expression, influencing societal perceptions and perpetuating power imbalances.

1) In today’s world of creativity, artists have to decide between respectfully acknowledging works that are inspired by diverse cultures and appropriating elements without respect for their contexts.
2) Artists in a globalised world must navigate between drawing inspiration from diverse cultures respectfully and cultural appropriation that involves borrowing without proper acknowledgement which has broader societal impacts including perpetuating power imbalances.
3) In a globalised world, artists must draw from diverse cultural influences to create works that appeal to all, and this results in instances of both inspiration and cultural appropriation.
4) Artists must navigate the thin line between inspiration and cultural appropriation, where respectful inspiration fosters cultural understanding whereas appropriation involves borrowing without acknowledgement leading to commodification and reinforcement of stereotypes.

### Directions for Q13–Q16
The passage below is accompanied by four questions. Based on the passage, choose the best answer for each question.

Often the well intentioned music lover or the traditionallyminded professional composer asks two basic questions when faced with the electronic music phenomena:
(1) . . . is this type of artistic creation music at all? and, (2) given that the product is accepted as music of a new type or order, is not such music “inhuman”? . . .
As Lejaren Hiller points out in his book Experimental Music (co-author Leonard M. Isaacson), two questions which often arise when music is discussed are: (a) the substance of musical communication and its symbolic and semantic significance, if any, and (b) the particular processes, both mental and technical, which are involved in creating and responding to musical composition. The ever-present popular concept of music as a direct, open, emotional expression and as a subjective form of communication from the composer, is, of course still that of the nineteenth century, when composers themselves spoke of music in those terms . . . But since the third decade of our century many composers have preferred more objective definitions of music, epitomized in Stravinsky’s description of it as “a form of speculation in terms of sound and time”. An acceptance of this more characteristic twentieth-century view of the art of musical composition will of course immediately bring the layman closer to an understanding of, and sympathetic response to, electronic music, even if the forms, sounds and approaches it uses will still be of a foreign nature to him.

A communication problem however will still remain.

The principal barrier that electronic music presents at large, in relation to the communication process, is that composers in this medium are employing a new language of forms . . . where terms like ‘densities’, ‘indefinite pitch relations’, ‘dynamic serialization’, ‘permutation’, etc., are substitutes (or remote equivalents) for the traditional concepts of harmony, melody, rhythm, etc. . . . When the new structural procedures of electronic music are at last fully understood by the listener the barriers between him and the work he faces will be removed. . . .

The medium of electronic music has of course tempted many kinds of composers to try their hand at it . . . But the serious-minded composer approaches the world of electronic music with a more sophisticated and profound concept of creation. Although he knows that he can reproduce and employ melodic, rhythmic patterns and timbres of a traditional nature, he feels that it is in the exploration of sui generis languages and forms that the aesthetic magic of the new medium lies. And, conscientiously, he plunges into this search. The second objection usually levelled against electronic music is much more innocent in nature. When people speak—sometimes very vehemently—of the ‘inhuman’ quality of this music they seem to forget that the composer is the one who fires the machines, collects the sounds, manipulates them, pushes the buttons, programs the computer, filters the sounds, establishes pitches and scales, splices tape, thinks of forms, and rounds up the over-all structure of the piece, as well as every detail of it.

### Q13
The goal of the author over the course of this passage is to:
1) defend electronic music from certain common charges.
2) differentiate the modern composer from the nineteenth century composer.
3) differentiate between electronic music and other forms of music.
4) defend the “serious-minded composer” from Lejaren Hill and Stravinsky.

### Q14
The mention of Stravinsky’s description of music in the first paragraph does all the following EXCEPT:
1) allow us to classify electronic music as music.
2) complicate our notion of what is communicated through music.
3) help us determine which sounds are musical and which are not.
4) respond to and expand upon earlier understandings of music.

### Q15
From the context in which it is placed, the phrase “sui generis” in paragraph 3 suggests which one of the following?
1) Unaesthetic
2) Generic
3) Particular
4) Indescribable

### Q16
What relation does the “communication problem” mentioned in paragraph 2 have to the questions that the author recounts at the beginning of the passage?
1) Unfamiliar forms and terms might get in the way of our seeing electronic music as music, but this can be overcome.
2) None; they are unrelated to one another and form parts of different discussions.
3) Its unfamiliar “language of forms” and novel terms mean that we cannot see electronic music as music since it does not employ traditional musical concepts.
4) The communication problem is what allows us to see electronic music as music because music must be difficult to understand.

### Directions for Q17–Q20
The passage below is accompanied by four questions. Based on the passage, choose the best answer for each question.

How can we know what someone else is thinking or feeling, let alone prove it in court? In his 1863 book, A General View of the Criminal Law of England, James Fitzjames Stephen, among the most celebrated legal thinkers of his generation, was of the opinion that the assessment of a person’s mental state was an inference made with “little consciousness.” In a criminal case, jurors, doctors, and lawyers could watch defendants— scrutinizing clothing, mannerisms, tone of voice—but the best they could hope for were clues. . . . Rounding these clues up to a judgment about a defendant’s guilt, or a defendant’s life, was an act of empathy and imagination. . . . The closer the resemblance between defendants and their judges, the easier it was to overlook the gap that inference filled. Conversely, when a defendant struck officials as unlike themselves, whether by dint of disease, gender, confession, or race, the precariousness of judgments about mental state was exposed.

In the nineteenth century, physicians who specialized in the study of madness and the care of the insane held themselves out as experts in the new field of mental science. Often called alienists or mad doctors, they were the predecessors of modern psychiatrists, neurologists, and psychologists. . . . The opinions of family and neighbors had once been sufficient to sift the sane from the insane, but a growing belief that insanity was a subtle condition that required expert, medical diagnosis pushed physicians into the witness box. . . . Lawyers for both prosecution and defense began to recruit alienists to assess defendants’ sanity and to testify to it in court.

Irresponsibility and insanity were not identical, however. Criminal responsibility was a legal concept and not, fundamentally, a medical one. Stephen explained: “The question ‘What are the mental elements of responsibility?’ is, and must be, a legal question. It cannot be anything else, for the meaning of responsibility is liability to punishment.” . . . Nonetheless, medical and legal accounts of what it meant to be mentally sound became entangled and mutually referential throughout the nineteenth century. Lawyers relied on medical knowledge to inform their opinions and arguments about the sanity of their clients. Doctors commented on the legal responsibility of their patients. Ultimately, the fields of criminal law and mental science were both invested in constructing an image of the broken and damaged psyche that could be contrasted with the whole and healthy one. This shared interest, and the shared space of the criminal courtroom, made it nearly impossible to consider responsibility without medicine, or insanity without law. . . .

Physicians and lawyers shared more than just concern for the mind. Class, race, and gender bound these middle-class, white, professional men together, as did family ties, patriotism, Protestantism, business ventures, the alumni networks of elite schools and universities, and structures of political patronage. But for all their affinities, men of medicine and law were divided by contests over the borders of criminal responsibility, as much within each profession as between them. Alienists steadily pushed the boundaries of their field, developing increasingly complex and capacious definitions of insanity. Eccentricity and aggression came to be classified as symptoms of mental disease, at least by some.

### Q17
According to the passage, who or what was an “alienist”?
1) Physicians and lawyers who were responsible for examining accounts of extraterrestrials or ‘aliens’ in the nineteenth century.
2) Physicians and lawyers who were responsible for the condition of immigrants or ‘aliens’ in the nineteenth century.
3) Professionals who pushed the boundaries of their fields till they became unrecognisable in the nineteenth century.
4) Physicians who specialised in the study of madness and the care of the insane in the nineteenth century.

### Q18
“Conversely, when a defendant struck officials as unlike themselves, whether by dint of disease, gender, confession, or race, the precariousness of judgments about mental state was exposed.” Which one of the following best describes the use of the word “confession” in this sentence?
1) The defendants struck out at the officials and then confessed to the act.
2) Referring to the practice of ‘confession’ in some faiths, here it is a metaphor for the religion of the defendant.
3) Referring to the defendant’s confession of his or her crime as false, because ‘dint’ is an archaic form of ‘didn’t’ or ‘did not’.
4) Referring to the gender, race or disease claimed as a defence by the defendant, here it is a synonym for ‘professing’ a gender, race, or disease.

### Q19
The last paragraph of the passage refers to “middleclass, white, professional men”. Which one of the following qualities best describes the connection among them?
1) Eccentricity and aggression.
2) The opinions of family and neighbours.
3) Empathy and imagination.
4) The borders of criminal responsibility.

### Q20
Study the following sets of concepts and identify the set that is conceptually closest to the concerns and arguments of the passage.
1) Empathy, Prosecution, Knowledge, Business.
2) Judgement, Belief, Accounts, Patronage.
3) Assessment, Empathy, Prosecution, Patriotism.
4) Judgement, Insanity, Punishment, Responsibility.

### Directions for Q21–Q24
The passage below is accompanied by four questions. Based on the passage, choose the best answer for each question.

Studies showing that income inequality plays a positive role in economic growth are largely based on three arguments. The first argument focuses on investment indivisibilities wherein large sunk costs are required when implementing new fundamental innovations. Without stock markets and financial institutions to mobilize large sums of money, a high concentration of wealth is needed for individuals to undertake new industrial activities accompanied by high sunk costs . . . [One study] shows the relation between economic growth and income inequality for 45 countries during 1966-1995. [It was found] that the increase in income inequality has a significant positive relationship with economic growth in the short and medium term. Using system GMM, [another study estimated] the relation between income inequality and economic growth for 106 countries during 1965–2005 period. The results show that income inequality has a positive impact on economic growth in the short run, but the two are negatively correlated in the long run. The second argument is related to moral hazard and incentives . . . Because economic performance is determined by the unobservable level of effort that agents make, paying compensations without taking into account the economic performance achieved by individual agents will fail to elicit optimum effort from the agents. Thus, certain income inequalities contribute to growth by enhancing worker motivation . . . and by giving motivation to innovators and entrepreneurs . . . Finally, [another study] point[s] out that the concentration of wealth or stock ownership in relation to corporate governance contributes to growth. If stock ownership is distributed and owned by a large number of shareholders, it is not easy to make quick decisions due to the conflicting interests among shareholders, and this may also cause a free-rider problem in terms of monitoring and supervising managers and workers. . . .

Various studies have examined the relationships between income inequality and economic growth, and most of these assert that a negative correlation exists between the two. . . . Analyzing 159 countries for 1980– 2012, they conclude that there exists a negative relation between income inequality and economic growth; when the income share of the richest 20% of population increases by 1%, the GDP decreases by 0.08%, whereas when the income share of the poorest 20% of population increases by 1%, the GDP increases by 0.38%. Some studies find that inequality has a negative impact on growth due to poor human capital accumulation and low fertility rates . . . while [others] point out that inequality creates political instability, resulting in lower investment. . . . [Some economists] argue that widening income inequality has a negative impact on economic growth because it negatively affects social consensus or social capital formation. One important research topic is the correlation between democratization and income redistribution. [Some scholars] explain that social pressure for income redistribution rises as income inequality increases in a democratic society. In other words, when democratization extends suffrage to a wider class of people, the increased political power of low- and middleincome voters results in broader support for income redistribution and social welfare expansion. However . . . if the rich have more political influence than the poor, the democratic system actually worsens income inequality rather than improving it.

### Q21
Which one of the options below best summarises the passage?
1) The passage confines its discussion to financing gaps and corporate control while undercutting cross country evidence and overlooking the significance of concerns regarding human capital accumulation, fertility rates, and income redistribution under democratisation.
2) The passage outlines investment, incentive, and governance channels through which income inequality may support economic growth and reports short-term gains while noting long-term drawbacks.
3) The passage claims that evaluating the effect of income inequality on economic growth without considering both short- and long-term consequences is misguided.
4) The passage argues that income inequality accelerates economic growth while also emphasising the significance of concerns regarding human capital accumulation, fertility rates, and political instability.

### Q22
The passage refers to “democratization”. Choose the one option below that comes closest to the opposite of this process.
1) The coalition imposed term limits and strengthened judicial review in order to further entrench autocratic rule.
2) Corporate donations were capped and parties received public funding which was portrayed as establishing an oligarchy.
3) After the emergency decree, the regime shifted toward authoritarianism as suffrage narrowed and opposition parties were deregistered.
4) Municipalities adopted participatory budgeting and recall elections which a press release called totalitarianism.

### Q23
The primary function of the three-part case for a positive income inequality–economic growth link in the first half of the passage is to show that:
1) inequality can aid short-term growth in settings with high sunk costs, incentive alignment, and concentrated ownership.
2) mature stock markets make wealth concentration unnecessary, yet they might still be harmful to investment.
3) dispersed ownership speeds corporate decisionmaking and removes free rider problems.
4) inequality boosts growth in every period and type of economy, regardless of finance or governance conditions.

### Q24
According to the incentive or moral hazard argument, which of the designs below is most consistent with the claim that some inequality can raise growth?
1) A regime that concentrates stock ownership in relation to corporate governance.
2) Rents protected by market power that enlarge top incomes without linking pay to results.
3) Wages are determined by tenure rather than output to ensure equity.
4) Pay rewards on verifiable performance for highly productive workers.
