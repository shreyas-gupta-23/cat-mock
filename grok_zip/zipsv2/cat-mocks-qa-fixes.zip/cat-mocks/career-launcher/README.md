# Career Launcher — free mocks & CAT 2025 slots

**Source hub:** https://www.careerlauncher.com/cat-mba/freecatmock/  
**MyZone:** https://myzone.careerlauncher.com/

## Keys status

**Yes — Free Mock 1–2 answer keys are in this pack** (captured 1 Oct 2026 IST from MyZone Solutions).

| File | What it is |
| --- | --- |
| `free-mock-1-answers.md` | Official option/numeric keys for Mock 01 (68Q) |
| `free-mock-2-answers.md` | Official option/numeric keys for Mock 02 (68Q) |
| `KEYS-CHECK.md` | How keys were verified; no expiry text shown on site |

CAT 2025 slot files here remain questions-only — use `../with-keys/` for keyed CAT 2025 PYQs.

## Free Mock questions (full length)

| File | Contents |
| --- | --- |
| `free-mock-1.md` | Free CAT Mock 01 — VARC 24 + DILR 22 + QA 22 |
| `free-mock-2.md` | Free CAT Mock 02 — VARC 24 + DILR 22 + QA 22 |

**Caveats:** some DILR embedded tables/grids did not render in MyZone’s text Question Paper view (called out in-file).

## Other files

| File | Role |
| --- | --- |
| `cat-2025-slot-1.md` … `slot-3.md` | CAT 2025 actual-paper slot captures (questions only) |
| `CATALOG.md` | Topic/sectional instruction URL catalog |
| `UNLOCKED.md` | What Free Zone showed unlocked (30 Sep 2026) |

Copies of catalog/unlocked notes also live under `../docs/`.
