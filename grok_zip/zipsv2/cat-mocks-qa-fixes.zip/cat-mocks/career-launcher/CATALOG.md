# Career Launcher Free CAT Mocks — catalog (no questions scraped)
Source: https://www.careerlauncher.com/cat-mba/freecatmock/
Fetched: 30 Sep 2026 IST

## Full-length / actual papers
These "Start Test" buttons open a **login/register modal** (`#myModalNorm`).
No public PDF of questions. Interactive only after free signup.

- Free CAT Mock Test 1 — requires CL free account (modal on Start Test)
- Free CAT Mock Test 2 — requires CL free account (modal on Start Test)
- CAT 2025 Actual Paper Slot 1 — requires CL free account (modal on Start Test)
- CAT 2025 Actual Paper Slot 2 — requires CL free account (modal on Start Test)
- CAT 2025 Actual Paper Slot 3 — requires CL free account (modal on Start Test)

## Topic / sectional tests (instructions.jsp links)
Instructions pages load without login; starting the timed test posts `qset_id` and typically needs a session.
Do not scrape question banks. Use browser after free signup.

Total topic-test instruction links found: 79

| Topic | Level | Test | Instructions URL |
|---|---|---|---|
| Arithmetic | Basic | 1 | https://www.careerlauncher.com/cat-mba/freecatmock/take-test/instructions.jsp?qset_id=RHTJBYRmkpU%3D |
| Arithmetic | Basic | 2 | https://www.careerlauncher.com/cat-mba/freecatmock/take-test/instructions.jsp?qset_id=SEUgToGoKYc%3D |
| Arithmetic | Basic | 3 | https://www.careerlauncher.com/cat-mba/freecatmock/take-test/instructions.jsp?qset_id=KiZmAjyJm20%3D |
| Number System | Basic | 1 | https://www.careerlauncher.com/cat-mba/freecatmock/take-test/instructions.jsp?qset_id=G4vCxt%2FEvAI%3D |
| Number System | Basic | 2 | https://www.careerlauncher.com/cat-mba/freecatmock/take-test/instructions.jsp?qset_id=QSxcanjMCMY%3D |
| Number System | Basic | 3 | https://www.careerlauncher.com/cat-mba/freecatmock/take-test/instructions.jsp?qset_id=VVbgT6K6xPc%3D |
| Algebra | Basic | 1 | https://www.careerlauncher.com/cat-mba/freecatmock/take-test/instructions.jsp?qset_id=xkcfHaiNaeI%3D |
| Algebra | Basic | 2 | https://www.careerlauncher.com/cat-mba/freecatmock/take-test/instructions.jsp?qset_id=bgGMvOk8ayA%3D |
| Algebra | Basic | 3 | https://www.careerlauncher.com/cat-mba/freecatmock/take-test/instructions.jsp?qset_id=%2FI0wUWb2Egc%3D |
| Geometry | Basic | 1 | https://www.careerlauncher.com/cat-mba/freecatmock/take-test/instructions.jsp?qset_id=hBTMsQwku08%3D |
| Geometry | Basic | 2 | https://www.careerlauncher.com/cat-mba/freecatmock/take-test/instructions.jsp?qset_id=ISaYLOXUyN0%3D |
| Geometry | Basic | 3 | https://www.careerlauncher.com/cat-mba/freecatmock/take-test/instructions.jsp?qset_id=CUgIcu6VR5E%3D |
| Modern Maths | Basic | 1 | https://www.careerlauncher.com/cat-mba/freecatmock/take-test/instructions.jsp?qset_id=WnaStIzPVqw%3D |
| Modern Maths | Basic | 2 | https://www.careerlauncher.com/cat-mba/freecatmock/take-test/instructions.jsp?qset_id=ml4NtlCx1Wo%3D |
| Modern Maths | Basic | 3 | https://www.careerlauncher.com/cat-mba/freecatmock/take-test/instructions.jsp?qset_id=%2FStAcrAvO58%3D |
| Logical Reasoning | Basic | 1 | https://www.careerlauncher.com/cat-mba/freecatmock/take-test/instructions.jsp?qset_id=j3pUPhOlrPM%3D |
| Logical Reasoning | Basic | 2 | https://www.careerlauncher.com/cat-mba/freecatmock/take-test/instructions.jsp?qset_id=VBJOBqSxzpg%3D |
| Data Interpretation | Basic | 1 | https://www.careerlauncher.com/cat-mba/freecatmock/take-test/instructions.jsp?qset_id=vtrVdOtPBk4%3D |
| Data Interpretation | Basic | 2 | https://www.careerlauncher.com/cat-mba/freecatmock/take-test/instructions.jsp?qset_id=Ww3CMV02uw4%3D |
| Data Interpretation | Basic | 3 | https://www.careerlauncher.com/cat-mba/freecatmock/take-test/instructions.jsp?qset_id=cnjZQkBq9K4%3D |
| Reading Comprehension | Basic | 1 | https://www.careerlauncher.com/cat-mba/freecatmock/take-test/instructions.jsp?qset_id=gKo0lJCEvAk%3D |
| Reading Comprehension | Basic | 2 | https://www.careerlauncher.com/cat-mba/freecatmock/take-test/instructions.jsp?qset_id=co0ndSDYkBg%3D |
| Reading Comprehension | Basic | 3 | https://www.careerlauncher.com/cat-mba/freecatmock/take-test/instructions.jsp?qset_id=t0qk3w%207KmA%3D |
| Grammar & Vocabulary | Basic | 1 | https://www.careerlauncher.com/cat-mba/freecatmock/take-test/instructions.jsp?qset_id=TY3Nqmj5xiQ%3D |
| Grammar & Vocabulary | Basic | 2 | https://www.careerlauncher.com/cat-mba/freecatmock/take-test/instructions.jsp?qset_id=lTB7WPTURgo%3D |
| Grammar & Vocabulary | Basic | 3 | https://www.careerlauncher.com/cat-mba/freecatmock/take-test/instructions.jsp?qset_id=BFe%201YJppFM%3D |
| Para-Jumbles | Basic | 1 | https://www.careerlauncher.com/cat-mba/freecatmock/take-test/instructions.jsp?qset_id=G%2FrvpyXBxXI%3D |
| Para-Jumbles | Basic | 2 | https://www.careerlauncher.com/cat-mba/freecatmock/take-test/instructions.jsp?qset_id=UDsTUpwD7rI%3D |
| Para-Jumbles | Basic | 3 | https://www.careerlauncher.com/cat-mba/freecatmock/take-test/instructions.jsp?qset_id=4G2q4FnpNJo%3D |
| Critical Reasoning | Basic | 1 | https://www.careerlauncher.com/cat-mba/freecatmock/take-test/instructions.jsp?qset_id=I89csrCLZEo%3D |
| Critical Reasoning | Basic | 2 | https://www.careerlauncher.com/cat-mba/freecatmock/take-test/instructions.jsp?qset_id=IXAREIJOZKY%3D |
| Critical Reasoning | Basic | 3 | https://www.careerlauncher.com/cat-mba/freecatmock/take-test/instructions.jsp?qset_id=DtcB8eVjkYM%3D |
| Para-Summary | Basic | 1 | https://www.careerlauncher.com/cat-mba/freecatmock/take-test/instructions.jsp?qset_id=Zt7qpeP4Xc0%3D |
| Para-Summary | Basic | 2 | https://www.careerlauncher.com/cat-mba/freecatmock/take-test/instructions.jsp?qset_id=ELCN5AB3xO8%3D |
| Para-Summary | Basic | 3 | https://www.careerlauncher.com/cat-mba/freecatmock/take-test/instructions.jsp?qset_id=rBvWvMgOriU%3D |
| Arithmetic | Advanced | 1 | https://www.careerlauncher.com/cat-mba/freecatmock/take-test/instructions.jsp?qset_id=AJvnjTcT7%2FM%3D |
| Arithmetic | Advanced | 2 | https://www.careerlauncher.com/cat-mba/freecatmock/take-test/instructions.jsp?qset_id=ftxVOd%2FSl%2Fw%3D |
| Number System | Advanced | 1 | https://www.careerlauncher.com/cat-mba/freecatmock/take-test/instructions.jsp?qset_id=XN1uS%2FZFd0A%3D |
| Number System | Advanced | 2 | https://www.careerlauncher.com/cat-mba/freecatmock/take-test/instructions.jsp?qset_id=sxh2bv1y61M%3D |
| Algebra | Advanced | 1 | https://www.careerlauncher.com/cat-mba/freecatmock/take-test/instructions.jsp?qset_id=Rlo%2F1n8nPvI%3D |
| Algebra | Advanced | 2 | https://www.careerlauncher.com/cat-mba/freecatmock/take-test/instructions.jsp?qset_id=Vod%2Fx0j4dbc%3D |
| Geometry | Advanced | 1 | https://www.careerlauncher.com/cat-mba/freecatmock/take-test/instructions.jsp?qset_id=922JC9N7Z6s%3D |
| Geometry | Advanced | 2 | https://www.careerlauncher.com/cat-mba/freecatmock/take-test/instructions.jsp?qset_id=oO05QjS5wfI%3D |
| Modern Maths | Advanced | 1 | https://www.careerlauncher.com/cat-mba/freecatmock/take-test/instructions.jsp?qset_id=%2FqIuhL0CJv8%3D |
| Modern Maths | Advanced | 2 | https://www.careerlauncher.com/cat-mba/freecatmock/take-test/instructions.jsp?qset_id=4mukLJoilng%3D |
| Logical Reasoning | Advanced | 1 | https://www.careerlauncher.com/cat-mba/freecatmock/take-test/instructions.jsp?qset_id=X6KtFwZf9SY%3D |
| Logical Reasoning | Advanced | 2 | https://www.careerlauncher.com/cat-mba/freecatmock/take-test/instructions.jsp?qset_id=93cXJk0pBYs%3D |
| Data Interpretation | Advanced | 1 | https://www.careerlauncher.com/cat-mba/freecatmock/take-test/instructions.jsp?qset_id=PwcLa9zRKbI%3D |
| Data Interpretation | Advanced | 2 | https://www.careerlauncher.com/cat-mba/freecatmock/take-test/instructions.jsp?qset_id=wmtds9b6bRI%3D |
| Reading Comprehension | Advanced | 1 | https://www.careerlauncher.com/cat-mba/freecatmock/take-test/instructions.jsp?qset_id=oxLzetu8WIk%3D |
| Reading Comprehension | Advanced | 2 | https://www.careerlauncher.com/cat-mba/freecatmock/take-test/instructions.jsp?qset_id=di9sQVtr%2FuQ%3D |
| Grammar & Vocabulary | Advanced | 1 | https://www.careerlauncher.com/cat-mba/freecatmock/take-test/instructions.jsp?qset_id=Ecc1ktbQ7Zs%3D |
| Grammar & Vocabulary | Advanced | 2 | https://www.careerlauncher.com/cat-mba/freecatmock/take-test/instructions.jsp?qset_id=xxyjHtbaSeM%3D |
| Para-Jumbles | Advanced | 1 | https://www.careerlauncher.com/cat-mba/freecatmock/take-test/instructions.jsp?qset_id=6mDC14GGM3A%3D |
| Para-Jumbles | Advanced | 2 | https://www.careerlauncher.com/cat-mba/freecatmock/take-test/instructions.jsp?qset_id=i3alx5xfzfU%3D |
| Para-Jumbles | Advanced | 1 | https://www.careerlauncher.com/cat-mba/freecatmock/take-test/instructions.jsp?qset_id=xmGasZiXApc%3D |
| Para-Jumbles | Advanced | 2 | https://www.careerlauncher.com/cat-mba/freecatmock/take-test/instructions.jsp?qset_id=a78UaW%20wtNs%3D |
| Para-Summary | Advanced | 1 | https://www.careerlauncher.com/cat-mba/freecatmock/take-test/instructions.jsp?qset_id=nB1M2PvEUN0%3D |
| Para-Summary | Advanced | 2 | https://www.careerlauncher.com/cat-mba/freecatmock/take-test/instructions.jsp?qset_id=vX3ctujCp18%3D |
| Arithmetic | Expert | 1 | https://www.careerlauncher.com/cat-mba/freecatmock/take-test/instructions.jsp?qset_id=VfGzMzSx4dg%3D |
| Arithmetic | Expert | 2 | https://www.careerlauncher.com/cat-mba/freecatmock/take-test/instructions.jsp?qset_id=l%209HQBC%20NK0%3D |
| Number System | Expert | 1 | https://www.careerlauncher.com/cat-mba/freecatmock/take-test/instructions.jsp?qset_id=kroknwk9KJk%3D |
| Number System | Expert | 2 | https://www.careerlauncher.com/cat-mba/freecatmock/take-test/instructions.jsp?qset_id=ZNlYRgtNi9U%3D |
| Algebra | Expert | 1 | https://www.careerlauncher.com/cat-mba/freecatmock/take-test/instructions.jsp?qset_id=7Ee0EMxEq2k%3D |
| Algebra | Expert | 2 | https://www.careerlauncher.com/cat-mba/freecatmock/take-test/instructions.jsp?qset_id=a9R7rSZQ4Ns%3D |
| Geometry | Expert | 1 | https://www.careerlauncher.com/cat-mba/freecatmock/take-test/instructions.jsp?qset_id=Ewm3wgR3OeI%3D |
| Geometry | Expert | 2 | https://www.careerlauncher.com/cat-mba/freecatmock/take-test/instructions.jsp?qset_id=g30HJupGxlM%3D |
| Modern Maths | Expert | 1 | https://www.careerlauncher.com/cat-mba/freecatmock/take-test/instructions.jsp?qset_id=4A%2FKHGLgg9A%3D |
| Modern Maths | Expert | 2 | https://www.careerlauncher.com/cat-mba/freecatmock/take-test/instructions.jsp?qset_id=HKwZxQxVwqg%3D |
| Logical Reasoning | Expert | 1 | https://www.careerlauncher.com/cat-mba/freecatmock/take-test/instructions.jsp?qset_id=bwb87RrqBKk%3D |
| Logical Reasoning | Expert | 2 | https://www.careerlauncher.com/cat-mba/freecatmock/take-test/instructions.jsp?qset_id=5Ayw0evMSk0%3D |
| Grammar & Vocabulary | Expert | 1 | https://www.careerlauncher.com/cat-mba/freecatmock/take-test/instructions.jsp?qset_id=VMt80tC3QEU%3D |
| Grammar & Vocabulary | Expert | 2 | https://www.careerlauncher.com/cat-mba/freecatmock/take-test/instructions.jsp?qset_id=SEPbpuUl%2FAU%3D |
| Para-Jumbles | Expert | 1 | https://www.careerlauncher.com/cat-mba/freecatmock/take-test/instructions.jsp?qset_id=p2VRqjSgLQc%3D |
| Para-Jumbles | Expert | 2 | https://www.careerlauncher.com/cat-mba/freecatmock/take-test/instructions.jsp?qset_id=olE3iYcLBF0%3D |
| Critical Reasoning | Expert | 1 | https://www.careerlauncher.com/cat-mba/freecatmock/take-test/instructions.jsp?qset_id=YWSFl5m6QFI%3D |
| Critical Reasoning | Expert | 2 | https://www.careerlauncher.com/cat-mba/freecatmock/take-test/instructions.jsp?qset_id=fnXvcEKgdqU%3D |
| Para-Summary | Expert | 1 | https://www.careerlauncher.com/cat-mba/freecatmock/take-test/instructions.jsp?qset_id=DDzZdhYiaOE%3D |
| Para-Summary | Expert | 2 | https://www.careerlauncher.com/cat-mba/freecatmock/take-test/instructions.jsp?qset_id=eC1wLz6EuiU%3D |

## Sample instructions page saved
- `/workspace/cat-mocks/career-launcher/sample-instructions-arithmetic-basic-t1.html`
- Shows general CAT UI rules; Start Test form with hidden `qset_id=772964`.
- Questions themselves are not in the HTML (loaded by the test engine after start).

## Formula / QP blog PDFs
- Quant formula PDF: lead-capture gate (`slcpd` plugin) — email required. Not downloaded.
- CAT 2023/2024/2025 QP blog pages also use lead-capture Download PDF buttons. Not downloaded.
