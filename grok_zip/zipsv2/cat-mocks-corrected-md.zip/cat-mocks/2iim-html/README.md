# 2IIM HTML text extracts (CAT 2022–2025)

**Source:** https://online.2iim.com/CAT-question-paper/ public HTML pages → plain text.  
**Keys status:** Raw extracts; **prefer `../with-keys/`** which merges these with on-page Correct Answer labels.

## Naming

`CAT-YYYY-Question-Paper-Slot-N-{VARC|DILR|Quant}.txt`

36 files = years 2022–2025 × 3 slots × 3 sections.

## Agent note

Use `with-keys/CAT-YYYY-Slot-N-with-keys.md` for study. Keep this folder as the raw source used by `with-keys/_build.py`.
