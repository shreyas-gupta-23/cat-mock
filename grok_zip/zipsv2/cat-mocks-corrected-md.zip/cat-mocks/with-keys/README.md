# CAT papers with answer keys (preferred PYQ pack)

Built from `../2iim-html/` public 2IIM HTML extracts. Every listed 2022–2025 question has an on-page **ANSWER**.

## CAT 2022–2025 (complete on-page keys)

| Year | Slots | Sections | Answers | Combined files |
| --- | --- | --- | --- | --- |
| 2022 | 1–3 | VARC/DILR/Quant | 198 | `CAT-2022-Slot-{1,2,3}-with-keys.md` |
| 2023 | 1–3 | VARC/DILR/Quant | 198 | `CAT-2023-Slot-{1,2,3}-with-keys.md` |
| 2024 | 1–3 | VARC/DILR/Quant | 204 | `CAT-2024-Slot-{1,2,3}-with-keys.md` |
| 2025 | 1–3 | VARC/DILR/Quant | 204 | `CAT-2025-Slot-{1,2,3}-with-keys.md` |

Also present: per-section files `CAT-YYYY-Slot-N-{VARC|DILR|Quant}-with-keys.md`.

**Source URL pattern:** `https://online.2iim.com/CAT-question-paper/CAT-YYYY-Question-Paper-Slot-N-SECTION/`

## Earlier years (2017–2021)

See `earlier-years/` for PDF answer-key/solutions copies and plain-text answer extracts (often TITA-only). Full MCQ keys frequently need the PDF — see `MISSING-KEYS.md`.

## Career Launcher free mocks

CL Free Mock 1–2 official keys are in `../career-launcher/free-mock-*-answers.md` (MyZone, 1 Oct 2026). See `MISSING-KEYS.md` for remaining gaps elsewhere. No keys are fabricated.

## Build

`_build.py` regenerates the 2022–2025 markdown from `../2iim-html/` (kept for reproducibility).
