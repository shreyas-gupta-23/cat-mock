# CAT 2025 — Slot 1 — DILR (Questions + On-page Answer Key)

Answers are on-page 2IIM **Correct Answer** labels. Not invented.

## DILR

- Source file: `2iim-html/CAT-2025-Question-Paper-Slot-1-DILR.txt`
- Page: https://online.2iim.com/CAT-question-paper/CAT-2025-Question-Paper-Slot-1-DILR/
- On-page answers found: 22
- Answer source: 2IIM on-page **Correct Answer** / **Correct Answer Choice** (not invented)

### Q1

A train travels from Station A to Station E, passing through stations B, C, and D, in that order. The train has a seating capacity of 200. A ticket may be booked from any station to any other station ahead on the route, but not to any earlier station.

A ticket from one station to another reserves one seat on every intermediate segment of the route. For example, a ticket from B to E reserves a seat in the intermediate segments B – C, C – D, and D – E.

The occupancy factor for a segment is the total number of seats reserved in the segment as a percentage of the seating capacity. The total number of seats reserved for any segment cannot exceed 200.

The following information is known.
1. Segment C – D had an occupancy factor of 95%. Only segment B – C had a higher occupancy factor.
2. Exactly 40 tickets were booked from B to C and 30 tickets were booked from B to E.
3. Among the seats reserved on segment D – E, exactly four-sevenths were from stations before C.
4. The number of tickets booked from A to C was equal to that booked from A to E, and it was higher than that from B to E.
5. No tickets were booked from A to B, from B to D and from D to E.
6. The number of tickets booked for any segment was a multiple of 10.

 CAT 2025 Slot 1 - DI LR

 What was the occupancy factor for segment D – E?

**ANSWER:** Choice D

### Q2

CAT 2025 Slot 1 - DI LR

 How many tickets were booked from Station A to Station E?

**ANSWER:** 50

### Q3

CAT 2025 Slot 1 - DI LR

 How many tickets were booked from Station C?

**ANSWER:** 80

### Q4

CAT 2025 Slot 1 - DI LR

 What is the difference between the number of tickets booked to Station C and the number of tickets booked to Station D?

**ANSWER:** 40

### Q5

CAT 2025 Slot 1 - DI LR

 How many tickets were booked to travel in exactly one segment?

**ANSWER:** 60

### Q6

At InnovateX, six employees, Asha, Bunty, Chintu, Dolly, Eklavya, and Falguni, were split into two groups of three each: Elite led by Manager Kuku, and Novice led by Manager Lalu.

At the end of each quarter, Kuku and Lalu handed out ratings to all members in their respective groups. In each group, each employee received a distinct integer rating from 1 to 3.

The score for an employee at the end of a quarter is defined as their cumulative rating from the beginning of the year. At the end of each quarter the employee in Novice with the highest score was promoted to Elite, and the employee in Elite with the minimum score was demoted to Novice. If there was a tie in scores, the employee with a higher rating in the latest quarter was ranked higher.

1. Asha, Bunty, and Chintu were in Elite at the beginning of Quarter 1. All of them were in Novice at the beginning of Quarter 4.
2. Dolly and Falguni were the only employees who got the same rating across all the quarters.
3. The following is known about ratings given by Lalu:
 • Bunty received a rating of 1 in Quarter 2.
 • Asha and Dolly received ratings of 1 and 2, respectively, in Quarter 3.

 CAT 2025 Slot 1 - DI LR

 What was Eklavya's score at the end of Quarter 2?

**ANSWER:** 4

### Q7

CAT 2025 Slot 1 - DI LR

 How many employees changed groups more than once up to the beginning of Quarter 4?

**ANSWER:** 0

### Q8

CAT 2025 Slot 1 - DI LR

 What was Bunty's score at the end of Quarter 3?

**ANSWER:** 5

### Q9

CAT 2025 Slot 1 - DI LR

 For how many employees can the scores at the end of Quarter 3 be determined with certainty?

**ANSWER:** 4

### Q10

CAT 2025 Slot 1 - DI LR

 Which of the following statements is/are NECESSARILY true?
I. Asha received a rating of 2 in Quarter 1.
II. Asha received a rating of 1 in Quarter 2.

 Only I

 Both I and II

 Neither I nor II

 Only II

**ANSWER:** Choice D

### Q11

Only II

 A round table has seven chairs around it. The chairs are numbered 1 through 7 in a clockwise direction. Four friends, Aslam, Bashir, Chhavi, and Davies, sit on four of the chairs. In the starting position, Aslam and Chhavi are sitting next to each other, while for Bashir as well as Davies, there are empty chairs on either side of the chairs that are sitting on.

The friends take turns moving either clockwise or counterclockwise from their chair. The friend who has to move in a turn occupies the first empty chair in whichever direction (s)he chooses to move. Aslam moves first (Turn 1), followed by Bashir, Chhavi, and Davies (Turns 2, 3, and 4, respectively). Then Aslam moves again followed by Bashir, and Chhavi (Turns 5, 6, and 7, respectively).

The following information is known.

1. The four friends occupy adjacent chairs only at the end of Turn 2 and Turn 6.
2. Davies occupies Chair 2 after Turn 1 and Chair 4 after Turn 5, and Chhavi occupies Chair 7 after Turn 2.

 CAT 2025 Slot 1 - DI LR

 What is the number of the chair initially occupied by Bashir?

**ANSWER:** 4

### Q12

CAT 2025 Slot 1 - DI LR

 Who sits on the chair numbered 4 at the end of Turn 3?

 Bashir

 Chhavi

 Davies

 No one

**ANSWER:** Choice D

### Q13

No one

 CAT 2025 Slot 1 - DI LR

 Which of the chairs are occupied at the end of Turn 6?

 Chairs numbered 1, 2, 3, and 4

 Chairs numbered 2, 3, 4, and 5

 Chairs numbered 1, 2, 6, and 7

 Chairs numbered 4, 5, 6, and 7

**ANSWER:** Choice D

### Q14

Chairs numbered 4, 5, 6, and 7

 CAT 2025 Slot 1 - DI LR

 Which of the following BEST describes the friends sitting on chairs adjacent to the one occupied by Bashir at the end of Turn 7?

 Aslam and Chhavi

 Chhavi only

 Davies only

 Chhavi and Davies

**ANSWER:** Choice C

### Q15

Davies only

 Five countries engage in trade with each other. Each country levies import tariffs on the other countries. The import tariff levied by Country X on Country Y is calculated by multiplying the corresponding tariff percentage with the total imports of Country X from Country Y.

The radar chart below depicts different import tariff percentages charged by each of the five countries on the others. For example, US (the blue line in the chart) charges 20%, 40%, 30%, and 30% import tariff percentages on imports from France, India, Japan, and UK, respectively. The bar chart depicts the import tariffs levied by each county on other countries. For example, US charged import tariff of 3 billion USD on UK.

Assume that imports from one country to another equals the exports from the latter to the former.

The trade surplus of Country X with Country Y is defined as follows.
Trade surplus = Exports from Country X to Country Y – Imports to Country X from Country Y.

A negative trade surplus is called trade deficit.

 CAT 2025 Slot 1 - DI LR

 How much is Japan's export to India worth?

 7.0 Billion USD

 1.75 Billion USD

 16.0 Billion USD

 8.5 Billion USD

**ANSWER:** Choice A

### Q16

7.0 Billion USD

 CAT 2025 Slot 1 - DI LR

 Which among the following is the highest?

 Imports by US from France

 Exports by France to Japan

 Exports by Japan to UK

 Imports by France from India

**ANSWER:** Choice A

### Q17

Imports by US from France

 CAT 2025 Slot 1 - DI LR

 What is the trade surplus/trade deficit of India with UK?

 Deficit of 15.0 Billion USD

 Deficit of 10.0 Billion USD

 Surplus of 10.0 Billion USD

 Surplus of 15.0 Billion USD

**ANSWER:** Choice A

### Q18

Deficit of 15.0 Billion USD

 CAT 2025 Slot 1 - DI LR

 Among France and UK, who has/have trade surplus(es) with US?

 Neither France nor UK

 Only UK

 Both France and UK

 Only France

**ANSWER:** Choice D

### Q19

Only France

 Alia, Badal, Clive, Dilshan, and Ehsaan played a game in which each asks a unique question to all the others and they respond by tapping their feet, either once or twice or thrice. One tap means "Yes", two taps mean "No", and three taps mean "Maybe".

A total of 40 taps were heard across the five questions. Each question received at least one "Yes", one "No", and one "Maybe."

The following information is known.
1. Alia tapped a total of 6 times and received 9 taps to her question. She responded "Yes" to the questions asked by both Clive and Dilshan.
2. Dilshan and Ehsaan tapped a total of 11 and 9 times respectively. Dilshan responded "No" to Badal.
3. Badal, Dilshan, and Ehsaan received equal number of taps to their respective questions.
4. No one responded "Yes" more than twice.
5. No one's answer to Alia's question matched the answer that Alia gave to that person's question. This was also true for Ehsaan.
6. Clive tapped more times in total than Badal.

 CAT 2025 Slot 1 - DI LR

 How many taps did Clive receive for his question?

**ANSWER:** 7

### Q20

CAT 2025 Slot 1 - DI LR

 Which two people tapped an equal number of times in total?

 Alia and Badal

 Clive and Ehsaan

 Badal and Dilshan

 Dilshan and Clive

**ANSWER:** Choice A

### Q21

Alia and Badal

 CAT 2025 Slot 1 - DI LR

 What was Clive's response to Ehsaan's question?

 Yes

 Maybe

 Cannot be determined

 No

**ANSWER:** Choice D

### Q22

No

 CAT 2025 Slot 1 - DI LR

 How many "Yes" responses were received across all the questions?

**ANSWER:** 6
