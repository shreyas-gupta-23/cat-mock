# CAT 2023 — Slot 1 — Quantitative Ability (Questions + On-page Answer Key)

Answers are on-page 2IIM **Correct Answer** labels. Not invented.

## Quantitative Ability

- Source file: `2iim-html/CAT-2023-Question-Paper-Slot-1-Quant.txt`
- Page: https://online.2iim.com/CAT-question-paper/CAT-2023-Question-Paper-Slot-1-Quant/
- On-page answers found: 22
- Answer source: 2IIM on-page **Correct Answer** / **Correct Answer Choice** (not invented)

### Q1

CAT 2023 Slot 1 - QA

 If \(x\) and \(y\) are positive real numbers such that \(\log _x\left(x^2+12\right)=4\) and \(3 \log _y x=1\), then \(x+y\) equals

 20

 11

 68

 10

**ANSWER:** Choice D

### Q2

10

 CAT 2023 Slot 1 - QA

 If \(x\) and \(y\) are real numbers such that \(x^2+(x-2 y-1)^2=-4 y(x+y)\), then the value \(x-2 y\) is

 0

 1

 2

 -1

**ANSWER:** Choice B

### Q3

1

 CAT 2023 Slot 1 - QA

 If \(\sqrt{5 x+9}+\sqrt{5 x-9}=3(2+\sqrt{2})\), then \(\sqrt{10 x+9}\) is equal to

 \(4 \sqrt{5}\)

 \(2 \sqrt{7}\)

 \(3 \sqrt{31}\)

 \(3 \sqrt{7}\)

**ANSWER:** Choice D

### Q4

\(3 \sqrt{7}\)

 CAT 2023 Slot 1 - QA

 Let \(n\) be the least positive integer such that 168 is a factor of \(1134^n\). If \(m\) is the least positive integer such that \(1134^n\) is a factor of \(168^m\), then \(m+n\) equals

 12

 9

 15

 24

**ANSWER:** Choice C

### Q5

15

 CAT 2023 Slot 1 - QA

 The number of integer solutions of equation \( 2|x|\left(x^2+1\right)=5 x^2 \) is

**ANSWER:** 3

### Q6

CAT 2023 Slot 1 - QA

 Let \(\alpha\) and \(\beta\) be the two distinct roots of the equation \(2 x^2-6 x+k=0\), such that \((\alpha+\beta)\) and \(\alpha \beta\) are the distinct roots of the equation \(x^2+p x+p=0\). Then, the value of \(8(k-p)\) is

**ANSWER:** 6

### Q7

CAT 2023 Slot 1 - QA

 The equation \(x^3+(2 r+1) x^2+(4 r-1) x+2=0\) has -2 as one of the roots. If the other two roots are real, then the minimum possible non-negative integer value of \(r\) is

**ANSWER:** 2

### Q8

CAT 2023 Slot 1 - QA

 Brishti went on an 8-hour trip in a car. Before the trip, the car had travelled a total of \(x \mathrm{~km}\) till then, where \(x\) is a whole number and is palindromic, i.e., \(x\) remains unchanged when its digits are reversed. At the end of the trip, the car had travelled a total of \(26862 \mathrm{~km}\) till then, this number again being palindromic. If Brishti never drove at more than \(110 \mathrm{~km} / \mathrm{h}\), then the greatest possible average speed at which she drove during the trip, in \(\mathrm{km} / \mathrm{h}\), was

 90

 100

 80

 110

**ANSWER:** Choice B

### Q9

100

 CAT 2023 Slot 1 - QA

 The minor angle between the hours hand and minutes hand of a clock was observed at \(8: 48 \mathrm{am}\). The minimum duration, in minutes, after 8.48 am when this angle increases by \(50 \%\) is

 \(\frac{36}{11}\)

 \(\frac{24}{11}\)

 2

 4

**ANSWER:** Choice B

### Q10

\(\frac{24}{11}\)

 CAT 2023 Slot 1 - QA

 In an examination, the average marks of 4 girls and 6 boys is 24. Each of the girls has the same marks while each of the boys has the same marks. If the marks of any girl is at most double the marks of any boy, but not less than the marks of any boy, then the number of possible distinct integer values of the total marks of 2 girls and 6 boys is

 19

 21

 20

 22

**ANSWER:** Choice B

### Q11

21

 CAT 2023 Slot 1 - QA

 A mixture P is formed by removing a certain amount of coffee from a coffee jar and replacing the same amount with cocoa powder. The same amount is again removed from mixture P and replaced with same amount of cocoa powder to form a new mixture Q. If the ratio of coffee and cocoa in the mixture Q is 16 : 9, then the ratio of cocoa in mixture P to that in mixture Q is

 4 : 9

 1 : 3

 5 : 9

 1 : 2

**ANSWER:** Choice C

### Q12

5 : 9

 CAT 2023 Slot 1 - QA

 The salaries of three friends Sita, Gita and Mita are initially in the ratio 5 : 6 : 7, respectively. In the first year, they get salary hikes of 20%, 25% and 20%, respectively. In the second year, Sita and Mita get salary hikes of 40% and 25%, respectively, and the salary of Gita becomes equal to the mean salary of the three friends. The salary hike of Gita in the second year is

**ANSWER:** Choice A

### Q13

CAT 2023 Slot 1 - QA

 Gita sells two objects A and B at the same price such that she makes a profit of 20% on object A and a loss of 10% on object B. If she increases the selling price such that objects A and B are still sold at an equal price and a profit of 10% is made on object B, then the profit made on object A will be nearest to

**ANSWER:** Choice B

### Q14

CAT 2023 Slot 1 - QA

 Arvind travels from town A to town B, and Surbhi from town B to town A, both starting at the same time along the same route. After meeting each other, Arvind takes 6 hours to reach town B while Surbhi takes 24 hours to reach town A. If Arvind travelled at a speed of 54 km/h, then the distance, in km, between town A and town B is

**ANSWER:** 972

### Q15

CAT 2023 Slot 1 - QA

 The amount of job that Amal, Sunil and Kamal can individually do in a day, are in harmonic progression. Kamal takes twice as much time as Amal to do the same amount of job. If Amal and Sunil work for 4 days and 9 days, respectively, Kamal needs to work for 16 days to finish the remaining job. Then the number of days Sunil will take to finish the job working alone, is

**ANSWER:** 27

### Q16

CAT 2023 Slot 1 - QA

 Anil invests Rs. 22000 for 6 years in a certain scheme with 4% interest per annum, compounded half-yearly. Sunil invests in the same scheme for 5 years, and then reinvests the entire amount received at the end of 5 years for one year at 10% simple interest. If the amounts received by both at the end of 6 years are same, then the initial investment made by Sunil, in rupees, is

**ANSWER:** 20808

### Q17

CAT 2023 Slot 1 - QA

 Let \(\mathrm{C}\) be the circle \(x^2+y^2+4 x-6 y-3=0\) and \(\mathrm{L}\) be the locus of the point of intersection of a pair of tangents to \(\mathrm{C}\) with the angle between the two tangents equal to \(60^{\circ}\). Then, the point at which \(L\) touches the line \(x=6\) is

 (6,4)

 (6,8)

 (6,3)

 (6,6)

**ANSWER:** Choice C

### Q18

(6,3)

 CAT 2023 Slot 1 - QA

 A quadrilateral ABCD is inscribed in a circle such that AB : CD = 2 : 1 and BC : AD = 5 : 4. If AC and BD intersect at the point E, then AE : CE equals

 1 : 2

 5 : 8

 8 : 5

 2 : 1

**ANSWER:** Choice C

### Q19

8 : 5

 CAT 2023 Slot 1 - QA

 In a right-angled triangle ABC, the altitude AB is 5 cm, and the base BC is 12 cm. P and Q are two points on BC such that the areas of &Delta;ABP, &Delta;ABQ and &Delta;ABC are in arithmetic progression. If the area of &Delta;ABC is 1.5 times the area of &Delta;ABP, the length of PQ, in cm, is

**ANSWER:** 2

### Q20

CAT 2023 Slot 1 - QA

 For some positive and distinct real numbers \(x, y\) and \(z\), if \(\frac{1}{\sqrt{y}+\sqrt{z}}\) is the arithmetic mean of \(\frac{1}{\sqrt{x}+\sqrt{z}}\) and \(\frac{1}{\sqrt{x}+\sqrt{y}}\), then the relationship which will always hold true, is

 \(\sqrt{x}, \sqrt{y}\) and \(\sqrt{z}\) are in arithmetic progression

 \(\sqrt{x}, \sqrt{z}\) and \(\sqrt{y}\) are in arithmetic progression

 \(y, x\) and \(z\) are in arithmetic progression

 \(x, y\) and \(z\) are in arithmetic progression

**ANSWER:** Choice C

### Q21

\(y, x\) and \(z\) are in arithmetic progression

 CAT 2023 Slot 1 - QA

 The number of all natural numbers up to 1000 with non-repeating digits is

 585

 504

 648

 738

**ANSWER:** Choice D

### Q22

738

 CAT 2023 Slot 1 - QA

 A lab experiment measures the number of organisms at 8 am every day. Starting with 2 organisms on the first day, the number of organisms on any day is equal to 3 more than twice the number on the previous day. If the number of organisms on the \(n^{\text {th }}\) day exceeds one million, then the lowest possible value of \(n\) is

**ANSWER:** 19
