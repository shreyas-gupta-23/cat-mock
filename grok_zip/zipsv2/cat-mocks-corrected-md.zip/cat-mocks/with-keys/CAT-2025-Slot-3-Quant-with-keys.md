# CAT 2025 — Slot 3 — Quantitative Ability (Questions + On-page Answer Key)

Answers are on-page 2IIM **Correct Answer** labels. Not invented.

## Quantitative Ability

- Source file: `2iim-html/CAT-2025-Question-Paper-Slot-3-Quant.txt`
- Page: https://online.2iim.com/CAT-question-paper/CAT-2025-Question-Paper-Slot-3-Quant/
- On-page answers found: 22
- Answer source: 2IIM on-page **Correct Answer** / **Correct Answer Choice** (not invented)

### Q1

CAT 2025 Question Paper | CAT QUANT

 CAT Question Paper | CAT Previous Year Paper

 CAT 2025 Slot 3 - QA

 A triangle ABC is formed with AB = AC = 50 cm and BC = 80 cm. Then, the sum of the lengths, in cm, of all three altitudes of the triangle ABC is

**ANSWER:** 126

### Q2

CAT 2025 Slot 3 - QA

 In an arithmetic progression, if the sum of fourth, seventh and tenth terms is 99, and the sum of the first fourteen terms is 497, then the sum of first five terms is

**ANSWER:** 65

### Q3

CAT 2025 Slot 3 - QA

 ABCD is a trapezium in which AB is parallel to \( \mathrm { DC } , \mathrm { AD } \) is perpendicular to
AB , and \( \mathrm { AB } = 3 \mathrm { DC } \). If a circle inscribed in the trapezium touching all the sides
has a radius of 3 cm , then the area, in sq. cm , of the trapezium is

 \( 36 \sqrt { 2 } \)

 \( 54 \)

 \( 48 \)

 \( 30 \sqrt { 3 } \)

**ANSWER:** Choice C

### Q4

\( 48 \)

 CAT 2025 Slot 3 - QA

 If \( \left( x ^ { 2 } + \frac { 1 } { x ^ { 2 } } \right) = 25 \) and \( x > 0 \), then the value of \( \left( x ^ { 7 } + \frac { 1 } { x ^ { 7 } } \right) \) is

 \( 44859 \sqrt { 3 } \)

 \( 44856 \sqrt { 3 } \)

 \( 44853 \sqrt { 3 } \)

 \( 44850 \sqrt { 3 } \)

**ANSWER:** Choice C

### Q5

\( 44853 \sqrt { 3 } \)

 CAT 2025 Slot 3 - QA

 The monthly sales of a product from January to April were 120, 135, 150 and 165 units, respectively. The cost price of the product was Rs. 240 per unit, and a fixed marked price was used for the product in all the four months. Discounts of 20%, 10% and 5% were given on the marked price per unit in January, February and March, respectively, while no discounts were given in April. If the total profit from January to April was Rs. 138825, then the marked price per unit, in rupees, was

 525

 520

 510

 515

**ANSWER:** Choice A

### Q6

525

 CAT 2025 Slot 3 - QA

 Rahul starts on his journey at 5 pm at a constant speed so that he reaches his destination at 11 pm the same day. However, on his way, he stops for 20 minutes, and after that, increases his speed by 3 km per hour to reach on time. If he had stopped for 10 minutes more, he would have had to increase his speed by 5 km per hour to reach on time. His initial speed, in km per hour, was

 18

 12

 20

 15

**ANSWER:** Choice D

### Q7

15

 CAT 2025 Slot 3 - QA

 The sum of all possible real values of \( x \) for which
\( \log _ { x - 3 } \left( x ^ { 2 } - 9 \right) = \log _ { x - 3 } ( x + 1 ) + 2 \), is

 \( - 3 \)

 \( \sqrt { 33 } \)

 \( \frac { 3 + \sqrt { 33 } } { 2 } \)

 \( 3 \)

**ANSWER:** Choice C

### Q8

\( \frac { 3 + \sqrt { 33 } } { 2 } \)

 CAT 2025 Slot 3 - QA

 The ratio of the number of coins in boxes A and B was 17:7. After 108 coins were shifted from box A to box B, this ratio became 37:20. The number of coins that needs to be shifted further from A to B, to make this ratio 1:1, is

**ANSWER:** 272

### Q9

CAT 2025 Slot 3 - QA

 If \( 12 ^ { 12 x } \times 4 ^ { 24 x + 12 } \times 5 ^ { 2 y } = 8 ^ { 4 z } \times 20 ^ { 12 x } \times 243 ^ { 3 x - 6 } \), where \( x , y \) and \( z \) are
natural numbers, then \( x + y + z \) equals

**ANSWER:** 112

### Q10

CAT 2025 Slot 3 - QA

 Teams A, B, and C consist of five, eight, and ten members, respectively, such that every member within a team is equally productive. Working separately, teams A, B, and C can complete a certain job in 40 hours, 50 hours, and 4 hours, respectively. Two members from team A, three members from team B, and one member from team C together start the job, and the member from team C leaves after 23 hours. The number of additional member(s) from team B, that would be required to replace the member from team C, to finish the job in the next one hour, is

 2

 4

 1

 3

**ANSWER:** Choice A

### Q11

2

 CAT 2025 Slot 3 - QA

 If \( f ( x ) = \left( x ^ { 2 } + 3 x \right) \left( x ^ { 2 } + 3 x + 2 \right) \), then the sum of all real roots of the
equation \( \sqrt { f ( x ) + 1 } = 9701 \), is

 \( 6 \)

 \( - 3 \)

 \( - 6 \)

 \( 3 \)

**ANSWER:** Choice B

### Q12

\( - 3 \)

 CAT 2025 Slot 3 - QA

 The average salary of 5 managers and 25 engineers in a company is 60000 rupees. If each of the managers received 20% salary increase while the salary of the engineers remained unchanged, the average salary of all 30 employees would have increased by 5%. The average salary, in rupees, of the engineers is

 54000

 40000

 45000

 50000

**ANSWER:** Choice A

### Q13

54000

 CAT 2025 Slot 3 - QA

 In a school with 1500 students, each student chooses any one of the streams out of science, arts, and commerce, by paying a fee of Rs 1100, Rs 1000, and Rs 800, respectively. The total fee paid by all the students is Rs 15,50,000. If the number of science students is not more than the number of arts students, then the maximum possible number of science students in the school is

**ANSWER:** 700

### Q14

CAT 2025 Slot 3 - QA

 In a class of 150 students, 75 students chose physics, 111 students chose mathematics and 40 students chose chemistry. All students chose at least one of the three subjects and at least one student chose all three subjects. The number of students who chose both physics and chemistry is equal to the number of students who chose both chemistry and mathematics, and this is half the number of students who chose both physics and mathematics. The maximum possible number of students who chose physics but not mathematics, is

 30

 35

 40

 55

**ANSWER:** Choice B

### Q15

35

 CAT 2025 Slot 3 - QA

 For real values of \( x \), the range of the function \( f ( x ) = \frac { 2 x - 3 } { 2 x ^ { 2 } + 4 x - 6 } \) is

 \( \left( - \infty , \frac { 1 } { 8 } \right] \cup [ 1 , \infty ) \)

 \( \left( - \infty , \frac { 1 } { 8 } \right] \cup \left[ \frac { 1 } { 2 } , \infty \right) \)

 \( \left( - \infty , \frac { 1 } { 4 } \right] \cup \left[ \frac { 1 } { 2 } , \infty \right) \)

 \( \left( - \infty , \frac { 1 } { 4 } \right] \cup [ 1 , \infty ) \)

**ANSWER:** Choice B

### Q16

\( \left( - \infty , \frac { 1 } { 8 } \right] \cup \left[ \frac { 1 } { 2 } , \infty \right) \)

 CAT 2025 Slot 3 - QA

 Ankita walks from A to C through B, and runs back through the same route at a speed that is 40% more than her walking speed. She takes exactly 3 hours 30 minutes to walk from B to C as well as to run from B to A. The total time, in minutes, she would take to walk from A to B and run from B to C, is

**ANSWER:** 444

### Q17

CAT 2025 Slot 3 - QA

 The sum of all the digits of the number \( \left( 10 ^ { 50 } + 10 ^ { 25 } - 123 \right) \), is

 \( 324 \)

 \( 221 \)

 \( 212 \)

 \( 255 \)

**ANSWER:** Choice B

### Q18

\( 221 \)

 CAT 2025 Slot 3 - QA

 In \( \triangle A B C , A B = A C = 12 \mathrm {~cm} \) and \( D \) is a point on side \( B C \) such that \( A D = 8 \mathrm {~cm} \). If \( A D \) is
extended to a point \( E \) such that \( \angle A C B = \angle A E B \), then the length, in cm , of \( A E \) is

 \( 14 \)

 \( 20 \)

 \( 18 \)

 \( 16 \)

**ANSWER:** Choice C

### Q19

\( 18 \)

 CAT 2025 Slot 3 - QA

 The rate of water flow through three pipes A, B and C are in the ratio 4 : 9 : 36. An empty tank can be filled up completely by pipe A in 15 hours. If all the three pipes are used simultaneously to fill up this empty tank, the time, in minutes, required to fill up the entire tank completely is nearest to

 73

 76

 78

 71

**ANSWER:** Choice A

### Q20

73

 CAT 2025 Slot 3 - QA

 For a 4-digit number (greater than 1000), sum of the digits in the thousands, hundreds, and tens places is 15. Sum of the digits in the hundreds, tens, and units places is 16. Also, the digit in the tens place is 6 more than the digit in the units place. The difference between the largest and smallest possible value of the number is

 4078

 3289

 811

 735

**ANSWER:** Choice C

### Q21

811

 CAT 2025 Slot 3 - QA

 Let p, q and r be three natural numbers such that their sum is 900, and r is a perfect square whose value lies between 150 and 500. If p is not less than 0.3q and not more than 0.7q, then the sum of the maximum and minimum possible values of p is

**ANSWER:** 397

### Q22

CAT 2025 Slot 3 - QA

 Vessels A and B contain 60 litres of alcohol and 60 litres of water, respectively. A certain volume is taken out from A and poured into B. After stirring, the same volume is taken out from B and poured into A. If the resultant ratio of alcohol and water in A is 15 : 4, then the volume, in litres, initially taken out from A is

**ANSWER:** 16
