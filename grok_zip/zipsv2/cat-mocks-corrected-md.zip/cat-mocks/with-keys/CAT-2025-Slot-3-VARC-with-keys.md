# CAT 2025 — Slot 3 — VARC (Questions + On-page Answer Key)

Answers are on-page 2IIM **Correct Answer** labels. Not invented.

## VARC

- Source file: `2iim-html/CAT-2025-Question-Paper-Slot-3-VARC.txt`
- Page: https://online.2iim.com/CAT-question-paper/CAT-2025-Question-Paper-Slot-3-VARC/
- On-page answers found: 24
- Answer source: 2IIM on-page **Correct Answer** / **Correct Answer Choice** (not invented)

### Q1

CAT 2025 Question Paper | CAT VARC

 CAT Question Paper | CAT Previous Year Paper

 CAT 2025 Slot 3 - VA RC

 Five jumbled sentences (labelled 1, 2, 3, 4, and 5), related to a topic, are given below. Four of them can be put together to form a coherent paragraph. Identify the odd sentence out and key in the number of that sentence as your answer.

1. The profound emotional impact of music has inspired ongoing research into its relationship with emotions.
2. Music is a universal phenomenon that utilizes a myriad brain resources.
3. This inherent connection to musical expression is deeply intertwined with human identity and experience.
4. The proclivity to create and appreciate music is ubiquitous among humans, permeating daily life across diverse societies.
5. Engaging with music is among the most cognitively demanding tasks a human can undergo, and it is identified across cultures.

**ANSWER:** 1

### Q2

CAT 2025 Slot 3 - VA RC

 Five jumbled sentences (labelled 1, 2, 3, 4, and 5), related to a topic, are given below. Four of them can be put together to form a coherent paragraph. Identify the odd sentence out and key in the number of that sentence as your answer.

1. About half of all the oxygen we breathe is made near the surface of the ocean by phytoplankton that photosynthesize just like land-dwelling plants.
2. A team of scientists that includes Boston University experts has discovered they also produce oxygen on the seafloor.
3. The research team used deep-sea chambers that land on the seafloor and enclose the seawater, sediment, polymetallic nodules, and living organisms.
4. The discovery is a surprise considering oxygen is typically created by plants and organisms with help from the sun—not by rocks on the ocean floor.
5. The deep-sea rocks, called polymetallic nodules, don't only host a surprising number of sea critters.

**ANSWER:** 3

### Q3

The passage below is accompanied by four questions. Based on the passage, choose the best answer for each question.

Once a society accepts a secular mode of creativity, within which the creator replaces God, imaginative transactions assume a self-conscious form. The tribal imagination, on the other hand, is still to a large extent dreamlike and hallucinatory. It admits fusion between various planes of existence and levels of time in a natural and artless manner. In tribal stories, oceans fly in the sky as birds, mountains swim in water as fish, animals speak as humans and stars grow like plants. Spatial order and temporal sequence do not restrict the narrative. This is not to say that tribal creations have no conventions or rules, but simply that they admit the principle of association between emotion and the narrative motif. Thus stars, seas, mountains, trees, men and animals can be angry, sad or happy.

It might be said that tribal artists work more on the basis of their racial and sensory memory than on the basis of a cultivated imagination. In order to understand this distinction, we must understand the difference between imagination and memory. In the animate world, consciousness meets two immediate material realities: space and time. We put meaning into space by perceiving it in terms of images. The image-making faculty is a genetic gift to the human mind—this power of imagination helps us understand the space that envelops us. With regard to time, we make connections with the help of memory; one remembers being the same person today as one was yesterday.

The tribal mind has a more acute sense of time than the sense of space. Somewhere along the history of human civilization, tribal communities seem to have realized that domination over territorial space was not their lot. Thus, they seem to have turned almost obsessively to gaining domination over time. This urge is substantiated in their ritual of conversing with their dead ancestors: year after year, tribals in many parts of India worship terracotta or carved-wood objects representing their ancestors, aspiring to enter a trance in which they can converse with the dead. Over the centuries, an amazingly sharp memory has helped tribals classify material and natural objects into a highly complex system of knowledge. . . .

One of the main characteristics of the tribal arts is their distinct manner of constructing space and imagery, which might be described as 'hallucinatory'. In both oral and visual forms of representation, tribal artists seem to interpret verbal or pictorial space as demarcated by an extremely flexible 'frame'. The boundaries between art and non-art become almost invisible. A tribal epic can begin its narration from a trivial everyday event; tribal paintings merge with living space as if the two were one and the same. And within the narrative itself, or within the painted imagery, there is no deliberate attempt to follow a sequence. The episodes retold and the images created take on the apparently chaotic shapes of dreams. In a way, the syntax of language and the grammar of painting are the same, as if literature were painted words and painting were a song of images.

 CAT 2025 Slot 3 - VA RC

 All of the following, if true, would weaken the passage's claims about the hallucinatory tribal imagination EXCEPT that:

 shamanic rituals involving conversing with the dead often feature in tribal stories.

 tribal art excludes the depiction of the mundane reality of everyday life and objects.

 tribal narratives exhibit a chronological beginning, middle, and end.

 tribal stories depict the natural world in accordance with rational scientific knowledge.

**ANSWER:** Choice A

### Q4

shamanic rituals involving conversing with the dead often feature in tribal stories.

 CAT 2025 Slot 3 - VA RC

 On the basis of the passage, which one of the following explains the main difference between imagination and memory?

 Tribal groups value memory over imagination when it comes to creating art and literature.

 Imagination helps humans make sense of space while memory helps them understand time.

 Imagination needs to be cultivated whereas memory is more intuitive because it is racial and sensory.

 Imagination is a genetic gift to humans whereas memory is central to human consciousness.

**ANSWER:** Choice B

### Q5

Imagination helps humans make sense of space while memory helps them understand time.

 CAT 2025 Slot 3 - VA RC

 Which one of the following best explains why tribals in India worship their dead ancestors?

 Tribals possess a sophisticated knowledge system that is based on memory.

 Tribals show respect to their ancestors through terracotta and carved-wood objects.

 For tribals, conversing with the dead becomes a way of seeking control over time.

 Tribals seek territorial domination over the spaces that they inhabit.

**ANSWER:** Choice C

### Q6

For tribals, conversing with the dead becomes a way of seeking control over time.

 CAT 2025 Slot 3 - VA RC

 Non-human living forms exhibit human emotions in tribal narratives because tribal narratives:

 are rudimentary and underdeveloped.

 abandon all rules and regulations.

 have a self-conscious form.

 accommodate existential fluidity.

**ANSWER:** Choice D

### Q7

accommodate existential fluidity.

 CAT 2025 Slot 3 - VA RC

 The passage given below is followed by four summaries. Choose the option that best captures the essence of the passage.

In investigating memory-beliefs, there are certain points which must be borne in mind. In the first place, everything constituting a memory-belief is happening now, not in that past time to which the belief is said to refer. It is not logically necessary to the existence of a memory-belief that the event remembered should have occurred, or even that the past should have existed at all. There is no logical impossibility in the hypothesis that the world sprang into being five minutes ago, exactly as it then was, with a population that "remembered" a wholly unreal past. There is no logically necessary connection between events at different times; therefore nothing that is happening now or will happen in the future can disprove the hypothesis that the world began five minutes ago. Hence the occurrences which are CALLED knowledge of the past are logically independent of the past; they are wholly analysable into present contents, which might, theoretically, be just what they are even if no past had existed.

 That which we call 'knowledge of the past' is logically independent of the past, since the act of remembering which forms memory-beliefs happens in the present, and does not need to be based in real past occurrences, or even need a past at all.

 When we discuss the concept of memory-beliefs, we must understand that it is not logically impossible for the event remembered to have never happened at all; it could just be a figment of our imagination.

 Memory-beliefs depend wholly on what is remembered in the present, and not on anything else; just as it is not logically impossible that the world came into being five minutes ago, and that everyone now just remembers a wholly imaginary past for it.

 When investigating memory beliefs, we must keep in mind that an actual past event is not a prerequisite for a memory-belief to exist, and that what we know of the past could theoretically not need a past at all.

**ANSWER:** Choice A

### Q8

That which we call 'knowledge of the past' is logically independent of the past, since the act of remembering which forms memory-beliefs happens in the present, and does not need to be based in real past occurrences, or even need a past at all.

 The passage below is accompanied by four questions. Based on the passage, choose the best answer for each question.

Imagine a world in which artificial intelligence is entrusted with the highest moral responsibilities: sentencing criminals, allocating medical resources, and even mediating conflicts between nations. This might seem like the pinnacle of human progress: an entity unburdened by emotion, prejudice or inconsistency, making ethical decisions with impeccable precision. . . .

Yet beneath this vision of an idealised moral arbiter lies a fundamental question: can a machine understand morality as humans do, or is it confined to a simulacrum of ethical reasoning? AI might replicate human decisions without improving on them, carrying forward the same biases, blind spots and cultural distortions from human moral judgment. In trying to emulate us, it might only reproduce our limitations, not transcend them. But there is a deeper concern. Moral judgment draws on intuition, historical awareness and context – qualities that resist formalisation. Ethics may be so embedded in lived experience that any attempt to encode it into formal structures risks flattening its most essential features. If so, AI would not merely reflect human shortcomings; it would strip morality of the very depth that makes ethical reflection possible in the first place.

Still, many have tried to formalise ethics, by treating certain moral claims not as conclusions, but as starting points. A classic example comes from utilitarianism, which often takes as a foundational axiom the principle that one should act to maximise overall wellbeing. From this, more specific principles can be derived, for example, that it is right to benefit the greatest number, or that actions should be judged by their consequences for total happiness. As computational resources increase, AI becomes increasingly well-suited to the task of starting from fixed ethical assumptions and reasoning through their implications in complex situations.

But what, exactly, does it mean to formalise something like ethics? The question is easier to grasp by looking at fields in which formal systems have long played a central role. Physics, for instance, has relied on formalisation for centuries. There is no single physical theory that explains everything. Instead, we have many physical theories, each designed to describe specific aspects of the Universe: from the behaviour of quarks and electrons to the motion of galaxies. These theories often diverge. Aristotelian physics, for instance, explained falling objects in terms of natural motion toward Earth's centre; Newtonian mechanics replaced this with a universal force of gravity. These explanations are not just different; they are incompatible. Yet both share a common structure: they begin with basic postulates – assumptions about motion, force or mass – and derive increasingly complex consequences. . . .

Ethical theories have a similar structure. Like physical theories, they attempt to describe a domain – in this case, the moral landscape. They aim to answer questions about which actions are right or wrong, and why. These theories also diverge and, even when they recommend similar actions, such as giving to charity, they justify them in different ways. Ethical theories also often begin with a small set of foundational principles or claims, from which they reason about more complex moral problems.

 CAT 2025 Slot 3 - VA RC

 Which one of the options below best summarises the passage?

 The passage weighs the appeal of an impersonal AI judge against doubts about moral grasp. It warns that codification can erode case-sensitive judgement, allow axiom-led reasoning at scale, and use a physics analogy to model structured plurality.

 The passage rejects formal methods in principle. It holds that moral judgement cannot be expressed in disciplined terms and concludes that AI should not serve in courts, medicine, or diplomacy under any conditions.

 The passage weighs the appeal of an impersonal AI judge against doubts about moral grasp. It claims codified schemes retain case nuance at scale and uses a physics analogy to predict convergence on a unified framework.

 The passage highlights administrative gains from automation. It treats reproducing human moral judgement as progress and argues that, as computational resources increase, AI can be responsible for decision-making across varied institutional settings.

**ANSWER:** Choice A

### Q9

The passage weighs the appeal of an impersonal AI judge against doubts about moral grasp. It warns that codification can erode case-sensitive judgement, allow axiom-led reasoning at scale, and use a physics analogy to model structured plurality.

 CAT 2025 Slot 3 - VA RC

 Choose the one option below that comes closest to being the opposite of "utilitarianism".

 The policy was cast as deontological ethics, selecting the option that delivered the highest total benefit to citizens while presenting duty as a secondary consideration in public decision-making.

 The authors advocated an absolutist stance, following exceptionless rules regardless of outcomes and evaluating choices by broadest societal benefit.

 The committee adopted a non-egoist framework, ranking policies by their contribution to overall social welfare and treating self-interest as a derivative concern within institutional evaluation.

 The council followed a prioritarian approach, assigning greater moral weight to improvements for the worst-off rather than to maximising total welfare across the affected population.

**ANSWER:** Choice D

### Q10

The council followed a prioritarian approach, assigning greater moral weight to improvements for the worst-off rather than to maximising total welfare across the affected population.

 CAT 2025 Slot 3 - VA RC

 All of the following can reasonably be inferred from the passage EXCEPT:

 with fixed moral starting points and expanding computational resources, the argument forecasts convergence on one ethical system and treats contextual judgement as unnecessary once formal reasoning scales across domains and cultures.

 encoding ethics into fixed structures risks stripping away intuition, history, and context and, if that occurs, the depth that enables reflective judgement disappears. So, machines would mirror our limits rather than exceed them.

 by analogy with physics, compact postulates can yield broad predictions across incompatible theories and ethics can likewise share structure while continuing to diverge rather than close on a single comprehensive framework.

 the appeal of an AI judge rests on immunity to bribery, partiality, and fatigue; yet the text questions whether procedural cleanliness amounts to moral understanding without lived context and interpretive depth.

**ANSWER:** Choice A

### Q11

with fixed moral starting points and expanding computational resources, the argument forecasts convergence on one ethical system and treats contextual judgement as unnecessary once formal reasoning scales across domains and cultures.

 CAT 2025 Slot 3 - VA RC

 The passage compares ethics to physics, where different theories apply to different aspects of a domain and says AI can reason from fixed starting points in complex cases. Which one of the assumptions below must hold for that comparison to guide practice?

 There is a principled way to decide which ethical framework applies to which class of cases, so the system can select the relevant starting points before deriving a recommendation.

 A single master framework replaces all others after translation into one code, so domain boundaries disappear in application.

 Once formalised, all ethical frameworks yield the same recommendation in every case, so selection among them is unnecessary.

 Real cases never straddle different areas, so a case always fits exactly one framework without any overlap whatsoever.

**ANSWER:** Choice A

### Q12

There is a principled way to decide which ethical framework applies to which class of cases, so the system can select the relevant starting points before deriving a recommendation.

 CAT 2025 Slot 3 - VA RC

 The four sentences (labelled 1, 2, 3, and 4) given below, when properly sequenced, would yield a coherent paragraph. Decide on the proper sequencing of the order of the sentences and key in the sequence of the four numbers as your answer.

1. When I ask the distinguished LGBTQ activist and writer Cherie Moraga whether she uses Latinx to refer to herself, she tells me, 'I worked too hard for the "a" in Latina to give it up! I refer to myself as Xicana.'
2. Of our accumulated ethnic population, only a third use Hispanic to identify themselves, a mere 14 percent use Latino, and less than 2 percent recognize Latinx.
3.They have done this, although gender in languages is grammatical, not sociological or sexual, and found in linguistic families throughout the world, from French to Russian to Japanese.
4. More recently, activists seeking to render our name gender neutral, out of respect for our LGBTQ members, have devised yet another name for us: Latinx.

**ANSWER:** 4312

### Q13

CAT 2025 Slot 3 - VA RC

 The given sentence is missing in the paragraph below. Decide where it best fits among the options 1, 2, 3, or 4 indicated in the paragraph.

Sentence: In each of the affected males, the genetic defect was located to the X chromosome in the region of p11-12.

Paragraph: The first suggested evidence of a human genetic mutation associated with aggressive behaviour came from a study in 1993. _____(1)____. Genetic and metabolic studies were conducted on a large Dutch family in which several of the males has a syndrome of borderline mental retardation and abnormal behaviour. _____(2)____. The undesirable behaviour included impulsive aggression, arson and exhibitionism. _____(3)____. A point mutation was identified in the eighth exon of the monoamine oxidase A (MAOA) structural gene which changes glutamine to a termination codon. _____(4)____.

 Option 2

 Option 1

 Option 3

 Option 4

**ANSWER:** Choice C

### Q14

Option 3

 CAT 2025 Slot 3 - VA RC

 The passage given below is followed by four summaries. Choose the option that best captures the essence of the passage.

The return to the tailor is the juxtaposition of three key things for the mindful Indian shopper. The first is the conscious shift away from the homogeneity of fast fashion, the idea of a hundred other people owning exactly the same Zara trench coat or H&M pleated skirt. The second is an actual understanding of the waste behind the fast fashion market, and wanting not to contribute to that anymore. The last is the shift toward customisation and fit—the idea of having imaginations brought to life and to have them fit exactly; without paying exorbitant rates for that bespoke tailoring. For the individual with a keen fashion sense and a genuine desire to move away from the waste and uniformity of fast fashion without paying the premium for it that indie brands would invariably demand, the tailor is the perfect crossover.

 The mindful Indian shoppers are returning to the tailor with a genuine desire to wear clothes which are less expensive, fit them well and are yet fashionable.

 All Indian shoppers are opting for customisation and a shift away from homogeneity over expensive clothing brands like Zara and H&M.

 The mindful Indian shopper is shifting away from convenience and uniformity of clothing, and waste in fashion, to customisation and less exorbitantly priced clothing.

 In the Indian retail market, people believe that expensive branded clothes are wasteful and, therefore, are returning to the neighbourhood tailor.

**ANSWER:** Choice C

### Q15

The mindful Indian shopper is shifting away from convenience and uniformity of clothing, and waste in fashion, to customisation and less exorbitantly priced clothing.

 CAT 2025 Slot 3 - VA RC

 The given sentence is missing in the paragraph below. Decide where it best fits among the options 1, 2, 3, or 4 indicated in the paragraph.

Sentence: Productivity gains, once expected to feed through to broader living standards, now primarily serve to enhance returns to wealth.

Paragraph: Economists now argue that inequality is no longer a by-product of growth but a condition of it. ____ (1) ____. Unlike wages, wealth reflects not just income but also access to assets, favourable institutional conditions – such as low interest rates – and public policies like low taxes and housing shortages. ____ (2) ____. In other words, wealth depends on political choices in ways that income currently does not. It's not just the inequality itself that is the issue but the erosion of mechanisms that once constrained it. ____ (3) ____. Wealth and income inequality are linked, but where wages have stagnated and collective bargaining has weakened, capital income – derived from profits, rents and interest – has been boosted by design. ____ (4) ____.

 Option 3

 Option 1

 Option 4

 Option 2

**ANSWER:** Choice C

### Q16

Option 4

 CAT 2025 Slot 3 - VA RC

 The four sentences (labelled 1, 2, 3, and 4) given below, when properly sequenced, would yield a coherent paragraph. Decide on the proper sequencing of the order of the sentences and key in the sequence of the four numbers as your answer.

1. The effigy of a candidate establishes a personal link between him and the voters; the candidate does not only offer a programme for judgement, he suggests a physical climate, a set of daily choices expressed in a morphology, a way of dressing, a posture.
2. Some candidates for Parliament adorn their electoral prospectus with a portrait; this presupposes that photography has a power to convert which must be analysed.
3. Inasmuch as photography is an ellipse of language and a condensation of an 'ineffable' social whole, it constitutes an anti-intellectual weapon and tends to spirit away 'politics' (that is to say a body of problems and solutions) to the advantage of a 'manner of being', a socio-moral status.
4. Photography tends to restore the paternalistic nature of elections, whose elitist essence has been disrupted by proportional representation and the rule of parties (the Right seems to use it more than the Left).

**ANSWER:** 2143

### Q17

The passage below is accompanied by four questions. Based on the passage, choose the best answer for each question.

In 1982, a raging controversy broke out over a forest act drafted by the Government of India. This act sought to strengthen the already extensive powers enjoyed by the forest bureaucracy in controlling the extraction, disposal and sale of forest produce. It also gave forest officials greater powers to strictly regulate the entry of any person into reserved forest areas. While forest officials justified the act on the grounds that it was necessary to stop the continuing deforestation, it was bitterly opposed by representatives of grassroots organisations, who argued that it was a major violation of the rights of peasants and tribals living in and around forest areas. . . .

The debate over the draft forest act fuelled a larger controversy over the orientation of state forest policy. It was pointed out, for example, that the draft act was closely modelled on its predecessor, the Forest Act of 1878. The earlier Act rested on a usurpation of rights of ownership by the colonial state which had little precedent in precolonial history. It was further argued that the system of forestry introduced by the British—and continued, with little modification, after 1947—emphasised revenue generation and commercial exploitation, while its policing orientation excluded villagers who had the most longstanding claim on forest resources. Critics called for a complete overhaul of forest administration, pressing the government to formulate policy and legislation more appropriate to present needs. . . .

That debate is not over yet. The draft act was shelved, though it has not as yet been formally withdrawn. Meanwhile, the 1878 Act (as modified by an amendment in 1927) continues to be in operation. In response to its critics, the government has made some important changes in forest policy, e.g., no longer treating forests as a source of revenue, and stopping ecologically hazardous practices such as the clearfelling of natural forests. At the same time, it has shown little inclination to meet the major demand of the critics of forest policy—namely, abandoning the principle of state monopoly over forest land by handing over areas of degraded forests to individuals and communities for afforestation.

. . . [The] 1878 Forest Act itself was passed only after a bitter and prolonged debate within the colonial bureaucracy, in which protagonists put forward arguments strikingly similar to those being advanced today. As is well known, the Indian Forest Department owes its origin to the requirements of railway companies. The early years of the expansion of the railway network, c. 1853 onwards, led to tremendous deforestation in peninsular India owing to the railway's requirements of fuelwood and construction timber. Huge quantities of durable timbers were also needed for use as sleepers across the newly laid tracks. Inexperienced in forestry, the British called in German experts to commence systematic forest management. The Indian Forest Department was started in 1864, with Dietrich Brandis, formerly a Lecturer at Bonn, as the first Inspector General of Forests. The new department needed legislative backing to function effectively, and in the following year, 1865, the first forest act was passed. . . .

 CAT 2025 Slot 3 - VA RC

 According to the passage, which one of the following reforms is yet to happen in India's forest policies?

 A ban on deforestation.

 Recognising the significance of forests to ecology.

 Involving local people in cultivating forests.

 Recognising the state's claim to forest land use.

**ANSWER:** Choice C

### Q18

Involving local people in cultivating forests.

 CAT 2025 Slot 3 - VA RC

 According to the passage, which one of the following is not common to the 1878 Forest Act and the 1982 draft forest act?

 Both resulted in large scale deforestation.

 Both sought to establish the state's monopoly over forest resources.

 Both reflect a colonial mindset.

 Both sparked controversy and debate among the various stakeholders.

**ANSWER:** Choice A

### Q19

Both resulted in large scale deforestation.

 CAT 2025 Slot 3 - VA RC

 Which one of the following best encapsulates the reason for the "raging controversy" developing into a "larger controversy"?

 The 1982 draft forest act was unjustifiably defended by forest officials in the face of bitter opposition by grassroots organisations.

 The 1982 draft forest act replicated colonial measures of control and regulation of forest resources.

 The 1982 draft forest act violated the rights of tribals and peasants who lived in and around forest areas.

 The 1982 draft forest act further enabled the commercial exploitation of forest resources by the forest bureaucracy.

**ANSWER:** Choice B

### Q20

The 1982 draft forest act replicated colonial measures of control and regulation of forest resources.

 CAT 2025 Slot 3 - VA RC

 All of the following, if true, would weaken the narrative presented in the passage EXCEPT that:

 the timber requirement for railway works in nineteenth century India was met through import from China, in exchange for spices.

 nineteenth century German forestry experts were infamous for violating the rights of indigenous communities that lived in forest regions.

 before British rule, peasants and tribal groups were denied access to forest resources by Indian rulers and their administrations.

 certain tribal groups in India are responsible for climate change because their sustenance has historically depended on mass scale deforestation.

**ANSWER:** Choice B

### Q21

nineteenth century German forestry experts were infamous for violating the rights of indigenous communities that lived in forest regions.

 The passage below is accompanied by four questions. Based on the passage, choose the best answer for each question.

Over the course of the twentieth century, humans built, on average, one large dam a day, hulking structures of steel and concrete designed to control flooding, facilitate irrigation, and generate electricity. Dams were also lucrative contracts, large-scale employers, and the physical instantiation of a messianic drive to conquer territories and control nature. Some of the results of that drive were charismatic mega-infrastructure—the Hoover on the Colorado River or the Aswan on the Nile—but most of the tens of thousands of dams that dot the Earth's landscape have drawn little attention. These are the smaller, though not inconsequential, barriers that today impede the flow of water on nearly two-thirds of the world's large waterways. Chances are, what your map calls a "lake" is actually a reservoir, and that thin blue line that emerges from it once flowed very differently.

Damming a river is always a partisan act. Even when explicit infrastructure goals—irrigation, flood control, electrification—were met, other consequences were significant and often deleterious. Across the world, river control displaced millions of people, threatening livelihoods, foodways, and cultures. In the western United States, dams were often an instrument of colonialism, used to dispossess Indigenous people and subsidize settler agriculture. And as dams slowed the flow of water, inhibited the movement of nutrients, and increased the amount of toxic algae and other parasites, they snuffed out entire river ecologies. Declining fish populations are the most evident effect, but dams also threaten a host of other animals—from birds and reptiles to fungi and plants—with extinction. Every major dam, then, is also a sacrifice zone, a place where lives, livelihoods, and ways of life are eliminated so that new sorts of landscapes can support water-intensive agriculture and cities that sprout downstream of new reservoirs.

Such sacrifices have been justified as offerings at the temples of modernity. Justified by—and for—whom, though? Over the course of the twentieth century, rarely were the costs and benefits weighed thoughtfully and decided democratically. As Kader Asmal, chair of the landmark 2000 World Commission on Dams, concluded, "There have been precious few, if any, comprehensive, independent analyses as to why dams came about, how dams perform over time, and whether we are getting a fair return from our $2 trillion investment." A quarter-century later, Asmal's words ring ever truer. A litany of dams built in the mid-twentieth century are approaching the end of their expected lives, with worrying prospects for their durability. Droughts, magnified and multiplied by the effects of climate change, have forced more and more to run below capacity. If ever there were a time to rethink the mania for dams, it would be now.

There is some evidence that a combination of opposition, alternative energy sources, and a lack of viable projects has slowed the construction of major dams. But a wave of recent and ongoing construction, from India and China to Ethiopia and Canada, continues to tilt the global balance firmly in favor of water impoundment.

 CAT 2025 Slot 3 - VA RC

 Which one of the following sets of terms is closest to mapping the key arguments of the passage?

 Mega-infrastructure – Sacrifice zone – Worshipping modernity – Water impoundment

 Partisan act – Threatened livelihoods – Toxic algae – Quarter century

 Lucrative contracts – Sacrifice zone – Expected lives – Global balance

 Physical instantiation – Partisan act – Decided democratically – Alternative energy

**ANSWER:** Choice A

### Q22

Mega-infrastructure – Sacrifice zone – Worshipping modernity – Water impoundment

 CAT 2025 Slot 3 - VA RC

 The word "instantiation" is used in the first paragraph. Which one of the following pairs of terms would be the best substitute for it in the context of its usage in the paragraph?

 Durability and timeliness

 Concreteness and viability

 Development and construction

 Exemplification and manifestation

**ANSWER:** Choice D

### Q23

Exemplification and manifestation

 CAT 2025 Slot 3 - VA RC

 All of the following statements may be considered valid inferences from the passage EXCEPT that:

 processes of colonisation have used dam-building to make people vacate their territories.

 smaller, though not inconsequential, dams are safer than large dam projects.

 despite increasing evidence of opposition to dams as well as alternatives to them, they continue to be built.

 dam-building has proved to be an extremely costly enterprise that may not be justifiable.

**ANSWER:** Choice B

### Q24

smaller, though not inconsequential, dams are safer than large dam projects.

 CAT 2025 Slot 3 - VA RC

 What does the author wish to communicate by referring to the Hoover and Aswan dams in the first paragraph?

 The Colorado and Nile rivers may be seen as thin blue lines on a map.

 By building dams like the Hoover and Aswan dams, large-scale employers became messianic figures.

 The designers and builders of these mega-structures were highly charismatic individuals.

 The drive to control nature is evident not only in mega-infrastructures like the Hoover and Aswan dams, but in smaller dams as well.

**ANSWER:** Choice D
