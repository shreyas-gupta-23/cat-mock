# CAT 2024 — Slot 3 — VARC (Questions + On-page Answer Key)

Answers are on-page 2IIM **Correct Answer** labels. Not invented.

## VARC

- Source file: `2iim-html/CAT-2024-Question-Paper-Slot-3-VARC.txt`
- Page: https://online.2iim.com/CAT-question-paper/CAT-2024-Question-Paper-Slot-3-VARC/
- On-page answers found: 24
- Answer source: 2IIM on-page **Correct Answer** / **Correct Answer Choice** (not invented)

### Q1

CAT 2024 Question Paper | CAT VARC

 CAT Question Paper | CAT Previous Year Paper

 CAT 2024 Slot 3 - VA RC

 The passage given below is followed by four alternate summaries. Choose the option that
 best captures the essence of the passage.

Lyric poetry is a genre of private
 meditation rather than public commitment. The impulse in Marxism toward changing a
 society deemed unacceptable in its basic design would seem to place demands on lyric
 poetry that such poetry, with its tendency toward the personal, the small scale, and the
 idiosyncratic, could never answer. There is within Marxism, however, also a strand of
 thought that would locate in lyric poetry alternative modes of perception and
 description that call forth a vision of worlds at odds with a repressive reality or that
 draw attention to the workings of ideology within the hegemonic culture. The poetic
 imagination may indeed deflect larger social concerns, but it may also be implicitly
 critical and utopian.

 Marxism has internal contradictions due to which one strand of Marxism sees
 no merit in lyric poetry while another appreciates the alternative modes of
 perception in poetry.

 The focus of lyric poetry is largely personal while that of Marxism is
 bringing change in society. Unless the difference is resolved, poetry will
 remain largely utopian.

 Marxism makes unreasonable demands on lyric poetry. However, lyric poetry
 has its own merits that are largely ignored by Marxism due to its personal
 nature.

 The focus of lyric poetry as personal may not seem compatible with Marxism.
 However, it is possible to envisage lyric poetry as a symbol of resistance
 against an oppressive culture.

**ANSWER:** Choice D

### Q2

The focus of lyric poetry as
 personal may not seem compatible with Marxism. However, it is possible
 to envisage lyric poetry as a symbol of resistance against an oppressive
 culture.

 CAT 2024 Slot 3 - VA RC

 There is a sentence that is missing in the paragraph below. Look at the paragraph and
 decide where (option 1, 2, 3, or 4) the following sentence would best
 fit.

Sentence: Taken outside the village of Trang Bang on June 8, 1972, the
 picture captured the trauma and indiscriminate violence of a conflict that claimed, by
 some estimates, a million or more civilian lives.

Paragraph: The horrifying
 photograph of children fleeing a deadly napalm attack has become a defining image not
 only of the Vietnam War but the 20 th century. ___(1)___. Dark smoke billowing
 behind them, the young subjects' faces are painted with a mixture of terror, pain and
 confusion. ___(2)___. Soldiers from the South Vietnamese army's 25 th Division
 follow helplessly behind. ___(3)___. The picture was officially titled "The Terror of
 War," but the photo is better known by the nickname given to naked 9-year-old at its
 centre "Napalm Girl". ___(4)___.

 Option 4

 Option 3

 Option 1

 Option 2

**ANSWER:** Choice B

### Q3

Option 3

 CAT 2024 Slot 3 - VA RC

 The passage given below is followed by four alternate summaries. Choose the option that
 best captures the essence of the passage.

Humans have managed to tweak the
 underlying biology of various plants and animals to produce high-tech crops and
 microbes. But regulating these entities is complicated, as the framework of policies and
 procedures are outdated and not flexible enough to adapt to emerging technology. The
 question is whether regulation will ever be able to keep up with human innovation, to
 regulate living things, which are apt to be unpredictable and unique; to capture all the
 potential risks when new biological entities are introduced, or when they pass on
 variations of their genes?

 A new framework of rules and procedures for regulating the most recent
 research emerging from biotechnology is urgently needed, to keep up with
 this rapidly changing discipline.

 Current regulation of biotechnology is outdated, but it is debatable if we
 can create a framework, imaginative and flexible, to cover all contingencies
 in this fast-changing area.

 The problem with formulating regulation for innovation in the scientific
 arena it that it is impossible to imagine the outcomes or risks related to
 the outcomes of all the research.

 The mercurial nature of biological entities calls for scientists to shape
 the regulations governing emerging technology, with regular calibration to
 handle variations in the field.

**ANSWER:** Choice B

### Q4

Current regulation of biotechnology
 is outdated, but it is debatable if we can create a framework,
 imaginative and flexible, to cover all contingencies in this
 fast-changing area.

 The passage below is accompanied by four questions. Based on the passage,
 choose the best answer for each question.

There is a group in the space community
 who view the solar system not as an opportunity to expand human potential but as a nature
 preserve, forever the provenance of an elite group of scientists and their sanitary robotic
 probes. These planetary protection advocates [call] for avoiding "harmful contamination" of
 celestial bodies. Under this regime, NASA incurs great expense sterilizing robotic probes in
 order to prevent the contamination of entirely theoretical biospheres. . .
 .

Transporting bacteria would matter if Mars were the vital world once imagined
 by astronomers who mistook optical illusions for canals. Nobody wants to expose Martians to
 measles, but sadly, robotic exploration reveals a bleak, rusted landscape, lacking oxygen
 and flooded with radiation ready to sterilize any Earthly microbes. Simple life might exist
 underground, or down at the bottom of a deep canyon, but it has been very hard to find with
 robots. . . . The upsides from human exploration and development of Mars clearly outweigh
 the welfare of purely speculative Martian fungi. . . .

The other likely targets
 of human exploration, development, and settlement, our moon and the asteroids, exist in a
 desiccated, radiation-soaked realm of hard vacuum and extreme temperature variations that
 would kill nearly anything. It's also important to note that many international competitors
 will ignore the demands of these protection extremists in any case. For example, China
 recently sent a terrarium to the moon and germinated a plant seed—with, unsurprisingly, no
 protest from its own scientific community. In contrast, when it was recently revealed that a
 researcher had surreptitiously smuggled super-resilient microscopic tardigrades aboard the
 ill-fated Israeli Beresheet lunar probe, a firestorm was unleashed within the space
 community. . . .

NASA's previous human exploration efforts made no serious
 attempt at sterility, with little notice. As the Mars expert Robert Zubrin noted in the
 National Review, U.S. lunar landings did not leave the campsites cleaner than they found it.
 Apollo's bacteria-infested litter included bags of feces. Forcing NASA's proposed Mars
 exploration to do better, scrubbing everything and hauling out all the trash, would destroy
 NASA's human exploration budget and encroach on the agency's other directorates, too.
 Getting future astronauts off Mars is enough of a challenge, without trying to tote weeks of
 waste along as well.

A reasonable compromise is to continue on the course laid
 out by the U.S. government and the National Research Council, which proposed a system of
 zones on Mars, some for science only, some for habitation, and some for resource
 exploitation. This approach minimizes contamination, maximizes scientific exploration . . .
 Mars presents a stark choice of diverging human futures. We can turn inward, pursuing ever
 more limited futures while we await whichever natural or manmade disaster will eradicate our
 species and life on Earth. Alternatively, we can choose to propel our biosphere further into
 the solar system, simultaneously protecting our home planet and providing a backup plan for
 the only life we know exists in the universe. Are the lives on Earth worth less than some
 hypothetical microbe lurking under Martian rocks?

 CAT 2024 Slot 3 - VA RC

 The author mentions all of the following reasons to dismiss concerns about contaminating
 Mars EXCEPT:

 the lack of evidence of living organisms on Mars makes possible
 contamination from earthly microbes a moot point.

 the use of similar probes on astronomical bodies like the moon have had
 little effect on the environment.

 efforts to contain contamination on Mars are likely to be derailed as
 competitor countries may not follow similar restrictions.

 earlier explorations have already contaminated pristine space environments.

**ANSWER:** Choice B

### Q5

the use of similar probes on
 astronomical bodies like the moon have had little effect on the
 environment.

 CAT 2024 Slot 3 - VA RC

 The author's overall tone in the first paragraph can be described as

 approving of the amount of money NASA spends to restrict the spread of
 contamination in space.

 sceptical about the excessive efforts to sanitise planets where life has not
 yet been proven to exist.

 indifferent to the elitism of a few scientists aiming to corner space
 exploration.

 equivocal about the reasons extended by the group of scientists seeking to
 limit space exploration.

**ANSWER:** Choice B

### Q6

sceptical about the excessive
 efforts to sanitise planets where life has not yet been proven to
 exist.

 CAT 2024 Slot 3 - VA RC

 The author is unlikely to disagree with any of the following EXCEPT:

 the proposal for a zonal segregation of the Martian landscape into regions
 for different purposes.

 that while NASA's earlier missions were not ideal in their approach to space
 contamination, they likely did no grave damage.

 space contamination should be minimised until the possibility of life on the
 astronomical body being explored is ruled out.

 the exorbitant costs of continuing to keep the space environment pristine
 may be unsustainable.

**ANSWER:** Choice C

### Q7

space contamination should be
 minimised until the possibility of life on the astronomical body being
 explored is ruled out.

 CAT 2024 Slot 3 - VA RC

 The contrasting reactions to the Chinese and Israeli "contaminations" of lunar space

 are evidence of China's reasonable approach towards space contamination.

 are valid as the contamination of the lunar environment from animal sources
 is far greater than from plants.

 reveal global biases prevalent in attitudes towards different countries.

 indicate that national scientists may have different sensitivities to issues
 of biosphere protection.

**ANSWER:** Choice D

### Q8

indicate that national scientists
 may have different sensitivities to issues of biosphere
 protection.

 CAT 2024 Slot 3 - VA RC

 There is a sentence that is missing in the paragraph below. Look at the paragraph and
 decide where (option 1, 2, 3, or 4) the following sentence would best
 fit.

Sentence: Many have had to leave their homes behind, with more than 1.3
 million people being displaced due to the drought.

Passage: Somalia has been
 dealing with an enormous humanitarian catastrophe, driven by the longest and most severe
 drought the country has experienced in at least 40 years. ___(1)___. Five consecutive
 rainy seasons have failed, causing more than 8 million people - almost half of the
 country's population – to experience acute food insecurity. ___(2)___. More than 43,000
 people are believed to have lost their lives, with half of the lives lost likely being
 children under five. The damage the drought has caused is far-reaching. ___(3)___.
 Farmers have lost all their agricultural income, while pastoralists have lost more than
 3 million livestock, impoverishing entire communities, and leaving them on the brink of
 famine. ___(4)___. Some, like the pastoralists, may never be able to go back as their
 livelihoods have been irreversibly wiped out.

 Option 4

 Option 3

 Option 1

 Option 2

**ANSWER:** Choice A

### Q9

Option 4

 The passage below is accompanied by four questions. Based on the passage,
 choose the best answer for each question.

Languages become endangered and die out
 for many reasons. Sadly, the physical annihilation of communities of native speakers of a
 language is all too often the cause of language extinction. In North America, European
 colonists brought death and destruction to many Native American communities. This was
 followed by US federal policies restricting the use of indigenous languages, including the
 removal of native children from their communities to federal boarding schools where native
 languages and cultural practices were prohibited. As many as 75 percent of the languages
 spoken in the territories that became the United States have gone extinct, with slightly
 better language survival rates in Central and South America . . .

Even without
 physical annihilation and prohibitions against language use, the language of the "dominant"
 cultures may drive other languages into extinction; young people see education, jobs,
 culture and technology associated with the dominant language and focus their attention on
 that language. The largest language "killers" are English, Spanish, Portuguese, French,
 Russian, Hindi, and Chinese, all of which have privileged status as dominant languages
 threatening minority languages.

When we lose a language, we lose the worldview,
 culture and knowledge of the people who spoke it, constituting a loss to all humanity.
 People around the world live in direct contact with their native environment, their habitat.
 When the language they speak goes extinct, the rest of humanity loses their knowledge of
 that environment, their wisdom about the relationship between local plants and illness,
 their philosophical and religious beliefs as well as their native cultural expression (in
 music, visual art and poetry) that has enriched both the speakers of that language and
 others who would have encountered that culture. . . .

As educators deeply
 immersed in the liberal arts, we believe that educating students broadly in all facets of
 language and culture . . . yields immense rewards. Some individuals educated in the liberal
 arts tradition will pursue advanced study in linguistics and become actively engaged in
 language preservation, setting out for the Amazon, for example, with video recording
 equipment to interview the last surviving elders in a community to record and document a
 language spoken by no children.

Certainly, though, the vast majority of students
 will not pursue this kind of activity. For these students, a liberal arts education is
 absolutely critical from the twin perspectives of language extinction and global
 citizenship. When students study languages other than their own, they are sensitized to the
 existence of different cultural perspectives and practices. With such an education, students
 are more likely to be able to articulate insights into their own cultural biases, be more
 empathetic to individuals of other cultures, communicate successfully across linguistic and
 cultural differences, consider and resolve questions in a way that reflects multiple
 cultural perspectives, and, ultimately extend support to people, programs, practices, and
 policies that support the preservation of endangered languages.

There is ample
 evidence that such preservation can work in languages spiraling toward extinction. For
 example, Navajo, Cree and Inuit communities have established schools in which these
 languages are the language of instruction and the number of speakers of each has increased.

 CAT 2024 Slot 3 - VA RC

 The author believes that a liberal arts education combined with participation in language
 preservation empower students in all of the following ways EXCEPT that they will

 develop a better understanding of their own culture.

 learn different languages.

 establish schools to preserve languages spiralling towards extinction.

 overcome cultural barriers to communication.

**ANSWER:** Choice C

### Q10

establish schools to preserve
 languages spiralling towards extinction.

 CAT 2024 Slot 3 - VA RC

 It can be inferred from the passage that it is likely South America had a slightly better
 language survival rate than North America for all of the following reasons EXCEPT:

 European colonists allowed children of native speakers to stay at home with
 their families.

 not many native speakers were killed by European colonists.

 the colonial government was unable to mainstream the locals.

 locals were provided job opportunities in the colonial administration.

**ANSWER:** Choice D

### Q11

locals were provided job
 opportunities in the colonial administration.

 CAT 2024 Slot 3 - VA RC

 Which one of the following hypothetical scenarios, if true, would most strongly undermine
 the central ideas of the passage?

 A liberal arts education requires that, in addition to being fluent in
 English, students gain fluency in two of the top five most spoken languages
 globally.

 Schools that teach endangered languages can preserve the language only for a
 generation.

 Recording a dying language that has only a few remaining speakers freezes it
 in time: it stops evolving further.

 Most liberal arts students will pursue jobs in publishing and human resource
 management rather than doctorates in linguistics.

**ANSWER:** Choice A

### Q12

A liberal arts education requires
 that, in addition to being fluent in English, students gain fluency in
 two of the top five most spoken languages globally.

 CAT 2024 Slot 3 - VA RC

 In the context of the passage, which one of the following hypothetical scenarios, if
 true, is NOT an example of the kind of loss that occurs when a language becomes extinct?

 The Inuits of Alaska have 35 different words to describe the texture of
 snow. When the language becomes extinct, we will lose that understanding of
 nature.

 The Lamkangs of Manipur have only 3 remaining native speakers of the
 language. When they die, we will lose one more group from the government
 list of indigenous tribes.

 The Andamanese language has a word to describe someone who has lost a
 step-sister. When the language dies, we will lose the concept of the word
 and the emotions it evokes.

 The Nicobarese language describes 20 different moods of the ocean. By the
 time the last speaker is educated in a Central Board school, they will have
 forgotten their language.

**ANSWER:** Choice B

### Q13

The Lamkangs of Manipur have only 3
 remaining native speakers of the language. When they die, we will lose
 one more group from the government list of indigenous tribes.

 CAT 2024 Slot 3 - VA RC

 There is a sentence that is missing in the paragraph below. Look at the paragraph and
 decide where (option 1, 2, 3, or 4) the following sentence would best
 fit.

Sentence: This reality is putting stress on employees who have to pay
 for transport, desk lunches, more childcare, clothing and that after-work socialisation
 – costs they haven't incurred for nearly two years.

Paragraph: ___(1)___.
 Prices are rising at their fastest rate in 40 years, consequently,
 return-to-office-related costs have shot up – think petrol and food, for instance.
 ___(2)___. Yet wages haven't kept up with inflation – even despite the salary growth
 many workers have enjoyed during a favourable pandemic labour market. ___(3)___. This is
 especially jarring for workers who were able to save during remote work, when these
 expenditures weren't a factor. ___(4)___. In April 2022, Umus, a London university
 lecturer, told BBC Worklife that they were spending nearly a quarter of what they made
 every day on return-to-work costs.

 Option 2

 Option 3

 Option 1

 Option 4

**ANSWER:** Choice B

### Q14

Option 3

 The passage below is accompanied by four questions. Based on the passage,
 choose the best answer for each question.

Moutai has been the global booze
 sensation of the decade. A bottle of its Flying Fairy which sold in the 1980s for the
 equivalent of a dollar now retails for $400. Moutai's listed shares have soared by almost
 600% in the past five years, outpacing the likes of Amazon. . . .

It does this
 while disregarding every Western marketing mantra. It is not global, has meagre digital
 sales and does not appeal to millennials. It scores pitifully on environmental, social and
 governance measures. In the Boy Scout world of Western business it would leave a bad taste,
 in more ways than one.

Moutai owes its intoxicating success to three factors—not
 all of them easy to emulate. First, it profits from Chinese nationalism. Moutai is known as
 the "national liquor". It was used to raise spirits and disinfect wounds in Mao's Long
 March. It was Premier Zhou Enlai's favourite tipple, shared with Richard Nixon in 1972. Its
 centuries-old craftsmanship—it is distilled eight times and stored for years in earthenware
 jars—is a source of national pride. It also claims to be hangover-proof, which would make it
 an invention to rival gunpowder....

Second, it chose to serve China's super-rich
 rather than its middle class. Markets are littered with the corpses of firms that could not
 compete in the cut-throat battle for Chinese middle-class wallets. And the country's premium
 market is massive—at 73m-strong, bigger than the population of France, notes Euan McLeish of
 Bernstein, an investment firm, and still less crowded with prestige brands than advanced
 economies. Moutai is to these well-heeled drinkers what vintage champagne is to the rest of
 the world.....

Third, Moutai looks beyond affluent millennials and digital
 natives. The elderly and the middle-aged, it found, can be just as lucrative. Its biggest
 market now is (male) drinkers in their mid-30s. Many have no siblings, thanks to four
 decades of China's one-child policy—which also means their elderly parents can splash out on
 weddings and banquets. Moutai is often a guest of honour.

Moutai has succeeded
 thanks to nationalism, elitism and ageism, in other words—not in spite of this unholy
 trinity. But it faces risks. The government is its largest shareholder—and a meddlesome one.
 It appears to want prices to remain stable. Exorbitantly priced booze is at odds with its
 professed socialist ideals. Yet minority investors—including many foreign funds—lament that
 Moutai's wholesale price is a third of what it sells for in shops. Raising it could boost
 the company's profits further. Instead, in what some see as a travesty of corporate
 governance, its majority owner has plans to set up its own sales channel.....

In
 the long run, its biggest risk may be millennials. As they grow older, health concerns,
 work-life balance and the desire for more wholesome pursuits than binge-drinking may curb
 the "Ganbei!" toasting culture [heavy drinking] on which so much of the demand for Moutai
 rests. For the time being, though, the party goes on.

 CAT 2024 Slot 3 - VA RC

 Which one of the following is both a reason for Moutai's success as well as a possible
 threat to that success?

 Its appeal to the rich.

 Government involvement in its business.

 Its appeal to the older age group.

 Chinese love of liquor filled celebration.

**ANSWER:** Choice C

### Q15

Its appeal to the older age
 group.

 CAT 2024 Slot 3 - VA RC

 In the context of the passage we can infer that to succeed in the liquor industry in
 China, a marketing firm must consider all of the following factors affecting the Chinese
 liquor market EXCEPT that

 the competition for winning over the middle class is very stiff.

 there is money to be made from marketing to the middle class.

 the government may control the pricing of products.

 there are few competitors to meet the demands of high end liquor consumers.

**ANSWER:** Choice B

### Q16

there is money to be made from
 marketing to the middle class.

 CAT 2024 Slot 3 - VA RC

 In the context of the passage, it is most likely that the author refers to Moutai's
 marketing strategy as "the unholy trinity" because

 it profits from Chinese nationalist feelings.

 it exposes the firm to long term risks.

 it contradicts the Western strategy of marketing.

 there is nothing holy about marketing techniques for liquor.

**ANSWER:** Choice C

### Q17

it contradicts the Western strategy
 of marketing.

 CAT 2024 Slot 3 - VA RC

 The phrase "would make it an invention to rival gunpowder" has been used in the passage
 in a sense that is

 substantive.

 metaphorical.

 literal.

 synonymical.

**ANSWER:** Choice B

### Q18

metaphorical.

 CAT 2024 Slot 3 - VA RC

 Five jumbled up sentences (labelled 1, 2, 3, 4 and 5), related to a topic, are given
 below. Four of them can be put together to form a coherent paragraph. Identify the odd
 sentence and key in the number of that sentence as your answer.

1. To create
 a synapse, the neuron has specialized structures, often seen as tiny swellings, at its
 terminal end of the axon where it stores the chemicals that are emitted to transmit a
 signal to the next neuron.
2. This fetal warm-up act—the soldering of neural
 connections before the eyes actually function—is crucial to the performance of the
 visual system.
3. The reasons for this paring back of synapses is a mystery, but
 synaptic pruning is thought to sharpen and reinforce the "correct" synapses, while
 removing the weak and unnecessary ones.
4. Neural connections between the eyes and
 the brain are formed long before birth, establishing the wiring and the circuitry that
 allow a child to begin visualizing the world the minute she emerges from the
 womb.
5. During this rehearsal period, synapses—points of chemical
 connection—between nerve cells are generated in great excess, only to be pruned back
 during later development.

**ANSWER:** 1

### Q19

CAT 2024 Slot 3 - VA RC

 Five jumbled up sentences (labelled 1, 2, 3, 4 and 5), related to a topic, are given
 below. Four of them can be put together to form a coherent paragraph. Identify the odd
 sentence and key in the number of that sentence as your answer.

1. Part of
 the appeal of forecasting is not just that it seems to work, but that you don't seem to
 need specialized expertise to succeed at it.
2. The tight connection between
 forecasting and building a model of the world helps explain why so much of the early
 interest in the idea came from the intelligence community.
3. This was true even
 though the latter had access to classified intelligence.
4. One frequently cited
 study found that accurate forecasters' predictions of geopolitical events, when
 aggregated using standard scientific methods, were more accurate than the forecasts of
 members of the US intelligence community who answered the same questions in a
 confidential prediction market.
5. The aggregated opinions of non-experts doing
 forecasting have proven to be a better guide to the future than the aggregated opinions
 of experts.

**ANSWER:** 2

### Q20

CAT 2024 Slot 3 - VA RC

 The passage given below is followed by four alternate summaries. Choose the option that
 best captures the essence of the passage.

When the tradwife puts on that
 georgic, pinstriped dress, she is not just admiring the visual cues of a fantastical
 past. She takes these dreams of storybook bliss literally, tracing them backward in time
 until she reaches a logical conclusion that satisfies her. And by doing so, she ends up
 delivering an unhappy reminder of just how much our lives consist of artifice and
 playacting. The tradwife outrages people because of her deliberately regressive ideals.
 And yet her behaviour is, on some level, indistinguishable from the nontradwife's. The
 tradwife's trollish genius is to beat us at our own dress-up game. By insisting that the
 idyllic cottage daydream should be real, right down to the primitive gender roles, she
 leaves others feeling hollow, cheated. The hullabaloo and headaches she causes may be
 the price we pay for taking too many things at face value: our just deserts, served
 Instagram-perfect by a manicured hand on a gorgeous ceramic dish, with fat,
 mouthwatering maraschino cherries on top.

 The tradwife, with her vintage dress and traditional roles, highlights the
 superficiality of modern life and challenges current societal norms.

 The tradwife's commitment to outdated gender roles and retro fashion
 critiques the superficiality of today's societal ideals.

 By promoting an idealized past, the tradwife exposes the artifice of
 contemporary values and mocks societal norms.

 The tradwife's vintage dress and adherence to traditional roles reveal the
 artificial nature of modern life and its superficial values.

**ANSWER:** Choice A

### Q21

The tradwife, with her vintage
 dress and traditional roles, highlights the superficiality of modern
 life and challenges current societal norms.

 The passage below is accompanied by four questions. Based on the passage,
 choose the best answer for each question.

Fears of artificial intelligence (AI)
 have haunted humanity since the very beginning of the computer age. Hitherto these fears
 focused on machines using physical means to kill, enslave or replace people. But over the
 past couple of years new AI tools have emerged that threaten the survival of human
 civilisation from an unexpected direction. AI has gained some remarkable abilities to
 manipulate and generate language, whether with words, sounds or images. AI has thereby
 hacked the operating system of our civilisation.

Language is the stuff almost all
 human culture is made of. Human rights, for example, aren't inscribed in our DNA. Rather,
 they are cultural artefacts we created by telling stories and writing laws. Gods aren't
 physical realities. Rather, they are cultural artefacts we created by inventing myths and
 writing scriptures….What would happen once a non-human intelligence becomes better than the
 average human at telling stories, composing melodies, drawing images, and writing laws and
 scriptures? When people think about Chatgpt and other new AI tools, they are often drawn to
 examples like school children using AI to write their essays. What will happen to the school
 system when kids do that? But this kind of question misses the big picture. Forget about
 school essays. Think of the next American presidential race in 2024, and try to imagine the
 impact of AI tools that can be made to mass-produce political content, fake-news stories and
 scriptures for new cults…

Through its mastery of language, AI could even form
 intimate relationships with people, and use the power of intimacy to change our opinions and
 worldviews. Although there is no indication that AI has any consciousness or feelings of its
 own, to foster fake intimacy with humans it is enough if the AI can make them feel
 emotionally attached to it….

What will happen to the course of history when AI
 takes over culture, and begins producing stories, melodies, laws and religions? Previous
 tools like the printing press and radio helped spread the cultural ideas of humans, but they
 never created new cultural ideas of their own. AI is fundamentally different. AI can create
 completely new ideas, completely new culture…. Of course, the new power of AI could be used
 for good purposes as well. I won't dwell on this, because the people who develop AI talk
 about it enough….

We can still regulate the new AI tools, but we must act
 quickly. Whereas nukes cannot invent more powerful nukes, AI can make exponentially more
 powerful AI.… Unregulated AI deployments would create social chaos, which would benefit
 autocrats and ruin democracies. Democracy is a conversation, and conversations rely on
 language. When AI hacks language, it could destroy our ability to have meaningful
 conversations, thereby destroying democracy….And the first regulation I would suggest is to
 make it mandatory for AI to disclose that it is an AI. If I am having a conversation with
 someone, and I cannot tell whether it is a human or an AI—that's the end of democracy. This
 text has been generated by a human. Or has it?

 CAT 2024 Slot 3 - VA RC

 The author identifies all of the following as dire outcomes of the capture of language by
 AI EXCEPT that it could

 out-strip human creativity and endeavours in the spheres such as art and
 music and, in the formulation of laws.

 apply its mastery of language to create strong emotional ties which could
 exacerbate the polarization of political views.

 spawn a completely new culture through its ability to create new ideas and
 opinions.

 eventually subvert democratic processes through the mass creation and spread
 of fake political content and news.

**ANSWER:** Choice B

### Q22

apply its mastery of language to
 create strong emotional ties which could exacerbate the polarization of
 political views.

 CAT 2024 Slot 3 - VA RC

 The author terms language "the operating system of our civilization" for all the
 following reasons EXCEPT that it

 is fundamental to the articulation and spread of human values and culture in
 our society.

 has laid the foundation for the creation of cultural artefacts through
 writing and telling of stories.

 can influence political views and opinions as it engenders close emotional
 ties among people.

 is the basis of AI tools like ChatGPT which can be used to generate academic
 content and opinion.

**ANSWER:** Choice D

### Q23

is the basis of AI tools like
 ChatGPT which can be used to generate academic content and
 opinion.

 CAT 2024 Slot 3 - VA RC

 The tone of the passage could best be described as

 cautionary, because the author lays out some adverse effects of the
 proliferation of unregulated AI tools.

 alarmist, because the passage discusses scenarios of the influence of new AI
 tools on language and human emotions.

 quizzical, as the passage poses several questions, concluding with the
 question of whether or not the passage content has been generated by AI.

 prescient, as the author analyses the future impact of the use of new AI
 tools on crucial areas of our society and culture.

**ANSWER:** Choice A

### Q24

cautionary, because the author lays
 out some adverse effects of the proliferation of unregulated AI
 tools.

 CAT 2024 Slot 3 - VA RC

 We can infer that the author is most likely to agree with which of the following
 statements?

 People's fears of the dangers of students using ChatGPT and other new AI
 tools are unfounded.

 Apart from its drawbacks, AI tools have been beneficial in boosting
 technological and industrial advance worldwide.

 The commonly expressed fear that future AI developments will fatally harm
 humans is unfounded.

 One of the biggest casualties from the spread of unregulated AI is likely to
 be the democratic process.

**ANSWER:** Choice D
