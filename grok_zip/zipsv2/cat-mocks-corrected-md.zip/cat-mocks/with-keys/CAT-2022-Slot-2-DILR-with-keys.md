# CAT 2022 — Slot 2 — DILR (Questions + On-page Answer Key)

Answers are on-page 2IIM **Correct Answer** labels. Not invented.

## DILR

- Source file: `2iim-html/CAT-2022-Question-Paper-Slot-2-DILR.txt`
- Page: https://online.2iim.com/CAT-question-paper/CAT-2022-Question-Paper-Slot-2-DILR/
- On-page answers found: 20
- Answer source: 2IIM on-page **Correct Answer** / **Correct Answer Choice** (not invented)

### Q1

C AT DI LR section has become increasingly tough beginning from 2015. DILR used to have distinct Data Interpretation sets and Logical reasoning puzzles. It used to be about computation and ability to read charts, graphs and tables for the Data Interpretation and Logical reasoning used to have Family tree, grid puzzles, arrangement, tournaments, cubes as some standard forms of puzzles.Since 2015 this pattern has been broken. With passing years, even the distinction between DI and LR has come down significantly. All you get in that one hour, are 8 high quality puzzles, with more than a few of them being significantly tough. Between CAT 2017 Question paper to CAT 2022 Question paper, you get to solve 90 actual CAT puzzles. This page intends to provide you just that. So, head on and crack those puzzles!

 A few salesmen are employed to sell a product called TRICCEK among households in various housing complexes. On each day, a salesman is assigned to visit one housing complex. Once a salesman enters a housing complex, he can meet any number of households in the time available. However, if a household makes a complaint against the salesman, then he must leave the housing complex immediately and cannot meet any other household on that day. A household may buy any number of TRICCEK items or may not buy any item. The salesman needs to record the total number of TRICCEK items sold as well as the number of households met in each day. The success rate of a salesman for a day is defined as the ratio of the number of items sold to the number of households met on that day. Some details about the performances of three salesmen - Tohri, Hokli and Lahur, on two particular days are given below.

1. Over the two days, all three of them met the same total number of households, and each of them sold a total of 100 items.
2. On both days, Lahur met the same number of households and sold the same number of items.
3. Hokli could not sell any item on the second day because the first household he met on that day complained against him.
4. Tohri met 30 more households on the second day than on the first day.
5. Tohri's success rate was twice that of Lahur's on the first day, and it was 75% of Lahur's on the second day.

 CAT 2022 Slot 2 - DI LR

 What was the total number of households met by Tohri, Hokli and Lahur on the first day?

**ANSWER:** 84

### Q2

CAT 2022 Slot 2 - DI LR

 How many TRICCEK items were sold by Tohri on the first day?

**ANSWER:** 40

### Q3

CAT 2022 Slot 2 - DI LR

 How many households did Lahur meet on the second day?

 20 or less

 between 21 and 29

 between 30 and 35

 more than 35

**ANSWER:** Choice B

### Q4

between 21 and 29

 CAT 2022 Slot 2 - DI LR

 How many households did Tohri meet on the first day?

 more than 40

 10 or less

 between 11 and 20

 between 21 and 40

**ANSWER:** Choice B

### Q5

10 or less

 CAT 2022 Slot 2 - DI LR

 Which of the following statements is FALSE?

 Among the three, Tohri had the highest success rate on the first day.

 Tohri had a higher success rate on the first day compared to the second day.

 Among the three, Lahur had the lowest success rate on the first day.

 Among the three, Tohri had the highest success rate on the second day.

**ANSWER:** Choice D

### Q6

Among the three, Tohri had the highest success rate on the second day.

 Every day a widget supplier supplies widgets from the warehouse (W) to four locations – Ahmednagar (A), Bikrampore (B), Chitrachak (C), and Deccan Park (D). The daily demand for widgets in each location is uncertain and independent of each other. Demands and corresponding probability values (in parenthesis) are given against each location (A, B, C, and D) in the figure below. For example, there is a 40% chance that the demand in Ahmednagar will be 50 units and a 60% chance that the demand will be 70 units. The lines in the figure connecting the locations and warehouse represent two-way roads connecting those places with the distances (in km) shown beside the line. The distances in both the directions along a road are equal. For example, the road from Ahmednagar to Bikrampore and the road from Bikrampore to Ahmednagar are both 6 km long.

Every day the supplier gets the information about the demand values of the four locations and creates the travel route that starts from the warehouse and ends at a location after visiting all the locations exactly once. While making the route plan, the supplier goes to the locations in decreasing order of demand. If there is a tie for the choice of the next location, the supplier will go to the location closest to the current location. Also, while creating the route, the supplier can either follow the direct path (if available) from one location to another or can take the path via the warehouse. If both paths are available (direct and via warehouse), the supplier will choose the path with minimum distance.

 CAT 2022 Slot 2 - DI LR

 If the last location visited is Ahmednagar, then what is the total distance covered in the route (in km)?

**ANSWER:** 35

### Q7

CAT 2022 Slot 2 - DI LR

 If the total number of widgets delivered in a day is 250 units, then what is the total distance covered in the route (in km)?

**ANSWER:** 38

### Q8

CAT 2022 Slot 2 - DI LR

 What is the chance that the total number of widgets delivered in a day is 260 units and the route ends at Bikrampore?

**ANSWER:** Choice C

### Q9

CAT 2022 Slot 2 - DI LR

 If the first location visited from the warehouse is Ahmednagar, then what is the chance that the total distance covered in the route is 40 km?

**ANSWER:** Choice D

### Q10

CAT 2022 Slot 2 - DI LR

 If Ahmednagar is not the first location to be visited in a route and the total route distance is 29 km, then which of the following is a possible number of widgets delivered on that day?

 210

 200

 250

 220

**ANSWER:** Choice A

### Q11

210

 A speciality supermarket sells 320 products. Each of these products was either a cosmetic product or a nutrition product. Each of these products was also either a foreign product or a domestic product. Each of these products had at least one of the two approvals – FDA or EU.

The following facts are also known:

1. There were equal numbers of domestic and foreign products.
2. Half of the domestic products were FDA approved cosmetic products.
3. None of the foreign products had both the approvals, while 60 domestic products had both the approvals.
4. There were 140 nutrition products, half of them were foreign products.
5. There were 200 FDA approved products. 70 of them were foreign products and 120 of them were cosmetic products.

 CAT 2022 Slot 2 - DI LR

 How many foreign products were FDA approved cosmetic products?

**ANSWER:** 40

### Q12

CAT 2022 Slot 2 - DI LR

 How many cosmetic products did not have FDA approval?

 Cannot be determined

 50

 10

 60

**ANSWER:** Choice D

### Q13

60

 CAT 2022 Slot 2 - DI LR

 Which among the following options best represents the number of domestic cosmetic products that had both the approvals?

 At least 10 and at most 60

 At least 20 and at most 50

 At least 10 and at most 80

 At least 20 and at most 70

**ANSWER:** Choice A

### Q14

At least 10 and at most 60

 CAT 2022 Slot 2 - DI LR

 If 70 cosmetic products did not have EU approval, then how many nutrition products had both the approvals?

 10

 30

 50

 20

**ANSWER:** Choice A

### Q15

10

 CAT 2022 Slot 2 - DI LR

 If 50 nutrition products did not have EU approval, then how many domestic cosmetic products did not have EU approval?

**ANSWER:** 50

### Q16

The two plots below show data for four companies code-named A, B, C, and D over three years - 2019, 2020, and 2021.

The first plot shows the revenues and costs incurred by the companies during these years. For example, in 2021, company C earned Rs.100 crores in revenue and spent Rs.30 crores. The profit of a company is defined as its revenue minus its costs.

The second plot shows the number of employees employed by the company (employee strength) at the start of each of these three years, as well as the number of new employees hired each year (new hires). For example, Company B had 250 employees at the start of 2021, and 30 new employees joined the company during the year.

 CAT 2022 Slot 2 - DI LR

 Considering all three years, which company had the highest annual profit?

 Company C

 Company B

 Company A

 Company D

**ANSWER:** Choice A

### Q17

Company C

 CAT 2022 Slot 2 - DI LR

 Which of the four companies experienced the highest annual loss in any of the years?

 Company D

 Company C

 Company A

 Company B

**ANSWER:** Choice A

### Q18

Company D

 CAT 2022 Slot 2 - DI LR

 The ratio of a company's annual profit to its annual costs is a measure of its performance. Which of the four companies had the lowest value of this ratio in 2019?

 Company A

 Company B

 Company C

 Company D

**ANSWER:** Choice A

### Q19

Company A

 CAT 2022 Slot 2 - DI LR

 The total number of employees lost in 2019 and 2020 was the least for:

 Company A

 Company C

 Company B

 Company D

**ANSWER:** Choice C

### Q20

Company B

 CAT 2022 Slot 2 - DI LR

 Profit per employee is the ratio of a company's profit to its employee strength. For this purpose, the employee strength in a year is the average of the employee strength at the beginning of that year and the beginning of the next year. In 2020, which of the four companies had the highest profit per employee?

 Company B

 Company A

 Company D

 Company C

**ANSWER:** Choice A
