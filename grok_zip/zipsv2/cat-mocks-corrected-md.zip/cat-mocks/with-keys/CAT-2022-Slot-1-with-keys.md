# CAT 2022 — Slot 1 (Questions + On-page Answer Key)

Combined from public 2IIM HTML question pages (`2iim-html/`).
Answers are the on-page **Correct Answer** / **Correct Answer Choice** labels. Not invented. Not an official IIM PDF unless cross-checked.

---

## VARC

- Source file: `2iim-html/CAT-2022-Question-Paper-Slot-1-VARC.txt`
- Page: https://online.2iim.com/CAT-question-paper/CAT-2022-Question-Paper-Slot-1-VARC/
- On-page answers found: 24
- Answer source: 2IIM on-page **Correct Answer** / **Correct Answer Choice** (not invented)

### Q1

T he best way to improve your VARC skill is Reading. Read tons of stuff from Bharath's Curated Reading list and get a wonderful VARC score.

 The passage below is accompanied by a set of questions. Choose the best answer to each question.

The Chinese have two different concepts of a copy. Fangzhipin . . . are imitations where the difference from the original is obvious. These are small models or copies that can be purchased in a museum shop, for example. The second concept for a copy is fuzhipin . . . They are exact reproductions of the original, which, for the Chinese, are of equal value to the original. It has absolutely no negative connotations. The discrepancy with regard to the understanding of what a copy is has often led to misunderstandings and arguments between China and Western museums. The Chinese often send copies abroad instead of originals, in the firm belief that they are not essentially different from the originals. The rejection that then comes from the Western museums is perceived by the Chinese as an insult. . . .

The Far Eastern notion of identity is also very confusing to the Western observer. The Ise Grand Shrine [in Japan] is 1,300 years old for the millions of Japanese people who go there on pilgrimage every year. But in reality this temple complex is completely rebuilt from scratch every 20 years. . . .

Fundamentally, this is the same operation as with the Japanese shrine, except in this case the production of a replica takes place very slowly and over long periods of time. . . . In the field of art as well, the idea of an unassailable original developed historically in the Western world. Back in the 17th century [in the West], excavated artworks from antiquity were treated quite differently from today. They were not restored in a way that was faithful to the original. Instead, there was massive intervention in these works, changing their appearance. . . .

It is probably this intellectual position that explains why Asians have far fewer scruples about cloning than Europeans. The South Korean cloning researcher Hwang Woo-suk, who attracted worldwide attention with his cloning experiments in 2004, is a Buddhist. He found a great deal of support and followers among Buddhists, while Christians called for a ban on human cloning. . . . Hwang legitimised his cloning experiments with his religious affiliation: 'I am Buddhist, and I have no philosophical problem with cloning. And as you know, the basis of Buddhism is that life is recycled through reincarnation. In some ways, I think, therapeutic cloning restarts the circle of life.'

 CAT 2022 Slot 1 - VA RC

 Based on the passage, which one of the following copies would a Chinese museum be unlikely to consider as having less value than the original?

 Pablo Picasso's painting of Vincent van Gogh's original painting, identical in every respect.

 Pablo Picasso's photograph of Vincent van Gogh's original painting, printed to exactly the same scale.

 Pablo Picasso's miniaturised, but otherwise faithful and accurate painting of Vincent van Gogh's original painting.

 Pablo Picasso's painting of Vincent van Gogh's original painting, bearing Picasso's signature.

**ANSWER:** Choice A

### Q2

Pablo Picasso's painting of Vincent van Gogh's original painting, identical in every respect.

 CAT 2022 Slot 1 - VA RC

 Which one of the following statements does not correctly express the similarity between the Ise Grand Shrine and the cathedral of Freiburg Minster?

 Both can be regarded as very old structures.

 Both will one day be completely rebuilt.

 Both were built as places of worship.

 Both are continually undergoing restoration.

**ANSWER:** Choice D

### Q3

Both are continually undergoing restoration.

 CAT 2022 Slot 1 - VA RC

 Which one of the following scenarios is unlikely to follow from the arguments in the passage?

 A 17th century British painter would have no problem adding personal touches when restoring an ancient Roman painting.

 A 20th century Japanese Buddhist monk would value a reconstructed shrine as the original.

 A 17th century French artist who adhered to a Christian worldview would need to be completely true to the original intent of a painting when restoring it.

 A 21st century Christian scientist is likely to oppose cloning because of his philosophical orientation.

**ANSWER:** Choice C

### Q4

A 17th century French artist who adhered to a Christian worldview would need to be completely true to the original intent of a painting when restoring it.

 CAT 2022 Slot 1 - VA RC

 The value that the modern West assigns to "an unassailable original" has resulted in all of the following EXCEPT:

 it discourages them from making interventions in ancient art.

 it discourages them from carrying out human cloning.

 it discourages them from simultaneous displays of multiple copies of a painting.

 it allows regular employment for certain craftsmen.

**ANSWER:** Choice B

### Q5

it discourages them from carrying out human cloning.

 The passage below is accompanied by a set of questions. Choose the best answer to each question.

Stoicism was founded in 300 BC by the Greek philosopher Zeno and survived into the Roman era until about AD 300. According to the Stoics, emotions consist of two movements. The first movement is the immediate feeling and other reactions (e.g., physiological response) that occur when a stimulus or event occurs. For instance, consider what could have happened if an army general accused Marcus Aurelius of treason in front of other officers. The first movement for Marcus may have been (internal) surprise and anger in response to this insult, accompanied perhaps by some involuntary physiological and expressive responses such as face flushing and a movement of the eyebrows. The second movement is what one does next about the emotion. Second movement behaviors occur after thinking and are under one's control. Examples of second movements for Marcus might have included a plot to seek revenge, actions signifying deference and appeasement, or perhaps proceeding as he would have proceeded whether or not this event occurred: continuing to lead the Romans in a way that Marcus Aurelius believed best benefited them. In the Stoic view, choosing a reasoned, unemotional response as the second movement is the only appropriate response.

The Stoics believed that to live the good life and be a good person, we need to free ourselves of nearly all desires such as too much desire for money, power, or sexual gratification. Prior to second movements, we can consider what is important in life. Money, power, and excessive sexual gratification are not important. Character, rationality, and kindness are important. The Epicureans, first associated with the Greek philosopher Epicurus . . . held a similar view, believing that people should enjoy simple pleasures, such as good conversation, friendship, food, and wine, but not be indulgent in these pursuits and not follow passion for those things that hold no real value like power and money. As Oatley (2004) states, "the Epicureans articulated a view—enjoyment of relationship with friends, of things that are real rather than illusory, simple rather than artificially inflated, possible rather than vanishingly unlikely—that is certainly relevant today" . . . In sum, these ancient Greek and Roman philosophers saw emotions, especially strong ones, as potentially dangerous. They viewed emotions as experiences that needed to be [reined] in and controlled.

As Oatley (2004) points out, the Stoic idea bears some similarity to Buddhism. Buddha, living in India in the 6th century BC, argued for cultivating a certain attitude that decreases the probability of (in Stoic terms) destructive second movements. Through meditation and the right attitude, one allows emotions to happen to oneself (it is impossible to prevent this), but one is advised to observe the emotions without necessarily acting on them; one achieves some distance and decides what has value and what does not have value. Additionally, the Stoic idea of developing virtue in oneself, of becoming a good person, which the Stoics believed we could do because we have a touch of the divine, laid the foundation for the three monotheistic religions: Judaism, Christianity, and Islam . . . As with Stoicism, tenets of these religions include controlling our emotions lest we engage in sinful behavior.

 CAT 2022 Slot 1 - VA RC

 On the basis of the passage, which one of the following statements can be regarded as true?

 The Epicureans believed in controlling all emotions.

 There were no Stoics in India at the time of the Roman civilisation.

 The Stoic influences can be seen in multiple religions.

 The Stoics valorised the pursuit of money, power, and sexual gratification.

**ANSWER:** Choice C

### Q6

The Stoic influences can be seen in multiple religions.

 CAT 2022 Slot 1 - VA RC

 Which one of the following statements, if false, could be seen as contradicting the facts/arguments in the passage?

 In the Epicurean view, indulging in simple pleasures is not desirable.

 Despite practising meditation and cultivating the right attitude, emotions cannot ever be controlled.

 In the Stoic view, choosing a reasoned, unemotional response as the first movement is an appropriate response to emotional situations.

 The Greek philosopher Zeno survived into the Roman era until about AD 300.

**ANSWER:** Choice A

### Q7

In the Epicurean view, indulging in simple pleasures is not desirable.

 CAT 2022 Slot 1 - VA RC

 "Through meditation and the right attitude, one allows emotions to happen to oneself (it is impossible to prevent this), but one is advised to observe the emotions without necessarily acting on them; one achieves some distance and decides what has value and what does not have value." In the context of the passage, which one of the following is not a possible implication of the quoted statement?

 Meditation allows certain out-of-body experiences that permit us to gain the distance necessary to control our emotions.

 Emotional responses can make it difficult to distinguish valuable experiences from valueless experiences.

 The observation of emotions in a distant manner corresponds to the second movement referred to earlier in the passage.

 "Meditation and the right attitude", in this instance, implies an initially passive reception of all experiences.

**ANSWER:** Choice A

### Q8

Meditation allows certain out-of-body experiences that permit us to gain the distance necessary to control our emotions.

 CAT 2022 Slot 1 - VA RC

 Which one of the following statements would be an accurate inference from the example of Marcus Aurelius?

 Marcus Aurelius was humiliated by the accusation of treason in front of the other officers.

 Marcus Aurelius was one of the leaders of the Roman army.

 Marcus Aurelius was a Stoic whose philosophy survived into the Roman era.

 Marcus Aurelius plotted revenge in his quest for justice.

**ANSWER:** Choice B

### Q9

Marcus Aurelius was one of the leaders of the Roman army.

 The passage below is accompanied by a set of questions. Choose the best answer to each question.

Critical theory of technology is a political theory of modernity with a normative dimension. It belongs to a tradition extending from Marx to Foucault and Habermas according to which advances in the formal claims of human rights take center stage while in the background centralization of ever more powerful public institutions and private organizations imposes an authoritarian social order.

Marx attributed this trajectory to the capitalist rationalization of production. Today it marks many institutions besides the factory and every modern political system, including so-called socialist systems. This trajectory arose from the problems of command over a disempowered and deskilled labor force; but everywhere [that] masses are organized – whether it be Foucault's prisons or Habermas's public sphere – the same pattern prevails. Technological design and development is shaped by this pattern as the material base of a distinctive social order. Marcuse would later point to a "project" as the basis of what he called rather confusingly "technological rationality." Releasing technology from this project is a democratic political task.

In accordance with this general line of thought, critical theory of technology regards technologies as an environment rather than as a collection of tools. We live today with and even within technologies that determine our way of life. Along with the constant pressures to build centers of power, many other social values and meanings are inscribed in technological design. A hermeneutics of technology must make explicit the meanings implicit in the devices we use and the rituals they script. Social histories of technologies such as the bicycle, artificial lighting or firearms have made important contributions to this type of analysis. Critical theory of technology attempts to build a methodological approach on the lessons of these histories.

As an environment, technologies shape their inhabitants. In this respect, they are comparable to laws and customs. Each of these institutions can be said to represent those who live under their sway through privileging certain dimensions of their human nature. Laws of property represent the interest in ownership and control. Customs such as parental authority represent the interest of childhood in safety and growth. Similarly, the automobile represents its users in so far as they are interested in mobility. Interests such as these constitute the version of human nature sanctioned by society.

This notion of representation does not imply an eternal human nature. The concept of nature as non-identity in the Frankfurt School suggests an alternative. On these terms, nature is what lies at the limit of history, at the point at which society loses the capacity to imprint its meanings on things and control them effectively. The reference here is, of course, not to the nature of natural science, but to the lived nature in which we find ourselves and which we are. This nature reveals itself as that which cannot be totally encompassed by the machinery of society. For the Frankfurt School, human nature, in all its transcending force, emerges out of a historical context as that context is [depicted] in illicit joys, struggles and pathologies. We can perhaps admit a less romantic . . . conception in which those dimensions of human nature recognized by society are also granted theoretical legitimacy.

 CAT 2022 Slot 1 - VA RC

 All of the following claims can be inferred from the passage, EXCEPT:

 technologies seek to privilege certain dimensions of human nature at a high cost to lived nature.

 the significance of parental authority to children's safety does not therefore imply that parental authority is a permanent aspect of human nature.

 analyses of technologies must engage with their social histories to be able to reveal their implicit and explicit meanings for us.

 the critical theory of technology argues that, as issues of human rights become more prominent, we lose sight of the ways in which the social order becomes more authoritarian.

**ANSWER:** Choice A

### Q10

technologies seek to privilege certain dimensions of human nature at a high cost to lived nature.

 CAT 2022 Slot 1 - VA RC

 Which one of the following statements best reflects the main argument of the fourth paragraph of the passage?

 Technological environments privilege certain dimensions of human nature as effectively as laws and customs.

 Technology, laws, and customs are not unlike each other if considered as institutions.

 Technology, laws, and customs are comparable, but dissimilar phenomena.

 Automobiles represent the interest in mobility present in human nature.

**ANSWER:** Choice B

### Q11

Technology, laws, and customs are not unlike each other if considered as institutions.

 CAT 2022 Slot 1 - VA RC

 Which one of the following statements contradicts the arguments of the passage?

 Marx's understanding of the capitalist rationalisation of production and Marcuse's understanding of a "project" of "technological rationality" share theoretical inclinations.

 Masses are organised in patterns set by Foucault's prisons and Habermas' public sphere.

 Paradoxically, the capitalist rationalisation of production is a mark of so-called socialist systems as well.

 The problems of command over a disempowered and deskilled labour force gave rise to similar patterns of the capitalist rationalisation of production wherever masses were organised.

**ANSWER:** Choice B

### Q12

Masses are organised in patterns set by Foucault's prisons and Habermas' public sphere.

 CAT 2022 Slot 1 - VA RC

 Which one of the following statements could be inferred as supporting the arguments of the passage?

 The romantic conception of nature referred to by the passage is the one that requires theoretical legitimacy.

 Technologies form the environmental context and shape the contours of human society.

 It is not human nature, but human culture that is represented by institutions such as law and custom.

 Nature decides the point at which society loses its capacity to control history.

**ANSWER:** Choice B

### Q13

Technologies form the environmental context and shape the contours of human society.

 The passage below is accompanied by a set of questions. Choose the best answer to each question.

Stories concerning the Undead have always been with us. From out of the primal darkness of Mankind's earliest years, come whispers of eerie creatures, not quite alive (or alive in a way which we can understand), yet not quite dead either. These may have been ancient and primitive deities who dwelt deep in the surrounding forests and in remote places, or simply those deceased who refused to remain in their tombs and who wandered about the countryside, physically tormenting and frightening those who were still alive. Mostly they were ill-defined—strange sounds in the night beyond the comforting glow of the fire, or a shape, half-glimpsed in the twilight along the edge of an encampment. They were vague and indistinct, but they were always there with the power to terrify and disturb. They had the power to touch the minds of our early ancestors and to fill them with dread. Such fear formed the basis of the earliest tales although the source and exact nature of such terrors still remained very vague.

And as Mankind became more sophisticated, leaving the gloom of their caves and forming themselves into recognizable communities—towns, cities, whole cultures—so the Undead travelled with them, inhabiting their folklore just as they had in former times. Now they began to take on more definite shapes. They became walking cadavers; the physical embodiment of former deities and things which had existed alongside Man since the Creation. Some still remained vague and ill-defined but, as Mankind strove to explain the horror which it felt towards them, such creatures emerged more readily into the light.

In order to confirm their abnormal status, many of the Undead were often accorded attributes, which defied the natural order of things—the power to transform themselves into other shapes, the ability to sustain themselves by drinking human blood, and the ability to influence human minds across a distance. Such powers—described as supernatural—only [lent] an added dimension to the terror that humans felt regarding them.

And it was only natural, too, that the Undead should become connected with the practice of magic. From very early times, Shamans and witchdoctors had claimed at least some power and control over the spirits of departed ancestors, and this has continued down into more "civilized" times. Formerly, the invisible spirits and forces that thronged around men's earliest encampments, had spoken "through" the tribal Shamans but now, as entities in their own right, they were subject to magical control and could be physically summoned by a competent sorcerer. However, the relationship between the magician and an Undead creature was often a very tenuous and uncertain one. Some sorcerers might have even become Undead entities once they died, but they might also have been susceptible to the powers of other magicians when they did.

From the Middle Ages and into the Age of Enlightenment, theories of the Undead continued to grow and develop. Their names became more familiar—werewolf, vampire, ghoul—each one certain to strike fear into the hearts of ordinary humans.

 CAT 2022 Slot 1 - VA RC

 Which one of the following statements best describes what the passage is about?

 The passage discusses the evolution of theories of the Undead from primitive thinking to the Age of Enlightenment.

 The passage describes the failure of human beings to fully comprehend their environment.

 The writer discusses the transition from primitive thinking to the Age of Enlightenment.

 The writer describes the ways in which the Undead come to be associated with Shamans and the practice of magic.

**ANSWER:** Choice A

### Q14

The passage discusses the evolution of theories of the Undead from primitive thinking to the Age of Enlightenment.

 CAT 2022 Slot 1 - VA RC

 "In order to confirm their abnormal status, many of the Undead were often accorded attributes, which defied the natural order of things . . ." Which one of the following best expresses the claim made in this statement?

 The Undead are deified in nature's order by giving them divine attributes.

 According the Undead an abnormal status is to reject the natural order of things.

 Human beings conceptualise the Undead as possessing abnormal features.

 The natural attributes of the Undead are rendered abnormal by changing their status.

**ANSWER:** Choice C

### Q15

Human beings conceptualise the Undead as possessing abnormal features.

 CAT 2022 Slot 1 - VA RC

 All of the following statements, if false, could be seen as being in accordance with the passage, EXCEPT:

 the Undead remained vague and ill-defined, even as Mankind strove to understand the horror they inspired.

 the relationship between Shamans and the Undead was believed to be a strong and stable one.

 the growing sophistication of Mankind meant that humans stopped believing in the Undead.

 the transition from the Middle Ages to the Age of Enlightenment saw new theories of the Undead.

**ANSWER:** Choice D

### Q16

the transition from the Middle Ages to the Age of Enlightenment saw new theories of the Undead.

 CAT 2022 Slot 1 - VA RC

 Which one of the following observations is a valid conclusion to draw from the statement, "From out of the primal darkness of Mankind's earliest years, come whispers of eerie creatures, not quite alive (or alive in a way which we can understand), yet not quite dead either."?

 Mankind's primal years were marked by creatures alive with eerie whispers, but seen only in the darkness.

 Mankind's early years were marked by a belief in the existence of eerie creatures that were neither quite alive nor dead.

 We can understand the lives of the eerie creatures in Mankind's early years through their whispers in the darkness.

 Long ago, eerie creatures used to whisper in the primal darkness that they were not quite dead.

**ANSWER:** Choice B

### Q17

Mankind's early years were marked by a belief in the existence of eerie creatures that were neither quite alive nor dead.

 CAT 2022 Slot 1 - VA RC

 The passage given below is followed by four alternate summaries. Choose the option that best captures the essence of the passage.

Petitioning is an expeditious democratic tradition, used frequently in prior centuries, by which citizens can bring issues directly to governments. As expressions of collective voice, they support procedural democracy by shaping agendas. They can also recruit citizens to causes, give voice to the voteless, and apply the discipline of rhetorical argument that clarifies a point of view. By contrast, elections are limited in several respects: they involve only a few candidates, and thus fall far short of a representative democracy. Further, voters' choices are not specific to particular policies or laws, and elections are episodic, whereas the voice of the people needs to be heard and integrated constantly into democratic government.

 Petitioning has been important to democratic functioning, as it supplements the electoral process by enabling ongoing engagement with the government.

 Petitioning is definitely more representative of the collective voice, and the functioning of democratic government could improve if we relied more on petitioning rather than holding periodic elections.

 By giving citizens greater control over shaping political and democratic agendas, political petitions are invaluable as they represent an ideal form of a representative democracy.

 Citizens become less inclined to petitioning as it enables vocal citizens to shape political agendas, but this needs to change to strengthen democracies today.

**ANSWER:** Choice A

### Q18

Petitioning has been important to democratic functioning, as it supplements the electoral process by enabling ongoing engagement with the government.

 CAT 2022 Slot 1 - VA RC

 The passage given below is followed by four alternate summaries. Choose the option that best captures the essence of the passage.

All that we think we know about how life hangs together is really some kind of illusion that we have perpetrated on ourselves because of our limited vision. What appear to be inanimate objects such as stones turn out not only to be alive in the same way that we are, but also in many infinitesimal ways to be affected by stimuli just as humans are. The distinction between animate and inanimate simply cannot be made when you enter the world of quantum mechanics and try to determine how those apparent subatomic particles, of which you and everything else in our universe is composed, are all tied together. The point is that physics and metaphysics show there is a pattern to the universe that goes beyond our capacity to grasp it with our brains.

 Arbitrary distinctions between inanimate and animate objects disappear at the scale at which quantum mechanics works.

 Quantum physics indicates that an astigmatic view of reality results in erroneous assumptions about the universe.

 The inanimate world is both sentient and cognizant like its animate counterpart.

 The effect of stimuli is similar in inanimate objects when compared to animate objects or living beings.

**ANSWER:** Choice A

### Q19

Arbitrary distinctions between inanimate and animate objects disappear at the scale at which quantum mechanics works.

 CAT 2022 Slot 1 - VA RC

 The four sentences (labelled 1, 2, 3 and 4) below, when properly sequenced, would yield a coherent paragraph. Decide on the proper sequencing of the order of the sentences and key in the sequence of the four numbers as your answer:

 1. Some company leaders are basing their decisions on locating offices to foster innovation and growth, as their best-performing inventors suffered the greatest productivity losses when their commutes grew longer.
2. Shorter commutes support innovation by giving employees more time in the office and greater opportunities for in-person collaboration, while removing the physical strain of a long commute.
3. This is not always the case: remote work does not automatically lead to greater creativity and productivity as office water-cooler conversations are also very important for innovation.
4. Some see the link between long commutes and productivity as support for work-from-home scenarios, as many workers have grown accustomed to their commute-free arrangements during the pandemic.

**ANSWER:** 2143

### Q20

CAT 2022 Slot 1 - VA RC

 There is a sentence that is missing in the paragraph below. Look at the paragraph and decide in which blank (option 1, 2, 3, or 4) the following sentence would best fit.

Sentence: Having made citizens more and less knowledgeable than their predecessors, the Internet has proved to be both a blessing and a curse.

Paragraph: Never before has a population, nearly all of whom has enjoyed at a least a secondary school education, been exposed to so much information, whether in newspapers and magazines or through YouTube, Google, and Facebook. ___(1)___. Yet it is not clear that people today are more knowledgeable than their barely literate predecessors. Contemporary advances in technology offered more serious and inquisitive students access to realms of knowledge previously unimaginable and unavailable. ___(2)___. But such readily available knowledge leads many more students away from serious study, the reading of actual texts, and toward an inability to write effectively and grammatically. ___(3)___. It has let people choose sources that reinforce their opinions rather than encouraging them to question inherited beliefs. ___(4)___.

 Option 1

 Option 2

 Option 3

 Option 4

**ANSWER:** Choice D

### Q21

Option 4

 CAT 2022 Slot 1 - VA RC

 The four sentences (labelled 1, 2, 3 and 4) below, when properly sequenced, would yield a coherent paragraph. Decide on the proper sequencing of the order of the sentences and key in the sequence of the four numbers as your answer:

 1. The creative element in product design has become of paramount importance as it is one of the few ways a firm or industry can sustain a competitive advantage over its rivals.
2. In fact, the creative element in the value of world industry would be larger still, if we added the contribution of the creative element in other industries, such as the design of tech accessories.
3. The creative industry is receiving a lot of attention today as its growth rate is faster than that of the world economy as a whole.
4. It is for this reason that today's trade issues are increasingly involving intellectual property, as Western countries have an interest in protecting their revenues along with freeing trade in non-tangibles.

**ANSWER:** 3214

### Q22

CAT 2022 Slot 1 - VA RC

 There is a sentence that is missing in the paragraph below. Look at the paragraph and decide in which blank (option 1, 2, 3, or 4) the following sentence would best fit.

Sentence: Easing the anxiety and pressure of having a "big day" is part of the appeal for many couples who marry in secret.

Paragraph: Wedding season is upon us and – after two years of Covid chaos that saw nuptials scaled back– you may think the temptation would be to go all out. ___(1)___. But instead of expanding the guest list, many couples are opting to have entirely secret ceremonies. With Covid case numbers remaining high and the cost of living crisis meaning that many couples are feeling the pinch, it's no wonder that some are less than eager to send out invites. ___(2)___. Plus, it can't hurt that in celebrity circles getting married in secret is all the rage. ___(3)___. "I would definitely say that secret weddings are becoming more common," says Landis Bejar, the founder of a therapy practice, which specialises in helping brides and grooms manage wedding stress. "People are looking for ways to get out of the spotlight and avoid the pomp and circumstance of weddings. ___(4)___. They just want to get to the part where they are married."

 Option 1

 Option 2

 Option 3

 Option 4

**ANSWER:** Choice B

### Q23

Option 2

 CAT 2022 Slot 1 - VA RC

 The passage given below is followed by four alternate summaries. Choose the option that best captures the essence of the passage.

It's not that modern historians of medieval Africa have been ignorant about contacts between Ethiopia and Europe; they just had the power dynamic reversed. The traditional narrative stressed Ethiopia as weak and in trouble in the face of aggression from external forces, so Ethiopia sought military assistance from their fellow Christians to the north. But the real story, buried in plain sight in medieval diplomatic texts, simply had not yet been put together by modern scholars. Recent research pushes scholars of medieval Europe to imagine a much more richly connected medieval world: at the beginning of the so-called Age of Exploration, there is evidence that the kings of Ethiopia were sponsoring their own missions of diplomacy, faith and commerce.

 Medieval historical sources selectively promoted the narrative that powerful European forces were called on to protect weak African civilisations such as Ethiopia, but this is far from reality.

 Medieval texts have been 'cherry-picked' to promote a view of Ethiopia as weak and in need of Europe's military help with aggressive neighbours, but recent studies reveal it was a well-connected and outward-looking culture.

 Medieval texts have documented how strong connections between the Christian communities of Ethiopia and Europe were invaluable in establishing military and trade links between the two civilisations.

 Historians were under the illusion that Ethiopia needed military protection from their neighbours, but in fact the country had close commercial and religious connections with them.

**ANSWER:** Choice B

### Q24

Medieval texts have been 'cherry-picked' to promote a view of Ethiopia as weak and in need of Europe's military help with aggressive neighbours, but recent studies reveal it was a well-connected and outward-looking culture.

 CAT 2022 Slot 1 - VA RC

 The four sentences (labelled 1, 2, 3 and 4) below, when properly sequenced, would yield a coherent paragraph. Decide on the proper sequencing of the order of the sentences and key in the sequence of the four numbers as your answer:

1. Fish skin collagen has excellent thermo-stability and tensile strength making it ideal for use as bandage that adheres to the skin and adjusts to body movements.
2. Collagen, one of the main structural proteins in connective tissues in the human body, is well known for promoting skin regeneration.
3. Fish skin swims in here as diseases and bacteria that affect fish are different from most human pathogens.
4. The risk of introducing disease agents into other species through the use of pig and cow collagen proteins for wound healing has inhibited its broader applications in the medical field.

**ANSWER:** 2431

---

## DILR

- Source file: `2iim-html/CAT-2022-Question-Paper-Slot-1-DILR.txt`
- Page: https://online.2iim.com/CAT-question-paper/CAT-2022-Question-Paper-Slot-1-DILR/
- On-page answers found: 20
- Answer source: 2IIM on-page **Correct Answer** / **Correct Answer Choice** (not invented)

### Q1

C AT DI LR section has become increasingly tough beginning from 2015. DILR used to have distinct Data Interpretation sets and Logical reasoning puzzles. It used to be about computation and ability to read charts, graphs and tables for the Data Interpretation and Logical reasoning used to have Family tree, grid puzzles, arrangement, tournaments, cubes as some standard forms of puzzles.Since 2015 this pattern has been broken. With passing years, even the distinction between DI and LR has come down significantly. All you get in that one hour, are 8 high quality puzzles, with more than a few of them being significantly tough. Between CAT 2017 Question paper to CAT 2022 Question paper, you get to solve 90 actual CAT puzzles. This page intends to provide you just that. So, head on and crack those puzzles!

 There are 15 girls and some boys among the graduating students in a class. They are planning a get-together, which can be either a 1-day event, or a 2-day event, or a 3-day event. There are 6 singers in the class, 4 of them are boys. There are 10 dancers in the class, 4 of them are girls. No dancer in the class is a singer.

Some students are not interested in attending the get-together. Those students who are interested in attending a 3-day event are also interested in attending a 2-day event; those who are interested in attending a 2-day event are also interested in attending a 1-day event.

The following facts are also known:

1. All the girls and 80% of the boys are interested in attending a 1-day event. 60% of the boys are interested in attending a 2-day event.
2. Some of the girls are interested in attending a 1-day event, but not a 2-day event; some of the other girls are interested in attending both.
3. 70% of the boys who are interested in attending a 2-day event are neither singers nor dancers. 60% of the girls who are interested in attending a 2-day event are neither singers nor dancers.
4. No girl is interested in attending a 3-day event. All male singers and 2 of the dancers are interested in attending a 3-day event.
5. The number of singers interested in attending a 2-day event is one more than the number of dancers interested in attending a 2-day event.

 CAT 2022 Slot 1 - DI LR

 How many boys are there in the class?

**ANSWER:** 50

### Q2

CAT 2022 Slot 1 - DI LR

 Which of the following can be determined from the given information?

I. The number of boys who are interested in attending a 1-day event and are neither dancers nor singers.
II. The number of female dancers who are interested in attending a 1-day event.

 Neither I nor II

 Both I and II

 Only I

 Only II

**ANSWER:** Choice D

### Q3

Only II

 CAT 2022 Slot 1 - DI LR

 What fraction of the class are interested in attending a 2-day event?

 7/10

 9/13

 7/13

 2/3

**ANSWER:** Choice C

### Q4

7/13

 CAT 2022 Slot 1 - DI LR

 What BEST can be concluded about the number of male dancers who are interested in attending a 1-day event?

 5 or 6

 4 or 6

 5

 6

**ANSWER:** Choice A

### Q5

5 or 6

 CAT 2022 Slot 1 - DI LR

 How many female dancers are interested in attending a 2-day event?

 0

 2

 Cannot be determined

 1

**ANSWER:** Choice A

### Q6

0

Given above is the schematic map of the metro lines in a city with rectangles denoting terminal stations (e.g. A), diamonds denoting junction stations (e.g. R) and small filled-up circles denoting other stations. Each train runs either in east-west or north-south direction, but not both. All trains stop for 2 minutes at each of the junction stations on the way and for 1 minute at each of the other stations. It takes 2 minutes to reach the next station for trains going in east-west direction and 3 minutes to reach the next station for trains going in north-south direction. From each terminal station, the first train starts at 6 am; the last trains leave the terminal stations at midnight. Otherwise, during the service hours, there are metro service every 15 minutes in the north-south lines and every 10 minutes in the east-west lines. A train must rest for at least 15 minutes after completing a trip at the terminal station, before it can undertake the next trip in the reverse direction. (All questions are related to this metro service only. Assume that if someone reaches a station exactly at the time a train is supposed to leave, (s)he can catch that train.)

 CAT 2022 Slot 1 - DI LR

 If Hari is ready to board a train at 8:05 am from station M, then when is the earliest that he can reach station N?

 9:01 am

 9:13 am

 9:06 am

 9:11 am

**ANSWER:** Choice D

### Q7

9:11 am

 CAT 2022 Slot 1 - DI LR

 If Priya is ready to board a train at 10:25 am from station T, then when is the earliest that she can reach station S?

 11:22 am

 11:28 am

 11:12 am

 11:07 am

**ANSWER:** Choice C

### Q8

11:12 am

 CAT 2022 Slot 1 - DI LR

 Haripriya is expected to reach station S late. What is the latest time by which she must be ready to board at station S if she must reach station B before 1 am via station R?

 11:35 pm

 11:39 pm

 11:43 pm

 11:49 am

**ANSWER:** Choice B

### Q9

11:39 pm

 CAT 2022 Slot 1 - DI LR

 What is the minimum number of trains that are required to provide the service on the AB line (considering both north and south directions)?

**ANSWER:** 8

### Q10

CAT 2022 Slot 1 - DI LR

 What is the minimum number of trains that are required to provide the service in this city?

**ANSWER:** 48

### Q11

The management of a university hockey team was evaluating performance of four women players - Amla, Bimla, Harita and Sarita for their possible selection in the university team for next year. For this purpose, the management was looking at the number of goals scored by them in the past 8 matches, numbered 1 through 8. The four players together had scored a total of 12 goals in these matches. In the 8 matches, each of them had scored at least one goal. No two players had scored the same total number of goals.

The following facts are known about the goals scored by these four players only. All the questions refer only to the goals scored by these four players.

1. Only one goal was scored in every even numbered match.
2. Harita scored more goals than Bimla.
3. The highest goal scorer scored goals in exactly 3 matches including Match 4 and Match 8.
4. Bimla scored a goal in Match 1 and one each in three other consecutive matches.
5. An equal number of goals were scored in Match 3 and Match 7, which was different from the number of goals scored in either Match 1 or Match 5.
6. The match in which the highest number of goals was scored was unique and it was not Match 5.

 CAT 2022 Slot 1 - DI LR

 How many goals were scored in Match 7?

 3

 Cannot be determined

 2

 1

**ANSWER:** Choice D

### Q12

1

 CAT 2022 Slot 1 - DI LR

 Which of the following is the correct sequence of goals scored in matches 1, 3, 5 and 7?

 3, 1, 2, 1

 4, 1, 2, 1

 5, 1, 0, 1

 3, 2, 1, 2

**ANSWER:** Choice B

### Q13

4, 1, 2, 1

 CAT 2022 Slot 1 - DI LR

 Which of the following statement(s) is/are true?

Statement-1: Amla and Sarita never scored goals in the same match.
Statement-2: Harita and Sarita never scored goals in the same match.

 Statement-1 only

 Both the statements

 None of the statements

 Statement-2 only

**ANSWER:** Choice B

### Q14

Both the statements

 CAT 2022 Slot 1 - DI LR

 Which of the following statement(s) is/are false?

Statement-1: In every match at least one player scored a goal.
Statement-2: No two players scored goals in the same number of matches.

 None of the statements

 Statement-1 only

 Statement-2 only

 Both the statements

**ANSWER:** Choice A

### Q15

None of the statements

 CAT 2022 Slot 1 - DI LR

 If Harita scored goals in one more match as compared to Sarita, which of the following statement(s) is/are necessarily true?

Statement-1: Amla scored goals in consecutive matches.
Statement-2: Sarita scored goals in consecutive matches.

 None of the statements

 Statement-1 only

 Both the statements

 Statement-2 only

**ANSWER:** Choice A

### Q16

None of the statements

 Adhara, Bithi, Chhaya, Dhanavi, Esther, and Fathima are the interviewers in a process that awards funding for new initiatives. Every interviewer individually interviews each of the candidates individually and awards a token only if she recommends funding. A token has a face value of 2, 3, 5, 7, 11, or 13. Each interviewer awards tokens of a single face value only. Once all six interviews are over for a candidate, the candidate receives a funding that is Rs.1000 times the product of the face values of all the tokens. For example, if a candidate has tokens with face values 2, 5, and 7, then they get a funding of Rs.1000 × (2 × 5 × 7) = Rs.70,000.
 Pragnyaa, Qahira, Rasheeda, Smera, and Tantra were five candidates who received funding. The funds they received, in descending order, were Rs.390,000, Rs.210,000, Rs.165,000, Rs.77,000, and Rs.66,000.

The following additional facts are known:
 1. Fathima awarded tokens to everyone except Qahira, while Adhara awarded tokens to no one except Pragnyaa.
2. Rashida received the highest number of tokens that anyone received, but she did not receive one from Esther.
3. Bithi awarded a token to Smera but not to Qahira, while Dhanavi awarded a token to Qahira but not to Smera.

 CAT 2022 Slot 1 - DI LR

 How many tokens did Qahira receive?

**ANSWER:** 2

### Q17

CAT 2022 Slot 1 - DI LR

 Who among the following definitely received a token from Bithi but not from Dhanavi?

 Qahira

 Tantra

 Pragnyaa

 Rasheeda

**ANSWER:** Choice C

### Q18

Pragnyaa

 CAT 2022 Slot 1 - DI LR

 How many tokens did Chhaya award?

**ANSWER:** 3

### Q19

CAT 2022 Slot 1 - DI LR

 How many tokens did Smera receive?

**ANSWER:** 3

### Q20

CAT 2022 Slot 1 - DI LR

 Which of the following could be the amount of funding that Tantra received?
 (a) Rs. 66,000
 (b) Rs. 165,000

 Neither (a) nor (b)

 Only (a)

 Both (a) and (b)

 Only (b)

**ANSWER:** Choice C

---

## Quantitative Ability

- Source file: `2iim-html/CAT-2022-Question-Paper-Slot-1-Quant.txt`
- Page: https://online.2iim.com/CAT-question-paper/CAT-2022-Question-Paper-Slot-1-Quant/
- On-page answers found: 22
- Answer source: 2IIM on-page **Correct Answer** / **Correct Answer Choice** (not invented)

### Q1

CAT 2022 Slot 1 - QA

 Let ABCD be a parallelogram such that the coordinates of its three vertices A, B, C are
 (1, 1), (3, 4) and (−2, 8), respectively. Then, the coordinates of the vertex D are

 (−4, 5)

 (4, 5)

 (−3, 4)

 (0, 11)

**ANSWER:** Choice A

### Q2

(−4, 5)

 CAT 2022 Slot 1 - QA

 The number of ways of distributing 20 identical balloons among 4 children such that each
 child gets some balloons but no child gets an odd number of balloons, is

**ANSWER:** 84

### Q3

CAT 2022 Slot 1 - QA

 A mixture contains lemon juice and sugar syrup in equal proportion. If a new mixture is
 created by adding this mixture and sugar syrup in the ratio 1 : 3, then the ratio of
 lemon juice and sugar syrup in the new mixture is

 1 : 6

 1 : 4

 1 : 5

 1 : 7

**ANSWER:** Choice D

### Q4

1 : 7

 CAT 2022 Slot 1 - QA

 For natural numbers \(x, y\), and \(z\), if \(x y+y z=19\) and \(y z+x z=51\), then the
 minimum possible value of \(x y z\) is

**ANSWER:** 34

### Q5

CAT 2022 Slot 1 - QA

 Let \(a, b, c\) be non-zero real numbers such that \(b^2 \lt 4 a c\), and \(f(x)=a x^2+b
 x+c\). If the set \(S\) consists of al integers \(m\) such that \(f(m)\lt0\), then the
 set \(S\) must necessarily be

 the set of all integers

 either the empty set or the set of all integers

 the empty set

 the set of all positive integers

**ANSWER:** Choice B

### Q6

either the empty set or the set of
 all integers

 CAT 2022 Slot 1 - QA

 Trains A and B start traveling at the same time towards each other with constant speeds
 from stations X and Y, respectively. Train A reaches station Y in 10 minutes while train
 B takes 9 minutes to reach station X after meeting train A. Then the total time taken,
 in minutes, by train B to travel from station Y to station X is

 15

 12

 6

 10

**ANSWER:** Choice A

### Q7

15

 CAT 2022 Slot 1 - QA

 The average of three integers is 13 . When a natural number \(n\) is included, the
 average of these four integers remains an odd integer. The minimum possible value of
 \(n\) is

 3

 4

 5

 1

**ANSWER:** Choice C

### Q8

5

 CAT 2022 Slot 1 - QA

 Pinky is standing in a queue at a ticket counter. Suppose the ratio of the number of
 persons standing ahead of Pinky to the number of persons standing behind her in the
 queue is 3 : 5. If the total number of persons in the queue is less than 300, then the
 maximum possible number of persons standing ahead of Pinky is

**ANSWER:** 111

### Q9

CAT 2022 Slot 1 - QA

 Ankita buys 4 kg cashews, 14 kg peanuts and 6 kg almonds when the cost of 7 kg cashews is
 the same as that of 30 kg peanuts or 9 kg almonds. She mixes all the three nuts and
 mixture at this marked price and the remaining at a 20% discount on the marked price,
 buying almonds is

 1440

 1176

 1680

 2520

**ANSWER:** Choice C

### Q10

1680

 CAT 2022 Slot 1 - QA

 The largest real value of \(a\) for which the equation \(|x+a|+|x-1|=2\) has an infinite
 number of solutions for \(x\) is

 -1

 0

 1

 2

**ANSWER:** Choice C

### Q11

1

 CAT 2022 Slot 1 - QA

 A trapezium \(\text{ABCD}\) has side \(\text{AD}\) parallel to \(\text{BC}, \angle
 \text{BAD}=90^{\circ}, \text{BC}=3 \text{~cm}\) and \(\text{AD}=8 \text{~cm}\). If the
 perimeter of this trapezium is \(36 \text{~cm}\), then its area, in sq. \(\text{cm}\),
 is

**ANSWER:** 66

### Q12

CAT 2022 Slot 1 - QA

 For any real number \(x\), let \([x]\) be the largest integer less than or equal to
 \(x\). If \(\sum_{n=1}^N\left[\frac{1}{5}+\frac{n}{25}\right]=25\) then \(N\) is

**ANSWER:** 44

### Q13

CAT 2022 Slot 1 - QA

 In a village, the ratio of number of males to females is 5 : 4. The ratio of number of
 literate males to literate females is 2 : 3. The ratio of the number of illiterate males
 to illiterate females is 4 : 3. If 3600 males in the village are literate, then the
 total number of females in the village is

**ANSWER:** 43200

### Q14

CAT 2022 Slot 1 - QA

 Amal buys 110 kg of syrup and 120 kg of juice, syrup being 20% less costly than juice,
 per kg. He sells 10 kg of syrup at 10% profit and 20 kg of juice at 20% profit. Mixing
 the remaining juice and syrup, Amal sells the mixture at ₹ 308.32 per kg and makes an
 overall profit of 64%. Then, Amal's cost price for syrup, in rupees per kg, is

**ANSWER:** 160

### Q15

CAT 2022 Slot 1 - QA

 Let \(a\) and \(b\) be natural numbers. If \(a^2+a b+a=14\) and \(b^2+a b+b=28\), then
 \((2 a+b)\) equals

 7

 10

 9

 8

**ANSWER:** Choice D

### Q16

8

 CAT 2022 Slot 1 - QA

 Alex invested his savings in two parts. The simple interest earned on the first part at
 15% per annum for 4 years is the same as the simple interest earned on the second part
 at 12% per annum for 3 years. Then, the percentage of his savings invested in the first
 part is

**ANSWER:** Choice B

### Q17

CAT 2022 Slot 1 - QA

 In a class of 100 students, 73 like coffee, 80 like tea and 52 like lemonade. It may be
 possible that some students do not like any of these three drinks. Then the difference
 between the maximum and minimum possible number of students who like all the three
 drinks is

 48

 53

 47

 52

**ANSWER:** Choice C

### Q18

47

 CAT 2022 Slot 1 - QA

 For any natural number \(n\), suppose the sum of the first \(n\) terms of an arithmetic
 progression is \(\left(n+2 n^2\right)\). If the \(n^{\text {th }}\) term of the
 progression is divisible by 9 , then the smallest possible value of \(n\) is

 4

 8

 7

 9

**ANSWER:** Choice C

### Q19

7

 CAT 2022 Slot 1 - QA

 All the vertices of a rectangle lie on a circle of radius \(R\). If the perimeter of the
 rectangle is \(P\), then the area of the rectangle is

 \(\frac{P^2}{2}-2 P R\)

 \(\frac{P^2}{8}-2 R^2\)

 \(\frac{P^2}{16}-R^2\)

 \(\frac{P^2}{8}-\frac{R^2}{2}\)

**ANSWER:** Choice B

### Q20

\(\frac{P^2}{8}-2 R^2\)

 CAT 2022 Slot 1 - QA

 The average weight of students in a class increases by 600 gm when some new students join
 the class. If the average weight of the new students is 3 kg more than the average
 weight of the original students, then the ratio of the number of original students to
 the number of new students is

 1 : 2

 3 : 1

 1 : 4

 4 : 1

**ANSWER:** Choice D

### Q21

4 : 1

 CAT 2022 Slot 1 - QA

 Let \(A\) be the largest positive integer that divides all the numbers of the form
 \(3^k+4^k+5^k\), and \(B\) be the largest positive integer that divides all the numbers
 of the form \(4^k+3\left(4^k\right)+4^{k+2}\), where \(k\) is any positive integer. Then
 \((A+B)\) equals

**ANSWER:** 82

### Q22

CAT 2022 Slot 1 - QA

 Let \(0 \leq a \leq x \leq 100\) and \(f(x)=|x-a|+|x-100|+|x-a-50|\). Then the maximum
 value of \(f(x)\) becomes 100 when \(a\) is equal to

 100

 25

 0

 50

**ANSWER:** Choice D

---
