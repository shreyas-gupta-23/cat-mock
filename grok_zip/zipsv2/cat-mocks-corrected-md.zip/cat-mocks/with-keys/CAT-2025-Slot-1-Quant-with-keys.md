# CAT 2025 — Slot 1 — Quantitative Ability (Questions + On-page Answer Key)

Answers are on-page 2IIM **Correct Answer** labels. Not invented.

## Quantitative Ability

- Source file: `2iim-html/CAT-2025-Question-Paper-Slot-1-Quant.txt`
- Page: https://online.2iim.com/CAT-question-paper/CAT-2025-Question-Paper-Slot-1-Quant/
- On-page answers found: 22
- Answer source: 2IIM on-page **Correct Answer** / **Correct Answer Choice** (not invented)

### Q1

CAT Question
 Paper / CAT-2025-Slot1-Quants

 C AT 2025 Quant, unlike previous years was not dominated by
 Arithmetic. Though Arithematic was the most tested topic followed by Algebra. In Arithmetic, the
 questions were dominated by topics like Speed-time-distance , Mixture and Alligations . This year,
 there was a surprise. The questions from Geometry were relatively on the lower
 side as compared to the previous years. There were 8 TITA Qs this year. Overall this section was
 at a medium level of difficulty.

 CAT 2025 Slot 1 - QA

 If \(a-6 b+6 c=4\) and \(6 a+3 b-3 c=50\), where \(a, b\) and \(c\) are real numbers, the value of \(2 a+3 b-3 c\) is

 18

 20

 15

 14

**ANSWER:** Choice A

### Q2

18

 CAT 2025 Slot 1 - QA

 A cafeteria offers 5 types of sandwiches. Moreover, for each type of sandwich, a customer can choose one of 4 breads and opt for either small or large sized sandwich. Optionally, the customer may also add up to 2 out of 6 available sauces. The number of different ways in which an order can be placed for a sandwich, is

 880

 600

 800

 840

**ANSWER:** Choice A

### Q3

880

 CAT 2025 Slot 1 - QA

 The number of distinct integers \(n\) for which \(\log _{\left(\frac{1}{4}\right)}\left(n^2-7 n+11\right)>0\), is

 infinite

 0

 2

 1

**ANSWER:** Choice B

### Q4

0

 CAT 2025 Slot 1 - QA

 In the set of consecutive odd numbers \(\{1,3,5, \ldots, 57\}\), there is a number \(k\) such that the sum of all the elements less than \(k\) is equal to the sum of all the elements greater than \(k\). Then, \(k\) equals

 41

 39

 37

 43

**ANSWER:** Choice A

### Q5

41

 CAT 2025 Slot 1 - QA

 In a 3-digit number N, the digits are non-zero and distinct such that none of the digits is a perfect square, and only one of the digits is a prime number. Then, the number of factors of the minimum possible value of N is

**ANSWER:** 6

### Q6

CAT 2025 Slot 1 - QA

 At a certain simple rate of interest, a given sum amounts to Rs 13920 in 3 years, and to Rs 18960 in 6 years and 6 months. If the same given sum had been invested for 2 years at the same rate as before but with interest compounded every 6 months, then the total interest earned, in rupees, would have been nearest to

 3096

 3150

 3180

 3221

**ANSWER:** Choice D

### Q7

3221

 CAT 2025 Slot 1 - QA

 The number of non-negative integer values of \(k\) for which the quadratic equation \(x^2-5 x+k=0\) has only integer roots, is

**ANSWER:** 3

### Q8

CAT 2025 Slot 1 - QA

 A value of \(c\) for which the minimum value of \(f(x)=x^2-4 c x+8 c\) is greater than the maximum value of \(g(x)=-x^2+3 c x-2 c\), is

 2

 \(-\frac{1}{2}\)

 \(-2\)

 \(\frac{1}{2}\)

**ANSWER:** Choice D

### Q9

\(\frac{1}{2}\)

 CAT 2025 Slot 1 - QA

 A container holds 200 litres of a solution of acid and water, having 30% acid by volume. Atul replaces 20% of this solution with water, then replaces 10% of the resulting solution with acid, and finally replaces 15% of the solution thus obtained, with water. The percentage of acid by volume in the final solution obtained after these three replacements, is nearest to

 23

 25

 29

 27

**ANSWER:** Choice D

### Q10

27

 CAT 2025 Slot 1 - QA

 Shruti travels a distance of 224 km in four parts for a total travel time of 3 hours. Her speeds in these four parts follow an arithmetic progression, and the corresponding time taken to cover these four parts follow another arithmetic progression. If she travels at a speed of 960 meters per minute for 30 minutes to cover the first part, then the distance, in meters, she travels in the fourth part is

 96000

 112000

 76800

 86400

**ANSWER:** Choice D

### Q11

86400

 CAT 2025 Slot 1 - QA

 The ratio of the number of students in the morning shift and afternoon shift of a school was 13 : 9. After 21 students moved from the morning shift to the afternoon shift, this ratio became 19 : 14. Next, some new students joined the morning and afternoon shifts in the ratio 3 : 8 and then the ratio of the number of students in the morning shift and the afternoon shift became 5 : 4. The number of new students who joined is

 110

 88

 121

 99

**ANSWER:** Choice D

### Q12

99

 CAT 2025 Slot 1 - QA

 In a circle with center \(C\) and radius \(6 \sqrt{2} \mathrm{~cm}, P Q\) and \(S R\) are two parallel chords separated by one of the diameters. If \(\angle P Q C=45^{\circ}\), and the ratio of the perpendicular distance of \(P Q\) and \(S R\) from \(C\) is \(3: 2\), then the area, in sq. cm , of the quadrilateral \(P Q R S\) is

 \(4(3+\sqrt{14})\)

 \(20(3 \sqrt{2}+\sqrt{7})\)

 \(20(3+\sqrt{14})\)

 \(4(3 \sqrt{2}+\sqrt{7})\)

**ANSWER:** Choice C

### Q13

\(20(3+\sqrt{14})\)

 CAT 2025 Slot 1 - QA

 The \((x, y)\) coordinates of vertices \(\mathrm{P}, \mathrm{Q}\) and R of a parallelogram PQRS are \((-3,-2),(1,-5)\) and \((9,1)\), respectively. If the diagonal SQ intersects the \(x\)-axis at \((a, 0)\), then the value of \(a\) is

 \(\frac{13}{4}\)

 \(\frac{29}{9}\)

 \(\frac{10}{3}\)

 \(\frac{27}{7}\)

**ANSWER:** Choice B

### Q14

\(\frac{29}{9}\)

 CAT 2025 Slot 1 - QA

 In a class, there were more than 10 boys and a certain number of girls. After 40% of the girls and 60% of the boys left the class, the remaining number of girls was 8 more than the remaining number of boys. Then, the minimum possible number of students initially in the class was

**ANSWER:** 55

### Q15

CAT 2025 Slot 1 - QA

 If the length of a side of a rhombus is 36 cm and the area of the rhombus is 396 sq. cm, then the absolute value of the difference between the lengths, in cm, of the diagonals of the rhombus is

**ANSWER:** 60

### Q16

CAT 2025 Slot 1 - QA

 A shopkeeper offers a discount of 22% on the marked price of each chair, and gives 13 chairs to a customer for the discounted price of 12 chairs to earn a profit of 26% on the transaction. If the cost price of each chair is Rs 100, then the marked price, in rupees, of each chair is

**ANSWER:** 175

### Q17

CAT 2025 Slot 1 - QA

 The number of distinct pairs of integers \((x, y)\) satisfying the inequalities \(x>y \geq 3\) and \(x+y

**ANSWER:** 16

### Q18

CAT 2025 Slot 1 - QA

 Arun, Varun and Tarun, if working alone, can complete a task in 24, 21, and 15 days, respectively. They charge Rs 2160, Rs 2400, and Rs 2160 per day, respectively, even if they are employed for a partial day. On any given day, any of the workers may or may not be employed to work. If the task needs to be completed in 10 days or less, then the minimum possible amount, in rupees, required to be paid for the entire task is

 34400

 38880

 47040

 38400

**ANSWER:** Choice D

### Q19

38400

 CAT 2025 Slot 1 - QA

 For any natural number \(k\), let \(a_k=3^k\). The smallest natural number \(m\) for which \(\left\{\left(a_1\right)^1 \times\left(a_2\right)^2 \times \ldots \times\left(a_{20}\right)^{20}\right\}

 59

 56

 58

 57

**ANSWER:** Choice C

### Q20

58

 CAT 2025 Slot 1 - QA

 Stocks A, B and C are priced at rupees 120, 90 and 150 per share, respectively. A trader holds a portfolio consisting of 10 shares of stock A, and 20 shares of stocks B and C put together. If the total value of her portfolio is rupees 3300, then the number of shares of stock B that she holds, is

**ANSWER:** 15

### Q21

CAT 2025 Slot 1 - QA

 Kamala divided her investment of Rs 100000 between stocks, bonds, and gold. Her investment in bonds was 25% of her investment in gold. With annual returns of 10%, 6%, 8% on stocks, bonds, and gold, respectively, she gained a total amount of Rs 8200 in one year. The amount, in rupees, that she gained from the bonds, was

**ANSWER:** 900

### Q22

CAT 2025 Slot 1 - QA

 Let \(3 \leq x \leq 6\) and \(\left[x^2\right]=[x]^2\), where \([x]\) is the greatest integer not exceeding \(x\). If set S represents all feasible values of \(x\), then a possible subset of S is

 \((4, \sqrt{18}) \cup[5, \sqrt{27}) \cup\{6\}\)

 \([3, \sqrt{10}] \cup[4, \sqrt{17}] \cup\{6\}\)

 \([3, \sqrt{10}] \cup[5, \sqrt{26}]\)

 \((3, \sqrt{10}) \cup[5, \sqrt{26}) \cup\{6\}\)

**ANSWER:** Choice D
