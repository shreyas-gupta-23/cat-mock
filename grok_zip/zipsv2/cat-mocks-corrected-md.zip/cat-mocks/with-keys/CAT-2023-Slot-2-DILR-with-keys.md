# CAT 2023 — Slot 2 — DILR (Questions + On-page Answer Key)

Answers are on-page 2IIM **Correct Answer** labels. Not invented.

## DILR

- Source file: `2iim-html/CAT-2023-Question-Paper-Slot-2-DILR.txt`
- Page: https://online.2iim.com/CAT-question-paper/CAT-2023-Question-Paper-Slot-2-DILR/
- On-page answers found: 20
- Answer source: 2IIM on-page **Correct Answer** / **Correct Answer Choice** (not invented)

### Q1

2017 Question paper to CAT 2023 Question paper, you get to solve 102 actual CAT puzzles. This
 page intends to provide you just that. So, head on and crack those puzzles!

 There are nine boxes arranged in a 3×3 array as shown in Tables 1 and 2. Each
 box contains three sacks. Each sack has a certain number of coins, between 1 and 9, both
 inclusive.

The average number of coins per sack in the boxes are all distinct
 integers. The total number of coins in each row is the same. The total number of coins in
 each column is also the same.

Table 1 gives
 information regarding the median of the numbers of coins in the three sacks in a box for
 some of the boxes. In Table 2 each box has a number which represents the number of sacks in
 that box having more than 5 coins. That number is followed by a * if the sacks in that box
 satisfy exactly one among the following three conditions, and it is followed by ** if two or
 more of these conditions are satisfied.

i) The minimum among the numbers of
 coins in the three sacks in the box is 1.
ii) The median of the numbers of coins in the
 three sacks is 1.
iii) The maximum among the numbers of coins in the three sacks in the
 box is 9.

 CAT 2023 Slot 2 - DI LR

 What is the total number of coins in all the boxes in the 3 rd row?

 36

 30

 45

 15

**ANSWER:** Choice C

### Q2

45

 CAT 2023 Slot 2 - DI LR

 How many boxes have at least one sack containing 9 coins?

 3

 5

 4

 8

**ANSWER:** Choice B

### Q3

5

 CAT 2023 Slot 2 - DI LR

 For how many boxes are the average and median of the numbers of coins contained in the
 three sacks in that box the same?

**ANSWER:** 4

### Q4

CAT 2023 Slot 2 - DI LR

 How many sacks have exactly one coin?

**ANSWER:** 9

### Q5

CAT 2023 Slot 2 - DI LR

 In how many boxes do all three sacks contain different numbers of coins?

**ANSWER:** 5

### Q6

Three participants – Akhil, Bimal and Chatur participate in a random draw
 competition for five days. Every day, each participant randomly picks up a ball numbered
 between 1 and 9. The number on the ball determines his score on that day. The total score of
 a participant is the sum of his scores attained in the five days. The total score of a day
 is the sum of participants' scores on that day. The 2-day average on a day, except on Day 1,
 is the average of the total scores of that day and of the previous day. For example, if the
 total scores of Day 1 and Day 2 are 25 and 20, then the 2-day average on Day 2 is calculated
 as 22.5. Table 1 gives the 2-day averages for Days 2 through 5.

 Table 1:
 2-day averages for Days 2
 through 5

 Day 2
 Day 3
 Day 4
 Day 5

 15
 15.5
 16
 17

Participants are ranked each day, with the person having the maximum score being
 awarded the minimum rank (1) on that day. If there is a tie, all participants with the tied
 score are awarded the best available rank. For example, if on a day Akhil, Bimal, and Chatur
 score 8, 7 and 7 respectively, then their ranks will be 1, 2 and 2 respectively on that day.
 These ranks are given in Table 2.

 Table 2: Ranks of participants on each
 day

 Day 1
 Day 2
 Day 3
 Day 4
 Day 5

 Akhil
 1
 2
 2
 3
 3

 Bimal
 2
 3
 2
 1
 1

 Chatur
 3
 1
 1
 2
 2

The following information is also known.
1. Chatur always scores in multiples
 of 3. His score on Day 2 is the unique highest score in the competition. His minimum score is
 observed only on Day 1, and it matches Akhil's score on Day 4.
2. The total score on Day 3
 is the same as the total score on Day 4.
3. Bimal's scores are the same on Day 1 and Day 3.

 CAT 2023 Slot 2 - DI LR

 What is Akhil's score on Day 1?

 5

 6

 7

 8

**ANSWER:** Choice C

### Q7

7

 CAT 2023 Slot 2 - DI LR

 Who attains the maximum total score?

 Chatur

 Bimal

 Cannot be determined

 Akhil

**ANSWER:** Choice A

### Q8

Chatur

 CAT 2023 Slot 2 - DI LR

 What is the minimum possible total score of Bimal?

**ANSWER:** 25

### Q9

CAT 2023 Slot 2 - DI LR

 If the total score of Bimal is a multiple of 3, what is the score of Akhil on Day 2?

 Cannot be determined

 4

 6

 5

**ANSWER:** Choice B

### Q10

4

 CAT 2023 Slot 2 - DI LR

 If Akhil attains a total score of 24, then what is the total score of Bimal?

**ANSWER:** 26

### Q11

Odsville has five firms – Alfloo, Bzygoo, Czechy, Drjbna and Elavalaki. Each of
 these firms was founded in some year and also closed down a few years later.

Each firm raised Rs. 1 crore in its first and last year of existence. The amount each
 firm raised every year increased until it reached a maximum, and then decreased until the
 firm closed down. No firm raised the same amount of money in two consecutive years. Each
 annual increase and decrease was either by Rs. 1 crore or by Rs. 2 crores.

The
 table below provides partial information about the five firms.

 Firm
 First year of existence
 Last year of
 existence
 Total amount raised (Rs. crores)

 Alfloo
 2009
 2016
 21

 Bzygoo
 2012
 2015

 Czechy
 2013

 9

 Drjbna
 2011
 2015
 10

 Elavalaki
 2010

 13

 CAT 2023 Slot 2 - DI LR

 For which firm(s) can the amounts raised by them be concluded with certainty in each
 year?

 Only Czechy and Drjbna

 Only Bzygoo and Czechy and Drjbna

 Only Czechy

 Only Drjbna

**ANSWER:** Choice A

### Q12

Only Czechy and Drjbna

 CAT 2023 Slot 2 - DI LR

 What best can be concluded about the total amount of money raised in 2015?

 It is either Rs. 7 crores or Rs. 8 crores.

 It is either Rs. 7 crores or Rs. 8 crores or Rs. 9 crores.

 It is exactly Rs. 8 crores.

 It is either Rs. 8 crores or Rs. 9 crores.

**ANSWER:** Choice A

### Q13

It is either Rs. 7 crores or Rs. 8
 crores.

 CAT 2023 Slot 2 - DI LR

 What is the largest possible total amount of money (in Rs. crores) that could have been
 raised in 2013?

**ANSWER:** 17

### Q14

CAT 2023 Slot 2 - DI LR

 If Elavalaki raised Rs. 3 crores in 2013, then what is the smallest possible total amount
 of money (in Rs. crores) that could have been raised by all the companies in 2012?

 12

 11

 10

 9

**ANSWER:** Choice B

### Q15

11

 CAT 2023 Slot 2 - DI LR

 If the total amount of money raised in 2014 is Rs. 12 crores, then which of the following
 is not possible?

 Bzygoo raised the same amount of money as Elavalaki in 2013.

 Alfloo raised the same amount of money as Drjbna in 2013.

 Alfloo raised the same amount of money as Bzygoo in 2014.

 Bzygoo raised more money than Elavalaki in 2014.

**ANSWER:** Choice A

### Q16

Bzygoo raised the same amount of
 money as Elavalaki in 2013.

 Anjali, Bipasha, and Chitra visited an entertainment park that has four rides.
 Each ride lasts one hour and can accommodate one visitor at one point. All rides begin at 9
 am and must be completed by 5 pm except for Ride-3, for which the last ride has to be
 completed by 1 pm. Ride gates open every 30 minutes, e.g. 10 am, 10:30 am, and so on.
 Whenever a ride gate opens, and there is no visitor inside, the first visitor waiting in the
 queue buys the ticket just before taking the ride. The ticket prices are Rs. 20, Rs. 50, Rs.
 30 and Rs. 40 for Rides 1 to 4, respectively. Each of the three visitors took at least one
 ride and did not necessarily take all rides. None of them took the same ride more than once.
 The movement time from one ride to another is negligible, and a visitor leaves the ride
 immediately after the completion of the ride. No one takes a break inside the park unless
 mentioned explicitly.

The following information is also known.

1.
 Chitra never waited in the queue and completed her visit by 11 am after spending Rs. 50 to
 pay for the ticket(s).
2. Anjali took Ride-1 at 11 am after waiting for 30 mins for
 Chitra to complete it. It was the only ride where Anjali waited.
3. Bipasha began her
 first of three rides at 11:30 am. All three visitors incurred the same amount of ticket
 expense by 12:15 pm.
4. The last ride taken by Anjali and Bipasha was the same, where
 Bipasha waited 30 mins for Anjali to complete her ride. Before standing in the queue for
 that ride, Bipasha took a 1-hour coffee break after completing her previous ride.

 CAT 2023 Slot 2 - DI LR

 What was the total amount spent on tickets (in Rs.) by Bipasha?

 120

 110

 100

 90

**ANSWER:** Choice B

### Q17

110

 CAT 2023 Slot 2 - DI LR

 Which were all the rides that Anjali completed by 2:00 pm?

 Ride-1 and Ride-4

 Ride-1, Ride-2, and Ride-3

 Ride-1 and Ride-3

 Ride-1, Ride-2, and Ride-4

**ANSWER:** Choice B

### Q18

Ride-1, Ride-2, and Ride-3

 CAT 2023 Slot 2 - DI LR

 Which ride was taken by all three visitors?

 Ride-3

 Ride-1

 Ride-4

 Ride-2

**ANSWER:** Choice B

### Q19

Ride-1

 CAT 2023 Slot 2 - DI LR

 How many rides did Anjali and Chitra take in total?

**ANSWER:** 6

### Q20

CAT 2023 Slot 2 - DI LR

 What was the total amount spent on tickets (in Rs.) by Anjali?

**ANSWER:** 140
