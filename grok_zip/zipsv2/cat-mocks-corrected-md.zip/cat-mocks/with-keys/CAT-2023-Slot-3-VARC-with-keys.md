# CAT 2023 — Slot 3 — VARC (Questions + On-page Answer Key)

Answers are on-page 2IIM **Correct Answer** labels. Not invented.

## VARC

- Source file: `2iim-html/CAT-2023-Question-Paper-Slot-3-VARC.txt`
- Page: https://online.2iim.com/CAT-question-paper/CAT-2023-Question-Paper-Slot-3-VARC/
- On-page answers found: 24
- Answer source: 2IIM on-page **Correct Answer** / **Correct Answer Choice** (not invented)

### Q1

We know we are facing more frequent and more severe heatwaves,
 storms, floods, droughts and wildfires due to climate change. We know our expansion through
 deforestation, dam building, canal cutting – in short, terraforming, the word Ghosh uses –
 has brought us repeated disasters . . . Are these the responses of an angry Gaia who has
 finally had enough? By using the word 'curse' in the title, the author makes it clear that
 he thinks so. I use the pronoun 'who' knowingly, because Ghosh has quoted many non-European
 sources to enquire into the relationship between humans and the world around them so that he
 can question the prevalent way of looking at Earth as an inert object to be exploited to the
 maximum.

 As Ghosh's text, notes and bibliography show once more, none of this is new. There
 have always been challenges to the way European colonialists looked at other civilisations
 and at Earth. It is just that the invaders and their myriad backers in the fields of
 economics, politics, anthropology, philosophy, literature, technology, physics, chemistry,
 biology have dominated global intellectual discourse. . . .

 There are other points of view
 that we can hear today if we listen hard enough. Those observing global climate negotiations
 know about the Latin American way of looking at Earth as Pachamama (Earth Mother). They also
 know how such a framing is just provided lip service and is ignored in the substantive
 portions of the negotiations. In The Nutmeg's Curse, Ghosh explains why. He shows the extent
 of the vested interest in the oil economy – not only for oil-exporting countries, but also
 for a superpower like the US that controls oil drilling, oil prices and oil movement around
 the world. Many of us know power utilities are sabotaging decentralised solar power
 generation today because it hits their revenues and control. And how the other points of
 view are so often drowned out.

 CAT 2023 Slot 3 - VA RC

 On the basis of information in the passage, which one of the following is NOT a reason
 for the failure of policies seeking to address climate change?

 The greed of organisations benefiting from non-renewable energy resources.

 The marginalised status of non-European ways of looking at nature and the
 environment.

 The decentralised characteristic of renewable energy resources like solar
 power.

 The global dominance of oil economies and international politics built
 around it.

**ANSWER:** Choice C

### Q2

The decentralised characteristic of
 renewable energy resources like solar power.

 CAT 2023 Slot 3 - VA RC

 Which one of the following best explains the primary purpose of the discussion of the
 colonisation of the Banda islands in "The Nutmeg's Curse"?

 To illustrate how systemic violence against the colonised constituted the
 cornerstone of colonialism.

 To illustrate the first instance in history when the processes responsible
 for climate change were initiated.

 To illustrate the role played by the cultivation of certain crops in the
 plantation mode in contributing to climate change.

 To illustrate how colonialism represented and perpetuated the mindset that
 has led to climate change.

**ANSWER:** Choice D

### Q3

To illustrate how colonialism
 represented and perpetuated the mindset that has led to climate
 change.

 CAT 2023 Slot 3 - VA RC

 All of the following can be inferred from the reviewer's discussion of "The Nutmeg's
 Curse", EXCEPT:

 academic discourses have always served the function of raising awareness
 about environmental preservation.

 environmental preservation policy makers can learn a lot from non-European
 and/or pre-colonial societies.

 the contemporary dominant perception of nature and the environment was put
 in place by processes of colonialism.

 the history of climate change is deeply intertwined with the history of
 colonialism.

**ANSWER:** Choice A

### Q4

academic discourses have always
 served the function of raising awareness about environmental
 preservation.

 CAT 2023 Slot 3 - VA RC

 Which one of the following, if true, would make the reviewer's choice of the pronoun
 "who" for Gaia inappropriate?

 Modern western science discovers new evidence for the Earth being an
 inanimate object.

 Ghosh's book has a different title: "The Nutmeg's Revenge".

 Non-European societies have perceived the Earth as a non-living source of
 all resources.

 There is a direct cause–effect relationship between human activities and
 global climate change.

**ANSWER:** Choice C

### Q5

Non-European societies have
 perceived the Earth as a non-living source of all resources.

 The passage below is accompanied by four questions. Based on the passage,
 choose the best answer for each question.

Steven Pinker's new book, "Rationality:
 What It Is, Why It Seems Scarce, Why It Matters," offers a pragmatic dose of measured
 optimism, presenting rationality as a fragile but achievable ideal in personal and civic
 life. . . . Pinker's ambition to illuminate such a crucial topic offers the welcome prospect
 of a return to sanity. . . . It's no small achievement to make formal logic, game theory,
 statistics and Bayesian reasoning delightful topics full of charm and
 relevance.

It's also plausible to believe that a wider application of the
 rational tools he analyzes would improve the world in important ways. His primer on
 statistics and scientific uncertainty is particularly timely and should be required reading
 before consuming any news about the [COVID] pandemic. More broadly, he argues that less
 media coverage of shocking but vanishingly rare events, from shark attacks to adverse
 vaccine reactions, would help prevent dangerous overreactions, fatalism and the diversion of
 finite resources away from solvable but less-dramatic issues, like malnutrition in the
 developing world.

It's a reasonable critique, and Pinker is not the first to make
 it. But analyzing the political economy of journalism — its funding structures, ownership
 concentration and increasing reliance on social media shares — would have given a fuller
 picture of why so much coverage is so misguided and what we might do about
 it.

Pinker's main focus is the sort of conscious, sequential reasoning that can
 track the steps in a geometric proof or an argument in formal logic. Skill in this domain
 maps directly onto the navigation of many real-world problems, and Pinker shows how greater
 mastery of the tools of rationality can improve decision-making in medical, legal, financial
 and many other contexts in which we must act on uncertain and shifting information. . . .

Despite the undeniable power of the sort of rationality he describes, many of
 the deepest insights in the history of science, math, music and art strike their originators
 in moments of epiphany. From the 19 th -century chemist Friedrich August Kekulé's
 discovery of the structure of benzene to any of Mozart's symphonies, much extraordinary
 human achievement is not a product of conscious, sequential reasoning. Even Plato's Socrates
 — who anticipated many of Pinker's points by nearly 2,500 years, showing the virtue of
 knowing what you do not know and examining all premises in arguments, not simply trusting
 speakers' authority or charisma — attributed many of his most profound insights to dreams
 and visions. Conscious reasoning is helpful in sorting the wheat from the chaff, but it
 would be interesting to consider the hidden aquifers that make much of the grain grow in the
 first place.

The role of moral and ethical education in promoting rational
 behavior is also underexplored. Pinker recognizes that rationality "is not just a cognitive
 virtue but a moral one." But this profoundly important point, one subtly explored by ancient
 Greek philosophers like Plato and Aristotle, doesn't really get developed. This is a shame,
 since possessing the right sort of moral character is arguably a precondition for using
 rationality in beneficial ways.

 CAT 2023 Slot 3 - VA RC

 The author refers to the ancient Greek philosophers to:

 indicate the various similarities between their thinking and Pinker's
 conclusions.

 reveal gaps in Pinker's discussion of the importance of ethical
 considerations in rational behaviour.

 show how dreams and visions have for centuries influenced subconscious
 behaviour and pathbreaking inventions.

 highlight the influence of their thinking on the development of Pinker's
 arguments.

**ANSWER:** Choice B

### Q6

reveal gaps in Pinker's discussion
 of the importance of ethical considerations in rational
 behaviour.

 CAT 2023 Slot 3 - VA RC

 The author mentions Kekulé's discovery of the structure of benzene and Mozart's
 symphonies to illustrate the point that:

 great innovations across various fields can stem from flashes of intuition
 and are not always propelled by logical thinking.

 unlike the sciences, human achievements in other fields are a mix of logical
 reasoning and spontaneous epiphanies.

 Pinker's conclusions on sequential reasoning are belied by European
 achievements which, in the past, were more rooted in unconscious bursts of
 genius.

 it is not just the creative arts, but also scientific fields that have
 benefitted from flashes of creativity.

**ANSWER:** Choice A

### Q7

great innovations across various
 fields can stem from flashes of intuition and are not always propelled
 by logical thinking.

 CAT 2023 Slot 3 - VA RC

 According to the author, for Pinker as well as the ancient Greek philosophers, rational
 thinking involves all of the following EXCEPT:

 the belief that the ability to reason logically encompasses an ethical and
 moral dimension.

 an awareness of underlying assumptions in an argument and gaps in one's own
 knowledge.

 the primacy of conscious sequential reasoning as the basis for seminal human
 achievements.

 arriving at independent conclusions irrespective of who is presenting the
 argument.

**ANSWER:** Choice C

### Q8

the primacy of conscious sequential
 reasoning as the basis for seminal human achievements.

 CAT 2023 Slot 3 - VA RC

 The author endorses Pinker's views on the importance of logical reasoning as it:

 equips people with the ability to tackle challenging practical problems.

 focuses public attention on real issues like development rather than
 sensational events.

 provides a moral compass for resolving important ethical dilemmas.

 helps people to gain expertise in statistics and other scientific
 disciplines.

**ANSWER:** Choice A

### Q9

equips people with the ability to
 tackle challenging practical problems.

 The passage below is accompanied by four questions. Based on the passage,
 choose the best answer for each question.
In 2006, the Met [art museum in the US]
 agreed to return the Euphronios krater, a masterpiece Greek urn that had been a museum draw
 since 1972. In 2007, the Getty [art museum in the US] agreed to return 40 objects to Italy,
 including a marble Aphrodite, in the midst of looting scandals. And in December, Sotheby's
 and a private owner agreed to return an ancient Khmer statue of a warrior, pulled from
 auction two years before, to Cambodia.

Cultural property, or patrimony, laws
 limit the transfer of cultural property outside the source country's territory, including
 outright export prohibitions and national ownership laws. Most art historians,
 archaeologists, museum officials and policymakers portray cultural property laws in general
 as invaluable tools for counteracting the ugly legacy of Western cultural
 imperialism.

During the late 19 th and early 20 th century —
 an era former Met director Thomas Hoving called "the age of piracy" — American and European
 art museums acquired antiquities by hook or by crook, from grave robbers or souvenir
 collectors, bounty from digs and ancient sites in impoverished but art-rich source
 countries. Patrimony laws were intended to protect future archaeological discoveries against
 Western imperialist designs. . . .

I surveyed 90 countries with one or more
 archaeological sites on UNESCO's World Heritage Site list, and my study shows that in most
 cases the number of discovered sites diminishes sharply after a country passes a cultural
 property law. There are 222 archaeological sites listed for those 90 countries. When you
 look into the history of the sites, you see that all but 21 were discovered before the
 passage of cultural property laws. . . .

Strict cultural patrimony laws are
 popular in most countries. But the downside may be that they reduce incentives for foreign
 governments, nongovernmental organizations and educational institutions to invest in
 overseas exploration because their efforts will not necessarily be rewarded by opportunities
 to hold, display and study what is uncovered. To the extent that source countries can fund
 their own archaeological projects, artifacts and sites may still be discovered. . . . The
 survey has far-reaching implications. It suggests that source countries, particularly in the
 developing world, should narrow their cultural property laws so that they can reap the
 benefits of new archaeological discoveries, which typically increase tourism and enhance
 cultural pride. This does not mean these nations should abolish restrictions on foreign
 excavation and foreign claims to artifacts.

China provides an interesting
 alternative approach for source nations eager for foreign archaeological investment. From
 1935 to 2003, China had a restrictive cultural property law that prohibited foreign
 ownership of Chinese cultural artifacts. In those years, China's most significant
 archaeological discovery occurred by chance, in 1974, when peasant farmers accidentally
 uncovered ranks of buried terra cotta warriors, which are part of Emperor Qin's spectacular
 tomb system.

In 2003, the Chinese government switched course, dropping its
 cultural property law and embracing collaborative international archaeological research.
 Since then, China has nominated 11 archaeological sites for inclusion in the World Heritage
 Site list, including eight in 2013, the most ever for China.

 CAT 2023 Slot 3 - VA RC

 From the passage we can infer that the author is likely to advise poor, but
 archaeologically-rich source countries to do all of the following, EXCEPT:

 to find ways to motivate other countries to finance archaeological
 explorations in their country.

 allow foreign countries to analyse and exhibit the archaeological finds made
 in the source country.

 adopt China's strategy of dropping its cultural property laws and carrying
 out archaeological research through international collaboration.

 fund institutes in other countries to undertake archaeological exploration
 in the source country reaping the benefits of cutting-edge techniques.

**ANSWER:** Choice D

### Q10

fund institutes in other countries
 to undertake archaeological exploration in the source country reaping
 the benefits of cutting-edge techniques.

 CAT 2023 Slot 3 - VA RC

 It can be inferred from the passage that archaeological sites are considered important by
 some source countries because they:

 give a boost to the tourism sector.

 are a symbol of Western imperialism.

 generate funds for future discoveries.

 are subject to strict patrimony laws.

**ANSWER:** Choice A

### Q11

give a boost to the tourism
 sector.

 CAT 2023 Slot 3 - VA RC

 Which one of the following statements, if true, would undermine the central idea of the
 passage?

 Affluent archaeologically-rich source countries can afford to carry out
 their own excavations.

 Museums established in economically deprived archaeologically-rich source
 countries can display the antiques discovered there.

 Western countries will have to apologise to countries for looting their
 cultural property in the past century.

 UNESCO finances archaeological research in poor, but archaeologically-rich
 source countries.

**ANSWER:** Choice D

### Q12

UNESCO finances archaeological
 research in poor, but archaeologically-rich source countries.

 CAT 2023 Slot 3 - VA RC

 Which one of the following statements best expresses the paradox of patrimony laws?

 They were intended to protect cultural property, but instead resulted in the
 neglect of historical sites.

 They were aimed at protecting cultural property, but instead reduced
 business for auctioneers like Sotheby's.

 They were aimed at protecting cultural property, but instead reduced new
 archaeological discoveries.

 They were intended to protect cultural property, but instead resulted in the
 withholding of national treasure from museums.

**ANSWER:** Choice C

### Q13

They were aimed at protecting
 cultural property, but instead reduced new archaeological
 discoveries.

 The passage below is accompanied by four questions. Based on the passage,
 choose the best answer for each question.

Understanding romantic aesthetics is
 not a simple undertaking for reasons that are internal to the nature of the subject.
 Distinguished scholars, such as Arthur Lovejoy, Northrop Frye and Isaiah Berlin, have
 remarked on the notorious challenges facing any attempt to define romanticism. Lovejoy, for
 example, claimed that romanticism is "the scandal of literary history and criticism" . . .
 The main difficulty in studying the romantics, according to him, is the lack of any "single
 real entity, or type of entity" that the concept "romanticism" designates. Lovejoy
 concluded, "the word 'romantic' has come to mean so many things that, by itself, it means
 nothing" . . .

The more specific task of characterizing romantic aesthetics adds
 to these difficulties an air of paradox. Conventionally, "aesthetics" refers to a theory
 concerning beauty and art or the branch of philosophy that studies these topics. However,
 many of the romantics rejected the identification of aesthetics with a circumscribed domain
 of human life that is separated from the practical and theoretical domains of life. The most
 characteristic romantic commitment is to the idea that the character of art and beauty and
 of our engagement with them should shape all aspects of human life. Being fundamental to
 human existence, beauty and art should be a central ingredient not only in a philosophical
 or artistic life, but also in the lives of ordinary men and women. Another challenge for any
 attempt to characterize romantic aesthetics lies in the fact that most of the romantics were
 poets and artists whose views of art and beauty are, for the most part, to be found not in
 developed theoretical accounts, but in fragments, aphorisms and poems, which are often more
 elusive and suggestive than conclusive.

Nevertheless, in spite of these
 challenges the task of characterizing romantic aesthetics is neither impossible nor
 undesirable, as numerous thinkers responding to Lovejoy's radical skepticism have noted.
 While warning against a reductive definition of romanticism, Berlin, for example, still
 heralded the need for a general characterization: "[Although] one does have a certain
 sympathy with Lovejoy's despair…[he is] in this instance mistaken. There was a romantic
 movement…and it is important to discover what it is" . . .

Recent attempts to
 characterize romanticism and to stress its contemporary relevance follow this path. Instead
 of overlooking the undeniable differences between the variety of romanticisms of different
 nations that Lovejoy had stressed, such studies attempt to characterize romanticism, not in
 terms of a single definition, a specific time, or a specific place, but in terms of
 "particular philosophical questions and concerns" . . .

While the German, British
 and French romantics are all considered, the central protagonists in the following are the
 German romantics. Two reasons explain this focus: first, because it has paved the way for
 the other romanticisms, German romanticism has a pride of place among the different national
 romanticisms . . . Second, the aesthetic outlook that was developed in Germany roughly
 between 1796 and 1801–02 — the period that corresponds to the heyday of what is known as
 "Early Romanticism" . . .— offers the most philosophical expression of romanticism since it
 is grounded primarily in the epistemological, metaphysical, ethical, and political concerns
 that the German romantics discerned in the aftermath of Kant's philosophy.

 CAT 2023 Slot 3 - VA RC

 According to the romantics, aesthetics:

 is widely considered to be irrelevant to human existence.

 permeates all aspects of human life, philosophical and mundane.

 should be confined to a specific domain separate from the practical and
 theoretical aspects of life.

 is primarily the concern of philosophers and artists, rather than of
 ordinary people.

**ANSWER:** Choice B

### Q14

permeates all aspects of human
 life, philosophical and mundane.

 CAT 2023 Slot 3 - VA RC

 Which one of the following statements is NOT supported by the passage?

 Recent studies on romanticism seek to refute the differences between
 national romanticisms.

 Romantic aesthetics are primarily expressed through fragments, aphorisms,
 and poems.

 Many romantics rejected the idea of aesthetics as a domain separate from
 other aspects of life.

 Characterising romantic aesthetics is both possible and desirable, despite
 the challenges involved.

**ANSWER:** Choice A

### Q15

Recent studies on romanticism seek
 to refute the differences between national romanticisms.

 CAT 2023 Slot 3 - VA RC

 The main difficulty in studying romanticism is the:

 absence of written accounts by romantic poets and artists.

 elusive and suggestive nature of romantic aesthetics.

 controversial and scandalous history of romantic literature.

 lack of clear conceptual contours of the domain.

**ANSWER:** Choice D

### Q16

lack of clear conceptual contours
 of the domain.

 CAT 2023 Slot 3 - VA RC

 According to the passage, recent studies on romanticism avoid "a single definition, a
 specific time, or a specific place" because they:

 prefer to highlight the paradox of romantic aesthetics as a concept.

 seek to discredit Lovejoy's scepticism regarding romanticism.

 understand that the variety of romanticisms renders a general analysis
 impossible.

 prefer to focus on the fundamental concerns of the romantics.

**ANSWER:** Choice D

### Q17

prefer to focus on the fundamental
 concerns of the romantics.

 CAT 2023 Slot 3 - VA RC

 There is a sentence that is missing in the paragraph below. Look at the paragraph and
 decide where (option 1, 2, 3, or 4) the following sentence would best
 fit.

Sentence: For theoretical purposes, arguments may be considered as
 freestanding entities, abstracted from their contexts of use in actual human
 activities.

Paragraph : ___(1)___. An argument can be defined as a complex
 symbolic structure where some parts, known as the premises, offer support to another
 part, the conclusion. Alternatively, an argument can be viewed as a complex speech act
 consisting of one or more acts of premising (which assert propositions in favor of the
 conclusion), an act of concluding, and a stated or implicit marker ("hence",
 "therefore") that indicates that the conclusion follows from the premises.___(2)___. The
 relation of support between premises and conclusion can be cashed out in different ways:
 the premises may guarantee the truth of the conclusion, or make its truth more probable;
 the premises may imply the conclusion; the premises may make the conclusion more
 acceptable (or assertible).___(3)___. But depending on one's explanatory goals, there is
 also much to be gained from considering arguments as they in fact occur in human
 communicative practices.___(4)___.

 Option 1

 Option 4

 Option 2

 Option 3

**ANSWER:** Choice D

### Q18

Option 3

 CAT 2023 Slot 3 - VA RC

 There is a sentence that is missing in the paragraph below. Look at the paragraph and
 decide where (option 1, 2, 3, or 4) the following sentence would best
 fit.

Sentence: Beyond undermining the monopoly of the State on the use of
 force, armed conflict also creates an environment that can enable organized crime to
 prosper.

Paragraph: ___(1)___. Linkages between illicit arms, organized
 crime, and armed conflict can reinforce one another while also escalating and prolonging
 violence and eroding governance.___(2)___. Financial gains from crime can lengthen or
 intensify armed conflicts by creating revenue streams for non-State armed groups
 (NSAGs).___(3)___. In this context, when hostilities cease and parties to a conflict
 move towards a peaceful resolution, the widespread availability of surplus arms and
 ammunition can contribute to a situation of 'criminalized peace' that obstructs
 sustainable peacebuilding efforts.___(4)___.

 Option 2

 Option 4

 Option 1

 Option 3

**ANSWER:** Choice D

### Q19

Option 3

 CAT 2023 Slot 3 - VA RC

 Five jumbled up sentences (labelled 1, 2, 3, 4 and 5), related to a topic, are given
 below. Four of them can be put together to form a coherent paragraph. Identify the odd
 sentence and key in the number of that sentence as your answer.

1. Although
 hard skills have traditionally ruled the roost, some companies are moving away from
 choosing prospective hires based on technical abilities alone.
2. Companies are
 shaking off the old definition of an ideal candidate and ditching the idea of looking
 for the singularly perfect candidate altogether.
3. Now, some job descriptions are
 frequently asking for candidates to demonstrate soft skills, such as leadership or
 teamwork.
4. That's not to say that practical know-how is no longer required – some
 jobs still call for highly specific expertise
5. The move towards prioritising soft
 skills "is a natural response to three years of the pandemic" says a senior recruiter at
 Cenlar FSB.

**ANSWER:** 2

### Q20

CAT 2023 Slot 3 - VA RC

 Five jumbled up sentences (labelled 1, 2, 3, 4 and 5), related to a topic, are given
 below. Four of them can be put together to form a coherent paragraph. Identify the odd
 sentence and key in the number of that sentence as your answer.

1. Boa
 Senior, who lived through the 2004 tsunami, the Japanese occupation and diseases brought
 by British settlers, was the last native of the island chain who was fluent in
 Bo.
2. The indigenous population has been steadily collapsing since the island
 chain was colonised by British settlers in 1858 and used for most of the following 100
 years as a colonial penal colony.
3. Taking its name from a now-extinct tribe, Bo
 is one of the 10 Great Andamanese languages, which are thought to date back to
 pre-Neolithic human settlement of south-east Asia.
4. The last speaker of an
 ancient tribal language has died in the Andaman Islands, breaking a 65,000-year link to
 one of the world's oldest cultures.
5. Though the language has been closely studied
 by researchers of linguistic history, Boa Senior spent the last few years of her life
 unable to converse with anyone in her mother tongue.

**ANSWER:** 2

### Q21

CAT 2023 Slot 3 - VA RC

 The four sentences (labelled 1, 2, 3 and 4) given below, when properly sequenced, would
 yield a coherent paragraph. Decide on the proper sequencing of the order of the
 sentences and key in the sequence of the four numbers as your answer.

1.
 Veena Sahajwalla, a materials scientist at the University of New South Wales, believes
 there is a new way of solving this problem.
2. Her vision is for automated drones
 and robots to pick out components, put them into a small furnace and smelt them at
 specific temperatures to extract the metals one by one before they are sent off to
 manufacturers for reuse.
3. E-waste contains huge quantities of valuable metals,
 ceramics and plastics that could be salvaged and recycled, although currently not enough
 of it is.
4. She plans to build microfactories that can tease apart the tangle of
 materials in mobile phones, computers and other e-waste.

**ANSWER:** 3142

### Q22

CAT 2023 Slot 3 - VA RC

 The four sentences (labelled 1, 2, 3 and 4) given below, when properly sequenced, would
 yield a coherent paragraph. Decide on the proper sequencing of the order of the
 sentences and key in the sequence of the four numbers as your answer.

 1.
 Centuries later formal learning is still mostly based on reading, even with the
 widespread use of other possible education-affecting technologies such as film, radio,
 and television.
 2. One of the immediate and recognisable impacts of the printing
 press was on how people learned; in the scribal culture it primarily involved listening,
 so memorization was paramount.
 3. The transformation of learners from listeners to
 readers was a complex social and cultural phenomenon, and it was not until the
 industrial era that the concept of universal literacy took root.
 4. The printing
 press shifted the learning process, as listening and memorisation gradually gave way to
 reading and learning no longer required the presence of a mentor; it could be done
 privately.

**ANSWER:** 2431

### Q23

CAT 2023 Slot 3 - VA RC

 The passage given below is followed by four alternate summaries. Choose the option that
 best captures the essence of the passage.

Gradually, life for the island's
 birds is improving. Antarctic prions and white-headed petrels, which also nest in
 burrows, had managed to cling on in some sites while pests were on the island. Their
 numbers are now increasing. "It's fantastic and so exciting," Shaw says. As birds return
 to breed, they also poo. This adds nutrients to the soil, which in turn helps the plants
 to grow back stronger. Tall plants then help burrowing birds hide from predatory skuas.
 "It's this wonderful feedback loop," Shaw says. Today, the "pretty paddock" that
 Houghton first experienced has been transformed. "The tussock is over your head, and
 you're dodging all these penguin tunnels," she says. The orchids and tiny herb that had
 been protected by fencing have started turning up all over the place.

 There is an increasing number of predatory birds and plants on the island
 despite the presence of pests which is a positive development.

 In the absence of pests, life on the island is now protected, and there has
 been a revival of a variety of birds and plants.

 There is a huge positive transformation of the ecosystem of the island when
 brought under environmental protection.

 Flowering plants, herbs and birds are now being protected on this wonderful
 Antarctic island.

**ANSWER:** Choice B

### Q24

In the absence of pests, life on
 the island is now protected, and there has been a revival of a variety
 of birds and plants.

 CAT 2023 Slot 3 - VA RC

 The passage given below is followed by four alternate summaries. Choose the option that
 best captures the essence of the passage.

The weight of society's
 expectations is hardly a new phenomenon but it has become particularly draining over
 recent decades, perhaps because expectations themselves are so multifarious and
 contradictory. The perfectionism of the 1950s was rooted in the norms of mass culture
 and captured in famous advertising images of the ideal white American family that now
 seem self-satirising. In that era, perfectionism meant seamlessly conforming to values,
 behaviour and appearance: chiselled confidence for men, demure graciousness for women.
 The perfectionist was under pressure to look like everyone else, only more so. The
 perfectionists of today, by contrast, feel an obligation to stand out through their
 idiosyncratic style and wit if they are to gain a foothold in the attention economy.

 Though long-standing, the pressure to appear perfect and thereby attract
 attention, has evolved over time from one of conformism to one of
 non-conformism.

 The pressure to appear perfect has been the cause of tension and conflict
 because the idea itself has been in a state of flux and hard to define.

 The desire to attract attention is so deep-rooted in individual
 consciousness that people are willing to go to any lengths to achieve it.

 The image of perfectionism is reflected in and perpetuated by the media; and
 people do their best to adhere to these ideals.

**ANSWER:** Choice A
