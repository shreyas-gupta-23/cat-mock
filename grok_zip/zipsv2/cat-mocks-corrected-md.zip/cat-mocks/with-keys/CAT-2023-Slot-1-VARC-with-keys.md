# CAT 2023 — Slot 1 — VARC (Questions + On-page Answer Key)

Answers are on-page 2IIM **Correct Answer** labels. Not invented.

## VARC

- Source file: `2iim-html/CAT-2023-Question-Paper-Slot-1-VARC.txt`
- Page: https://online.2iim.com/CAT-question-paper/CAT-2023-Question-Paper-Slot-1-VARC/
- On-page answers found: 24
- Answer source: 2IIM on-page **Correct Answer** / **Correct Answer Choice** (not invented)

### Q1

Today, no
 scholar would be silly enough to deny that culture, history, and individual choices play a
 big role in many human phenomena. Scholars don't react to cultural, historical, and
 individual-agent explanations by denouncing "cultural determinism," "historical
 determinism," or "individual determinism," and then thinking no further. But many scholars
 do react to any explanation invoking some geographic role, by denouncing "geographic
 determinism" . . .

Several reasons may underlie this widespread but nonsensical
 view. One reason is that some geographic explanations advanced a century ago were racist,
 thereby causing all geographic explanations to become tainted by racist associations in the
 minds of many scholars other than geographers. But many genetic, historical, psychological,
 and anthropological explanations advanced a century ago were also racist, yet the validity
 of newer non-racist genetic etc. explanations is widely accepted today.

Another
 reason for reflex rejection of geographic explanations is that historians have a tradition,
 in their discipline, of stressing the role of contingency (a favorite word among historians)
 based on individual decisions and chance. Often that view is warranted . . . But often, too,
 that view is unwarranted. The development of warm fur clothes among the Inuit living north
 of the Arctic Circle was not because one influential Inuit leader persuaded other Inuit in
 1783 to adopt warm fur clothes, for no good environmental reason.

A third reason
 is that geographic explanations usually depend on detailed technical facts of geography and
 knowledge as part of the professional training.

 CAT 2023 Slot 1 - VA RC

 All of the following can be inferred from the passage EXCEPT:

 agricultural practices changed drastically in the Australian continent after
 it was colonised.

 individual dictat and contingency were not the causal factors for the use of
 fur clothing in some very cold climates.

 while most human phenomena result from culture and individual choice, some
 have bio-geographic origins.

 several academic studies of human phenomena in the past involved racist
 interpretations.

**ANSWER:** Choice C

### Q2

while most human phenomena result
 from culture and individual choice, some have bio-geographic
 origins.

 CAT 2023 Slot 1 - VA RC

 All of the following are advanced by the author as reasons why non-geographers disregard
 geographic influences on human phenomena EXCEPT their:

 dismissal of explanations that involve geographical causes for human
 behaviour.

 belief in the central role of humans, unrelated to physical surroundings, in
 influencing phenomena.

 lingering impressions of past geographic analyses that were politically
 offensive.

 disciplinary training which typically does not include technical knowledge
 of geography.

**ANSWER:** Choice A

### Q3

dismissal of explanations that
 involve geographical causes for human behaviour.

 CAT 2023 Slot 1 - VA RC

 The examples of the Inuit and Aboriginal Australians are offered in the passage to show:

 how environmental factors lead to comparatively divergent paths in
 livelihoods and development.

 human resourcefulness across cultures in adapting to their surroundings.

 how physical circumstances can dictate human behaviour and cultures.

 that despite geographical isolation, traditional societies were
 self-sufficient and adaptive.

**ANSWER:** Choice C

### Q4

how physical circumstances can
 dictate human behaviour and cultures.

 CAT 2023 Slot 1 - VA RC

 The author criticises scholars who are not geographers for all of the following reasons
 EXCEPT:

 their rejection of the role of biogeographic factors in social and cultural
 phenomena.

 their outdated interpretations of past cultural and historical phenomena.

 their labelling of geographic explanations as deterministic.

 the importance they place on the role of individual decisions when studying
 human phenomena.

**ANSWER:** Choice B

### Q5

their outdated interpretations of
 past cultural and historical phenomena.

 The passage below is accompanied by four questions. Based on the passage,
 choose the best answer for each question.

For early postcolonial literature, the
 world of the novel was often the nation. Postcolonial novels were usually [concerned with]
 national questions. Sometimes the whole story of the novel was taken as an allegory of the
 nation, whether India or Tanzania. This was important for supporting anti-colonial
 nationalism, but could also be limiting – land-focused and inward-looking.

My new
 book "Writing Ocean Worlds" explores another kind of world of the novel: not the village or
 nation, but the Indian Ocean world. The book describes a set of novels in which the Indian
 Ocean is at the centre of the story. It focuses on the novelists Amitav Ghosh, Abdulrazak
 Gurnah, Lindsey Collen and Joseph Conrad [who have] centred the Indian Ocean world in the
 majority of their novels. . . . Their work reveals a world that is outward-looking – full of
 movement, border-crossing and south-south interconnection. They are all very different –
 from colonially inclined (Conrad) to radically anti-capitalist (Collen), but together draw
 on and shape a wider sense of Indian Ocean space through themes, images, metaphors and
 language. This has the effect of remapping the world in the reader's mind, as centred in the
 interconnected global south. . . .

The Indian Ocean world is a term used to
 describe the very long-lasting connections among the coasts of East Africa, the Arab coasts,
 and South and East Asia. These connections were made possible by the geography of the Indian
 Ocean. For much of history, travel by sea was much easier than by land, which meant that
 port cities very far apart were often more easily connected to each other than to much
 closer inland cities. Historical and archaeological evidence suggests that what we now call
 globalisation first appeared in the Indian Ocean. This is the interconnected oceanic world
 referenced and produced by the novels in my book. . . .

For their part Ghosh,
 Gurnah, Collen and even Conrad reference a different set of histories and geographies than
 the ones most commonly found in fiction in English. Those [commonly found ones] are mostly
 centred in Europe or the US, assume a background of Christianity and whiteness, and mention
 places like Paris and New York. The novels in [my] book highlight instead a largely Islamic
 space, feature characters of colour and centralise the ports of Malindi, Mombasa, Aden, Java
 and Bombay. . . . It is a densely imagined, richly sensory image of a southern cosmopolitan
 culture which provides for an enlarged sense of place in the world.

This
 remapping is particularly powerful for the representation of Africa. In the fiction, sailors
 and travellers are not all European. . . . African, as well as Indian and Arab characters,
 are traders, nakhodas (dhow ship captains), runaways, villains, missionaries and activists.
 This does not mean that Indian Ocean Africa is romanticised. Migration is often a matter of
 force; travel is portrayed as abandonment rather than adventure, freedoms are kept from
 women and slavery is rife. What it does mean is that the African part of the Indian Ocean
 world plays an active role in its long, rich history and therefore in that of the wider
 world.

 CAT 2023 Slot 1 - VA RC

 All of the following claims contribute to the "remapping" discussed by the passage,
 EXCEPT:

 the global south, as opposed to the global north, was the first centre of
 globalisation.

 the world of early international trade and commerce was not the sole domain
 of white Europeans.

 cosmopolitanism originated in the West and travelled to the East through
 globalisation.

 Indian Ocean novels have gone beyond the specifics of national concerns to
 explore rich regional pasts.

**ANSWER:** Choice C

### Q6

cosmopolitanism originated in the
 West and travelled to the East through globalisation.

 CAT 2023 Slot 1 - VA RC

 Which one of the following statements is not true about migration in the Indian Ocean
 world?

 Geographical location rather than geographical proximity determined the
 choice of destination for migrants.

 The Indian Ocean world's migration networks were shaped by religious and
 commercial histories of the region.

 The Indian Ocean world's migration networks connected the global north with
 the global south.

 Migration in the Indian Ocean world was an ambivalent experience.

**ANSWER:** Choice C

### Q7

The Indian Ocean world's migration
 networks connected the global north with the global south.

 CAT 2023 Slot 1 - VA RC

 On the basis of the nature of the relationship between the items in each pair below,
 choose the odd pair out:

 Postcolonial novels : Border-crossing

 Postcolonial novels : Anti-colonial nationalism

 Indian Ocean world : Slavery

 Indian Ocean novels : Outward-looking

**ANSWER:** Choice A

### Q8

Postcolonial novels :
 Border-crossing

 CAT 2023 Slot 1 - VA RC

 All of the following statements, if true, would weaken the passage's claim about the
 relationship between mainstream English-language fiction and Indian Ocean novels EXCEPT:

 most mainstream English-language novels have historically privileged the
 Christian, white, male experience of travel and adventure.

 the depiction of Africa in most Indian Ocean novels is driven by an
 Orientalist imagination of its cultural crudeness.

 very few mainstream English-language novels have historically been set in
 American and European metropolitan centres.

 the depiction of Africa in most Indian Ocean novels is driven by a
 postcolonial nostalgia for an idyllic past.

**ANSWER:** Choice A

### Q9

most mainstream English-language
 novels have historically privileged the Christian, white, male
 experience of travel and adventure.

 The passage below is accompanied by four questions. Based on the passage,
 choose the best answer for each question.

[Fifty] years after its publication in
 English [in 1972], and just a year since [Marshall] Sahlins himself died—we may ask: why did
 [his essay] "Original Affluent Society" have such an impact, and how has it fared since? . .
 . Sahlins's principal argument was simple but counterintuitive: before being driven into
 marginal environments by colonial powers, hunter-gatherers, or foragers, were not engaged in
 a desperate struggle for meager survival. Quite the contrary, they satisfied their needs
 with far less work than people in agricultural and industrial societies, leaving them more
 time to use as they wished. Hunters, he quipped, keep bankers' hours. Refusing to maximize,
 many were "more concerned with games of chance than with chances of game." . . . The
 so-called Neolithic Revolution, rather than improving life, imposed a harsher work regime
 and set in motion the long history of growing inequality . . .

Moreover, foragers
 had other options. The contemporary Hadza of Tanzania, who had long been surrounded by
 farmers, knew they had alternatives and rejected them. To Sahlins, this showed that foragers
 are not simply examples of human diversity or victimhood but something more profound: they
 demonstrated that societies make real choices. Culture, a way of living oriented around a
 distinctive set of values, manifests a fundamental principle of collective
 self-determination. . . .

But the point [of the essay] is not so much the
 empirical validity of the data—the real interest for most readers, after all, is not in
 foragers either today or in the Paleolithic—but rather its conceptual challenge to
 contemporary economic life and bourgeois individualism. The empirical served a philosophical
 and political project, a thought experiment and stimulus to the imagination of
 possibilities.

With its title's nod toward The Affluent Society (1958),
 economist John Kenneth Galbraith's famously skeptical portrait of America's postwar
 prosperity and inequality, and dripping with New Left contempt for consumerism, "The
 Original Affluent Society" brought this critical perspective to bear on the contemporary
 world. It did so through the classic anthropological move of showing that radical
 alternatives to the readers' lives really exist. If the capitalist world seeks wealth
 through ever greater material production to meet infinitely expansive desires, foraging
 societies follow "the Zen road to affluence": not by getting more, but by wanting less. If
 it seems that foragers have been left behind by "progress," this is due only to the
 ethnocentric self-congratulation of the West. Rather than accumulate material goods, these
 societies are guided by other values: leisure, mobility, and above all, freedom. . .
 .

Viewed in today's context, of course, not every aspect of the essay has aged
 well. While acknowledging the violence of colonialism, racism, and dispossession, it does
 not thematize them as heavily as we might today. Rebuking evolutionary anthropologists for
 treating present-day foragers as "left behind" by progress, it too can succumb to the
 temptation to use them as proxies for the Paleolithic. Yet these characteristics should not
 distract us from appreciating Sahlins's effort to show that if we want to conjure new
 possibilities, we need to learn about actually inhabitable worlds.

 CAT 2023 Slot 1 - VA RC

 We can infer that Sahlins's main goal in writing his essay was to:

 highlight the fact that while we started off as a fairly contented
 egalitarian people, we have progressively degenerated into materialism.

 put forth the view that, despite egalitarian origins, economic progress
 brings greater inequality and social hierarchies.

 hold a mirror to an acquisitive society, with examples of other communities
 that have chosen successfully to be non-materialistic.

 counter Galbraith's pessimistic view of the inevitability of a capitalist
 trajectory for economic growth.

**ANSWER:** Choice C

### Q10

hold a mirror to an acquisitive
 society, with examples of other communities that have chosen
 successfully to be non-materialistic.

 CAT 2023 Slot 1 - VA RC

 The author mentions Tanzania's Hadza community to illustrate:

 that forager communities' lifestyles derived not from ignorance about
 alternatives, but from their own choice.

 how two vastly different ways of living and working were able to coexist in
 proximity for centuries.

 how pre-agrarian societies did not hamper the emergence of more advanced
 agrarian practices in contiguous communities.

 that hunter-gatherer communities' subsistence-level techniques equipped them
 to survive well into contemporary times.

**ANSWER:** Choice A

### Q11

that forager communities'
 lifestyles derived not from ignorance about alternatives, but from their
 own choice.

 CAT 2023 Slot 1 - VA RC

 The author of the passage criticises Sahlins's essay for its:

 outdated values regarding present-day foragers versus ancient foraging
 communities.

 failure to supplement its thesis with robust empirical data.

 critique of anthropologists who disparage the choices of foragers in today's
 society.

 cursory treatment of the effects of racism and colonialism on societies.

**ANSWER:** Choice D

### Q12

cursory treatment of the effects of
 racism and colonialism on societies.

 CAT 2023 Slot 1 - VA RC

 The author of the passage mentions Galbraith's "The Affluent Society" to:

 contrast the materialist nature of contemporary growth paths with the
 pacifist content ways of living among the foragers.

 document the influence of Galbraith's cynical views on modern consumerism on
 Sahlins's analysis of pre-historic societies.

 show how Galbraith's theories refute Sahlins's thesis on the contentment of
 pre-hunter-gatherer communities.

 show how Sahlins's views complemented Galbraith's criticism of the
 consumerism and inequality of contemporary society.

**ANSWER:** Choice D

### Q13

show how Sahlins's views
 complemented Galbraith's criticism of the consumerism and inequality of
 contemporary society.

 The passage below is accompanied by four questions. Based on the passage,
 choose the best answer for each question.

RESIDENTS of Lozère, a hilly department
 in southern France, recite complaints familiar to many rural corners of Europe. In remote
 hamlets and villages, with names such as Le Bacon and Le Bacon Vieux, mayors grumble about a
 lack of local schools, jobs, or phone and internet connections. Farmers of grazing animals
 add another concern: the return of wolves. Eradicated from France last century, the
 predators are gradually creeping back to more forests and hillsides. "The wolf must be taken
 in hand," said an aspiring parliamentarian, Francis Palombi, when pressed by voters in an
 election campaign early this summer. Tourists enjoy visiting a wolf park in Lozère, but
 farmers fret over their livestock and their livelihoods. . . .

As early as the
 ninth century, the royal office of the Luparii—wolf-catchers—was created in France to tackle
 the predators. Those official hunters (and others) completed their job in the 1930s, when
 the last wolf disappeared from the mainland. Active hunting and improved technology such as
 rifles in the 19 th century, plus the use of poison such as strychnine later on,
 caused the population collapse. But in the early 1990s the animals reappeared. They crossed
 the Alps from Italy, upsetting sheep farmers on the French side of the border. Wolves have
 since spread to areas such as Lozère, delighting environmentalists, who see the predators'
 presence as a sign of wider ecological health. Farmers, who say the wolves cause the deaths
 of thousands of sheep and other grazing animals, are less cheerful. They grumble that green
 activists and politically correct urban types have allowed the return of an old
 enemy.

Various factors explain the changes of the past few decades. Rural
 depopulation is part of the story. In Lozère, for example, farming and a once-flourishing
 mining industry supported a population of over 140,000 residents in the mid-19 th
 century. Today the department has fewer than 80,000 people, many in its towns. As humans
 withdraw, forests are expanding. In France, between 1990 and 2015, forest cover increased by
 an average of 102,000 hectares each year, as more fields were given over to trees. Now,
 nearly one-third of mainland France is covered by woodland of some sort. The decline of
 hunting as a sport also means more forests fall quiet. In the mid-to-late 20 th
 century over 2m hunters regularly spent winter weekends tramping in woodland, seeking
 boars, birds and other prey. Today the Fédération Nationale des Chasseurs, the national
 body, claims 1.1m people hold hunting licences, though the number of active hunters is
 probably lower. The mostly protected status of the wolf in Europe—hunting them is now
 forbidden, other than when occasional culls are sanctioned by the state—plus the efforts of
 NGOs to track and count the animals, also contribute to the recovery of wolf
 populations.

As the lupine population of Europe spreads westwards, with
 occasional reports of wolves seen closer to urban areas, expect to hear of more clashes
 between farmers and those who celebrate the predators' return. Farmers' losses are real, but
 are not the only economic story. Tourist venues, such as parks where wolves are kept and the
 animals' spread is discussed, also generate income and jobs in rural areas.

 CAT 2023 Slot 1 - VA RC

 The inhabitants of Lozère have to grapple with all of the following problems, EXCEPT:

 poor rural communication infrastructure.

 lack of educational facilities.

 decline in the number of hunting licences.

 livestock losses.

**ANSWER:** Choice C

### Q14

decline in the number of hunting
 licences.

 CAT 2023 Slot 1 - VA RC

 Which one of the following has NOT contributed to the growing wolf population in Lozère?

 The granting of a protected status to wolves in Europe.

 The shutting down of the royal office of the Luparii.

 An increase in woodlands and forest cover in Lozère.

 A decline in the rural population of Lozère.

**ANSWER:** Choice B

### Q15

The shutting down of the royal
 office of the Luparii.

 CAT 2023 Slot 1 - VA RC

 The author presents a possible economic solution to an existing issue facing Lozère that
 takes into account the divergent and competing interests of:

 tourists and environmentalists.

 environmentalists and politicians.

 politicians and farmers.

 farmers and environmentalists.

**ANSWER:** Choice D

### Q16

farmers and
 environmentalists.

 CAT 2023 Slot 1 - VA RC

 Which one of the following statements, if true, would weaken the author's claims?

 Wolf attacks on tourists in Lozère are on the rise.

 Having migrated out in the last century, wolves are now returning to Lozère.

 The old mining sites of Lozère are now being used as grazing pastures for
 sheep.

 Unemployment concerns the residents of Lozère.

**ANSWER:** Choice A

### Q17

Wolf attacks on tourists in Lozère
 are on the rise.

 CAT 2023 Slot 1 - VA RC

 There is a sentence that is missing in the paragraph below. Look at the paragraph and
 decide where (option 1, 2, 3, or 4) the following sentence would best
 fit.

Sentence:This philosophical cut at one's core beliefs, values, and way
 of life is difficult enough.

Paragraph: The experience of reading philosophy
 is often disquieting. When reading philosophy, the values around which one has
 heretofore organised one's life may come to look provincial, flatly wrong, or even evil.
 ___(1)___. When beliefs previously held as truths are rendered implausible, new beliefs,
 values, and ways of living may be required. ___(2)___. What's worse, philosophers
 admonish each other to remain unsutured until such time as a defensible new answer is
 revealed or constructed. Sometimes philosophical writing is even strictly critical in
 that it does not even attempt to provide an alternative after tearing down a cultural or
 conceptual citadel. ___(3)___. The reader of philosophy must be prepared for the
 possibility of this experience. While reading philosophy can help one clarify one's
 values, and even make one self-conscious for the first time of the fact that there are
 good reasons for believing what one believes, it can also generate unremediated doubt
 that is difficult to live with. ___(4)___.

 Option 1

 Option 3

 Option 2

 Option 4

**ANSWER:** Choice C

### Q18

Option 2

 CAT 2023 Slot 1 - VA RC

 There is a sentence that is missing in the paragraph below. Look at the paragraph and
 decide where (option 1, 2, 3, or 4) the following sentence would best
 fit.
Sentence: The discovery helps to explain archeological similarities between
 the Paleolithic peoples of China, Japan, and the Americas.

Paragraph: The
 researchers also uncovered an unexpected genetic link between Native Americans and
 Japanese people. ___(1)___. During the deglaciation period, another group branched out
 from northern coastal China and travelled to Japan. ___(2)___. "We were surprised to
 find that this ancestral source also contributed to the Japanese gene pool, especially
 the indigenous Ainus," says Li. ___(3)___. They shared similarities in how they crafted
 stemmed projectile points for arrowheads and spears. ___(4)___. "This suggests that the
 Pleistocene connection among the Americas, China, and Japan was not confined to culture
 but also to genetics," says senior author Qing-Peng Kong, an evolutionary geneticist at
 the Chinese Academy of Sciences.

 Option 1

 Option 2

 Option 4

 Option 3

**ANSWER:** Choice D

### Q19

Option 3

 CAT 2023 Slot 1 - VA RC

 Five jumbled up sentences (labelled 1, 2, 3, 4 and 5), related to a topic, are given
 below. Four of them can be put together to form a coherent paragraph. Identify the odd
 sentence and key in the number of that sentence as your answer.

1. In
 English, there is no systematic rule for the naming of numbers; after ten, we have
 "eleven" and "twelve" and then the teens: "thirteen", "fourteen", "fifteen" and so
 on.
2. Even more confusingly, some English words invert the numbers they refer to:
 the word "fourteen" puts the four first, even though it appears last.
3. It can
 take children a while to learn all these words, and understand that "fourteen" is
 different from "forty".
4. For multiples of 10, English speakers switch to a
 different pattern: "twenty", "thirty", "forty" and so on.
5. If you didn't know the
 word for "eleven", you would be unable to just guess it – you might come up with
 something like "one-teen".

**ANSWER:** 3

### Q20

CAT 2023 Slot 1 - VA RC

 Five jumbled up sentences (labelled 1, 2, 3, 4 and 5), related to a topic, are given
 below. Four of them can be put together to form a coherent paragraph. Identify the odd
 sentence and key in the number of that sentence as your answer.

1. Having an
 appreciation for the workings of another person's mind is considered a prerequisite for
 natural language acquisition, strategic social interaction, reflexive thought, and moral
 judgment.
2. It is a 'theory of mind' though some scholars prefer to call it
 'mentalizing' or 'mindreading', which is important for the development of one's
 cognitive abilities.
3. Though we must speculate about its evolutionary origin, we
 do have indications that the capacity evolved sometime in the last few million
 years.
4. This capacity develops from early beginnings in the first year of life to
 the adult's fast and often effortless understanding of others' thoughts, feelings, and
 intentions.
5. One of the most fascinating human capacities is the ability to
 perceive and interpret other people's behaviour in terms of their mental states.

**ANSWER:** 2

### Q21

CAT 2023 Slot 1 - VA RC

 The four sentences (labelled 1, 2, 3 and 4) given below, when properly sequenced, would
 yield a coherent paragraph. Decide on the proper sequencing of the order of the
 sentences and key in the sequence of the four numbers as your answer.

1.
 Algorithms hosted on the internet are accessed by many, so biases in AI models have
 resulted in much larger impact, adversely affecting far larger groups of people.

2. Though "algorithmic bias" is the popular term, the foundation of such bias is
 not in algorithms, but in the data; algorithms are not biased, data is, as algorithms
 merely reflect persistent patterns that are present in the training data.
3.
 Despite their widespread impact, it is relatively easier to fix AI biases than
 human-generated biases, as it is simpler to identify the former than to try to make
 people unlearn behaviors learnt over generations.
4. The impact of biased decisions
 made by humans is localised and geographically confined, but with the advent of AI, the
 impact of such decisions is spread over a much wider scale.

**ANSWER:** 4123

### Q22

CAT 2023 Slot 1 - VA RC

 The four sentences (labelled 1, 2, 3 and 4) given below, when properly sequenced, would
 yield a coherent paragraph. Decide on the proper sequencing of the order of the
 sentences and key in the sequence of the four numbers as your answer.

1. What
 precisely are the "unusual elements" that make a particular case so attractive to a
 certain kind of audience?
2 . It might be a particularly savage or unfathomable
 level of depravity, very often it has something to do with the precise amount of mystery
 involved.
3. Unsolved, and perhaps unsolvable cases offer something that
 "ordinary" murder doesn't.
4. Why are some crimes destined for perpetual
 re-examination and others locked into permanent obscurity?

**ANSWER:** 4123

### Q23

CAT 2023 Slot 1 - VA RC

 The passage given below is followed by four alternate summaries. Choose the option that
 best captures the essence of the passage.
 Manipulating information was a feature
 of history long before modern journalism established rules of integrity. A record dates
 back to ancient Rome, when Antony met Cleopatra and his political enemy Octavian
 launched a smear campaign against him with "short, sharp slogans written upon coins."
 The perpetrator became the first Roman Emperor and "fake news had allowed Octavian to
 hack the republican system once and for all". But the 21 st century has seen
 the weaponization of information on an unprecedented scale. Powerful new technology
 makes the fabrication of content simple, and social networks amplify falsehoods peddled
 by States, populist politicians, and dishonest corporate entities. The platforms have
 become fertile ground for computational propaganda, 'trolling' and 'troll armies'.

 Disinformation, which is mediated by technology today, is not new and has
 existed since ancient times.

 People need to become critical of what they read, since historically,
 weaponization of information has led to corruption.

 Use of misinformation for attaining power, a practice that is as old as the
 Octavian era, is currently fueled by technology.

 Octavian used fake news to manipulate people and attain power and influence,
 just as people do today.

**ANSWER:** Choice C

### Q24

Use of misinformation for attaining
 power, a practice that is as old as the Octavian era, is currently
 fueled by technology.

 CAT 2023 Slot 1 - VA RC

 The passage given below is followed by four alternate summaries. Choose the option that
 best captures the essence of the passage.
 Colonialism is not a modern phenomenon.
 World history is full of examples of one society gradually expanding by incorporating
 adjacent territory and settling its people on newly conquered territory. In the
 sixteenth century, colonialism changed decisively because of technological developments
 in navigation that began to connect more remote parts of the world. The modern European
 colonial project emerged when it became possible to move large numbers of people across
 the ocean and to maintain political control in spite of geographical dispersion. The
 term colonialism is used to describe the process of European settlement, violent
 dispossession and political domination over the rest of the world, including the
 Americas, Australia, and parts of Africa and Asia.

 Colonialism surged in the 16 th century due to advancements in
 navigation, enabling British settlements abroad and global dominance.

 As a result of developments in navigation technology, European colonialism,
 led to the displacement of indigenous populations and global political
 changes in the 16 th century.

 Colonialism, conceptualized in the 16 th century, allowed
 colonizers to expand their territories, establish settlements, and exercise
 political power.

 Technological advancements in navigation in the 16 th century,
 transformed colonialism, enabling Europeans to establish settlements and
 exert political dominance over distant regions.

**ANSWER:** Choice D
