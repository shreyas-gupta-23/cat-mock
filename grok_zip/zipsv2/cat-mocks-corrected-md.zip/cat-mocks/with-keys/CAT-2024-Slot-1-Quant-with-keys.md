# CAT 2024 — Slot 1 — Quantitative Ability (Questions + On-page Answer Key)

Answers are on-page 2IIM **Correct Answer** labels. Not invented.

## Quantitative Ability

- Source file: `2iim-html/CAT-2024-Question-Paper-Slot-1-Quant.txt`
- Page: https://online.2iim.com/CAT-question-paper/CAT-2024-Question-Paper-Slot-1-Quant/
- On-page answers found: 22
- Answer source: 2IIM on-page **Correct Answer** / **Correct Answer Choice** (not invented)

### Q1

CAT 2024 Slot 1 - QA - Ratios Mixtures Averages

 A fruit seller has a total of 187 fruits consisting of apples, mangoes and oranges. The
 number of apples and
 mangoes are in the ratio 5 : 2. After she sells 75 apples, 26 mangoes and half of the
 oranges, the ratio of
 number of unsold apples to number of unsold oranges becomes 3 : 2. The total number of
 unsold fruits is

**ANSWER:** 66

### Q2

CAT 2024 Slot 1 - QA - Linear Quadratic

 If \((a+b \sqrt{n})\) is the positive square root of
 \((29-12 \sqrt{5})\), where \(a\) and \(b\) are integers, and \(n\) is a natural number, then
 the maximum possible value of \((a+b+n)\) is

 22

 6

 18

 4

**ANSWER:** 18

### Q3

CAT 2024 Slot 1 - QA - Logarithms Exponents

 The sum of all real values of \(k\) for which
 \(\left(\frac{1}{8}\right)^k \times\left(\frac{1}{32768}\right)^{\frac{1}{3}}=\frac{1}{8}
 \times\left(\frac{1}{32768}\right)^{\frac{1}{k}}\), is

 \(\frac{2}{3}\)

 \(-\frac{2}{3}\)

 \(\frac{4}{3}\)

 \(-\frac{4}{3}\)

**ANSWER:** B \(-\frac{2}{3}\)

### Q4

CAT 2024 Slot 1 - QA - Functions

 In the \(X Y\)-plane, the area, in sq. units, of the region
 defined by the inequalities \(y \geq x+4\) and \(-4 \leq x^2+y^2+4(x-y) \leq 0\) is

 \(4 \pi\)

 \(2 \pi\)

 \(\pi\)

 \(3 \pi\)

**ANSWER:** B

### Q5

\(2 \pi\)

 CAT 2024 Slot 1 - QA - Pipes Cisterns Work Time

 Renu would take 15 days working 4 hours per day to complete a certain task whereas Seema
 would take 8 days
 working 5 hours per day to complete the same task. They decide to work together to
 complete this task. Seema
 agrees to work for double the number of hours per day as Renu, while Renu agrees to work
 for double the
 number of days as Seema. If Renu works 2 hours per day, then the number of days Seema
 will work, is

**ANSWER:** 6

### Q6

CAT 2024 Slot 1 - QA - Percents Profits SICI

 In September, the incomes of Kamal, Amal and Vimal are in the ratio 8 : 6 : 5. They rent a
 house together, and Kamal pays 15%, Amal pays 12% and Vimal pays 18% of their respective
 incomes to cover
 the total house rent in that month. In October, the house rent remains unchanged while
 their incomes
 increase by 10%, 12% and 15%, respectively. In October, the percentage of their total
 income that will be
 paid as house rent, is nearest to

 14.84

 12.75

 13.26

 15.18

**ANSWER:** C

### Q7

13.26

 CAT 2024 Slot 1 - QA - Functions

 Consider two sets \(A=\{2,3,5,7,11,13\}\) and
 \(B=\{1,8,27\}\). Let \(f\) be a function from \(A\) to \(B\) such that for every element \(b\)
 in \(B\), there is at least one element \(a\) in \(A\) such that \(f(a)=b\). Then, the total
 number of such functions \(f\) is

 540

 537

 665

 667

**ANSWER:** A

### Q8

540

 CAT 2024 Slot 1 - QA - Linear Quadratic

 Let \(x, y\), and \(z\) be real numbers satisfying

 $$
 \begin{aligned}
 & 4\left(x^2+y^2+z^2\right)=a \\
 & 4(x-y-z)=3+a
 \end{aligned}
 $$

 Then \(a\) equals

 3

 1 \(\frac{1}{3}\)

 1

 4

**ANSWER:** A

### Q9

3

 CAT 2024 Slot 1 - QA - Combinatorics

 The sum of all four-digit numbers that can be formed with
 the distinct non-zero digits \(a, b, c\), and \(d\), with each digit appearing exactly once in
 every number, is \(153310+n\), where \(n\) is a single digit natural number. Then, the value of
 \((a+b+c+d+n)\) is

**ANSWER:** 31

### Q10

CAT 2024 Slot 1 - QA - Remainders

 When \(10^{100}\) is divided by 7 , the remainder is

 3

 6

 1

 4

**ANSWER:** D

### Q11

4

 CAT 2024 Slot 1 - QA - Ratios Mixtures Averages

 There are four numbers such that average of first two numbers is 1 more than the first
 number, average of
 first three numbers is 2 more than average of first two numbers, and average of first
 four numbers is 3 more
 than average of first three numbers. Then, the difference between the largest and the
 smallest numbers, is

**ANSWER:** 15

### Q12

CAT 2024 Slot 1 - QA - Percents Profits SICI

 An amount of Rs 10000 is deposited in bank A for a certain number of years at a simple
 interest of 5% per
 annum. On maturity, the total amount received is deposited in bank B for another 5 years
 at a simple
 interest of 6% per annum. If the interests received from bank A and bank B are in the
 ratio 10 : 13, then
 the investment period, in years, in bank A is

 4

 3

 6

 5

**ANSWER:** C

### Q13

6

 CAT 2024 Slot 1 - QA - Linear Quadratic

 A shop wants to sell a certain quantity (in kg) of grains. It sells half the quantity and
 an additional 3 kg
 of these grains to the first customer. Then, it sells half of the remaining quantity and
 an additional 3 kg
 of these grains to the second customer. Finally, when the shop sells half of the
 remaining quantity and an
 additional 3 kg of these grains to the third customer, there are no grains left. The
 initial quantity, in
 kg, of grains is

 18

 36

 50

 42

**ANSWER:** D

### Q14

42

 CAT 2024 Slot 1 - QA - Progressions

 Suppose \(x_1, x_2, x_3, \ldots, x_{100}\) are in arithmetic
 progression such that \(x_5=-4\) and \(2 x_6+2 x_9=x_{11}+x_{13}\). Then, \(x_{100}\) equals

 204

 -194

 -196

 206

**ANSWER:** B

### Q15

-194

 CAT 2024 Slot 1 - QA - Speed Time Distance Races

 Two places A and B are 45 kms apart and connected by a straight road. Anil goes from A to
 B while Sunil goes
 from B to A. Starting at the same time, they cross each other in exactly 1 hour 30
 minutes. If Anil reaches
 B exactly 1 hour 15 minutes after Sunil reaches A, the speed of Anil, in km per hour, is

 16

 14

 12

 18

**ANSWER:** C

### Q16

12

 CAT 2024 Slot 1 - QA - Mensuration

 The surface area of a closed rectangular box, which is
 inscribed in a sphere, is 846 sq cm , and the sum of the lengths of all its edges is 144 cm .
 The volume, in cubic cm , of the sphere is

 \(750 \pi\)

 \(1125 \pi \sqrt{2}\)

 \(1125 \pi\)

 \(750 \pi \sqrt{2}\)

**ANSWER:** B

### Q17

\(1125 \pi \sqrt{2}\)

 CAT 2024 Slot 1 - QA - Ratios Mixtures Averages

 A glass is filled with milk. Two-thirds of its content is poured out and replaced with
 water. If this process
 of pouring out two-thirds the content and replacing with water is repeated three more
 times, then the final
 ratio of milk to water in the glass, is

 1 : 27

 1 : 81

 1 : 26

 1 : 80

**ANSWER:** D

### Q18

1 : 80

 CAT 2024 Slot 1 - QA - Functions

 For any natural number \(n\), let \(a_n\) be the largest
 integer not exceeding \(\sqrt{n}\). Then the value of \(a_1+a_2+\cdots+a_{50}\) is

**ANSWER:** 217

### Q19

CAT 2024 Slot 1 - QA - Geometry

 ABCD is a rectangle with sides AB = 56 cm and BC = 45 cm, and E is the midpoint of side
 CD. Then, the length,
 in cm, of radius of incircle of \(\triangle A D E\) is

**ANSWER:** 10

### Q20

CAT 2024 Slot 1 - QA - Linear Quadratic

 If the equations \(x^2+m x+9=0, x^2+n x+17=0\) and
 \(x^2+(m+n) x+35=0\) have a common negative root, then the value of \((2 m+3 n)\) is

**ANSWER:** 38

### Q21

CAT 2024 Slot 1 - QA - Percents Profits SICI

 The selling price of a product is fixed to ensure 40% profit. If the product had cost 40%
 less and had been
 sold for 5 rupees less, then the resulting profit would have been 50%. The original
 selling price, in
 rupees, of the product is

 10

 15

 20

 14

**ANSWER:** D

### Q22

14

 CAT 2024 Slot 1 - QA - Logarithms Exponents

 If \(x\) is a positive real number such that \(4 \log _{10}
 x+4 \log _{100} x+8 \log _{1000} x=13\), then the greatest integer not exceeding \(x\), is

**ANSWER:** 31
