# CAT 2022 — Slot 3 — Quantitative Ability (Questions + On-page Answer Key)

Answers are on-page 2IIM **Correct Answer** labels. Not invented.

## Quantitative Ability

- Source file: `2iim-html/CAT-2022-Question-Paper-Slot-3-Quant.txt`
- Page: https://online.2iim.com/CAT-question-paper/CAT-2022-Question-Paper-Slot-3-Quant/
- On-page answers found: 22
- Answer source: 2IIM on-page **Correct Answer** / **Correct Answer Choice** (not invented)

### Q1

CAT 2022 Slot 3 - QA

 Suppose \(k\) is any integer such that the equation \(2 x^2+k x+5=0\) has no real roots and the equation \(x^2+(k-5) x+1=0\) has two distinct real roots for \(x\). Then, the number of possible values of \(k\) is

 7

 8

 9

 13

**ANSWER:** Choice C

### Q2

9

 CAT 2022 Slot 3 - QA

 The minimum possible value of \(\frac{x^2-6 x+10}{3-x}\), for \(x\lt3\), is

 \(\frac{1}{2}\)

 \(-\frac{1}{2}\)

 \(2\)

 \(-2\)

**ANSWER:** Choice C

### Q3

\(2\)

 CAT 2022 Slot 3 - QA

 Bob can finish a job in 40 days, if he works alone. Alex is twice as fast as Bob and thrice as fast as Cole in the same job. Suppose Alex and Bob work together on the first day, Bob and Cole work together on the second day, Cole and Alex work together on the third day, and then, they continue the work by repeating this three-day roster, with Alex and Bob working together on the fourth day, and so on. Then, the total number of days Alex would have worked when the job gets finished, is

**ANSWER:** 11

### Q4

CAT 2022 Slot 3 - QA

 A glass contains 500 cc of milk and a cup contains 500 cc of water. From the glass, 150 cc of milk is transferred to the cup and mixed thoroughly. Next, 150 cc of this mixture is transferred from the cup to the glass. Now, the amount of water in the glass and the amount of milk in the cup are in the ratio

 3 : 10

 10 : 3

 1 : 1

 10 : 13

**ANSWER:** Choice C

### Q5

1 : 1

 CAT 2022 Slot 3 - QA

 In an examination, the average marks of students in sections A and B are 32 and 60, respectively. The number of students in section A is 10 less than that in section B. If the average marks of all the students across both the sections combined is an integer, then the difference between the maximum and minimum possible number of students in section A is

**ANSWER:** 63

### Q6

CAT 2022 Slot 3 - QA

 Let \(r\) be a real number and \(f(x)=\left\{\begin{array}{cl}2 x-r & \text { if } x \geq r \\ r & \text { if } x\lt r\end{array}\right.\). Then, the equation \(f(x)=f(f(x))\) holds for all real values of \(x\) where

 \(x \leq r\)

 \(x \geq r\)

 \(x \gt r\)

 \(x \neq r\)

**ANSWER:** Choice A

### Q7

\(x \leq r\)

 CAT 2022 Slot 3 - QA

 Suppose the medians BD and CE of a triangle ABC intersect at a point O. If area of triangle ABC is 108 sq. cm., then, the area of the triangle EOD, in sq. cm., is

**ANSWER:** 9

### Q8

CAT 2022 Slot 3 - QA

 The arithmetic mean of all the distinct numbers that can be obtained by rearranging the digits in 1421, including itself, is

 2442

 2222

 3333

 2592

**ANSWER:** Choice B

### Q9

2222

 CAT 2022 Slot 3 - QA

 Nitu has an initial capital of \(₹ 20,000\). Out of this, she invests \(₹ 8,000\) at \(5.5 \%\) in bank \(A, ₹ 5,000\) at \(5.6 \%\) in bank \(B\) and the remaining amount at \(x \%\) in bank \(\mathrm{C}\), each rate being simple interest per annum. Her combined annual interest income from these investments is equal to \(5 \%\) of the initial capital. If she had invested her entire initial capital in bank C alone, then her annual interest income, in rupees, would have been

 900

 700

 1000

 800

**ANSWER:** Choice D

### Q10

800

 CAT 2022 Slot 3 - QA

 Two cars travel from different locations at constant speeds. To meet each other after starting at the same time, they take 1.5 hours if they travel towards each other, but 10.5 hours if they travel in the same direction. If the speed of the slower car is 60 km/hr, then the distance traveled, in km, by the slower car when it meets the other car while traveling towards each other, is

 150

 100

 90

 120

**ANSWER:** Choice C

### Q11

90

 CAT 2022 Slot 3 - QA

 If \(\left(\sqrt{\frac{7}{5}}\right)^{3 x-y}=\frac{875}{2401}\) and \(\left(\frac{4 a}{b}\right)^{6 x-y}=\left(\frac{2 a}{b}\right)^{y-6 x}\), for all non-zero real values of \(a\) and \(b\), then the value of \(x+y\) is

**ANSWER:** 14

### Q12

CAT 2022 Slot 3 - QA

 Moody takes 30 seconds to finish riding an escalator if he walks on it at his normal speed in the same direction. He takes 20 seconds to finish riding the escalator if he walks at twice his normal speed in the same direction. If Moody decides to stand still on the escalator, then the time, in seconds, needed to finish riding the escalator is

**ANSWER:** 60

### Q13

CAT 2022 Slot 3 - QA

 Consider six distinct natural numbers such that the average of the two smallest numbers is 14, and the average of the two largest numbers is 28. Then, the maximum possible value of the average of these six numbers is

 22.5

 23.5

 24

 23

**ANSWER:** Choice A

### Q14

22.5

 CAT 2022 Slot 3 - QA

 If \((3+2 \sqrt{2})\) is a root of the equation \(a x^2+b x+c=0\), and \((4+2 \sqrt{3})\) is a root of the equation \(a y^2+m y+n=0\), where \(a, b, c, m\) and \(n\) are integers, then the value of \(\left(\frac{b}{m}+\frac{c-2 b}{n}\right)\) is

 3

 1

 4

 0

**ANSWER:** Choice C

### Q15

4

 CAT 2022 Slot 3 - QA

 If \(c=\frac{16 x}{y}+\frac{49 y}{x}\) for some non-zero real numbers \(x\) and \(y\), then \(c\) cannot take the value

 -70

 60

 -50

 -60

**ANSWER:** Choice C

### Q16

-50

 CAT 2022 Slot 3 - QA

 A group of \(N\) people worked on a project. They finished \(35 \%\) of the project by working 7 hours a day for 10 days. Thereafter, 10 people left the group and the remaining people finished the rest of the project in 14 days by working 10 hours a day. Then the value of \(N\) is

 23

 140

 36

 150

**ANSWER:** Choice B

### Q17

140

 CAT 2022 Slot 3 - QA

 The average of all 3-digit terms in the arithmetic progression 38, 55, 72, ..., is

**ANSWER:** 548

### Q18

CAT 2022 Slot 3 - QA

 In a triangle \(\mathrm{ABC}, \mathrm{AB}=\mathrm{AC}=8 \mathrm{cm}\). A circle drawn with \(\mathrm{BC}\) as diameter passes through \(\mathrm{A}\). Another circle drawn with center at A passes through B and \(\mathrm{C}\). Then the area, in sq. \(\mathrm{cm}\), of the overlapping region between the two circles is

 \(16(\pi-1)\)

 \(32(\pi-1)\)

 \(32 \pi\)

 \(16 \pi\)

**ANSWER:** Choice B

### Q19

\(32(\pi-1)\)

 CAT 2022 Slot 3 - QA

 A school has less than 5000 students and if the students are divided equally into teams of either 9 or 10 or 12 or 25 each, exactly 4 are always left out. However, if they are divided into teams of 11 each, no one is left out. The maximum number of teams of 12 each that can be formed out of the students in the school is

**ANSWER:** 150

### Q20

CAT 2022 Slot 3 - QA

**ANSWER:** 12

### Q21

CAT 2022 Slot 3 - QA

 Two ships are approaching a port along straight routes at constant speeds. Initially, the two ships and the port formed an equilateral triangle with sides of length 24 km. When the slower ship travelled 8 km, the triangle formed by the new positions of the two ships and the port became right-angled. When the faster ship reaches the port, the distance, in km, between the other ship and the port will be

 8

 12

 6

 4

**ANSWER:** Choice B

### Q22

12

 CAT 2022 Slot 3 - QA

 The lengths of all four sides of a quadrilateral are integer valued. If three of its sides are of length 1 cm, 2 cm and 4 cm, then the total number of possible lengths of the fourth side is

 6

 4

 5

 3

**ANSWER:** Choice C
