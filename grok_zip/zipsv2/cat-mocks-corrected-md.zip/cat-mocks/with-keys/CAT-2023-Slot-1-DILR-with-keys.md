# CAT 2023 — Slot 1 — DILR (Questions + On-page Answer Key)

Answers are on-page 2IIM **Correct Answer** labels. Not invented.

## DILR

- Source file: `2iim-html/CAT-2023-Question-Paper-Slot-1-DILR.txt`
- Page: https://online.2iim.com/CAT-question-paper/CAT-2023-Question-Paper-Slot-1-DILR/
- On-page answers found: 20
- Answer source: 2IIM on-page **Correct Answer** / **Correct Answer Choice** (not invented)

### Q1

C AT DI LR section has become increasingly tough beginning from 2015. DILR used to have distinct Data Interpretation sets and Logical reasoning puzzles. It used to be about computation and ability to read charts, graphs and tables for the Data Interpretation and Logical reasoning used to have Family tree, grid puzzles, arrangement, tournaments, cubes as some standard forms of puzzles.Since 2015 this pattern has been broken. With passing years, even the distinction between DI and LR has come down significantly. All you get in that 40 minutes, are 4 high quality puzzles, with more than a few of them being significantly tough. Between CAT 2017 Question paper to CAT 2023 Question paper, you get to solve 102 actual CAT puzzles. This page intends to provide you just that. So, head on and crack those puzzles!

 Faculty members in a management school can belong to one of four departments – Finance and Accounting (F&A), Marketing and Strategy (M&S), Operations and Quants (O&Q) and Behaviour and Human Resources (B&H). The numbers of faculty members in F&A, M&S, O&Q and B&H departments are 9, 7, 5 and 3 respectively.

Prof. Pakrasi, Prof. Qureshi, Prof. Ramaswamy and Prof. Samuel are four members of the school's faculty who were candidates for the post of the Dean of the school. Only one of the candidates was from O&Q.

Every faculty member, including the four candidates, voted for the post. In each department, all the faculty members who were not candidates voted for the same candidate. The rules for the election are listed below.

1. There cannot be more than two candidates from a single department.
2. A candidate cannot vote for himself/herself.
3. Faculty members cannot vote for a candidate from their own department.

After the election, it was observed that Prof. Pakrasi received 3 votes, Prof. Qureshi received 14 votes, Prof. Ramaswamy received 6 votes and Prof. Samuel received 1 vote. Prof. Pakrasi voted for Prof. Ramaswamy, Prof. Qureshi for Prof. Samuel, Prof. Ramaswamy for Prof. Qureshi and Prof. Samuel for Prof. Pakrasi.

 CAT 2023 Slot 1 - DI LR

 Which two candidates can belong to the same department?

 Prof. Pakrasi and Prof. Samuel

 Prof. Pakrasi and Prof. Qureshi

 Prof. Qureshi and Prof. Ramaswamy

 Prof. Ramaswamy and Prof. Samuel

**ANSWER:** Choice B

### Q2

Prof. Pakrasi and Prof. Qureshi

 CAT 2023 Slot 1 - DI LR

 Which of the following can be the number of votes that Prof. Qureshi received from a single department?

 8

 7

 9

 6

**ANSWER:** Choice C

### Q3

9

 CAT 2023 Slot 1 - DI LR

 If Prof. Samuel belongs to B&H, which of the following statements is/are true?

Statement A: Prof. Pakrasi belongs to M&S.
Statement B: Prof. Ramaswamy belongs to O&Q.

 Both statements A and B

 Only statement B

 Only statement A

 Neither statement A nor statement B

**ANSWER:** Choice A

### Q4

Both statements A and B

 CAT 2023 Slot 1 - DI LR

 What best can be concluded about the candidate from O&Q?

 It was either Prof. Pakrasi or Prof. Qureshi.

 It was Prof. Samuel.

 It was Prof. Ramaswamy.

 It was either Prof. Ramaswamy or Prof. Samuel.

**ANSWER:** Choice D

### Q5

It was either Prof. Ramaswamy or Prof. Samuel.

 CAT 2023 Slot 1 - DI LR

 Which of the following statements is/are true?

Statement A: Non-candidates from M&S voted for Prof. Qureshi.
Statement B: Non-candidates from F&A voted for Prof. Qureshi.

 Only statement B

 Only statement A

 Both statements A and B

 Neither statement A nor statement B

**ANSWER:** Choice A

### Q6

Only statement B

 Five restaurants, coded R1, R2, R3, R4 and R5 gave integer ratings to five gig workers – Ullas, Vasu, Waman, Xavier and Yusuf, on a scale of 1 to 5.

The means of the ratings given by R1, R2, R3, R4 and R5 were 3.4, 2.2, 3.8, 2.8 and 3.4 respectively.

The summary statistics of these ratings for the five workers is given below.

 Ullas
 Vasu
 Waman
 Xavier
 Yusuf

 Mean rating
 2.2
 3.8
 3.4
 3.6
 2.6

 Median rating
 2
 4
 4
 4
 3

 Modal rating
 2
 4
 5
 5
 1 and 4

 Range of rating*
 3
 3
 4
 4
 3

* Range of ratings is defined as the difference between the maximum and minimum ratings awarded to a worker.

The following is partial information about ratings of 1 and 5 awarded by the restaurants to the workers.
(a) R1 awarded a rating of 5 to Waman, as did R2 to Xavier, R3 to Waman and Xavier, and R5 to Vasu.
(b) R1 awarded a rating of 1 to Ullas, as did R2 to Waman and Yusuf, and R3 to Yusuf.

 CAT 2023 Slot 1 - DI LR

 How many individual ratings cannot be determined from the above information?

**ANSWER:** 0

### Q7

CAT 2023 Slot 1 - DI LR

 To how many workers did R2 give a rating of 4?

**ANSWER:** 0

### Q8

CAT 2023 Slot 1 - DI LR

 What rating did R1 give to Xavier?

**ANSWER:** 3

### Q9

CAT 2023 Slot 1 - DI LR

 What is the median of the ratings given by R3 to the five workers?

**ANSWER:** 4

### Q10

CAT 2023 Slot 1 - DI LR

 Which among the following restaurants gave its median rating to exactly one of the workers?

 R5

 R2

 R3

 R4

**ANSWER:** Choice D

### Q11

R4

 A visa processing office (VPO) accepts visa applications in four categories – US, UK, Schengen, and Others. The applications are scheduled for processing in twenty 15-minute slots starting at 9:00 am and ending at 2:00 pm. Ten applications are scheduled in each slot.
There are ten counters in the office, four dedicated to US applications, and two each for UK applications, Schengen applications and Others applications. Applicants are called in for processing sequentially on a first-come-first-served basis whenever a counter gets freed for their category. The processing time for an application is the same within each category. But it may vary across the categories. Each US and UK application requires 10 minutes of processing time. Depending on the number of applications in a category and time required to process an application for that category, it is possible that an applicant for a slot may be processed later.
On a particular day, Ira, Vijay and Nandini were scheduled for Schengen visa processing in that order. They had a 9:15 am slot but entered the VPO at 9:20 am. When they entered the office, exactly six out of the ten counters were either processing applications, or had finished processing one and ready to start processing the next.
Mahira and Osman were scheduled in the 9:30 am slot on that day for visa processing in the Others category.
The following additional information is known about that day.1. All slots were full.2. The number of US applications was the same in all the slots. The same was true for the other three categories.3. 50% of the applications were US applications.4. All applicants except Ira, Vijay and Nandini arrived on time.5. Vijay was called to a counter at 9:25 am.

 CAT 2023 Slot 1 - DI LR

 How many UK applications were scheduled on that day?

**ANSWER:** 0

### Q12

CAT 2023 Slot 1 - DI LR

 What is the maximum possible value of the total time (in minutes, nearest to its integer value) required to process all applications in the Others category on that day?

**ANSWER:** 200

### Q13

CAT 2023 Slot 1 - DI LR

 Which of the following is the closest to the time when Nandini's application process got over?

 9:35 am

 9:50 am

 9:37 am

 9:45 am

**ANSWER:** Choice D

### Q14

9:45 am

 CAT 2023 Slot 1 - DI LR

 Which of the following statements is false?

 The application process of Mahira was completed before Nandini's.

 The application process of Osman was completed before Vijay's.

 The application process of Osman was completed before 9:45 am.

 The application process of Mahira started after Nandini's.

**ANSWER:** Choice D

### Q15

The application process of Mahira started after Nandini's.

 CAT 2023 Slot 1 - DI LR

 When did the application processing for all US applicants get over on that day?

 2:25 pm

 3:40 pm

 2:00 pm

 2:05 pm

**ANSWER:** Choice D

### Q16

2:05 pm

 The schematic diagram below shows 12 rectangular houses in a housing complex. House numbers are mentioned in the rectangles representing the houses. The houses are located in six columns – Column-A through Column-F, and two rows – Row-1 and Row-2. The houses are divided into two blocks - Block XX and Block YY. The diagram also shows two roads, one passing in front of the houses in Row-2 and another between the two blocks.

Some of the houses are occupied. The remaining ones are vacant and are the only ones available for sale.

The road adjacency value of a house is the number of its sides adjacent to a road. For example, the road adjacency values of C2, F2, and B1 are 2, 1, and 0, respectively. The neighbour count of a house is the number of sides of that house adjacent to occupied houses in the same block. For example, E1 and C1 can have the maximum possible neighbour counts of 3 and 2, respectively.

The base price of a vacant house is Rs. 10 lakhs if the house does not have a parking space, and Rs. 12 lakhs if it does. The quoted price (in lakhs of Rs.) of a vacant house is calculated as (base price) + 5 × (road adjacency value) + 3 × (neighbour count).

The following information is also known.
1. The maximum quoted price of a house in Block XX is Rs. 24 lakhs. The minimum quoted price of a house in block YY is Rs. 15 lakhs, and one such house is in Column-E.
2. Row-1 has two occupied houses, one in each block.
3. Both houses in Column-E are vacant. Each of Column-D and Column-F has at least one occupied house.
4. There is only one house with parking space in Block YY.

 CAT 2023 Slot 1 - DI LR

 How many houses are vacant in Block XX?

**ANSWER:** 3

### Q17

CAT 2023 Slot 1 - DI LR

 Which of the following houses are definitely occupied? **

 F2 and A2

 D2 and B2

 D2 and B1

 A1 and D2

**ANSWER:** Choice C

### Q18

D2 and B1

 ** The original question had issues. We have modified the question to rectify the issue.

 CAT 2023 Slot 1 - DI LR

 Which of the following options best describes the number of vacant houses in Row-2?

 Either 3 or 4

 Either 2 or 3

 Exactly 3

 Exactly 2

**ANSWER:** Choice B

### Q19

Either 2 or 3

 CAT 2023 Slot 1 - DI LR

 What is the maximum possible quoted price (in lakhs of Rs.) for a vacant house in Column-E?

**ANSWER:** 21

### Q20

CAT 2023 Slot 1 - DI LR

 Which house in Block YY has parking space?

 F2

 F1

 E2

 E1

**ANSWER:** Choice D
