# CAT 2023 — Slot 2 — VARC (Questions + On-page Answer Key)

Answers are on-page 2IIM **Correct Answer** labels. Not invented.

## VARC

- Source file: `2iim-html/CAT-2023-Question-Paper-Slot-2-VARC.txt`
- Page: https://online.2iim.com/CAT-question-paper/CAT-2023-Question-Paper-Slot-2-VARC/
- On-page answers found: 24
- Answer source: 2IIM on-page **Correct Answer** / **Correct Answer Choice** (not invented)

### Q1

T he best way to improve your VARC skill is Reading. Read tons of stuff from Bharath's Curated Reading list and get a wonderful VARC score.

 The passage below is accompanied by four questions. Based on the passage, choose the best answer for each question.
The Second Hand September campaign, led by Oxfam . . . seeks to encourage shopping at local organisations and charities as alternatives to fast fashion brands such as Primark and Boohoo in the name of saving our planet. As innocent as mindless scrolling through online shops may seem, such consumers are unintentionally—or perhaps even knowingly—contributing to an industry that uses more energy than aviation. . . .

Brits buy more garments than any other country in Europe, so it comes as no shock that many of those clothes end up in UK landfills each year: 300,000 tonnes of them, to be exact. This waste of clothing is destructive to our planet, releasing greenhouse gasses as clothes are burnt as well as bleeding toxins and dyes into the surrounding soil and water. As ecologist Chelsea Rochman bluntly put it, "The mismanagement of our waste has even come back to haunt us on our dinner plate."

It's not surprising, then, that people are scrambling for a solution, the most common of which is second-hand shopping. Retailers selling consigned clothing are currently expanding at a rapid rate . . . If everyone bought just one used item in a year, it would save 449 million lbs of waste, equivalent to the weight of 1 million Polar bears. "Thrifting" has increasingly become a trendy practice. London is home to many second-hand, or more commonly coined 'vintage', shops across the city from Bayswater to Brixton.

So you're cool and you care about the planet; you've killed two birds with one stone. But do people simply purchase a second-hand item, flash it on Instagram with #vintage and call it a day without considering whether what they are doing is actually effective?

According to a study commissioned by Patagonia, for instance, older clothes shed more microfibres. These can end up in our rivers and seas after just one wash due to the worn material, thus contributing to microfibre pollution. To break it down, the amount of microfibres released by laundering 100,000 fleece jackets is equivalent to as many as 11,900 plastic grocery bags, and up to 40 per cent of that ends up in our oceans. . . . So where does this leave second-hand consumers? [They would be well advised to buy] high-quality items that shed less and last longer [as this] combats both microfibre pollution and excess garments ending up in landfills. . . .

Luxury brands would rather not circulate their latest season stock around the globe to be sold at a cheaper price, which is why companies like ThredUP, a US fashion resale marketplace, have not yet caught on in the UK. There will always be a market for consignment but there is also a whole generation of people who have been taught that only buying new products is the norm; second-hand luxury goods are not in their psyche. Ben Whitaker, director at Liquidation Firm B-Stock, told Prospect that unless recycling becomes cost-effective and filters into mass production, with the right technology to partner it, "high-end retailers would rather put brand before sustainability."

 CAT 2023 Slot 2 - VA RC

 The central idea of the passage would be undermined if:

 Primark and Boohoo recycled their clothes for vintage stores.

 customers bought all their clothes online.

 second-hand stores sold only high-quality clothes.

 clothes were not thrown and burnt in landfills.

**ANSWER:** Choice C

### Q2

second-hand stores sold only high-quality clothes.

 CAT 2023 Slot 2 - VA RC

 The act of "thrifting", as described in the passage, can be considered ironic because it:

 has created environmental problems.

 is an anti-consumerist attitude.

 is not cost-effective for retailers.

 offers luxury clothing at cut-rate prices.

**ANSWER:** Choice A

### Q3

has created environmental problems.

 CAT 2023 Slot 2 - VA RC

 Based on the passage, we can infer that the opposite of fast fashion, 'slow fashion', would most likely refer to clothes that:

 do not shed microfibres.

 are of high quality and long lasting.

 are sold by genuine vintage stores.

 do not bleed toxins and dyes.

**ANSWER:** Choice B

### Q4

are of high quality and long lasting.

 CAT 2023 Slot 2 - VA RC

 According to the author, companies like ThredUP have not caught on in the UK for all of the following reasons EXCEPT that:

 recycling is currently not financially attractive for luxury brands.

 luxury brands do not like their product to be devalued.

 the British don't buy second-hand clothing.

 luxury brands want to maintain their brand image.

**ANSWER:** Choice C

### Q5

the British don't buy second-hand clothing.

 The passage below is accompanied by four questions. Based on the passage, choose the best answer for each question.

Over the past four centuries liberalism has been so successful that it has driven all its opponents off the battlefield. Now it is disintegrating, destroyed by a mix of hubris and internal contradictions, according to Patrick Deneen, a professor of politics at the University of Notre Dame. . . . Equality of opportunity has produced a new meritocratic aristocracy that has all the aloofness of the old aristocracy with none of its sense of noblesse oblige. Democracy has degenerated into a theatre of the absurd. And technological advances are reducing ever more areas of work into meaningless drudgery. "The gap between liberalism's claims about itself and the lived reality of the citizenry" is now so wide that "the lie can no longer be accepted," Mr Deneen writes. What better proof of this than the vision of 1,000 private planes whisking their occupants to Davos to discuss the question of "creating a shared future in a fragmented world"? . . .

Deneen does an impressive job of capturing the current mood of disillusionment, echoing left-wing complaints about rampant commercialism, right-wing complaints about narcissistic and bullying students, and general worries about atomisation and selfishness. But when he concludes that all this adds up to a failure of liberalism, is his argument convincing? . . . He argues that the essence of liberalism lies in freeing individuals from constraints. In fact, liberalism contains a wide range of intellectual traditions which provide different answers to the question of how to trade off the relative claims of rights and responsibilities, individual expression and social ties. . . . liberals experimented with a range of ideas from devolving power from the centre to creating national education systems.

Mr Deneen's fixation on the essence of liberalism leads to the second big problem of his book: his failure to recognise liberalism's ability to reform itself and address its internal problems. The late 19 th century saw America suffering from many of the problems that are reappearing today, including the creation of a business aristocracy, the rise of vast companies, the corruption of politics and the sense that society was dividing into winners and losers. But a wide variety of reformers, working within the liberal tradition, tackled these problems head on. Theodore Roosevelt took on the trusts. Progressives cleaned up government corruption. University reformers modernised academic syllabuses and built ladders of opportunity. Rather than dying, liberalism reformed itself.

Mr Deneen is right to point out that the record of liberalism in recent years has been dismal. He is also right to assert that the world has much to learn from the premodern notions of liberty as self-mastery and self-denial. The biggest enemy of liberalism is not so much atomisation but old-fashioned greed, as members of the Davos elite pile their plates ever higher with perks and share options. But he is wrong to argue that the only way for people to liberate themselves from the contradictions of liberalism is "liberation from liberalism itself". The best way to read "Why Liberalism Failed" is not as a funeral oration but as a call to action: up your game, or else.

 CAT 2023 Slot 2 - VA RC

 The author of the passage faults Deneen's conclusions for all of the following reasons, EXCEPT:

 its repeated harking back to premodern notions of liberty.

 its failure to note historical instances in which the process of declining liberalism has managed to reverse itself.

 its very narrow definition of liberalism limited to individual freedoms.

 its extreme pessimism about the future of liberalism today and predictions of an ultimate decline.

**ANSWER:** Choice A

### Q6

its repeated harking back to premodern notions of liberty.

 CAT 2023 Slot 2 - VA RC

 The author of the passage is likely to disagree with all of the following statements, EXCEPT:

 the essence of liberalism lies in greater individual self-expression and freedoms.

 liberalism was the dominant ideal in the past century, but it had to reform itself to remain so.

 claims about liberalism's disintegration are exaggerated and misunderstand its core features.

 if we accept that liberalism is a dying ideal, we must work to find a viable substitute.

**ANSWER:** Choice B

### Q7

liberalism was the dominant ideal in the past century, but it had to reform itself to remain so.

 CAT 2023 Slot 2 - VA RC

 All of the following statements are evidence of the decline of liberalism today, EXCEPT:

 ". . . the creation of a business aristocracy, the rise of vast companies . . ."

 "And technological advances are reducing ever more areas of work into meaningless drudgery."

 "Democracy has degenerated into a theatre of the absurd."

 "'The gap between liberalism's claims about itself and the lived reality of the citizenry' is now so wide that 'the lie can no longer be accepted,'. . ."

**ANSWER:** Choice B

### Q8

"And technological advances are reducing ever more areas of work into meaningless drudgery."

 CAT 2023 Slot 2 - VA RC

 The author of the passage refers to "the Davos elite" to illustrate his views on:

 the way the debate around liberalism has been captured by the rich who have managed to insulate themselves from economic hardships.

 the fact that the rise in liberalism had led to a greater interest in shared futures from unlikely social classes.

 the unlikelihood of a return to the liberalism of the past as long as the rich continue to benefit from the decline in liberal values.

 the hypocrisy of the liberal rich, who profess to subscribe to liberal values while cornering most of the wealth.

**ANSWER:** Choice D

### Q9

the hypocrisy of the liberal rich, who profess to subscribe to liberal values while cornering most of the wealth.

 The passage below is accompanied by four questions. Based on the passage, choose the best answer for each question.

The Positivists, anxious to stake out their claim for history as a science, contributed the weight of their influence to the cult of facts. First ascertain the facts, said the positivists, then draw your conclusions from them. . . . This is what may [be] called the common-sense view of history. History consists of a corpus of ascertained facts. The facts are available to the historian in documents, inscriptions, and so on . . . [Sir George Clark] contrasted the "hard core of facts" in history with the surrounding pulp of disputable interpretation forgetting perhaps that the pulpy part of the fruit is more rewarding than the hard core. . . . It recalls the favourite dictum of the great liberal journalist C. P. Scott: "Facts are sacred, opinion is free.". . .

What is a historical fact? . . . According to the common-sense view, there are certain basic facts which are the same for all historians and which form, so to speak, the backbone of history—the fact, for example, that the Battle of Hastings was fought in 1066. But this view calls for two observations. In the first place, it is not with facts like these that the historian is primarily concerned. It is no doubt important to know that the great battle was fought in 1066 and not in 1065 or 1067, and that it was fought at Hastings and not at Eastbourne or Brighton. The historian must not get these things wrong. But [to] praise a historian for his accuracy is like praising an architect for using well-seasoned timber or properly mixed concrete in his building. It is a necessary condition of his work, but not his essential function. It is precisely for matters of this kind that the historian is entitled to rely on what have been called the "auxiliary sciences" of history—archaeology, epigraphy, numismatics, chronology, and so forth. . . .

The second observation is that the necessity to establish these basic facts rests not on any quality in the facts themselves, but on an apriori decision of the historian. In spite of C. P. Scott's motto, every journalist knows today that the most effective way to influence opinion is by the selection and arrangement of the appropriate facts. It used to be said that facts speak for themselves. This is, of course, untrue. The facts speak only when the historian calls on them: it is he who decides to which facts to give the floor, and in what order or context. . . . The only reason why we are interested to know that the battle was fought at Hastings in 1066 is that historians regard it as a major historical event. . . . Professor Talcott Parsons once called [science] "a selective system of cognitive orientations to reality." It might perhaps have been put more simply. But history is, among other things, that. The historian is necessarily selective. The belief in a hard core of historical facts existing objectively and independently of the interpretation of the historian is a preposterous fallacy, but one which it is very hard to eradicate.

 CAT 2023 Slot 2 - VA RC

 All of the following, if true, can weaken the passage's claim that facts do not speak for themselves, EXCEPT:

 the truth value of a fact is independent of the historian who expresses it.

 facts, like truth, can be relative: what is fact for person X may not be so for person Y.

 a fact, by its very nature, is objective and universal, irrespective of the context in which it is placed.

 the order in which a series of facts is presented does not have any bearing on the production of meaning.

**ANSWER:** Choice B

### Q10

facts, like truth, can be relative: what is fact for person X may not be so for person Y.

 CAT 2023 Slot 2 - VA RC

 If the author of the passage were to write a book on the Battle of Hastings along the lines of his/her own reasoning, the focus of the historical account would be on:

 deriving historical facts from the relevant documents and inscriptions.

 providing a nuanced interpretation by relying on the auxiliary sciences.

 exploring the socio-political and economic factors that led to the Battle.

 producing a detailed timeline of the various events that led to the Battle.

**ANSWER:** Choice C

### Q11

exploring the socio-political and economic factors that led to the Battle.

 CAT 2023 Slot 2 - VA RC

 According to this passage, which one of the following statements best describes the significance of archaeology for historians?

 Archaeology helps historians to carry out their primary duty.

 Archaeology helps historians to interpret historical facts.

 Archaeology helps historians to ascertain factual accuracy.

 Archaeology helps historians to locate the oldest civilisations in history.

**ANSWER:** Choice C

### Q12

Archaeology helps historians to ascertain factual accuracy.

 CAT 2023 Slot 2 - VA RC

 All of the following describe the "common-sense view" of history, EXCEPT:

 history is like science: a selective system of cognitive orientations to reality.

 only the positivist methods can lead to credible historical knowledge.

 history can be objective like the sciences if it is derived from historical facts.

 real history can be found in ancient engravings and archival documents.

**ANSWER:** Choice A

### Q13

history is like science: a selective system of cognitive orientations to reality.

 The passage below is accompanied by four questions. Based on the passage, choose the best answer for each question.

Umberto Eco, an Italian writer, was right when he said the language of Europe is translation. Netflix and other deep-pocketed global firms speak it well. Just as the EU employs a small army of translators and interpreters to turn intricate laws or impassioned speeches of Romanian MEPs into the EU's 24 official languages, so do the likes of Netflix. It now offers dubbing in 34 languages and subtitling in a few more. . . .

The economics of European productions are more appealing, too. American audiences are more willing than before to give dubbed or subtitled viewing a chance. This means shows such as "Lupin", a French crime caper on Netflix, can become global hits. . . . In 2015, about 75% of Netflix's original content was American; now the figure is half, according to Ampere, a media-analysis company. Netflix has about 100 productions under way in Europe, which is more than big public broadcasters in France or Germany. . . .

Not everything works across borders. Comedy sometimes struggles. Whodunits and bloodthirsty maelstroms between arch Romans and uppity tribesmen have a more universal appeal. Some do it better than others. Barbarians aside, German television is not always built for export, says one executive, being polite. A bigger problem is that national broadcasters still dominate. Streaming services, such as Netflix or Disney+, account for about a third of all viewing hours, even in markets where they are well-established. Europe is an ageing continent. The generation of teens staring at phones is outnumbered by their elders who prefer to gawp at the box.

In Brussels and national capitals, the prospect of Netflix as a cultural hegemon is seen as a threat. "Cultural sovereignty" is the watchword of European executives worried that the Americans will eat their lunch. To be fair, Netflix content sometimes seems stuck in an uncanny valley somewhere in the mid-Atlantic, with local quirks stripped out. Netflix originals tend to have fewer specific cultural references than shows produced by domestic rivals, according to Enders, a market analyst. The company used to have an imperial model of commissioning, with executives in Los Angeles cooking up ideas French people might like. Now Netflix has offices across Europe. But ultimately the big decisions rest with American executives. This makes European politicians nervous.

They should not be. An irony of European integration is that it is often American companies that facilitate it. Google Translate makes European newspapers comprehensible, even if a little clunky, for the continent's non-polyglots. American social-media companies make it easier for Europeans to talk politics across borders. (That they do not always like to hear what they say about each other is another matter.) Now Netflix and friends pump the same content into homes across a continent, making culture a cross-border endeavour, too. If Europeans are to share a currency, bail each other out in times of financial need and share vaccines in a pandemic, then they need to have something in common—even if it is just bingeing on the same series. Watching fictitious northern and southern Europeans tear each other apart 2,000 years ago beats doing so in reality.

 CAT 2023 Slot 2 - VA RC

 Based on information provided in the passage, all of the following are true, EXCEPT:

 European television productions have the potential to become global hits.

 only half of Netflix's original programming in the EU is now produced in America.

 national broadcasters dominate in the EU in terms of total television viewing hours.

 Netflix has been able to transform itself into a truly European entity.

**ANSWER:** Choice D

### Q14

Netflix has been able to transform itself into a truly European entity.

 CAT 2023 Slot 2 - VA RC

 The author sees the rise of Netflix in Europe as:

 a unifying force.

 a looming cultural threat.

 filling an entertainment gap.

 an economic threat.

**ANSWER:** Choice A

### Q15

a unifying force.

 CAT 2023 Slot 2 - VA RC

 Which one of the following research findings would weaken the author's conclusion in the final paragraph?

 Research shows that Netflix has been gradually losing market share to other streaming television service providers.

 Research shows there is a wide variance in the popularity and viewing of Netflix shows across different EU countries.

 Research shows that older women across the EU enjoy watching romantic comedies on Netflix, whereas younger women prefer historical fiction dramas.

 Research shows that Netflix hits produced in France are very popular with North American audiences.

**ANSWER:** Choice B

### Q16

Research shows there is a wide variance in the popularity and viewing of Netflix shows across different EU countries.

 CAT 2023 Slot 2 - VA RC

 Based only on information provided in the passage, which one of the following hypothetical Netflix shows would be most successful with audiences across the EU?

 A trans-Atlantic romantic drama set in Europe and America.

 An original German TV science fiction production.

 A murder mystery drama set in North Africa and France.

 An Italian comedy show hosted by an international star.

**ANSWER:** Choice C

### Q17

A murder mystery drama set in North Africa and France.

 CAT 2023 Slot 2 - VA RC

 There is a sentence that is missing in the paragraph below. Look at the paragraph and decide where (option 1, 2, 3, or 4) the following sentence would best fit.

Sentence: And probably much earlier, moving the documentation for kissing back 1,000 years compared to what was acknowledged in the scientific community.

Paragraph: Research has hypothesised that the earliest evidence of human lip kissing originated in a very specific geographical location in South Asia 3,500 years ago.___(1)___. From there it may have spread to other regions, simultaneously accelerating the spread of the herpes simplex virus 1. According to Dr Troels Pank Arbøll and Dr Sophie Lund Rasmussen, who in a new article in the journal Science draw on a range of written sources from the earliest Mesopotamian societies, kissing was already a well-established practice 4,500 years ago in the Middle East.___(2)___. In ancient Mesopotamia, people wrote in cuneiform script on clay tablets.___(3)___. Many thousands of these clay tablets have survived to this day, and they contain clear examples that kissing was considered a part of romantic intimacy in ancient times.___(4)___. "Kissing could also have been part of friendships and family members' relations," says Dr Troels Pank Arbøll, an expert on the history of medicine in Mesopotamia.

 Option 4

 Option 3

 Option 1

 Option 2

**ANSWER:** Choice D

### Q18

Option 2

 CAT 2023 Slot 2 - VA RC

 There is a sentence that is missing in the paragraph below. Look at the paragraph and decide where (option 1, 2, 3, or 4) the following sentence would best fit.

Sentence: Dualism was long held as the defining feature of developing countries in contrast to developed countries, where frontier technologies and high productivity were assumed to prevail.

Paragraph: ___(1)___. At the core of development economics lies the idea of 'productive dualism': that poor countries' economies are split between a narrow 'modern' sector that uses advanced technologies and a larger 'traditional' sector characterized by very low productivity.___(2)___. While this distinction between developing and advanced economies may have made some sense in the 1950s and 1960s, it no longer appears to be very relevant. A combination of forces have produced a widening gap between the winners and those left behind.___(3)___. Convergence between poor and rich parts of the economy was arrested and regional disparities widened.___(4)___. As a result, policymakers in advanced economies are now grappling with the same questions that have long preoccupied developing economies: mainly how to close the gap with the more advanced parts of the economy.

 Option 1

 Option 2

 Option 3

 Option 4

**ANSWER:** Choice B

### Q19

Option 2

 CAT 2023 Slot 2 - VA RC

 Five jumbled up sentences (labelled 1, 2, 3, 4 and 5), related to a topic, are given below. Four of them can be put together to form a coherent paragraph. Identify the odd sentence and key in the number of that sentence as your answer.

1. Self-care particularly links to loneliness, behavioural problems, and negative academic outcomes.
2. "Latchkey children" refers to children who routinely return home from school to empty homes and take care of themselves for extended periods of time.
3. Although self-care generally points to negative outcomes, it is important to consider that the bulk of research has yet to track long-term consequences.
4. In research and practice, the phrase "children in self-care" has come to replace latchkey in an effort to more accurately reflect the nature of their circumstances.
5. Although parents might believe that self-care would be beneficial for development, recent research has found quite the opposite.

**ANSWER:** 3

### Q20

CAT 2023 Slot 2 - VA RC

 Five jumbled up sentences (labelled 1, 2, 3, 4 and 5), related to a topic, are given below. Four of them can be put together to form a coherent paragraph. Identify the odd sentence and key in the number of that sentence as your answer.

 1. The banning of Northern Lights could be considered a precursor to censoring books for "moral", world view or religious reasons.
2. Attempts to ban books are attempts to silence authors who have summoned immense courage in telling their stories.
3. Now the banning and challenging of books in the US has escalated to an unprecedented level.
4. The widely acclaimed fantasy novel Northern Lights was banned in some parts of the US, and was the second most challenged book in the US.
5. The American Library Association documented an unparalleled number of reported book challenges in 2022, about 2,500 unique titles.

**ANSWER:** 2

### Q21

CAT 2023 Slot 2 - VA RC

 The four sentences (labelled 1, 2, 3 and 4) given below, when properly sequenced, would yield a coherent paragraph. Decide on the proper sequencing of the order of the sentences and key in the sequence of the four numbers as your answer.

1. Contemporary African writing like 'The Bottled Leopard' voices this theme using two children and two backgrounds to juxtapose two varying cultures.
2. Chukwuemeka Ike explores the conflict, and casts the Western tradition as condescending, enveloping and unaccommodating towards local African practice.
3. However, their views contradict the reality, for a rich and sustaining local African cultural ethos exists for all who care, to see and experience.
4. Western Christian concepts tend to deny or feign ignorance about the existence of a genuine and enduring indigenous African tradition.

**ANSWER:** 4312

### Q22

CAT 2023 Slot 2 - VA RC

 The four sentences (labelled 1, 2, 3 and 4) given below, when properly sequenced, would yield a coherent paragraph. Decide on the proper sequencing of the order of the sentences and key in the sequence of the four numbers as your answer.

1. Like the ants that make up a colony, no single neuron holds complex information like self-awareness, hope or pride.
2. Although the human brain is not yet understood enough to identify the mechanism by which emergence functions, most neurobiologists agree that complex interconnections among the parts give rise to qualities that belong only to the whole.
3. Nonetheless, the sum of all neurons in the nervous system generate complex human emotions like fear and joy, none of which can be attributed to a single neuron.
4. Human consciousness is often called an emergent property of the human brain.

**ANSWER:** 4132

### Q23

CAT 2023 Slot 2 - VA RC

 The passage given below is followed by four alternate summaries. Choose the option that best captures the essence of the passage.

Heatwaves are becoming longer, frequent and intense due to climate change. The impacts of extreme heat are unevenly experienced; with older people and young children, those with pre-existing medical conditions and on low incomes significantly more vulnerable. Adaptation to heatwaves is a significant public policy concern. Research conducted among at-risk people in the UK reveals that even vulnerable people do not perceive themselves as at risk of extreme heat; therefore, early warnings of extreme heat events do not perform as intended. This suggests that understanding how extreme heat is narrated is very important. The news media play a central role in this process and can help warn people about the potential danger, as well as about impacts on infrastructure and society.

 Protection from heat waves is important but current reports and public policies seem ineffective.

 Heatwaves pose an enormous risk; the media plays a pivotal role in alerting people to this danger.

 People are vulnerable to heatwaves caused due to climate change, measures taken are ineffective.

 News stories help in warning about heatwaves, but they have to become more effective.

**ANSWER:** Choice B

### Q24

Heatwaves pose an enormous risk; the media plays a pivotal role in alerting people to this danger.

 CAT 2023 Slot 2 - VA RC

 The passage given below is followed by four alternate summaries. Choose the option that best captures the essence of the passage.

People spontaneously create counterfactual alternatives to reality when they think "if only" or "what if" and imagine how the past could have been different. The mind computes counterfactuals for many reasons. Counterfactuals explain the past and prepare for the future, they implicate various relations including causal ones, and they affect intentions and decisions. They modulate emotions such as regret and relief, and they support moral judgments such as blame. The ability to create counterfactuals develops throughout childhood and contributes to reasoning about other people's beliefs, including their false beliefs.

 People create counterfactual alternatives to reality for various reasons, including reasoning about other people's beliefs.

 Counterfactual thinking helps to reverse past and future actions and reason out false beliefs.

 Counterfactual alternatives to reality are created for a variety of reasons and is part of one's developmental process.

 Counterfactuals help people to prepare for the future by understanding intentions and making decisions.

**ANSWER:** Choice C
