# Text-extractable answers: CAT-2018-Question-Paper-Slot-2-Quants-2IIM-With-Video-Solutions.pdf

- Source PDF: `2iim-pyq/CAT-2018-Question-Paper-Slot-2-Quants-2IIM-With-Video-Solutions.pdf`
- Explicit plain-text answer lines: **11**
- Only `Correct Answer:`, `Answer:`, and official TITA `Possible Answer:` fields.
- **Not included:** candidate `Chosen Option` (not necessarily correct); color-marked MCQ keys; answers only visible via PDF link/button.
- Do not invent missing MCQ keys.

1. **Answer:** 24
2. **Answer:** 10
3. **Answer:** 1098
4. **Answer:** 8
5. **Answer:** 50
6. **Answer:** 5
7. **Answer:** 36
8. **Answer:** 48
9. **Answer:** 4000
10. **Answer:** 105
11. **Answer:** -65/2
