# Text-extractable answers: CAT-2017-Slot-1-quants-2IIM-With-Video-Solutions.pdf

- Source PDF: `2iim-pyq/CAT-2017-Slot-1-quants-2IIM-With-Video-Solutions.pdf`
- Explicit plain-text answer lines: **11**
- Only `Correct Answer:`, `Answer:`, and official TITA `Possible Answer:` fields.
- **Not included:** candidate `Chosen Option` (not necessarily correct); color-marked MCQ keys; answers only visible via PDF link/button.
- Do not invent missing MCQ keys.

1. **Answer:** 20
2. **Answer:** 15
3. **Answer:** 11
4. **Answer:** 20
5. **Answer:** 70000
6. **Answer:** 6
7. **Answer:** 24
8. **Answer:** 11
9. **Answer:** 24
10. **Answer:** 2
11. **Answer:** 160
