# Text-extractable answers: CAT-2019-Quants-Slot2.pdf

- Source PDF: `2iim-pyq/CAT-2019-Quants-Slot2.pdf`
- Explicit plain-text answer lines: **11**
- TITA/explicit only; MCQ reveal links not transcribed.

1. **Answer:** 44
2. **Answer:** 12
3. **Answer:** 150
4. **Answer:** 48
5. **Answer:** 80
6. **Answer:** 4
7. **Answer:** 7
8. **Answer:** 4851
9. **Answer:** 13
10. **Answer:** 20920
11. **Answer:** 12
