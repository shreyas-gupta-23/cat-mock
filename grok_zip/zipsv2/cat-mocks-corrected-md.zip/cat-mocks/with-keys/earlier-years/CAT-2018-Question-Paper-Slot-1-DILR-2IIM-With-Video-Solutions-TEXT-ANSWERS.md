# Text-extractable answers: CAT-2018-Question-Paper-Slot-1-DILR-2IIM-With-Video-Solutions.pdf

- Source PDF: `2iim-pyq/CAT-2018-Question-Paper-Slot-1-DILR-2IIM-With-Video-Solutions.pdf`
- Explicit plain-text answer lines: **7**
- Only `Correct Answer:`, `Answer:`, and official TITA `Possible Answer:` fields.
- **Not included:** candidate `Chosen Option` (not necessarily correct); color-marked MCQ keys; answers only visible via PDF link/button.
- Do not invent missing MCQ keys.

1. **Answer:** 13
2. **Answer:** 14
3. **Answer:** 4
4. **Answer:** 7
5. **Answer:** 6
6. **Answer:** 4
7. **Answer:** 3
