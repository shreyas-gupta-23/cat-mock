# Text-extractable answers: CAT-2021-Verbal-Slot1.pdf

- Source PDF: `2iim-pyq/CAT-2021-Verbal-Slot1.pdf`
- Explicit plain-text answer lines: **3**
- Only `Correct Answer:`, `Answer:`, and official TITA `Possible Answer:` fields.
- **Not included:** candidate `Chosen Option` (not necessarily correct); color-marked MCQ keys; answers only visible via PDF link/button.
- Do not invent missing MCQ keys.

1. **Correct Answer:** 4312
2. **Correct Answer:** 2143
3. **Correct Answer:** 2341
