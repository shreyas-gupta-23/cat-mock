# Text-extractable answers: CAT-2017-Slot-2-quants-2IIM-With-Video-Solutions.pdf

- Source PDF: `2iim-pyq/CAT-2017-Slot-2-quants-2IIM-With-Video-Solutions.pdf`
- Explicit plain-text answer lines: **11**
- Only `Correct Answer:`, `Answer:`, and official TITA `Possible Answer:` fields.
- **Not included:** candidate `Chosen Option` (not necessarily correct); color-marked MCQ keys; answers only visible via PDF link/button.
- Do not invent missing MCQ keys.

1. **Answer:** 3
2. **Answer:** 1900
3. **Answer:** 90
4. **Answer:** 200
5. **Answer:** 16
6. **Answer:** 3
7. **Answer:** 51
8. **Answer:** 3
9. **Answer:** 6
10. **Answer:** 50
11. **Answer:** 1
