# Text-extractable answers: CAT-Answer-Key-CAT-2018-Slot-1.pdf

- Source PDF: `2iim-pyq/CAT-Answer-Key-CAT-2018-Slot-1.pdf`
- Explicit plain-text answer lines: **0**
- Only `Correct Answer:`, `Answer:`, and official TITA `Possible Answer:` fields.
- **Not included:** candidate `Chosen Option` (not necessarily correct); color-marked MCQ keys; answers only visible via PDF link/button.
- Do not invent missing MCQ keys.

_No plain-text answer lines found._
