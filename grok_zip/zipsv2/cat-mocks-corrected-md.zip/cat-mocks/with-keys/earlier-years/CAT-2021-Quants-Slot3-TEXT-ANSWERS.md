# Text-extractable answers: CAT-2021-Quants-Slot3.pdf

- Source PDF: `2iim-pyq/CAT-2021-Quants-Slot3.pdf`
- Explicit plain-text answer lines: **7**
- Only `Correct Answer:`, `Answer:`, and official TITA `Possible Answer:` fields.
- **Not included:** candidate `Chosen Option` (not necessarily correct); color-marked MCQ keys; answers only visible via PDF link/button.
- Do not invent missing MCQ keys.

1. **Correct Answer:** 3000
2. **Correct Answer:** 8
3. **Correct Answer:** 50
4. **Correct Answer:** 92
5. **Correct Answer:** 3500
6. **Correct Answer:** 34
7. **Correct Answer:** 6
