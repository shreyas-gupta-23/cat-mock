# Text-extractable answers: CAT-2017-Slot-2-VARC-2IIM-With-Text-Solutions.pdf

- Source PDF: `2iim-pyq/CAT-2017-Slot-2-VARC-2IIM-With-Text-Solutions.pdf`
- Explicit plain-text answer lines: **7**
- Only `Correct Answer:`, `Answer:`, and official TITA `Possible Answer:` fields.
- **Not included:** candidate `Chosen Option` (not necessarily correct); color-marked MCQ keys; answers only visible via PDF link/button.
- Do not invent missing MCQ keys.

1. **Answer:** 25341
2. **Answer:** 53421
3. **Answer:** 25431
4. **Answer:** 43512
5. **Answer:** 2                                                                                Question
6. **Answer:** 4
7. **Answer:** 1
