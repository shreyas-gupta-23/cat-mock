# Text-extractable answers: CAT-2021-DILR-Slot3.pdf

- Source PDF: `2iim-pyq/CAT-2021-DILR-Slot3.pdf`
- Explicit plain-text answer lines: **5**
- Only `Correct Answer:`, `Answer:`, and official TITA `Possible Answer:` fields.
- **Not included:** candidate `Chosen Option` (not necessarily correct); color-marked MCQ keys; answers only visible via PDF link/button.
- Do not invent missing MCQ keys.

1. **Correct Answer:** 3
2. **Correct Answer:** 1
3. **Correct Answer:** 3
4. **Correct Answer:** 1
5. **Correct Answer:** 2
