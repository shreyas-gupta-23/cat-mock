# Text-extractable answers: CAT-2019-slot1-answer-key.pdf

- Source PDF: `2iim-pyq/CAT-2019-slot1-answer-key.pdf`
- Explicit plain-text answer lines: **24**
- Only `Correct Answer:`, `Answer:`, and official TITA `Possible Answer:` fields.
- **Not included:** candidate `Chosen Option` (not necessarily correct); color-marked MCQ keys; answers only visible via PDF link/button.
- Do not invent missing MCQ keys.

1. **Possible Answer (TITA official field):** 2341
2. **Possible Answer (TITA official field):** 2
3. **Possible Answer (TITA official field):** 4123
4. **Possible Answer (TITA official field):** 1
5. **Possible Answer (TITA official field):** 2
6. **Possible Answer (TITA official field):** 3241
7. **Possible Answer (TITA official field):** 2
8. **Possible Answer (TITA official field):** 6
9. **Possible Answer (TITA official field):** 5
10. **Possible Answer (TITA official field):** 1
11. **Possible Answer (TITA official field):** 9
12. **Possible Answer (TITA official field):** 7
13. **Possible Answer (TITA official field):** 6
14. **Possible Answer (TITA official field):** 20
15. **Possible Answer (TITA official field):** 3920
16. **Possible Answer (TITA official field):** 9
17. **Possible Answer (TITA official field):** 10
18. **Possible Answer (TITA official field):** 9
19. **Possible Answer (TITA official field):** 6144
20. **Possible Answer (TITA official field):** 880
21. **Possible Answer (TITA official field):** 2
22. **Possible Answer (TITA official field):** 5
23. **Possible Answer (TITA official field):** 13
24. **Possible Answer (TITA official field):** 3
