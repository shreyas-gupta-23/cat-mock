# Text-extractable answers: CAT-2020-Quants-Slot2.pdf

- Source PDF: `2iim-pyq/CAT-2020-Quants-Slot2.pdf`
- Explicit plain-text answer lines: **8**
- Only `Correct Answer:`, `Answer:`, and official TITA `Possible Answer:` fields.
- **Not included:** candidate `Chosen Option` (not necessarily correct); color-marked MCQ keys; answers only visible via PDF link/button.
- Do not invent missing MCQ keys.

1. **Answer:** 17
2. **Answer:** 2704
3. **Answer:** 90000
4. **Answer:** 23
5. **Answer:** 10
6. **Answer:** 4
7. **Answer:** 800
8. **Answer:** 315
