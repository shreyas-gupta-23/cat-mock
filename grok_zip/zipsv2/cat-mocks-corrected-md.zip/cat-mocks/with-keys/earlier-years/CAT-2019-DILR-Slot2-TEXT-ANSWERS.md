# Text-extractable answers: CAT-2019-DILR-Slot2.pdf

- Source PDF: `2iim-pyq/CAT-2019-DILR-Slot2.pdf`
- Explicit plain-text answer lines: **8**
- TITA/explicit only; MCQ reveal links not transcribed.

1. **Answer:** 64
2. **Answer:** 84
3. **Answer:** 13
4. **Answer:** 8
5. **Answer:** 2
6. **Answer:** 3
7. **Answer:** 25
8. **Answer:** 70
