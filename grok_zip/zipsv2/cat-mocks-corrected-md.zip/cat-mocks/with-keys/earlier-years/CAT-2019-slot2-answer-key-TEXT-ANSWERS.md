# Text-extractable answers: CAT-2019-slot2-answer-key.pdf

- Source PDF: `2iim-pyq/CAT-2019-slot2-answer-key.pdf`
- Explicit plain-text answer lines: **29**
- Only `Correct Answer:`, `Answer:`, and official TITA `Possible Answer:` fields.
- **Not included:** candidate `Chosen Option` (not necessarily correct); color-marked MCQ keys; answers only visible via PDF link/button.
- Do not invent missing MCQ keys.

1. **Answer:** file:///C:/Users/ARVIND/OneDrive/website-staging/bharathwaj-results.html                                                                                    49/80
2. **Answer:** file:///C:/Users/ARVIND/OneDrive/website-staging/bharathwaj-results.html                                                            69/80
3. **Answer:** file:///C:/Users/ARVIND/OneDrive/website-staging/bharathwaj-results.html                                                                                        79/80
4. **Possible Answer (TITA official field):** 2
5. **Possible Answer (TITA official field):** 3421
6. **Possible Answer (TITA official field):** 2143
7. **Possible Answer (TITA official field):** 2431
8. **Possible Answer (TITA official field):** 4132
9. **Possible Answer (TITA official field):** 2
10. **Possible Answer (TITA official field):** 1
11. **Possible Answer (TITA official field):** 64
12. **Possible Answer (TITA official field):** 84
13. **Possible Answer (TITA official field):** 25
14. **Possible Answer (TITA official field):** 70
15. **Possible Answer (TITA official field):** 13
16. **Possible Answer (TITA official field):** 8
17. **Possible Answer (TITA official field):** 2
18. **Possible Answer (TITA official field):** 3
19. **Possible Answer (TITA official field):** 4851
20. **Possible Answer (TITA official field):** 13
21. **Possible Answer (TITA official field):** 80
22. **Possible Answer (TITA official field):** 12
23. **Possible Answer (TITA official field):** 7
24. **Possible Answer (TITA official field):** 44
25. **Possible Answer (TITA official field):** 150
26. **Possible Answer (TITA official field):** 20920
27. **Possible Answer (TITA official field):** 12
28. **Possible Answer (TITA official field):** 48
29. **Possible Answer (TITA official field):** 4
