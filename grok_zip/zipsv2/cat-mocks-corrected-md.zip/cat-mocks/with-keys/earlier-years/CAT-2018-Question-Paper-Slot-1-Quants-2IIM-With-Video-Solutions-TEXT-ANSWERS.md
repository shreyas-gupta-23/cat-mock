# Text-extractable answers: CAT-2018-Question-Paper-Slot-1-Quants-2IIM-With-Video-Solutions.pdf

- Source PDF: `2iim-pyq/CAT-2018-Question-Paper-Slot-1-Quants-2IIM-With-Video-Solutions.pdf`
- Explicit plain-text answer lines: **12**
- Only `Correct Answer:`, `Answer:`, and official TITA `Possible Answer:` fields.
- **Not included:** candidate `Chosen Option` (not necessarily correct); color-marked MCQ keys; answers only visible via PDF link/button.
- Do not invent missing MCQ keys.

1. **Answer:** 54
2. **Answer:** 60
3. **Answer:** 40
4. **Answer:** 198
5. **Answer:** 502
6. **Answer:** 1,21,000
7. **Answer:** 12
8. **Answer:** 5
9. **Answer:** 52
10. **Answer:** 15
11. **Answer:** 10
12. **Answer:** 32
