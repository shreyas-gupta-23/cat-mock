# Text-extractable answers: CAT-2020-Quants-Slot1.pdf

- Source PDF: `2iim-pyq/CAT-2020-Quants-Slot1.pdf`
- Explicit plain-text answer lines: **8**
- Only `Correct Answer:`, `Answer:`, and official TITA `Possible Answer:` fields.
- **Not included:** candidate `Chosen Option` (not necessarily correct); color-marked MCQ keys; answers only visible via PDF link/button.
- Do not invent missing MCQ keys.

1. **Correct Answer:** 21
2. **Correct Answer:** 12
3. **Correct Answer:** 36
4. **Correct Answer:** 1
5. **Correct Answer:** 20000
6. **Correct Answer:** 3
7. **Correct Answer:** 62
8. **Correct Answer:** 8
