# Text-extractable answers: CAT-2018-Verbal-solutions-slot2.pdf

- Source PDF: `2iim-pyq/CAT-2018-Verbal-solutions-slot2.pdf`
- Explicit plain-text answer lines: **5**
- Only `Correct Answer:`, `Answer:`, and official TITA `Possible Answer:` fields.
- **Not included:** candidate `Chosen Option` (not necessarily correct); color-marked MCQ keys; answers only visible via PDF link/button.
- Do not invent missing MCQ keys.

1. **Answer:** 3241
2. **Answer:** 2314
3. **Answer:** 3241
4. **Answer:** 4213
5. **Answer:** 3
