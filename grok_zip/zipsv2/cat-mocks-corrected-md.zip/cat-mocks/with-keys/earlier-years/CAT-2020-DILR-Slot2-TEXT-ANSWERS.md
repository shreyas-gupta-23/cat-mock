# Text-extractable answers: CAT-2020-DILR-Slot2.pdf

- Source PDF: `2iim-pyq/CAT-2020-DILR-Slot2.pdf`
- Explicit plain-text answer lines: **5**
- Only `Correct Answer:`, `Answer:`, and official TITA `Possible Answer:` fields.
- **Not included:** candidate `Chosen Option` (not necessarily correct); color-marked MCQ keys; answers only visible via PDF link/button.
- Do not invent missing MCQ keys.

1. **Answer:** 2
2. **Answer:** 9
3. **Answer:** 6
4. **Answer:** 9
5. **Answer:** 11
