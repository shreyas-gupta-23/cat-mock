# Text-extractable answers: CAT-2020-DILR-Slot3.pdf

- Source PDF: `2iim-pyq/CAT-2020-DILR-Slot3.pdf`
- Explicit plain-text answer lines: **5**
- Only `Correct Answer:`, `Answer:`, and official TITA `Possible Answer:` fields.
- **Not included:** candidate `Chosen Option` (not necessarily correct); color-marked MCQ keys; answers only visible via PDF link/button.
- Do not invent missing MCQ keys.

1. **Correct Answer:** 4
2. **Correct Answer:** 2
3. **Correct Answer:** 1
4. **Correct Answer:** 42
5. **Correct Answer:** 20
