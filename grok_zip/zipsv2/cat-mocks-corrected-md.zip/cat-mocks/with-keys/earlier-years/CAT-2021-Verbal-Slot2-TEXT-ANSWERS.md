# Text-extractable answers: CAT-2021-Verbal-Slot2.pdf

- Source PDF: `2iim-pyq/CAT-2021-Verbal-Slot2.pdf`
- Explicit plain-text answer lines: **6**
- Only `Correct Answer:`, `Answer:`, and official TITA `Possible Answer:` fields.
- **Not included:** candidate `Chosen Option` (not necessarily correct); color-marked MCQ keys; answers only visible via PDF link/button.
- Do not invent missing MCQ keys.

1. **Correct Answer:** Option 1
2. **Correct Answer:** Option B
3. **Correct Answer:** 2143
4. **Correct Answer:** 2413
5. **Correct Answer:** Option 5
6. **Correct Answer:** 3214
