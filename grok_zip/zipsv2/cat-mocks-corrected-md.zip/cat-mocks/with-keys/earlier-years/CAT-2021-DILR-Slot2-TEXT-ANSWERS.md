# Text-extractable answers: CAT-2021-DILR-Slot2.pdf

- Source PDF: `2iim-pyq/CAT-2021-DILR-Slot2.pdf`
- Explicit plain-text answer lines: **4**
- Only `Correct Answer:`, `Answer:`, and official TITA `Possible Answer:` fields.
- **Not included:** candidate `Chosen Option` (not necessarily correct); color-marked MCQ keys; answers only visible via PDF link/button.
- Do not invent missing MCQ keys.

1. **Correct Answer:** 12
2. **Correct Answer:** 6
3. **Correct Answer:** 5
4. **Correct Answer:** 6
