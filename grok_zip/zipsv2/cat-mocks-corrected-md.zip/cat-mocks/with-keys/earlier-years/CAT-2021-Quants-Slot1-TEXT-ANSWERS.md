# Text-extractable answers: CAT-2021-Quants-Slot1.pdf

- Source PDF: `2iim-pyq/CAT-2021-Quants-Slot1.pdf`
- Explicit plain-text answer lines: **8**
- Only `Correct Answer:`, `Answer:`, and official TITA `Possible Answer:` fields.
- **Not included:** candidate `Chosen Option` (not necessarily correct); color-marked MCQ keys; answers only visible via PDF link/button.
- Do not invent missing MCQ keys.

1. **Correct Answer:** 99
2. **Correct Answer:** 1000
3. **Correct Answer:** 200
4. **Correct Answer:** 32
5. **Correct Answer:** 47
6. **Correct Answer:** 120
7. **Correct Answer:** 35
8. **Correct Answer:** 70
