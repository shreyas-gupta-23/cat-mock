# Text-extractable answers: CAT-2020-Quants-Slot3.pdf

- Source PDF: `2iim-pyq/CAT-2020-Quants-Slot3.pdf`
- Explicit plain-text answer lines: **8**
- Only `Correct Answer:`, `Answer:`, and official TITA `Possible Answer:` fields.
- **Not included:** candidate `Chosen Option` (not necessarily correct); color-marked MCQ keys; answers only visible via PDF link/button.
- Do not invent missing MCQ keys.

1. **Correct Answer:** 18
2. **Answer:** 6
3. **Answer:** 40
4. **Answer:** 24
5. **Answer:** 3
6. **Answer:** 252
7. **Answer:** 16000
8. **Answer:** 28
