# Text-extractable answers: CAT-2021-Quants-Slot2.pdf

- Source PDF: `2iim-pyq/CAT-2021-Quants-Slot2.pdf`
- Explicit plain-text answer lines: **8**
- Only `Correct Answer:`, `Answer:`, and official TITA `Possible Answer:` fields.
- **Not included:** candidate `Chosen Option` (not necessarily correct); color-marked MCQ keys; answers only visible via PDF link/button.
- Do not invent missing MCQ keys.

1. **Correct Answer:** 1000                                             Click to go “Back to Question”
2. **Correct Answer:** 5
3. **Correct Answer:** 45
4. **Correct Answer:** 250
5. **Correct Answer:** 30
6. **Correct Answer:** 4195
7. **Correct Answer:** 10
8. **Correct Answer:** 7
