# Text-extractable answers: CAT-2019-Verbal-Solutions-Slot2.pdf

- Source PDF: `2iim-pyq/CAT-2019-Verbal-Solutions-Slot2.pdf`
- Explicit plain-text answer lines: **7**
- Only `Correct Answer:`, `Answer:`, and official TITA `Possible Answer:` fields.
- **Not included:** candidate `Chosen Option` (not necessarily correct); color-marked MCQ keys; answers only visible via PDF link/button.
- Do not invent missing MCQ keys.

1. **Answer:** 4132
2. **Answer:** 2431
3. **Answer:** 2143
4. **Answer:** 2
5. **Answer:** 1
6. **Answer:** 2
7. **Answer:** 3421
