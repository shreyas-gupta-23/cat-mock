# Earlier-year answer materials (2017–2021)

PDF copies of named answer-key / solutions packs from `2iim-pyq/` live here.
Companion `*-TEXT-ANSWERS.md` files list **only** plain-text answers (`Correct Answer:`, `Answer:`, official TITA `Possible Answer:`).

MCQ keys that are color-marked or behind PDF click-to-reveal are **not invented** — open the PDF. See also `../MISSING-KEYS.md`.

## PDFs copied here

- `CAT-2017-Slot-1-DILR-2IIM-With-Video-Solutions.pdf`
- `CAT-2017-Slot-1-VARC-2IIM-With-Text-Solutions.pdf`
- `CAT-2017-Slot-1-quants-2IIM-With-Video-Solutions.pdf`
- `CAT-2017-Slot-2-DILR-2IIM-With-Video-Solutions.pdf`
- `CAT-2017-Slot-2-VARC-2IIM-With-Text-Solutions.pdf`
- `CAT-2017-Slot-2-quants-2IIM-With-Video-Solutions.pdf`
- `CAT-2018-Question-Paper-Slot-1-DILR-2IIM-With-Video-Solutions.pdf`
- `CAT-2018-Question-Paper-Slot-1-Quants-2IIM-With-Video-Solutions.pdf`
- `CAT-2018-Question-Paper-Slot-2-DILR-2IIM-With-Video-Solutions.pdf`
- `CAT-2018-Question-Paper-Slot-2-Quants-2IIM-With-Video-Solutions.pdf`
- `CAT-2018-Verbal-solutions-slot1.pdf`
- `CAT-2018-Verbal-solutions-slot2.pdf`
- `CAT-2019-DILR-Slot1.pdf`
- `CAT-2019-DILR-Slot2.pdf`
- `CAT-2019-Quants-Slot1.pdf`
- `CAT-2019-Quants-Slot2.pdf`
- `CAT-2019-Verbal-Solutions-Slot1.pdf`
- `CAT-2019-Verbal-Solutions-Slot2.pdf`
- `CAT-2019-slot1-answer-key.pdf`
- `CAT-2019-slot2-answer-key.pdf`
- `CAT-Answer-Key-CAT-2018-Slot-1.pdf`
- `CAT-Answer-Key-CAT-2018-Slot-2.pdf`

## Text-extract answer counts

- `CAT-2017-Slot-1-DILR-2IIM-With-Video-Solutions.pdf` → `CAT-2017-Slot-1-DILR-2IIM-With-Video-Solutions-TEXT-ANSWERS.md` — **0** text answers
- `CAT-2017-Slot-1-VARC-2IIM-With-Text-Solutions.pdf` → `CAT-2017-Slot-1-VARC-2IIM-With-Text-Solutions-TEXT-ANSWERS.md` — **7** text answers
- `CAT-2017-Slot-1-quants-2IIM-With-Video-Solutions.pdf` → `CAT-2017-Slot-1-quants-2IIM-With-Video-Solutions-TEXT-ANSWERS.md` — **11** text answers
- `CAT-2017-Slot-2-DILR-2IIM-With-Video-Solutions.pdf` → `CAT-2017-Slot-2-DILR-2IIM-With-Video-Solutions-TEXT-ANSWERS.md` — **0** text answers
- `CAT-2017-Slot-2-VARC-2IIM-With-Text-Solutions.pdf` → `CAT-2017-Slot-2-VARC-2IIM-With-Text-Solutions-TEXT-ANSWERS.md` — **7** text answers
- `CAT-2017-Slot-2-quants-2IIM-With-Video-Solutions.pdf` → `CAT-2017-Slot-2-quants-2IIM-With-Video-Solutions-TEXT-ANSWERS.md` — **11** text answers
- `CAT-2018-Question-Paper-Slot-1-DILR-2IIM-With-Video-Solutions.pdf` → `CAT-2018-Question-Paper-Slot-1-DILR-2IIM-With-Video-Solutions-TEXT-ANSWERS.md` — **7** text answers
- `CAT-2018-Question-Paper-Slot-1-Quants-2IIM-With-Video-Solutions.pdf` → `CAT-2018-Question-Paper-Slot-1-Quants-2IIM-With-Video-Solutions-TEXT-ANSWERS.md` — **12** text answers
- `CAT-2018-Question-Paper-Slot-2-DILR-2IIM-With-Video-Solutions.pdf` → `CAT-2018-Question-Paper-Slot-2-DILR-2IIM-With-Video-Solutions-TEXT-ANSWERS.md` — **8** text answers
- `CAT-2018-Question-Paper-Slot-2-Quants-2IIM-With-Video-Solutions.pdf` → `CAT-2018-Question-Paper-Slot-2-Quants-2IIM-With-Video-Solutions-TEXT-ANSWERS.md` — **11** text answers
- `CAT-2018-Verbal-solutions-slot1.pdf` → `CAT-2018-Verbal-solutions-slot1-TEXT-ANSWERS.md` — **7** text answers
- `CAT-2018-Verbal-solutions-slot2.pdf` → `CAT-2018-Verbal-solutions-slot2-TEXT-ANSWERS.md` — **5** text answers
- `CAT-2019-DILR-Slot1.pdf` → `CAT-2019-DILR-Slot1-TEXT-ANSWERS.md` — **7** text answers
- `CAT-2019-DILR-Slot2.pdf` → `CAT-2019-DILR-Slot2-TEXT-ANSWERS.md` — **8** text answers
- `CAT-2019-Quants-Slot1.pdf` → `CAT-2019-Quants-Slot1-TEXT-ANSWERS.md` — **11** text answers
- `CAT-2019-Quants-Slot2.pdf` → `CAT-2019-Quants-Slot2-TEXT-ANSWERS.md` — **11** text answers
- `CAT-2019-Verbal-Solutions-Slot1.pdf` → `CAT-2019-Verbal-Solutions-Slot1-TEXT-ANSWERS.md` — **6** text answers
- `CAT-2019-Verbal-Solutions-Slot2.pdf` → `CAT-2019-Verbal-Solutions-Slot2-TEXT-ANSWERS.md` — **7** text answers
- `CAT-2019-slot1-answer-key.pdf` → `CAT-2019-slot1-answer-key-TEXT-ANSWERS.md` — **24** text answers
- `CAT-2019-slot2-answer-key.pdf` → `CAT-2019-slot2-answer-key-TEXT-ANSWERS.md` — **29** text answers
- `CAT-2020-DILR-Slot1.pdf` → `CAT-2020-DILR-Slot1-TEXT-ANSWERS.md` — **6** text answers
- `CAT-2020-DILR-Slot2.pdf` → `CAT-2020-DILR-Slot2-TEXT-ANSWERS.md` — **5** text answers
- `CAT-2020-DILR-Slot3.pdf` → `CAT-2020-DILR-Slot3-TEXT-ANSWERS.md` — **5** text answers
- `CAT-2020-Quants-Slot1.pdf` → `CAT-2020-Quants-Slot1-TEXT-ANSWERS.md` — **8** text answers
- `CAT-2020-Quants-Slot2.pdf` → `CAT-2020-Quants-Slot2-TEXT-ANSWERS.md` — **8** text answers
- `CAT-2020-Quants-Slot3.pdf` → `CAT-2020-Quants-Slot3-TEXT-ANSWERS.md` — **8** text answers
- `CAT-2020-Verbal-Slot2.pdf` → `CAT-2020-Verbal-Slot2-TEXT-ANSWERS.md` — **6** text answers
- `CAT-2020-Verbal-Slot3.pdf` → `CAT-2020-Verbal-Slot3-TEXT-ANSWERS.md` — **7** text answers
- `CAT-2021-DILR-Slot1.pdf` → `CAT-2021-DILR-Slot1-TEXT-ANSWERS.md` — **5** text answers
- `CAT-2021-DILR-Slot2.pdf` → `CAT-2021-DILR-Slot2-TEXT-ANSWERS.md` — **4** text answers
- `CAT-2021-DILR-Slot3.pdf` → `CAT-2021-DILR-Slot3-TEXT-ANSWERS.md` — **5** text answers
- `CAT-2021-Quants-Slot1.pdf` → `CAT-2021-Quants-Slot1-TEXT-ANSWERS.md` — **8** text answers
- `CAT-2021-Quants-Slot2.pdf` → `CAT-2021-Quants-Slot2-TEXT-ANSWERS.md` — **8** text answers
- `CAT-2021-Quants-Slot3.pdf` → `CAT-2021-Quants-Slot3-TEXT-ANSWERS.md` — **7** text answers
- `CAT-2021-Verbal-Slot1.pdf` → `CAT-2021-Verbal-Slot1-TEXT-ANSWERS.md` — **3** text answers
- `CAT-2021-Verbal-Slot2.pdf` → `CAT-2021-Verbal-Slot2-TEXT-ANSWERS.md` — **6** text answers
- `CAT-2021-Verbal-Slot3.pdf` → `CAT-2021-Verbal-Slot3-TEXT-ANSWERS.md` — **5** text answers
- `CAT-Answer-Key-CAT-2018-Slot-1.pdf` → `CAT-Answer-Key-CAT-2018-Slot-1-TEXT-ANSWERS.md` — **0** text answers
- `CAT-Answer-Key-CAT-2018-Slot-2.pdf` → `CAT-Answer-Key-CAT-2018-Slot-2-TEXT-ANSWERS.md` — **0** text answers

