# Text-extractable answers: CAT-2019-Verbal-Solutions-Slot1.pdf

- Source PDF: `2iim-pyq/CAT-2019-Verbal-Solutions-Slot1.pdf`
- Explicit plain-text answer lines: **6**
- Only `Correct Answer:`, `Answer:`, and official TITA `Possible Answer:` fields.
- **Not included:** candidate `Chosen Option` (not necessarily correct); color-marked MCQ keys; answers only visible via PDF link/button.
- Do not invent missing MCQ keys.

1. **Answer:** 2341
2. **Answer:** 2
3. **Answer:** 4123
4. **Answer:** 1
5. **Answer:** 2
6. **Answer:** 3241
