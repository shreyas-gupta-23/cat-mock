# Text-extractable answers: CAT-2019-DILR-Slot1.pdf

- Source PDF: `2iim-pyq/CAT-2019-DILR-Slot1.pdf`
- Explicit plain-text answer lines: **7**
- TITA/explicit only; MCQ reveal links not transcribed.

1. **Answer:** 2
2. **Answer:** 6
3. **Answer:** 5
4. **Answer:** 1
5. **Answer:** 9
6. **Answer:** 7
7. **Answer:** 6
