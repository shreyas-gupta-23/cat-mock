# Text-extractable answers: CAT-2018-Verbal-solutions-slot1.pdf

- Source PDF: `2iim-pyq/CAT-2018-Verbal-solutions-slot1.pdf`
- Explicit plain-text answer lines: **7**
- Only `Correct Answer:`, `Answer:`, and official TITA `Possible Answer:` fields.
- **Not included:** candidate `Chosen Option` (not necessarily correct); color-marked MCQ keys; answers only visible via PDF link/button.
- Do not invent missing MCQ keys.

1. **Answer:** 4213
2. **Answer:** 1432
3. **Answer:** 2413
4. **Answer:** 1324
5. **Answer:** 5
6. **Answer:** 4
7. **Answer:** 2
