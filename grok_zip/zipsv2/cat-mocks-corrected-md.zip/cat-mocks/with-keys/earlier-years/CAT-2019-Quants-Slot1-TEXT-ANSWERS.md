# Text-extractable answers: CAT-2019-Quants-Slot1.pdf

- Source PDF: `2iim-pyq/CAT-2019-Quants-Slot1.pdf`
- Explicit plain-text answer lines: **11**
- TITA/explicit only; MCQ reveal links not transcribed.

1. **Answer:** 20
2. **Answer:** 3920
3. **Answer:** 9
4. **Answer:** 10
5. **Answer:** 9
6. **Answer:** 6144
7. **Answer:** 880
8. **Answer:** 2
9. **Answer:** 5
10. **Answer:** 13
11. **Answer:** 3
