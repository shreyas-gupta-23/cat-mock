# Text-extractable answers: CAT-2018-Question-Paper-Slot-2-DILR-2IIM-With-Video-Solutions.pdf

- Source PDF: `2iim-pyq/CAT-2018-Question-Paper-Slot-2-DILR-2IIM-With-Video-Solutions.pdf`
- Explicit plain-text answer lines: **8**
- Only `Correct Answer:`, `Answer:`, and official TITA `Possible Answer:` fields.
- **Not included:** candidate `Chosen Option` (not necessarily correct); color-marked MCQ keys; answers only visible via PDF link/button.
- Do not invent missing MCQ keys.

1. **Answer:** 3
2. **Answer:** 48
3. **Answer:** 4
4. **Answer:** 2
5. **Answer:** 0
6. **Answer:** 3
7. **Answer:** 1200
8. **Answer:** 240
