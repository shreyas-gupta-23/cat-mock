# CAT 2022 — Slot 2 — VARC (Questions + On-page Answer Key)

Answers are on-page 2IIM **Correct Answer** labels. Not invented.

## VARC

- Source file: `2iim-html/CAT-2022-Question-Paper-Slot-2-VARC.txt`
- Page: https://online.2iim.com/CAT-question-paper/CAT-2022-Question-Paper-Slot-2-VARC/
- On-page answers found: 24
- Answer source: 2IIM on-page **Correct Answer** / **Correct Answer Choice** (not invented)

### Q1

T he best way to improve your VARC skill is Reading. Read tons of stuff from Bharath's Curated Reading list and get a wonderful VARC score.

 The passage below is accompanied by a set of questions. Choose the best answer to each question.

[Octopuses are] misfits in their own extended families . . . They belong to the Mollusca class Cephalopoda. But they don't look like their cousins at all. Other molluscs include sea snails, sea slugs, bivalves - most are shelled invertebrates with a dorsal foot. Cephalopods are all arms, and can be as tiny as 1 centimetre and as large at 30 feet. Some of them have brains the size of a walnut, which is large for an invertebrate. . . .

It makes sense for these molluscs to have added protection in the form of a higher cognition; they don't have a shell covering them, and pretty much everything feeds on cephalopods, including humans. But how did cephalopods manage to secure their own invisibility cloak? Cephalopods fire from multiple cylinders to achieve this in varying degrees from species to species. There are four main catalysts - chromatophores, iridophores, papillae and leucophores. . . .

[Chromatophores] are organs on their bodies that contain pigment sacs, which have red, yellow and brown pigment granules. These sacs have a network of radial muscles, meaning muscles arranged in a circle radiating outwards. These are connected to the brain by a nerve. When the cephalopod wants to change colour, the brain carries an electrical impulse through the nerve to the muscles that expand outwards, pulling open the sacs to display the colours on the skin. Why these three colours? Because these are the colours the light reflects at the depths they live in (the rest is absorbed before it reaches those depths). . . .

Well, what about other colours? Cue the iridophores. Think of a second level of skin that has thin stacks of cells. These can reflect light back at different wavelengths. . . . It's using the same properties that we've seen in hologram stickers, or rainbows on puddles of oil. You move your head and you see a different colour. The sticker isn't doing anything but reflecting light - it's your movement that's changing the appearance of the colour. This property of holograms, oil and other such surfaces is called "iridescence". . . .

Papillae are sections of the skin that can be deformed to make a texture bumpy. Even humans possess them (goosebumps) but cannot use them in the manner that cephalopods can. For instance, the use of these cells is how an octopus can wrap itself over a rock and appear jagged or how a squid or cuttlefish can imitate the look of a coral reef by growing miniature towers on its skin. It actually matches the texture of the substrate it chooses.

Finally, the leucophores: According to a paper, published in Nature, cuttlefish and octopuses possess an additional type of reflector cell called a leucophore. They are cells that scatter full spectrum light so that they appear white in a similar way that a polar bear's fur appears white. Leucophores will also reflect any filtered light shown on them . . . If the water appears blue at a certain depth, the octopuses and cuttlefish can appear blue; if the water appears green, they appear green, and so on and so forth.

 CAT 2022 Slot 2 - VA RC

 All of the following are reasons for octopuses being "misfits" EXCEPT that they:

 have several arms.

 are consumed by humans and other animals.

 do not possess an outer protective shell.

 exhibit higher intelligence than other molluscs.

**ANSWER:** Choice B

### Q2

are consumed by humans and other animals.

 CAT 2022 Slot 2 - VA RC

 Based on the passage, we can infer that all of the following statements, if true, would weaken the camouflaging adeptness of Cephalopods EXCEPT:

 the hydrostatic pressure at the depths at which Cephalopods reside renders radial muscle movements difficult.

 the temperature of water at the depths at which Cephalopods reside renders the transmission of neural signals difficult.

 light reflects the colours red, green, and yellow at the depths at which Cephalopods reside.

 the number of chromatophores in Cephalopods is half the number of iridophores and leucophores.

**ANSWER:** Choice D

### Q3

the number of chromatophores in Cephalopods is half the number of iridophores and leucophores.

 CAT 2022 Slot 2 - VA RC

 Based on the passage, it can be inferred that camouflaging techniques in an octopus are most dissimilar to those in:

 polar bears

 sea snails

 squids

 cuttlefish

**ANSWER:** Choice B

### Q4

sea snails

 CAT 2022 Slot 2 - VA RC

 Which one of the following statements is not true about the camouflaging ability of Cephalopods?

 Cephalopods can take on the colour of their predator.

 Cephalopods can blend into the colour of their surroundings.

 Cephalopods can change their colour.

 Cephalopods can change their texture.

**ANSWER:** Choice A

### Q5

Cephalopods can take on the colour of their predator.

 The passage below is accompanied by a set of questions. Choose the best answer to each question.

We begin with the emergence of the philosophy of the social sciences as an arena of thought and as a set of social institutions. The two characterisations overlap but are not congruent. Academic disciplines are social institutions. . . . My view is that institutions are all those social entities that organise action: they link acting individuals into social structures. There are various kinds of institutions. Hegelians and Marxists emphasise universal institutions such as the family, rituals, governance, economy and the military. These are mostly institutions that just grew. Perhaps in some imaginary beginning of time they spontaneously appeared. In their present incarnations, however, they are very much the product of conscious attempts to mould and plan them. We have family law, established and disestablished churches, constitutions and laws, including those governing the economy and the military. Institutions deriving from statute, like joint-stock companies are formal by contrast with informal ones such as friendships. There are some institutions that come in both informal and formal variants, as well as in mixed ones. Consider the fact that the stock exchange and the black market are both market institutions, one formal one not. Consider further that there are many features of the work of the stock exchange that rely on informal, noncodifiable agreements, not least the language used for communication. To be precise, mixtures are the norm . . . From constitutions at the top to by-laws near the bottom we are always adding to, or tinkering with, earlier institutions, the grown and the designed are intertwined.

It is usual in social thought to treat culture and tradition as different from, although alongside, institutions. The view taken here is different. Culture and tradition are sub-sets of institutions analytically isolated for explanatory or expository purposes. Some social scientists have taken all institutions, even purely local ones, to be entities that satisfy basic human needs - under local conditions . . . Others differed and declared any structure of reciprocal roles and norms an institution. Most of these differences are differences of emphasis rather than disagreements. Let us straddle all these versions and present institutions very generally . . . as structures that serve to coordinate the actions of individuals. . . . Institutions themselves then have no aims or purpose other than those given to them by actors or used by actors to explain them . . .

Language is the formative institution for social life and for science . . . Both formal and informal language is involved, naturally grown or designed. (Language is all of these to varying degrees.) Languages are paradigms of institutions or, from another perspective, nested sets of institutions. Syntax, semantics, lexicon and alphabet/character-set are all institutions within the larger institutional framework of a written language. Natural languages are typical examples of what Ferguson called 'the result of human action, but not the execution of any human design'[;] reformed natural languages and artificial languages introduce design into their modifications or refinements of natural language. Above all, languages are paradigms of institutional tools that function to coordinate.

 CAT 2022 Slot 2 - VA RC

 "Consider the fact that the stock exchange and the black market are both market institutions, one formal one not." Which one of the following statements best explains this quote, in the context of the passage?

 The stock exchange and the black market are both organised to function by rules.

 Market instruments can be formally traded in the stock exchange and informally traded in the black market.

 The stock exchange and the black market are both dependent on the market to survive.

 The stock exchange and the black market are examples of how, even within the same domain, different kinds of institutions can co-exist.

**ANSWER:** Choice D

### Q6

The stock exchange and the black market are examples of how, even within the same domain, different kinds of institutions can co-exist.

 CAT 2022 Slot 2 - VA RC

 All of the following inferences from the passage are false, EXCEPT:

 "natural language" refers to that stage of language development where no conscious human intent is evident in the formation of language.

 the institution of friendship cannot be found in the institution of joint-stock companies because the first is an informal institution, while the second is a formal one.

 as concepts, "culture" and "tradition" have no analytical, explanatory or expository power, especially when they are treated in isolation.

 institutions like the family, rituals, governance, economy, and the military are natural and cannot be consciously modified.

**ANSWER:** Choice A

### Q7

"natural language" refers to that stage of language development where no conscious human intent is evident in the formation of language.

 CAT 2022 Slot 2 - VA RC

 Which of the following statements best represents the essence of the passage?

 Institutions are structures that serve to coordinate the actions of individuals.

 It is usual in social thought to treat culture and tradition as different from institutions.

 Language is the fundamental formal institution for social life and for science.

 The stock exchange and the black market are both market institutions.

**ANSWER:** Choice A

### Q8

Institutions are structures that serve to coordinate the actions of individuals.

 CAT 2022 Slot 2 - VA RC

 In the first paragraph of the passage, what are the two "characterisations" that are seen as overlapping but not congruent?

 "the philosophy of the social sciences" and "a set of social institutions".

 "academic disciplines" and "institutions".

 "an arena of thought" and "academic disciplines".

 "individuals" and "social structures".

**ANSWER:** Choice B

### Q9

"academic disciplines" and "institutions".

 The passage below is accompanied by a set of questions. Choose the best answer to each question.

When we teach engineering problems now, we ask students to come to a single "best" solution defined by technical ideals like low cost, speed to build, and ability to scale. This way of teaching primes students to believe that their decision-making is purely objective, as it is grounded in math and science. This is known as technical-social dualism, the idea that the technical and social dimensions of engineering problems are readily separable and remain distinct throughout the problem-definition and solution process.

Nontechnical parameters such as access to a technology, cultural relevancy or potential harms are deemed political and invalid in this way of learning. But those technical ideals are at their core social and political choices determined by a dominant culture focused on economic growth for the most privileged segments of society. By choosing to downplay public welfare as a critical parameter for engineering design, we risk creating a culture of disengagement from societal concerns amongst engineers that is antithetical to the ethical code of engineering.

In my field of medical devices, ignoring social dimensions has real consequences. . . . Most FDA-approved drugs are incorrectly dosed for people assigned female at birth, leading to unexpected adverse reactions. This is because they have been inadequately represented in clinical trials.

Beyond physical failings, subjective beliefs treated as facts by those in decision-making roles can encode social inequities. For example, spirometers, routinely used devices that measure lung capacity, still have correction factors that automatically assume smaller lung capacity in Black and Asian individuals. These racially based adjustments are derived from research done by eugenicists who thought these racial differences were biologically determined and who considered nonwhite people as inferior. These machines ignore the influence of social and environmental factors on lung capacity.

Many technologies for systemically marginalized people have not been built because they were not deemed important such as better early diagnostics and treatment for diseases like endometriosis, a disease that afflicts 10 percent of people with uteruses. And we hardly question whether devices are built sustainably, which has led to a crisis of medical waste and health care accounting for 10 percent of U.S. greenhouse gas emissions.

Social justice must be made core to the way engineers are trained. Some universities are working on this. . . . Engineers taught this way will be prepared to think critically about what problems we choose to solve, how we do so responsibly and how we build teams that challenge our ways of thinking.

Individual engineering professors are also working to embed societal needs in their pedagogy. Darshan Karwat at the University of Arizona developed activist engineering to challenge engineers to acknowledge their full moral and social responsibility through practical self-reflection. Khalid Kadir at the University of California, Berkeley, created the popular course Engineering, Environment, and Society that teaches engineers how to engage in place-based knowledge, an understanding of the people, context and history, to design better technical approaches in collaboration with communities. When we design and build with equity and justice in mind, we craft better solutions that respond to the complexities of entrenched systemic problems.

 CAT 2022 Slot 2 - VA RC

 In this passage, the author is making the claim that:

 technical-social dualism has emerged as a technique for engineering students to incorporate social considerations into their technical problem-solving processes.

 the objective of best solutions in engineering has shifted the focus of pedagogy from humanism and social obligations to technological perfection.

 engineering students today are trained to be non-subjective in their reasoning as this best enables them to develop much-needed universal solutions.

 engineering students today are taught to focus on objective technical outcomes, independent of the social dimensions of their work.

**ANSWER:** Choice D

### Q10

engineering students today are taught to focus on objective technical outcomes, independent of the social dimensions of their work.

 CAT 2022 Slot 2 - VA RC

 The author gives all of the following reasons for why marginalised people are systematically discriminated against in technology-related interventions EXCEPT:

 "And we hardly question whether devices are built sustainably, which has led to a crisis of medical waste and health care accounting for 10 percent of U.S. greenhouse gas emissions."

 "These racially based adjustments are derived from research done by eugenicists who thought these racial differences were biologically determined and who considered nonwhite people as inferior."

 "Beyond physical failings, subjective beliefs treated as facts by those in decision-making roles can encode social inequities."

 "But those technical ideals are at their core social and political choices determined by a dominant culture focused on economic growth for the most privileged segments of society."

**ANSWER:** Choice A

### Q11

"And we hardly question whether devices are built sustainably, which has led to a crisis of medical waste and health care accounting for 10 percent of U.S. greenhouse gas emissions."

 CAT 2022 Slot 2 - VA RC

 All of the following are examples of the negative outcomes of focusing on technical ideals in the medical sphere EXCEPT the:

 incorrect assignment of people as female at birth which has resulted in faulty drug interventions.

 exclusion of non-privileged groups in clinical trials which leads to incorrect drug dosages.

 neglect of research and development of medical technologies for the diagnosis and treatment of diseases that typically afflict marginalised communities.

 continuing calibration of medical devices based on past racial biases that have remained unadjusted for changes.

**ANSWER:** Choice A

### Q12

incorrect assignment of people as female at birth which has resulted in faulty drug interventions.

 CAT 2022 Slot 2 - VA RC

 We can infer that the author would approve of a more evolved engineering pedagogy that includes all of the following EXCEPT:

 moving towards technical-social dualism where social community needs are incorporated in problem-definition and solutions.

 making considerations of environmental sustainability intrinsic to the development of technological solutions.

 design that is based on the needs of communities using local knowledge and responding to local priorities.

 a more responsible approach to technical design and problem-solving than a focus on speed in developing and bringing to scale.

**ANSWER:** Choice A

### Q13

moving towards technical-social dualism where social community needs are incorporated in problem-definition and solutions.

 The passage below is accompanied by a set of questions. Choose the best answer to each question.

Humans today make music. Think beyond all the qualifications that might trail after this bald statement: that only certain humans make music, that extensive training is involved, that many societies distinguish musical specialists from nonmusicians, that in today's societies most listen to music rather than making it, and so forth. These qualifications, whatever their local merit, are moot in the face of the overarching truth that making music, considered from a cognitive and psychological vantage, is the province of all those who perceive and experience what is made. We are, almost all of us, musicians - everyone who can entrain (not necessarily dance) to a beat, who can recognize a repeated tune (not necessarily sing it), who can distinguish one instrument or one singing voice from another. I will often use an antique word, recently revived, to name this broader musical experience. Humans are musicking creatures. . . .

The set of capacities that enables musicking is a principal marker of modern humanity. There is nothing polemical in this assertion except a certain insistence, which will figure often in what follows, that musicking be included in our thinking about fundamental human commonalities. Capacities involved in musicking are many and take shape in complicated ways, arising from innate dispositions . . . Most of these capacities overlap with nonmusical ones, though a few may be distinct and dedicated to musical perception and production. In the area of overlap, linguistic capacities seem to be particularly important, and humans are (in principle) language-makers in addition to music-makers - speaking creatures as well as musicking ones.

Humans are symbol-makers too, a feature tightly bound up with language, not so tightly with music. The species Cassirer dubbed Homo symbolicus cannot help but tangle musicking in webs of symbolic thought and expression, habitually making it a component of behavioral complexes that form such expression. But in fundamental features musicking is neither language-like nor symbol-like, and from these differences come many clues to its ancient emergence.

If musicking is a primary, shared trait of modern humans, then to describe its emergence must be to detail the coalescing of that modernity. This took place, archaeologists are clear, over a very long durée: at least 50,000 years or so, more likely something closer to 200,000, depending in part on what that coalescence is taken to comprise. If we look back 20,000 years, a small portion of this long period, we reach the lives of humans whose musical capacities were probably little different from our own. As we look farther back we reach horizons where this similarity can no longer hold - perhaps 40,000 years ago, perhaps 70,000, perhaps 100,000. But we never cross a line before which all the cognitive capacities recruited in modern musicking abruptly disappear. Unless we embrace the incredible notion that music sprang forth in full-blown glory, its emergence will have to be tracked in gradualist terms across a long period.

This is one general feature of a history of music's emergence . . . The history was at once sociocultural and biological . . . The capacities recruited in musicking are many, so describing its emergence involves following several or many separate strands.

 CAT 2022 Slot 2 - VA RC

 Which one of the following sets of terms best serves as keywords to the passage?

 Musicking; Cognitive psychology; Antique; Symbol-makers; Modernity.

 Humans; Psychological vantage; Musicking; Cassirer; Emergence of music.

 Humans; Capacities; Language; Symbols; Modernity.

 Humans; Musicking; Linguistic capacities; Symbol-making; Modern humanity.

**ANSWER:** Choice D

### Q14

Humans; Musicking; Linguistic capacities; Symbol-making; Modern humanity.

 CAT 2022 Slot 2 - VA RC

 Based on the passage, which one of the following statements is a valid argument about the emergence of music/musicking?

 Anyone who can perceive and experience music must be considered capable of musicking.

 Although musicking is not language-like, it shares the quality of being a form of expression.

 20,000 years ago, human musical capacities were not very different from what they are today.

 All musical work is located in the overlap between linguistic capacity and music production.

**ANSWER:** Choice C

### Q15

20,000 years ago, human musical capacities were not very different from what they are today.

 CAT 2022 Slot 2 - VA RC

 "Think beyond all the qualifications that might trail after this bald statement . . ." In the context of the passage, what is the author trying to communicate in this quoted extract?

 A bald statement is one that is trailed by a series of qualifying clarifications and caveats.

 Although there may be many caveats and other considerations, the statement is essentially true.

 Thinking beyond qualifications allows us to give free reign to musical expressions.

 A bald statement is one that requires no qualifications to infer its meaning.

**ANSWER:** Choice B

### Q16

Although there may be many caveats and other considerations, the statement is essentially true.

 CAT 2022 Slot 2 - VA RC

 Which one of the following statements, if true, would weaken the author's claim that humans are musicking creatures?

 Musical capacities are primarily socio-cultural, which explains the wide diversity of musical forms.

 Nonmusical capacities are of far greater consequence to human survival than the capacity for music.

 As musicking is neither language-like nor symbol-like, it is a much older form of expression.

 From a cognitive and psychological vantage, musicking arises from unconscious dispositions, not conscious ones.

**ANSWER:** Choice A

### Q17

Musical capacities are primarily socio-cultural, which explains the wide diversity of musical forms.

 CAT 2022 Slot 2 - VA RC

 The four sentences (labelled 1, 2, 3 and 4) below, when properly sequenced, would yield a coherent paragraph. Decide on the proper sequencing of the order of the sentences and key in the sequence of the four numbers as your answer:

1. The trajectory of cheerfulness through the self is linked to the history of the word 'cheer' which comes from an Old French meaning 'face'.
2. Translations of the Bible into vernacular languages, expanded the noun 'cheer' into the more abstract 'cheerful-ness', something that circulates as an emotional and social quality defining the self and a moral community.
3. When you take on a cheerful expression, no matter what the state of your soul, your cheerfulness moves into the self: the interior of the self is changed by the power of cheer.
4. People in the medieval 'Canterbury Tales' have a 'piteous' or a 'sober' cheer; 'cheer' is an expression and a body part, lying at the intersection of emotions and physiognomy.

**ANSWER:** 3142

### Q18

CAT 2022 Slot 2 - VA RC

 The passage given below is followed by four alternate summaries. Choose the option that best captures the essence of the passage.

Several of the world's earliest cities were organised along egalitarian lines. In some regions, urban populations governed themselves for centuries without any indication of the temples and palaces that would later emerge; in others, temples and palaces never emerged at all, and there is simply no evidence of a class of administrators or any other sort of ruling stratum. It would seem that the mere fact of urban life does not, necessarily, imply any particular form of political organization, and never did. Far from resigning us to inequality, the picture that is now emerging of humanity's past may open our eyes to egalitarian possibilities we otherwise would have never considered.

 We now have the evidence in support of the existence of an egalitarian urban life in some ancient cities, where political and civic organisation was far less hierarchical.

 The emergence of a class of administrators and ruling stratum transformed the egalitarian urban life of ancient cities to the hierarchical civic organisations of today.

 Contrary to our assumption that urban settlements have always involved hierarchical political and administrative structures, ancient cities were not organised in this way.

 The lack of hierarchical administration in ancient cities can be deduced by the absence of religious and regal structures such as temples and palaces.

**ANSWER:** Choice A

### Q19

We now have the evidence in support of the existence of an egalitarian urban life in some ancient cities, where political and civic organisation was far less hierarchical.

 CAT 2022 Slot 2 - VA RC

 There is a sentence that is missing in the paragraph below. Look at the paragraph and decide in which blank (option 1, 2, 3, or 4) the following sentence would best fit.

Sentence: Most were first-time users of a tablet and a digital app.

Paragraph: Aage Badhein's USP lies in the ethnographic research that constituted the foundation of its development process. Customizations based on learning directly from potential users were critical to making this self-paced app suitable for both a literate and non-literate audience. ___(1)___ The user interface caters to a Hindi-speaking audience who have minimal to no experience with digital services and devices. ___(2)___ The content and functionality of the app are suitable for a wide audience. This includes youth preparing for an independent role in life or a student ready to create a strong foundation of financial management early in her life. ___(3)___ Household members desirous of improving their family's financial strength to reach their aspirations can also benefit. We piloted Aage Badhein in early 2021 with over 400 women from rural areas. ___(4)___ The digital solution generated a large amount of interest in the communities.

 Option 1

 Option 2

 Option 3

 Option 4

**ANSWER:** Choice D

### Q20

Option 4

 CAT 2022 Slot 2 - VA RC

 The four sentences (labelled 1, 2, 3 and 4) below, when properly sequenced, would yield a coherent paragraph. Decide on the proper sequencing of the order of the sentences and key in the sequence of the four numbers as your answer:

1. From chemical pollutants in the environment to the damming of rivers to invasive species transported through global trade and travel, every environmental issue is different and there is no single tech solution that can solve this crisis.
2. Discourse on the threat of environmental collapse revolves around cutting down emissions, but biodiversity loss and ecosystem collapse are caused by myriad and diverse reasons.
3. This would require legislation that recognises the rights of future generations and other species that allows the judiciary to uphold a much higher standard of environmental protection than currently possible.
4. Clearly, our environmental crisis requires large political solutions, not minor technological ones, so, instead of focusing on infinite growth, we could consider a path of stable-state economies, while preserving markets and healthy competition.

**ANSWER:** 2143

### Q21

CAT 2022 Slot 2 - VA RC

 The passage given below is followed by four alternate summaries. Choose the option that best captures the essence of the passage.

Today, many of the debates about behavioural control in the age of big data echo Cold War-era anxieties about brainwashing, insidious manipulation and repression in the 'technological society'. In his book Psychopolitics, Han warns of the sophisticated use of targeted online content, enabling 'influence to take place on a pre-reflexive level'. On our current trajectory, "freedom will prove to have been merely an interlude." The fear is that the digital age has not liberated us but exposed us, by offering up our private lives to machine-learning algorithms that can process masses of personal and behavioural data. In a world of influencers and digital entrepreneurs, it's not easy to imagine the resurgence of a culture engendered through disconnect and disaffiliation, but concerns over the threat of online targeting, polarisation and big data have inspired recent polemics about the need to rediscover solitude and disconnect.

 Rather than freeing us, digital technology is enslaving us by collecting personal information and influencing our online behaviour.

 With big data making personal information freely available, the debate on the nature of freedom and the need for privacy has resurfaced.

 The notion of freedom and privacy is at stake in a world where artificial intelligence is capable of influencing behaviour through data gathered online.

 The role of technology in influencing public behaviour is reminiscent of the manner in which behaviour was manipulated during the Cold War.

**ANSWER:** Choice B

### Q22

With big data making personal information freely available, the debate on the nature of freedom and the need for privacy has resurfaced.

 CAT 2022 Slot 2 - VA RC

 There is a sentence that is missing in the paragraph below. Look at the paragraph and decide in which blank (option 1, 2, 3, or 4) the following sentence would best fit.

Sentence: This was years in the making but fast-tracked during the pandemic, when "people started being more mindful about their food", he explained.

Paragraph: For millennia, ghee has been a venerated staple of the subcontinental diet, but it fell out of favour a few decades ago when saturated fats were largely considered to be unhealthy. ___(1)___ But more recently, as the thinking around saturated fats is shifting globally, Indians are finding their own way back to this ingredient that is so integral to their cuisine. ___(2)___ For Karmakar, a renewed interest in ghee is emblematic of a return-to-basics movement in India. ___(3)___ This movement is also part of an overall trend towards "slow food". In keeping with the movement's philosophy, ghee can be produced locally (even at home) and has inextricable cultural ties. ___(4)___ At a basic level, ghee is a type of clarified butter believed to have originated in India as a way to preserve butter from going rancid in the hot climate.

 Option 1

 Option 2

 Option 3

 Option 4

**ANSWER:** Choice C

### Q23

Option 3

 CAT 2022 Slot 2 - VA RC

 The passage given below is followed by four alternate summaries. Choose the option that best captures the essence of the passage.

There's a common idea that museum artworks are somehow timeless objects available to admire for generations to come. But many are objects of decay. Even the most venerable Old Master paintings don't escape: pigments discolour, varnishes crack, canvases warp. This challenging fact of art-world life is down to something that sounds more like a thread from a morality tale: inherent vice. Damien Hirst's iconic shark floating in a tank - entitled The Physical Impossibility of Death in the Mind of Someone Living - is a work that put a spotlight on inherent vice. When he made it in 1991, Hirst got himself in a pickle by not using the right kind of pickle to preserve the giant fish. The result was that the shark began to decompose quite quickly - its preserving liquid clouding, the skin wrinkling, and an unpleasant smell wafting from the tank.

 Museums are left with the moral responsibility of restoring and preserving the artworks since artists cannot preserve their works beyond their life.

 Artworks may not last forever; they may deteriorate with time, and the challenge is to slow down their degeneration.

 The role of museums has evolved to ensure that the artworks are preserved forever in addition to guarding and displaying them.

 Museums have to guard timeless art treasures from intrinsic defects such as the deterioration of paint, polish and canvas.

**ANSWER:** Choice B

### Q24

Artworks may not last forever; they may deteriorate with time, and the challenge is to slow down their degeneration.

 CAT 2022 Slot 2 - VA RC

 The four sentences (labelled 1, 2, 3 and 4) below, when properly sequenced, would yield a coherent paragraph. Decide on the proper sequencing of the order of the sentences and key in the sequence of the four numbers as your answer:

1. Women may prioritize cooking because they feel they alone are responsible for mediating a toxic and unhealthy food system.
2. Food is commonly framed through the lens of individual choice: you can choose to eat healthily.
3. This is particularly so in a neoliberal context where the state has transferred the responsibility for food onto individual consumers.
4. The individualized framing of choice appeals to a popular desire to experience agency, but draws away from the structural obstacles that stratify individual food choices.

**ANSWER:** 2431
