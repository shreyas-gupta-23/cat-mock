# CAT 2022 — Slot 3 — DILR (Questions + On-page Answer Key)

Answers are on-page 2IIM **Correct Answer** labels. Not invented.

## DILR

- Source file: `2iim-html/CAT-2022-Question-Paper-Slot-3-DILR.txt`
- Page: https://online.2iim.com/CAT-question-paper/CAT-2022-Question-Paper-Slot-3-DILR/
- On-page answers found: 20
- Answer source: 2IIM on-page **Correct Answer** / **Correct Answer Choice** (not invented)

### Q1

C AT DI LR section has become increasingly tough beginning from 2015. DILR used to have distinct Data Interpretation sets and Logical reasoning puzzles. It used to be about computation and ability to read charts, graphs and tables for the Data Interpretation and Logical reasoning used to have Family tree, grid puzzles, arrangement, tournaments, cubes as some standard forms of puzzles.Since 2015 this pattern has been broken. With passing years, even the distinction between DI and LR has come down significantly. All you get in that one hour, are 8 high quality puzzles, with more than a few of them being significantly tough. Between CAT 2017 Question paper to CAT 2022 Question paper, you get to solve 90 actual CAT puzzles. This page intends to provide you just that. So, head on and crack those puzzles!

 All the first-year students in the computer science (CS) department in a university take both the courses (i) AI and (ii) ML. Students from other departments (non-CS students) can also take one of these two courses, but not both. Students who fail in a course get an F grade; others pass and are awarded A or B or C grades depending on their performance. The following are some additional facts about the number of students who took these two courses this year and the grades they obtained.

1. The numbers of non-CS students who took AI and ML were in the ratio 2 : 5.
2. The number of non-CS students who took either AI or ML was equal to the number of CS students.
3. The numbers of non-CS students who failed in the two courses were the same and their total is equal to the number of CS students who got a C grade in ML.
4. In both the courses, 50% of the students who passed got a B grade. But, while the numbers of students who got A and C grades were the same for AI, they were in the ratio 3 : 2 for ML.
5. No CS student failed in AI, while no non-CS student got an A grade in AI.
6. The numbers of CS students who got A, B and C grades respectively in AI were in the ratio 3 : 5 : 2, while in ML the ratio was 4 : 5 : 2.
7. The ratio of the total number of non-CS students failing in one of the two courses to the number of CS students failing in one of the two courses was 3 : 1.
8. 30 students failed in ML.

 CAT 2022 Slot 3 - DI LR

 How many students took AI?

 60

 270

 90

 210

**ANSWER:** Choice B

### Q2

270

 CAT 2022 Slot 3 - DI LR

 How many CS students failed in ML?

**ANSWER:** 12

### Q3

CAT 2022 Slot 3 - DI LR

 How many non-CS students got A grade in ML?

**ANSWER:** 27

### Q4

CAT 2022 Slot 3 - DI LR

 How many students got A grade in AI?

 42

 99

 84

 63

**ANSWER:** Choice D

### Q5

63

 CAT 2022 Slot 3 - DI LR

 How many non-CS students got B grade in ML?

 165

 90

 25

 75

**ANSWER:** Choice D

### Q6

75

It was also known that Pulak and Qasim had the same amount of money with them at the end of Round 4.

 Pulak
 Qasim
 Ritesh
 Suresh

 Round 1

 Round 2

 Round 3

 Round 4

 Round 5

 Round 6

 Round 7

 Round 8

 CAT 2022 Slot 3 - DI LR

 What BEST can be said about the amount of money that Ritesh had with him at the end of Round 8?

**ANSWER:** Choice A

### Q7

CAT 2022 Slot 3 - DI LR

 What BEST can be said about the amount of money that Pulak had with him at the end of Round 6?

**ANSWER:** Choice A

### Q8

CAT 2022 Slot 3 - DI LR

 How much money (in ₹) did Ritesh have at the end of Round 4?

**ANSWER:** 6

### Q9

CAT 2022 Slot 3 - DI LR

**ANSWER:** 6

### Q10

CAT 2022 Slot 3 - DI LR

 Which of the following pairings was made in Round 5?

 Pulak and Ritesh

 Pulak and Qasim

 Pulak and Suresh

 Qasim and Suresh

**ANSWER:** Choice C

### Q11

Pulak and Suresh

 CAT 2022 Slot 3 - DI LR

 In 2000, what was the ratio of the number of dead males to dead females among those being tracked?

 109 : 107

 129 : 131

 71 : 69

 41 : 43

**ANSWER:** Choice C

### Q12

71 : 69

 CAT 2022 Slot 3 - DI LR

 How many people who were being tracked and who were between 30 and 40 years of age in 1980 survived until 2010?

 90

 190

 110

 310

**ANSWER:** Choice B

### Q13

190

 In the following, a year corresponds to 1 st of January of that year.

A study to determine the mortality rate for a disease began in 1980. The study chose 1000 males and 1000 females and followed them for forty years or until they died, whichever came first. The 1000 males chosen in 1980 consisted of 250 each of ages 10 to less than 20, 20 to less than 30, 30 to less than 40, and 40 to less than 50. The 1000 females chosen in 1980 also consisted of 250 each of ages 10 to less than 20, 20 to less than 30, 30 to less than 40, and 40 to less than 50.

The four figures below depict the age profile of those among the 2000 individuals who were still alive in 1990, 2000, 2010, and 2020. The blue bars in each figure represent the number of males in each age group at that point in time, while the pink bars represent the number of females in each age group at that point in time. The numbers next to the bars give the exact numbers being represented by the bars. For example, we know that 230 males among those tracked and who were alive in 1990 were aged between 20 and 30.

 CAT 2022 Slot 3 - DI LR

 How many individuals who were being tracked and who were less than 30 years of age in 1980 survived until 2020?

 470

 580

 240

 230

**ANSWER:** Choice A

### Q14

470

 CAT 2022 Slot 3 - DI LR

 How many of the males who were being tracked and who were between 20 and 30 years of age in 1980 died in the period 2000 to 2010?

**ANSWER:** 40

### Q15

CAT 2022 Slot 3 - DI LR

 How many of the females who were being tracked and who were between 20 and 30 years of age in 1980 died between the ages of 50 and 60?

**ANSWER:** 30

### Q16

CAT 2022 Slot 3 - DI LR

 What BEST can be concluded about the total number of new cases in the city on Day 2?

 Either 6 or 7

 Exactly 8

 Exactly 7

 Either 7 or 8

**ANSWER:** Choice B

### Q17

Exactly 8

 There are only four neighbourhoods in a city - Levmisto, Tyhrmisto, Pesmisto and Kitmisto. During the onset of a pandemic, the number of new cases of a disease in each of these neighbourhoods was recorded over a period of five days. On each day, the number of new cases recorded in any of the neighbourhoods was either 0, 1, 2 or 3.

The following facts are also known:

1. There was at least one new case in every neighbourhood on Day 1.
2. On each of the five days, there were more new cases in Kitmisto than in Pesmisto.
3. The number of new cases in the city in a day kept increasing during the five-day period. The number of new cases on Day 3 was exactly one more than that on Day 2.
4. The maximum number of new cases in a day in Pesmisto was 2, and this happened only once during the five-day period.
5. Kitmisto is the only place to have 3 new cases on Day 2.
6. The total numbers of new cases in Levmisto, Tyhrmisto, Pesmisto and Kitmisto over the five-day period were 12, 12, 5 and 14 respectively.

 CAT 2022 Slot 3 - DI LR

 What BEST can be concluded about the number of new cases in Levmisto on Day 3?

 Exactly 3

 Either 2 or 3

 Exactly 2

 Either 0 or 1

**ANSWER:** Choice A

### Q18

Exactly 3

 CAT 2022 Slot 3 - DI LR

 On which day(s) did Pesmisto not have any new case?

 Only Day 3

 Only Day 2

 Both Day 2 and Day 4

 Both Day 2 and Day 3

**ANSWER:** Choice A

### Q19

Only Day 3

 CAT 2022 Slot 3 - DI LR

 Which of the two statements below is/are necessarily false?
Statement A: There were 2 new cases in Tyhrmisto on Day 3.
Statement B: There were no new cases in Pesmisto on Day 2.

 Statement B only

 Both Statement A and Statement B

 Statement A only

 Neither Statement A nor Statement B

**ANSWER:** Choice B

### Q20

Both Statement A and Statement B

 CAT 2022 Slot 3 - DI LR

 On how many days did Levmisto and Tyhrmisto have the same number of new cases?

 4

 5

 3

 2

**ANSWER:** Choice B
