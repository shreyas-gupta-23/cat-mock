# CAT 2025 — Slot 3 — DILR (Questions + On-page Answer Key)

Answers are on-page 2IIM **Correct Answer** labels. Not invented.

## DILR

- Source file: `2iim-html/CAT-2025-Question-Paper-Slot-3-DILR.txt`
- Page: https://online.2iim.com/CAT-question-paper/CAT-2025-Question-Paper-Slot-3-DILR/
- On-page answers found: 22
- Answer source: 2IIM on-page **Correct Answer** / **Correct Answer Choice** (not invented)

### Q1

Anu, Bijay, Chetan, Deepak, Eshan, and Faruq are six friends. Each of them uses
 a mobile number from exactly one of the two mobile operators - Xitel and Yocel. During the
 last month, the six friends made several calls to each other. Each call was made by one of
 these six friends to another. The table below summarizes the number of minutes of calls that
 each of the six made to (outgoing minutes) and received from (incoming minutes) these
 friends, grouped by the operators. Some of the entries are missing.

It is known that the duration of calls from Faruq to Eshan was 200
 minutes.
Also, there were no calls from:
i. Bijay to Eshan,
ii. Chetan to Anu
 and Chetan to Deepak,
iii. Deepak to Bijay and Deepak to Faruq,
iv. Eshan to
 Chetan and Eshan to Deepak.

 CAT 2025 Slot 3 - DI LR

 What was the duration of calls (in minutes) from Bijay to Anu?

**ANSWER:** 50

### Q2

CAT 2025 Slot 3 - DI LR

 What was the total duration of calls (in minutes) made by Anu to friends having mobile
 numbers from Operator Yocel?

**ANSWER:** 525

### Q3

CAT 2025 Slot 3 - DI LR

 What was the total duration of calls (in minutes) made by Faruq to friends having mobile
 numbers from Operator Yocel?

**ANSWER:** 350

### Q4

CAT 2025 Slot 3 - DI LR

 What was the duration of calls (in minutes) from Deepak to Chetan?

 0

 125

 100

 50

**ANSWER:** Choice C

### Q5

100

 Aurevia, Brelosia, Cyrenia and Zerathania are four countries with their
 currencies being Aurels, Brins, Crowns, and Zentars, respectively. The currencies have
 different exchange values. Crown's currency exchange rate with Zentars = 0.5, i.e., 1 Crown
 is worth 0.5 Zentars.

Three travelers, Jano, Kira, and Lian set out from
 Zerathania visiting exactly two of the countries. Each country is visited by exactly two
 travelers. Each traveler has a unique Flight Cost, which represents the total cost of
 airfare in traveling to both the countries and back to Zerathania. The Flight Cost of Jano
 was 4000 Zentars, while that of the other two travelers were 5000 and 6000 Zentars, not
 necessarily in that order.
When visiting a country, a traveler spent either 1000, 2000
 or 3000 in the country's local currency. Each traveler had different spends (in the
 country's local currency) in the two countries he/she visited. Across all the visits, there
 were exactly two spends of 1000 and exactly one spend of 3000 (in the country's local
 currency).
The
 total "Travel Cost" for a traveler is the sum of his/her Flight Cost and the money spent in
 the countries visited.

The citizens of the four countries with knowledge of these
 travels made a few observations, with spends measured in their respective local
 currencies: i.
 Aurevia citizen: Jano and Kira visited our country, and their Travel Costs were 3500 and
 8000, respectively. ii.
 Brelosia citizen: Kira and Lian visited our country, spending 2000 and 3000, respectively.
 Kira's Travel Cost was 4000. iii.
 Cyrenia citizen: Lian visited our country and her Travel Cost was 36000.

 CAT 2025 Slot 3 - DI LR

 What is the sum of Travel Costs for all travelers in Zentars?

**ANSWER:** 41000

### Q6

CAT 2025 Slot 3 - DI LR

 How many Zentars did Lian spend in the two countries he visited?

**ANSWER:** 13000

### Q7

CAT 2025 Slot 3 - DI LR

 What was Jano's total spend in the two countries he visited, in Aurels?

**ANSWER:** 1500

### Q8

CAT 2025 Slot 3 - DI LR

 One Brin is equivalent to how many Crowns?

 4

 0.5

 8

 0.125

**ANSWER:** Choice C

### Q9

8

 CAT 2025 Slot 3 - DI LR

 Which of the following statements is NOT true about money spent in the local currency?

 Kira spent 1000 in Aurevia

 Jano spent 2000 in Aurevia

 Jano spent 2000 in Cyrenia

 Lian spent 2000 in Cyrenia

**ANSWER:** Choice B

### Q10

Jano spent 2000 in Aurevia

 Anirbid, Chandranath, Koushik, and Suranjan participated in a puzzle solving
 competition. The competition comprised 10 puzzles that had to be solved in the same
 sequence, i.e., a competitor got access to a puzzle as soon as they solved the previous
 puzzle. Some of the puzzles were visual puzzles and the others were number-based puzzles.
 The winner of the competition was the one who solved all puzzles in the least time.

The following charts describe their progress in the competition. The chart on the left
 shows the number of puzzles solved by each competitor at a given time (in minutes) after the
 start of the competition. The chart on the right shows the number of visual puzzles solved
 by each competitor at a given time (in minutes) after the start of the
 competition.

 CAT 2025 Slot 3 - DI LR

 Who had solved the largest number of puzzles by the 20-th minute from the start of the
 competition?

 Chandranath

 Koushik

 Anirbid

 Suranjan

**ANSWER:** Choice B

### Q11

Koushik

 CAT 2025 Slot 3 - DI LR

 How many minutes did Suranjan take to solve the third visual puzzle in the competition?

**ANSWER:** 2

### Q12

CAT 2025 Slot 3 - DI LR

 At what number in the sequence was the fourth number-based puzzle?

**ANSWER:** 6

### Q13

CAT 2025 Slot 3 - DI LR

 Which of the following is the closest to the average time taken by Anirbid to solve the
 number-based puzzles in the competition?

 3.3 minutes

 2.5 minutes

 4.0 minutes

 3.8 minutes

**ANSWER:** Choice C

### Q14

4.0 minutes

 Seven children, Aarav, Bina, Chirag, Diya, Eshan, Farhan, and Gaurav, are
 sitting in a circle facing inside (not necessarily in the same order) and playing a game of
 'Passing the Buck'.

The game is played over 10 rounds. In each round, the child
 holding the Buck must pass it directly to a child sitting in one of the following
 positions:

• Immediately to the left;
• Immediate to the right;
•
 Second to the left; or
• Second to the right.

The game starts with Bina
 passing the Buck and ends with Chirag receiving the Buck. The table below provides some
 information about the pass types and the child receiving the Buck. Some information is
 missing and labelled as '?'.

 Round
 Position
 Name

 1
 Immediately to the left
 Aarav

 2
 Second to the right
 ?

 3
 Immediately to the right
 Diya

 4
 ?
 ?

 5
 ?
 Aarav

 6
 Second to the left
 ?

 7
 Immediately to the left
 Gaurav

 8
 Immediately to the left
 ?

 9
 ?
 Farhan

 10
 ?
 Chirag

 CAT 2025 Slot 3 - DI LR

 Who is sitting immediately to the right of Bina?

 Chirag

 Aarav

 Farhan

 Eshan

**ANSWER:** Choice D

### Q15

Eshan

 CAT 2025 Slot 3 - DI LR

 Who is sitting third to the left of Eshan?

 Aarav

 Chirag

 Gaurav

 Divya

**ANSWER:** Choice B

### Q16

Chirag

 CAT 2025 Slot 3 - DI LR

 For which of the following pass types can the total number of occurrences be uniquely
 determined?

 Second to the right

 Second to the left

 Immediately to the left

 Immediately to the right

**ANSWER:** Choice D

### Q17

Immediately to the right

 CAT 2025 Slot 3 - DI LR

 For which of the following children is it possible to determine how many times they
 received the Buck?

 Bina

 Gaurav

 Farhan

 Eshan

**ANSWER:** Choice B

### Q18

Gaurav

 Three countries — Pumpland (P), Xiland (X) and Cheeseland (C) — trade among
 themselves and with the (other countries in) Rest of World (ROW). All trade volumes are
 given in IC (international currency). The following terminology is used:
• Trade
 balance = Exports – Imports
• Total trade = Exports + Imports
• Normalized trade
 balance = Trade balance / Total trade, expressed in percentage terms

The
 following information is known.
1. The normalized trade balances of P, X and C are 0%,
 10%, and –20%, respectively.
2. 40% of exports of X are to P. 22% of imports of P are
 from X.
3. 90% of exports of C are to P; 4% are to ROW.
4. 12% of exports of ROW
 are to X, 40% are to P.
5. The export volumes of P, in IC, to X and C are 600 and 1200,
 respectively. P is the only country that exports to C.

 CAT 2025 Slot 3 - DI LR

 How much is exported from C to X, in IC?

**ANSWER:** 48

### Q19

CAT 2025 Slot 3 - DI LR

 How much is exported from P to ROW, in IC?

**ANSWER:** 200

### Q20

CAT 2025 Slot 3 - DI LR

 How much is exported from ROW to ROW, in IC?

**ANSWER:** 1008

### Q21

CAT 2025 Slot 3 - DI LR

 What is the trade balance of ROW?

 200

 100

 0

 -200

**ANSWER:** Choice A

### Q22

200

 CAT 2025 Slot 3 - DI LR

 Which among the countries P, X, and C has/have the least total trade?

 Both X and C

 Only X

 Only C

 Only P

**ANSWER:** Choice A
