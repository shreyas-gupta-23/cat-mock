#!/usr/bin/env python3
"""Build clean combined CAT papers with on-page answer keys from 2iim-html."""
from pathlib import Path
import re
from collections import defaultdict

SRC = Path('/workspace/cat-mocks/2iim-html')
OUT = Path('/workspace/cat-mocks/with-keys')

ANSWER_INLINE = re.compile(r'(?m)^[ \t]*Correct[ \t]+Answer(?:[ \t]+Choice)?[ \t]+(.+?)[ \t]*$')
ANSWER_SPLIT = re.compile(r'(?m)^[ \t]*Correct[ \t]*\n[ \t]*Answer(?:[ \t]+Choice)?[ \t]+(.+?)[ \t]*$')

SECTION_TITLE = {'VARC': 'VARC', 'DILR': 'DILR', 'Quant': 'Quantitative Ability'}

NOISE_SUBSTR = [
    '2IIM', 'Scholarship', 'Visit our Website', 'Quora Answers', 'Score Calculator',
    'Month-End Sale', 'Effortlessly calculate', 'PDFs of past years', 'Video Explanation',
    'Stats Correct', 'Incorrect:', 'Unattempted:', 'Question Bank', 'Workshop',
    'Previous Year Papers', 'Preparation Books', 'Quantitative Aptitude Blog',
    'Timed Quiz', 'trial user', 'CAT Coaching', 'Online CAT', 'CAT Online Coaching',
    'CAT Preparation', 'Take Test', 'Signup', 'May Month',
]

def is_noise_line(line: str) -> bool:
    s = line.strip()
    if not s:
        return False
    if s in {'|', '-->', 'Correct', 'Answer', 'Video', 'Explanation', 'Check'}:
        return True
    if s.endswith('%') and re.match(r'^[\d.%\s]+$', s):
        return True
    low = s.lower()
    if low.startswith('explanation') and len(s) < 20:
        return True
    if low.startswith('click'):
        return True
    for n in NOISE_SUBSTR:
        if n.lower() in low:
            return True
    if '&#x' in s or s.startswith('-->'):
        return True
    return False

def clean_block(text: str) -> str:
    kept = []
    for line in text.splitlines():
        if is_noise_line(line):
            continue
        kept.append(line.rstrip())
    out, blank = [], 0
    for line in kept:
        if not line.strip():
            blank += 1
            if blank <= 1:
                out.append('')
        else:
            blank = 0
            out.append(line)
    return '\n'.join(out).strip()

def format_answer(full_line: str, body: str) -> str:
    body = re.sub(r'\s+', ' ', body.strip())
    if re.search(r'choice', full_line, re.I):
        cm = re.match(r'(?i)^(?:Choice\s+)?([A-D])\b\s*(.*)$', body)
        if cm:
            letter, rest = cm.group(1).upper(), cm.group(2).strip()
            return f'Choice {letter}' + (f' — {rest}' if rest else '')
    cm = re.match(r'(?i)^Choice\s+([A-D])\b\s*(.*)$', body)
    if cm:
        letter, rest = cm.group(1).upper(), cm.group(2).strip()
        return f'Choice {letter}' + (f' — {rest}' if rest else '')
    return body

def strip_prev_echo(body: str, prev_answer: str | None) -> str:
    if not body:
        return body
    lines = body.splitlines()
    while lines and not lines[0].strip():
        lines.pop(0)
    if prev_answer and lines:
        echo = None
        m = re.search(r'Choice\s+[A-D]\s*—\s*(.*)$', prev_answer)
        if m and m.group(1).strip():
            echo = m.group(1).strip()
        elif not prev_answer.startswith('Choice'):
            echo = prev_answer.strip()
        if echo and lines[0].strip() == echo:
            lines = lines[1:]
    # Drop short leading analysis blurbs (heuristic): lines mentioning "unlike previous years"
    text = '\n'.join(lines)
    if 'unlike previous years' in text[:500].lower():
        # cut until first "CAT 20xx Slot" header if present
        m = re.search(r'(?m)^[ \t]*CAT 20\d\d Slot \d', text)
        if m:
            text = text[m.start():]
    return text.strip()

def find_content_start(lines):
    for i, line in enumerate(lines):
        if re.search(r'CAT 20\d\d Slot \d\s*-', line):
            return max(0, i - 40)
        if 'Attempt these questions' in line:
            return i
    for i, line in enumerate(lines):
        if 'Correct Answer' in line or line.strip() == 'Correct':
            return max(0, i - 120)
    return 0

def parse_section(path: Path):
    raw = path.read_text(encoding='utf-8', errors='replace').replace('\r\n', '\n').replace('\r', '\n')
    # Unify split Correct\n Answer X  →  Correct Answer X
    def _unify(m):
        return f' Correct Answer {m.group(1).strip()}'
    raw_u = ANSWER_SPLIT.sub(_unify, raw)

    source = ''
    msrc = re.search(r'^Source:\s*(\S+)', raw_u, re.M)
    if msrc:
        source = msrc.group(1)

    lines = raw_u.splitlines()
    content = '\n'.join(lines[find_content_start(lines):])
    matches = list(ANSWER_INLINE.finditer(content))

    questions = []
    prev = None
    for idx, m in enumerate(matches):
        # Reconstruct full match line for Choice detection
        full = m.group(0)
        ans = format_answer(full, m.group(1))
        q_start = matches[idx - 1].end() if idx else 0
        body = clean_block(content[q_start:m.start()])
        body = strip_prev_echo(body, prev)
        body = clean_block(body)
        questions.append({
            'n': idx + 1,
            'body': body or '*(stem sparse in extract — see source page)*',
            'answer': ans,
        })
        prev = ans

    return {'source': source, 'path': path.name, 'questions': questions, 'answer_count': len(matches)}

def parse_filename(name):
    m = re.match(r'CAT-(\d{4})-Question-Paper-Slot-(\d)-(VARC|DILR|Quant)\.txt$', name)
    return (int(m.group(1)), int(m.group(2)), m.group(3)) if m else None

def render_section(section, parsed):
    title = SECTION_TITLE[section]
    lines = [
        f'## {title}', '',
        f'- Source file: `2iim-html/{parsed["path"]}`',
    ]
    if parsed['source']:
        lines.append(f'- Page: {parsed["source"]}')
    lines += [
        f'- On-page answers found: {parsed["answer_count"]}',
        '- Answer source: 2IIM on-page **Correct Answer** / **Correct Answer Choice** (not invented)',
        '',
    ]
    for q in parsed['questions']:
        lines += [f'### Q{q["n"]}', '', q['body'], '', f'**ANSWER:** {q["answer"]}', '']
    return '\n'.join(lines)

def main():
    by_ys = defaultdict(dict)
    for path in sorted(SRC.glob('CAT-*-Question-Paper-Slot-*-*.txt')):
        meta = parse_filename(path.name)
        if not meta:
            continue
        y, s, sec = meta
        by_ys[(y, s)][sec] = parse_section(path)

    coverage = defaultdict(lambda: {'slots': set(), 'sections': 0, 'answers': 0})

    for (year, slot) in sorted(by_ys):
        sections = by_ys[(year, slot)]
        parts = [
            f'# CAT {year} — Slot {slot} (Questions + On-page Answer Key)',
            '',
            'Combined from public 2IIM HTML question pages (`2iim-html/`).',
            'Answers are on-page **Correct Answer** / **Correct Answer Choice** labels. Not invented.',
            '', '---', '',
        ]
        total = 0
        for section in ['VARC', 'DILR', 'Quant']:
            if section not in sections:
                parts += [f'## {SECTION_TITLE[section]}', '', '*Section extract missing.*', '']
                continue
            parts.append(render_section(section, sections[section]))
            parts += ['---', '']
            total += sections[section]['answer_count']
        (OUT / f'CAT-{year}-Slot-{slot}-with-keys.md').write_text('\n'.join(parts).rstrip() + '\n')
        for section, parsed in sections.items():
            body = [
                f'# CAT {year} — Slot {slot} — {SECTION_TITLE[section]} (Questions + On-page Answer Key)',
                '', 'Answers are on-page 2IIM **Correct Answer** labels. Not invented.', '',
                render_section(section, parsed),
            ]
            (OUT / f'CAT-{year}-Slot-{slot}-{section}-with-keys.md').write_text('\n'.join(body).rstrip() + '\n')
        coverage[year]['slots'].add(slot)
        coverage[year]['sections'] += len(sections)
        coverage[year]['answers'] += total

    readme = [
        '# CAT papers with answer keys', '',
        '## CAT 2022–2025 (complete on-page keys)', '',
        'Built from `/workspace/cat-mocks/2iim-html/` public 2IIM HTML extracts. Every listed question has an on-page **ANSWER**.', '',
    ]
    for year in sorted(coverage):
        c = coverage[year]
        slots = ', '.join(map(str, sorted(c['slots'])))
        readme.append(f'- **CAT {year}**: Slots {slots}; {c["sections"]} sections; **{c["answers"]}** answers.')
    readme += ['', '### Combined slot files', '']
    for (year, slot) in sorted(by_ys):
        readme.append(f'- `CAT-{year}-Slot-{slot}-with-keys.md`')
    readme += [
        '', '## Earlier years (2017–2021)', '',
        'See `earlier-years/` for PDF answer-key/solutions copies and plain-text answer extracts (often TITA-only).',
        'Full MCQ keys often need the PDF (color / click-to-reveal) — see `MISSING-KEYS.md`.',
        '', '## Career Launcher free mocks', '',
        'See `MISSING-KEYS.md` — solutions often unavailable until 1 day after the test window; no keys fabricated.', '',
    ]
    (OUT / 'README.md').write_text('\n'.join(readme) + '\n')

    print('OK')
    for year in sorted(coverage):
        print(f"  {year}: answers={coverage[year]['answers']} slots={sorted(coverage[year]['slots'])}")
    p = parse_section(SRC / 'CAT-2024-Question-Paper-Slot-1-DILR.txt')
    print('DILR Q1 head:', p['questions'][0]['body'][:300].replace('\n', ' | '))
    print('DILR Q1 ANS:', p['questions'][0]['answer'])

if __name__ == '__main__':
    main()
