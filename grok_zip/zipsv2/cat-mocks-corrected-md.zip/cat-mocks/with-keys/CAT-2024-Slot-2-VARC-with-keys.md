# CAT 2024 — Slot 2 — VARC (Questions + On-page Answer Key)

Answers are on-page 2IIM **Correct Answer** labels. Not invented.

## VARC

- Source file: `2iim-html/CAT-2024-Question-Paper-Slot-2-VARC.txt`
- Page: https://online.2iim.com/CAT-question-paper/CAT-2024-Question-Paper-Slot-2-VARC/
- On-page answers found: 24
- Answer source: 2IIM on-page **Correct Answer** / **Correct Answer Choice** (not invented)

### Q1

CAT 2024 Question Paper | CAT VARC

 CAT Question Paper | CAT Previous Year Paper

 CAT 2024 Slot 2 - VA RC

 The passage given below is followed by four alternate summaries. Choose the option that
 best captures the essence of the passage.

Recent important scientific
 findings have emerged from crossing the boundaries of scientific fields. They stem from
 physicists collaborating with biologists, sociologists and others, to answer questions
 about our world. But physicists and their potential collaborators often find their
 cultures out of sync. For one, physicists often discard a lot of information while
 extracting broad patterns; for other scientists, information is not readily disposed.
 Further, many non-physicists are uncomfortable with mathematical models. Still, the
 desire to work on something new and different is real, and there are clear benefits from
 the collision of views.

 Physicists have successfully buried their differences on research methods
 applied in other fields in their desire to find answers to baffling
 scientific questions.

 Large data sets and mathematical models in physics research combined with
 the research methods of non-physicist collaborators have yielded important
 scientific findings.

 The desire to diversify their research and answer important questions has
 led to several collaborations between physicists and other social
 scientists.

 Despite differences in their research styles, physicists' research
 collaborations with scholars from other disciplines have yielded important
 research findings.

**ANSWER:** Choice D

### Q2

Despite differences in their
 research styles, physicists' research collaborations with scholars from
 other disciplines have yielded important research findings.

 The passage below is accompanied by four questions. Based on the passage,
 choose the best answer for each question.

The job of a peer reviewer is
 thankless. Collectively, academics spend around 70 million hours every year evaluating each
 other's manuscripts on the behalf of scholarly journals — and they usually receive no
 monetary compensation and little if any recognition for their effort. Some do it as a way to
 keep abreast with developments in their field; some simply see it as a duty to the
 discipline. Either way, academic publishing would likely crumble without them.

In
 recent years, some scientists have begun posting their reviews online, mainly to claim
 credit for their work. Sites like Publons allow researchers to either share entire referee
 reports or simply list the journals for whom they've carried out a review….
The rise of
 Publons suggests that academics are increasingly placing value on the work of peer review
 and asking others, such as grant funders, to do the same. While that's vital in the
 publish-or-perish culture of academia, there's also immense value in the data underlying
 peer review. Sharing peer review data could help journals stamp out fraud, inefficiency, and
 systemic bias in academic publishing.….

Peer review data could also help root out
 bias. Last year, a study based on peer review data for nearly 24,000 submissions to the
 biomedical journal eLife found that women and non-Westerners were vastly underrepresented
 among peer reviewers. Only around one in every five reviewers was female, and less than two
 percent of reviewers were based in developing countries…. Openly publishing peer review data
 could perhaps also help journals address another problem in academic publishing: fraudulent
 peer reviews. For instance, a minority of authors have been known to use phony email
 addresses to pose as an outside expert and review their own
 manuscripts.…

Opponents of open peer review commonly argue that confidentiality
 is vital to the integrity of the review process; referees may be less critical of
 manuscripts if their reports are published, especially if they are revealing their
 identities by signing them. Some also hold concerns that open reviewing may deter referees
 from agreeing to judge manuscripts in the first place, or that they'll take longer to do so
 out of fear of scrutiny….

Even when the content of reviews and the identity of
 reviewers can't be shared publicly, perhaps journals could share the data with outside
 researchers for study. Or they could release other figures that wouldn't compromise the
 anonymity of reviews but that might answer important questions about how long the reviewing
 process takes, how many researchers editors have to reach out to on average to find one who
 will carry out the work, and the geographic distribution of peer reviewers.

Of
 course, opening up data underlying the reviewing process will not fix peer review entirely,
 and there may be instances in which there are valid reasons to keep the content of peer
 reviews hidden and the identity of the referees confidential. But the norm should shift from
 opacity in all cases to opacity only when necessary.

 CAT 2024 Slot 2 - VA RC

 Based on the passage we can infer that the author would most probably support

 publicising peer review data rather than the publication of actual reviews.

 preserving the anonymity of reviewers to protect them from criticism.

 more careful screening to ensure the recruitment of content-familiar peer
 reviewers.

 greater transparency across the peer review process in academic publishing.

**ANSWER:** Choice D

### Q3

greater transparency across the
 peer review process in academic publishing.

 CAT 2024 Slot 2 - VA RC

 According to the passage, which of the following is the only reason NOT given in favour
 of making peer review data public?

 It can tackle the problem of selecting appropriately qualified reviewers for
 academic writing.

 It would highlight the gender and race biases currently existing in the
 selection of reviewers.

 It will deal with peer review fraud such as authors publishing bogus reviews
 of their work.

 It could address various inefficiencies and fraudulent practices that
 continue in academic publishing process.

**ANSWER:** Choice A

### Q4

It can tackle the problem of
 selecting appropriately qualified reviewers for academic writing.

 CAT 2024 Slot 2 - VA RC

 According to the passage, some are opposed to making peer reviews public for all the
 following reasons EXCEPT that it

 delays the manuscript evaluation process as reviewers would take longer to
 write their reviews.

 makes reviewers reluctant to review manuscripts, especially if these are
 critical of the submitted work.

 leaves the reviewers unexposed to unwarranted and unjustified criticism or
 comments from others.

 deters reviewers from producing honest, if critical, reviews that are vital
 to the sound publishing process.

**ANSWER:** Choice C

### Q5

leaves the reviewers unexposed to
 unwarranted and unjustified criticism or comments from others.

 CAT 2024 Slot 2 - VA RC

 All of the following are listed as reasons why academics choose to review other scholars'
 work EXCEPT:

 It is seen as a form of service to the academic community.

 It helps them keep current with cutting-edge ideas in their academic
 disciplines.

 It is seen as an opportunity to expand their influence in the academic
 community.

 Some use this as an opportunity to publicise their own review work.

**ANSWER:** Choice C

### Q6

It is seen as an opportunity to
 expand their influence in the academic community.

 CAT 2024 Slot 2 - VA RC

 There is a sentence that is missing in the paragraph below. Look at the paragraph and
 decide where (option 1, 2, 3, or 4) the following sentence would best
 fit.

Sentence: Science has officially crowned us superior to our early-rising
 brethren.
 Paragraph: My fellow night owls, grab a strong cup of coffee and gather
 around: I have great news. ___(1)___. For a long time, our kind has been unfairly
 maligned. Stereotyped as lazy and undisciplined. Told we ought to be morning larks.
 Advised to go to bed early so we can wake before 5am and run a marathon before breakfast
 like all high-flyers seem to do. Now, however, we are having the last laugh. ___(2)___.
 It may be a tad more complicated than that. A study published last week, which you may
 have already seen while scrolling at 1am, suggests that staying up late could be good
 for brain power. ___(3)___. Is this study a thinly veiled PR exercise conducted by a
 caffeine-pill company? Nope, it's legit. ___(4)___. Research led by academics at
 Imperial College London studied data on more than 26,000 people and found that
 "self-declared 'night owls' generally tend to have higher cognitive scores".

 Option 4

 Option 1

 Option 2

 Option 3

**ANSWER:** Choice C

### Q7

Option 2

 CAT 2024 Slot 2 - VA RC

 Five jumbled up sentences (labelled 1, 2, 3, 4 and 5), related to a topic, are given
 below. Four of them can be put together to form a coherent paragraph. Identify the odd
 sentence and key in the number of that sentence as your answer.

1. The UK is
 a world leader in developing cultivated meat and the approval of a cultivated pet food
 is an important milestone.
2. If we're to realise the full potential benefits of
 cultivated meat the government must invest in research and infrastructure.
3. The
 first UK applications for cultivated meat produced for humans remain under assessment
 with the Food Standards Agency.
4. The previous UK government had been looking at
 fast-tracking the approval of cultivated meat for human consumption.
5. It
 underscores the potential for new innovation to help reduce the negative impacts of
 intensive animal agriculture.

**ANSWER:** 4

### Q8

The passage below is accompanied by four questions. Based on the passage,
 choose the best answer for each question.

[S]pices were a global commodity
 centuries before European voyages. There was a complex chain of relations, yet consumers had
 little knowledge of producers and vice versa. Desire for spices helped fuel European
 colonial empires to create political, military and commercial networks under a single
 power.

Historians know a fair amount about the supply of spices in Europe during
 the medieval period – the origins, methods of transportation, the prices – but less about
 demand. Why go to such extraordinary efforts to procure expensive products from exotic
 lands? Still, demand was great enough to inspire the voyages of Christopher Columbus and
 Vasco Da Gama, launching the first fateful wave of European colonialism. . . .

So, why were spices so highly prized in Europe in the centuries from about 1000 to
 1500? One widely disseminated explanation for medieval demand for spices was that they
 covered the taste of spoiled meat. . . . Medieval purchasers consumed meat much fresher than
 what the average city-dweller in the developed world of today has at hand. However,
 refrigeration was not available, and some hot spices have been shown to serve as an
 anti-bacterial agent. Salting, smoking or drying meat were other means of preservation. Most
 spices used in cooking began as medical ingredients, and throughout the Middle Ages spices
 were used as both medicines and condiments. Above all, medieval recipes involve the
 combination of medical and culinary lore in order to balance food's humeral properties and
 prevent disease. Most spices were hot and dry and so appropriate in sauces to counteract the
 moist and wet properties supposedly possessed by most meat and fish. . . .

Where
 spices came from was known in a vague sense centuries before the voyages of Columbus. Just
 how vague may be judged by looking at medieval world maps . . . To the medieval European
 imagination, the East was exotic and alluring. Medieval maps often placed India close to the
 so-called Earthly Paradise, the Garden of Eden described in the
 Bible.

Geographical knowledge has a lot to do with the perceptions of spices'
 relative scarcity and the reasons for their high prices. An example of the varying notions
 of scarcity is the conflicting information about how pepper is harvested. As far back as the
 7 th century Europeans thought that pepper in India grew on trees "guarded" by
 serpents that would bite and poison anyone who attempted to gather the fruit. The only way
 to harvest pepper was to burn the trees, which would drive the snakes underground. Of
 course, this bit of lore would explain the shriveled black peppercorns, but not white, pink
 or other colors.

Spices never had the enduring allure or power of gold and silver
 or the commercial potential of new products such as tobacco, indigo or sugar. But the taste
 for spices did continue for a while beyond the Middle Ages. As late as the 17 th
 century, the English and the Dutch were struggling for control of the Spice Islands: Dutch
 New Amsterdam, or New York, was exchanged by the British for one of the Moluccan Islands
 where nutmeg was grown.

 CAT 2024 Slot 2 - VA RC

 In the context of the passage, which one of the following conclusions CANNOT be reached?

 India was colonised for its spices and gold.

 Tobacco was more marketable than spices.

 The spice trade was a driver of colonial expansion.

 Colonialism was motivated by the demand for spices.

**ANSWER:** Choice A

### Q9

India was colonised for its spices
 and gold.

 CAT 2024 Slot 2 - VA RC

 It can be inferred that all of the following contributed to a decline in the allure of
 spices, EXCEPT:

 changes in European cuisine.

 the development of refrigeration techniques.

 increase in the availability of spices.

 changes in the system of medical treatment.

**ANSWER:** Choice C

### Q10

increase in the availability of
 spices.

 CAT 2024 Slot 2 - VA RC

 If a trader brought white peppercorns from India to medieval Europe, all of the following
 are unlikely to happen, EXCEPT:

 Europeans would doubt the story of pepper harvesting.

 the price of spices would decrease.

 medieval maps would be used as navigational aids.

 pepper would no longer be considered exotic.

**ANSWER:** Choice A

### Q11

Europeans would doubt the story of
 pepper harvesting.

 CAT 2024 Slot 2 - VA RC

 In the context of the passage, the people who heard the story of pepper trees being
 guarded by snakes would be least likely to arrive at the conclusion that

 it is no surprise that the pepper supply is so limited.

 it is not advisable to go to India to harvest the pepper themselves.

 this is why pepper is so hot.

 pepper is costly for good reason.

**ANSWER:** Choice C

### Q12

this is why pepper is so
 hot.

 The passage below is accompanied by four questions. Based on the passage,
 choose the best answer for each question.

The history of any major technological
 or industrial advance is inevitably shadowed by a less predictable history of unintended
 consequences and secondary effects — what economists sometimes call "externalities."
 Sometimes those consequences are innocuous ones, or even beneficial. Gutenberg invents the
 printing press, and literacy rates rise, which causes a significant part of the reading
 public to require spectacles for the first time, which creates a surge of investment in
 lens-making across Europe, which leads to the invention of the telescope and the microscope.

Oftentimes the secondary effects seem to belong to an entirely different sphere
 of society. When Willis Carrier hit upon the idea of air-conditioning, the technology was
 primarily intended for industrial use: ensuring cool, dry air for factories that required
 low-humidity environments. But…it touched off one of the largest migrations in the history
 of the United States, enabling the rise of metropolitan areas like Phoenix and Las Vegas
 that barely existed when Carrier first started tinkering with the idea in the early
 1900s.

Sometimes the unintended consequence comes about when consumers use an
 invention in a surprising way. Edison famously thought his phonograph, which he sometimes
 called "the talking machine," would primarily be used to take dictation….But then later
 innovators… discovered a much larger audience willing to pay for musical recordings made on
 descendants of Edison's original invention. In other cases, the original innovation comes
 into the world disguised as a plaything…the way the animatronic dolls of the mid-1700s
 inspired Jacquard to invent the first "programmable" loom and Charles Babbage to invent the
 first machine that fit the modern definition of a computer, setting the stage for the
 revolution in programmable technology that would transform the 21st century in countless
 ways.

We live under the gathering storm of modern history's most momentous
 unintended consequence….carbon-based climate change. Imagine the vast sweep of inventors
 whose ideas started the Industrial Revolution, all the entrepreneurs and scientists and
 hobbyists who had a hand in bringing it about. Line up a thousand of them and ask them all
 what they had been hoping to do with their work. Not one would say that their intent had
 been to deposit enough carbon in the atmosphere to create a greenhouse effect that trapped
 heat at the surface of the planet. And yet here we are.

Ethyl (leaded fuel) and
 Freon belonged to the same general class of secondary effect: innovations whose unintended
 consequences stem from some kind of waste by-product that they emit. But the potential
 health threats of Ethyl (unleaded fuel) were visible in the 1920s, unlike, say, the
 long-term effects of atmospheric carbon build up in the early days of the Industrial
 Revolution….

Indeed, it is reasonable to see CFCs (chlorofluorocarbons) as a
 forerunner of the kind of threat we will most likely face in the coming decades, as it
 becomes increasingly possible for individuals or small groups to create new scientific
 advances — through chemistry or biotechnology or materials science — setting off unintended
 consequences that reverberate on a global scale.

 CAT 2024 Slot 2 - VA RC

 We can assume that the author would support all of the following views EXCEPT:

 It has become far easier for people today to bring out innovations with dire
 worldwide consequences than it was earlier.

 The emissions caused by the large-scale use of leaded fuel ought to have
 been addressed earlier than they were.

 While technological advances in the past have had innocuous or beneficial
 outcomes, more recent advances have the potential to be more threatening
 globally.

 The by-products of leaded fuel, rather than the fuel itself, were
 responsible for the build-up of carbon-related gases in the atmosphere.

**ANSWER:** Choice C

### Q13

While technological advances in the
 past have had innocuous or beneficial outcomes, more recent advances
 have the potential to be more threatening globally.

 CAT 2024 Slot 2 - VA RC

 Carrier, Babbage, and Edison are mentioned in the passage to illustrate the author's
 point that

 these inventors could not have visualised the eventual impact of their
 inventions on society.

 the secondary effect of past inventions mostly resulted in the creation of
 new inventions.

 inventions typically end up being used for entirely different purposes than
 the intended ones.

 despite the original intention, the unintended consequences of their
 inventions were largely beneficial.

**ANSWER:** Choice A

### Q14

these inventors could not have
 visualised the eventual impact of their inventions on society.

 CAT 2024 Slot 2 - VA RC

 Which of the following best conveys the main point of the first paragraph?

 The secondary effects of most major technological advances in the past,
 especially if they were unintended, have turned out to be beneficial.

 The full impact of technological advances cannot be estimated in the short
 run as the ripple effects often extend far beyond the original intent.

 The entire impact of a technological advance should be evaluated by the
 boost its secondary effects gives to generating further technological
 advances.

 It is important to judge an invention not by its immediate outcomes, but by
 the holistic impact of its secondary effects.

**ANSWER:** Choice B

### Q15

The full impact of technological
 advances cannot be estimated in the short run as the ripple effects
 often extend far beyond the original intent.

 CAT 2024 Slot 2 - VA RC

 The author lists all of the following examples as "externalities" of major technical
 advances EXCEPT:

 extension of the phonograph to large-scale recording of music

 build-up of chlorofluorocarbons in the atmosphere

 cooling and de-humidifying of factories through air-conditioning

 application of the Jacquard loom to modern IT programming

**ANSWER:** Choice C

### Q16

cooling and de-humidifying of
 factories through air-conditioning

 CAT 2024 Slot 2 - VA RC

 Five jumbled up sentences (labelled 1, 2, 3, 4 and 5), related to a topic, are given
 below. Four of them can be put together to form a coherent paragraph. Identify the odd
 sentence and key in the number of that sentence as your answer.

1. No known
 real researcher of human behaviour would say that gender is all nature or all
 nurture.
2. The evidence for a biological basis for gender certainly doesn't mean
 we should be complacent in the face of sexism.
3. Many people are uncomfortable
 with the idea that gender is not purely a social construct.
4. Despite this
 empirical truth, researchers who study the biological basis of gender often face
 political pushback.
5. There's a political preference for gender to be only a
 reflection of social factors and so entirely malleable.

**ANSWER:** 2

### Q17

CAT 2024 Slot 2 - VA RC

 There is a sentence that is missing in the paragraph below. Look at the paragraph and
 decide where (option 1, 2, 3, or 4) the following sentence would best
 fit.

Sentence: Yet each day the flock produced eggs with calcareous shells
 though they apparently had not ingested any calcium from land which was entirely lacking
 in limestone.

Paragraph: Early in this century a young Breton schoolboy who
 preparing himself for a scientific career began to notice a strange fact about hens in
 his father's poultry yard. ___(1) ___. As they scratched the soil they constantly seemed
 to be pecking at specks of mica, a siliceous material dotting the ground. ___(2)___. No
 one could explain to Louis Kervran why the chickens selected the mica, or why each time
 a bird was killed for the family cooking pot no trace of the mica could be found in its
 gizzard. ___(3) ___. It took Kervran many years to establish that the chickens were
 transmuting one element into another. ___(4)___.

 Option 3

 Option 4

 Option 1

 Option 2

**ANSWER:** Choice A

### Q18

Option 3

 The passage below is accompanied by four questions. Based on the passage,
 choose the best answer for each question.

(. . .) There are three other common
 drivers for carnivore-human attacks, some of which are more preventable than others. Natural
 aggression-based conflicts – such as those involving females protecting their young or
 animals protecting a food source – can often be avoided as long as people stay away from
 those animals and their food.
Carnivores that recognise humans as a means to get food,
 are a different story. As they become more reliant on human food they might find at
 campsites or in rubbish bins, they become less avoidant of humans. Losing that instinctive
 fear response puts them into more situations where they could get into an altercation with a
 human, which often results in that bear being put down by humans. "A fed bear is a dead
 bear," says Servheen, referring to a common saying among biologists and
 conservationists.
Predatory or predation-related attacks are quite rare, only
 accounting for 17% of attacks in North America since 1955. They occur when a carnivore views
 a human as prey and hunts it like it would any other animal it uses for food. (. .
 .)

Then there are animal attacks provoked by people taking pictures with them or
 feeding them in natural settings such as national parks which often end with animals being
 euthanised out of precaution. "Eventually, that animal becomes habituated to people, and
 [then] bad things happen to the animal. And the folks who initially wanted to make that
 connection don't necessarily realise that," says Christine Wilkinson, a postdoctoral
 researcher at UC Berkeley, California, who's been studying coyote-human conflicts.

After conducting countless postmortems on all types of carnivore-human attacks
 spanning 75 years, Penteriani's team believes 50% could have been avoided if humans reacted
 differently. A 2017 study co-authored by Penteriani found that engaging in risky behaviour
 around large carnivores increases the likelihood of an attack.
Two of the most common
 risky behaviours are parents leaving their children to play outside unattended and walking
 an unleashed dog, according to the study. Wilkinson says 66% of coyote attacks involve a
 dog. "[People] end up in a situation where their dog is being chased, or their dog chases a
 coyote, or maybe they're walking their dog near a den that's marked, and the coyote wants to
 escort them away," says Wilkinson.

Experts believe climate change also plays a
 part in the escalation of human-carnivore conflicts, but the correlation still needs to be
 ironed out. "As finite resources become scarcer, carnivores and people are coming into more
 frequent contact, which means that more conflict could occur," says Jen Miller,
 international programme specialist for the US Fish & Wildlife Service. For example, she
 says, there was an uptick in lion attacks in western India during a drought when lions and
 people were relying on the same water sources.

(. . .) The likelihood of
 human-carnivore conflicts appears to be higher in areas of low-income countries dominated by
 vast rural landscapes and farmland, according to Penteriani's research. "There are a lot of
 working landscapes in the Global South that are really heterogeneous, that are interspersed
 with carnivore habitats, forests and savannahs, which creates a lot more opportunity for
 these encounters, just statistically," says Wilkinson.

 CAT 2024 Slot 2 - VA RC

 According to the passage, which of the following scenarios would MOST likely exacerbate
 the frequency of carnivore-human conflicts?

 Attempting to photograph wild animals from within secured viewing areas in
 national parks and protected zones.

 Implementing 'food waste' management strategies to prevent wild animals
 being attracted to human food sources.

 Addressing the impact of climate change on the availability of resources for
 wildlife.

 Unleashing dogs by pet owners in areas with known high concentrations of
 large carnivores.

**ANSWER:** Choice D

### Q19

Unleashing dogs by pet owners in
 areas with known high concentrations of large carnivores.

 CAT 2024 Slot 2 - VA RC

 According to the passage, what is a significant factor that contributes to the
 habituation of carnivores to human presence?

 The natural aggression exhibited by carnivores, exacerbated by human
 interference, particularly when they are safeguarding their offspring or
 food sources.

 The increased scarcity of resources due to climate change, forcing
 carnivores to venture outside their natural habitats in search of
 sustenance.

 The predatory perception of humans as potential prey within the carnivores'
 food chain.

 The reduction in carnivores' instinctive fear response, resulting from their
 reliance upon human-provided food.

**ANSWER:** Choice D

### Q20

The reduction in carnivores'
 instinctive fear response, resulting from their reliance upon
 human-provided food.

 CAT 2024 Slot 2 - VA RC

 Which of the following statements, if false, would be inconsistent with the concerns
 raised in the passage regarding the drivers of carnivore-human conflicts?

 Climate change has had negligible effects on the frequency of
 carnivore-human interactions in affected regions.

 Carnivores lose their instinctive fear of humans, when consistently exposed
 to human food sources.

 Predatory attacks by carnivores are a common occurrence and have steadily
 increased over the past few decades.

 Human efforts to avoid risky behaviours around large carnivores have proven
 effective in reducing conflict incidents.

**ANSWER:** Choice A

### Q21

Climate change has had negligible
 effects on the frequency of carnivore-human interactions in affected
 regions.

 CAT 2024 Slot 2 - VA RC

 Given the insights provided by Penteriani's research and Wilkinson's statement, which of
 the following conclusions can be drawn about the relationship between landscape
 heterogeneity and human-carnivore conflicts?

 Homogeneous landscapes with uniform agricultural practices are more likely
 to experience high rates of human-carnivore conflicts due to the
 predictability of resources.

 Landscape heterogeneity, characterized by a mix of farmland and natural
 habitats, inherently reduces the chances of human-carnivore conflicts by
 providing more refuge for wildlife away from human activity.

 The diversity and interspersion of working landscapes with carnivore
 habitats in rural areas increase the statistical probability of encounters
 between humans and carnivores.

 Low-income countries with vast, contiguous wilderness areas are less prone
 to human-carnivore conflicts because these areas lack the human presence
 necessary for such encounters.

**ANSWER:** Choice C

### Q22

The diversity and interspersion of
 working landscapes with carnivore habitats in rural areas increase the
 statistical probability of encounters between humans and
 carnivores.

 CAT 2024 Slot 2 - VA RC

 The passage given below is followed by four alternate summaries. Choose the option that
 best captures the essence of the passage.

John Cleese told Fox News Digital
 that comedians do not have the freedom to be funny in 2022. "There's always been
 limitations on what they're allowed to say," Cleese said. "I think it's particularly
 worrying at the moment because you can only create in an atmosphere of freedom, where
 you're not checking everything you say critically before you move on. What you have to
 be able to do is to build without knowing where you're going because you've never been
 there before. That's what creativity is — you have to be allowed to build. And a lot of
 comedians now are sitting there and when they think of something, they say something
 like, 'Can I get away with it? I don't think so. So and so got into trouble, and he said
 that, oh, she said that.' You see what I mean? And that's the death of creativity."

 Comedians are being prevented from saying what they want and that is the
 death of this art form.

 Comedians must not check what they think and say. They must go where no one
 has gone before.

 Freedom and creativity are essential for comedy. Fear about offending people
 hinders originality.

 Creativity and critical thinking cannot work together. Comedians must first
 be creative, and later be critical.

**ANSWER:** Choice C

### Q23

Freedom and creativity are
 essential for comedy. Fear about offending people hinders
 originality.

 CAT 2024 Slot 2 - VA RC

 There is a sentence that is missing in the paragraph below. Look at the paragraph and
 decide where (option 1, 2, 3, or 4) the following sentence would best
 fit.

Sentence: [T]he Europeans did not invent
 globalization.

Paragraph: The first phase of globalization occurred long
 before the introduction of either steam or electric power…Chinese consumers at all
 social levels consumed vast quantities of spices, fragrant woods and unusual plants. The
 peoples of Southeast Asia who lived in forests gave up their traditional livelihoods and
 completely reoriented their economies to supply Chinese consumers….___(1)___. These
 exchanges of the year 1000 opened some of the routes through which goods and peoples
 continued to travel after Columbus traversed the mid-Atlantic. ___(2)___. Yet the world
 of 1000 differed from that of 1492 in important ways….the travellers who encountered one
 another in the year 1000 were much closer technologically. ___(3)___. They changed and
 augmented what was already there since 1000. ___(4)___. If globalization hadn't yet
 begun, Europeans wouldn't have been able to penetrate the markets in so many places as
 quickly as they did after 1492.

 Option 2

 Option 1

 Option 4

 Option 3

**ANSWER:** Choice D

### Q24

Option 3

 CAT 2024 Slot 2 - VA RC

 The passage given below is followed by four alternate summaries. Choose the option that
 best captures the essence of the passage.

Different from individuals, states
 conduct warfare operations using the DIME model— "diplomacy, information, military, and
 economics." Most states do everything they can to inflict pain and confusion on their
 enemies before deploying the military. In fact, attacks on vectors of information are a
 well-worn tactic of war and usually are the first target when the charge begins. It's
 common for telecom data and communications networks to be routinely monitored by
 governments, which is why the open data policies of the web are so concerning to many
 advocates of privacy and human rights. With the worldwide adoption of social media, more
 governments are getting involved in low-grade information warfare through the use of
 cyber troops. According to a study by the Oxford Internet Institute in 2020, cyber
 troops are "government or political party actors tasked with manipulating public opinion
 online." The Oxford research group was able to identify 81 countries with active cyber
 troop operations utilizing many different strategies to spread false information,
 including spending millions on online advertising.

 As part of conducting information warfare as per the DIME model, many
 governments routinely monitor telecom data and communications networks, and
 use cyber troops on social media to manipulate public opinion.

 Following the DIME model, many governments have taken advantage of open data
 policies of the web to deploy cyber troops who manipulate domestic public
 opinion, using advertising and other strategies to spread false information.

 Governments primarily use the DIME model to deploy cyber troops who practise
 low-grade information warfare, seeking to manipulate public opinion with the
 objective of inflicting pain and confusion on their enemies.

 Using the DIME model, together with military operations, many governments
 simultaneously conduct information warfare with the help of cyber troops and
 routinely monitor telecom data and communications networks.

**ANSWER:** Choice A
