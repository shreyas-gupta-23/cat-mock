# CAT 2025 — Slot 2 — VARC (Questions + On-page Answer Key)

Answers are on-page 2IIM **Correct Answer** labels. Not invented.

## VARC

- Source file: `2iim-html/CAT-2025-Question-Paper-Slot-2-VARC.txt`
- Page: https://online.2iim.com/CAT-question-paper/CAT-2025-Question-Paper-Slot-2-VARC/
- On-page answers found: 24
- Answer source: 2IIM on-page **Correct Answer** / **Correct Answer Choice** (not invented)

### Q1

CAT 2025 Question Paper | CAT VARC

 CAT Question Paper | CAT Previous Year Paper

 CAT 2025 Slot 2 - VA RC

 The given sentence is missing in the paragraph below. Decide where it best fits among the options 1, 2, 3, or 4 indicated in the paragraph.

Sentence: While taste is related to judgment, with thinkers at the time often writing, for example, about "judgments of taste" or using the two terms interchangeably, taste retains a vital link to pleasure, embodiment, and personal specificity that is too often elided in post-Kantian ideas about judgment—a link that Arendt herself was working to restore.

Paragraph: ____(1) ____. Denneny focused on taste rather than judgment in order to highlight what he believed was a crucial but neglected historical change. ____(2) ____. Over the course of the seventeenth century and early eighteenth century, across Western Europe, the word taste took on a new extension of meaning, no longer referring specifically to gustatory sensation and the delights of the palate but becoming, for a time, one of the central categories for aesthetic—and ethical—thinking. ____(3) ____. Tracing the history of taste in Spanish, French, and British aesthetic theory, as Denneny did, also provides a means to recover the compelling and relevant writing of a set of thinkers who have been largely neglected by professional philosophy. ____(4) ____.

 Option 3

 Option 4

 Option 1

 Option 2

**ANSWER:** Choice A

### Q2

Option 3

 The passage below is accompanied by four questions. Based on the passage, choose the best answer for each question.

This book takes the position that setting in literature is more than just backdrop, that important insight into literary texts can be made by paying close attention to how authors craft place, as well as to how place functions in a narrative. The authors included in this reference work engage deeply with either real or imagined geographies. They care about how human decisions have shaped landscapes and how landscapes have shaped human practices and values. Some of the best writing is highly vivid, employing the language of the senses because this is the primary means through which humans know physical space.

Literature can offer valuable perspectives on physical and cultural geography. Unlike scientific reports, a literary narrative can provide the emotional component missing from the scientific record. In human experience, geographical places have a spiritual or emotional component in addition to and as part of a physical layout and topography. This emotional component, although subjective, is no less "real" than a surveyor's map. Human consciousness of place is experienced in a multi-modal manner. Histories of places live on in many forms, one of which is the human memory or imagination.

Both real and imaginary landscapes provide insight into the human experience of place. The pursuit of such a topic speaks to the valuable knowledge produced from bridging disciplines and combining material from both the arts and the sciences to better understand the human condition. The perspectives that most concern cultural geographers are often those regarding movement and migration, cultivation of natural resources, and organization of space. The latter two reflect concerns of the built environment, a topic shared with the field of architectural study. Many of these concerns are also reflected in work sociologists do. Scholars from literary studies can contribute an aesthetic dimension to what might otherwise be a purely ideological approach.

Literature can bring together material that spans different branches of science. For example, a literary description of place may involve not only the environment and geography but the noises and quality of light, or how people from different races or classes can experience the same place in different ways linked to those racial or class disparities. Literary texts can also account for the way in which absence—of other people, animals, and so on—affects a human observer or inhabitant. Both literary and scientific approaches to place are necessary, working in unison, to achieve a complete record of an environment. It is important to note that the interdisciplinary nature of this work teaches us that landscapes are not static, that they are not unchanged by human culture. At least part of their identity derives from the people who inhabit them and from the way space can alter and inspire human perspective. The intersection of scientific and literary expression that happens in the study of literary geography is of prime importance due to the complexity of the personal and political ways that humans experience place.

 CAT 2025 Slot 2 - VA RC

 All of the following statements, if false, would contradict the arguments in the passage, EXCEPT that:

 highly vivid writing, employing the language of the senses, can capture the multi-modal manner in which humans experience places.

 descriptions of places do not need satellite imagery or other visual aids to give a "real" sense of the place.

 literature provides us with deep insights into the ways in which movement and migration affect physical geography.

 humans do not interact with places in subjective, emotional ways because places are only physical topography.

**ANSWER:** Choice D

### Q3

humans do not interact with places in subjective, emotional ways because places are only physical topography.

 CAT 2025 Slot 2 - VA RC

 Which one of the following is a valid conclusion to draw from the author's statement that, "The pursuit of such a topic speaks to the valuable knowledge produced from bridging disciplines and combining material from both the arts and the sciences to better understand the human condition."?

 A comprehensive understanding of the valuable knowledge produced by the arts and sciences can best be achieved by studying the human condition.

 The literary descriptions of the emotions we experience in the places we visit can contribute to our understanding of the arts and sciences.

 A comprehensive bridging of the human condition can best be achieved by a disciplined pursuit of human understanding.

 A comprehensive understanding of the human condition can best be achieved by combining the findings of disciplines from the arts and the sciences.

**ANSWER:** Choice D

### Q4

A comprehensive understanding of the human condition can best be achieved by combining the findings of disciplines from the arts and the sciences.

 CAT 2025 Slot 2 - VA RC

 Which one of the following is not true of the argument in the second paragraph?

 Literary accounts of places can be filled with histories, manifested as memory or imagination.

 The spiritual experience of a place may be considered as real as the physical experience of it.

 Analysing the literary descriptions of a place can give us a sense of how people relate emotionally to it.

 The emotional and spiritual experience of a place can replace a surveyor's map.

**ANSWER:** Choice D

### Q5

The emotional and spiritual experience of a place can replace a surveyor's map.

 CAT 2025 Slot 2 - VA RC

 The author uses the example of the literary description of place to illustrate that:

 literature can convey how different people experience the same place differently.

 architects use diverse methods to calibrate the noises and lights of a given place.

 the absence of other people, animals, and so on in a place can profoundly affect its inhabitants.

 scientific approaches to place are more accurate than literary ones.

**ANSWER:** Choice A

### Q6

literature can convey how different people experience the same place differently.

 CAT 2025 Slot 2 - VA RC

 Five jumbled sentences (labelled 1, 2, 3, 4, and 5), related to a topic, are given below. Four of them can be put together to form a coherent paragraph. Identify the odd sentence out and key in the number of that sentence as your answer.

1. Sporting a copper-coloured pixie cut and a pair of pink feather antlers, Torres himself resembles a child's doodle.
2. His casual millennial delivery, peppered with "um"s and "ah"s, makes surreal concepts sound like items on a brunch menu.
3. Though he may have failed so far in his colour-scouting mission (he hasn't yet found a new one, he admits), this hour leaves you tickled pink.
4. Like his previous show, My Favourite Shapes, this is an hour of sit-down comedy aided by an overhead camera which relays Torres's theories – illustrated with crayon squiggles – on to a screen behind him.
5. His inquisitive mind produces interconnected ideas about Catholicism, the blandness of Pixar and what orange sounds like, while his insights train us to spot "highly purple behaviour".

**ANSWER:** 3

### Q7

The passage below is accompanied by four questions. Based on the passage, choose the best answer for each question.

Time and again, whenever a population [of Mexican tetra fish] was swept into a cave and survived long enough for natural selection to have its way, the eyes disappeared. "But it's not that everything has been lost in cavefish . . . Many enhancements have also happened." . . . Studies have found that cave-dwelling fish can detect lower levels of amino acids than surface fish can. They also have more tastebuds and a higher density of sensitive cells alongside their bodies that let them sense water pressure and flow. . . .

Killing the processes that support the formation of the eye is quite literally what happens. Just like non-cave-dwelling members of the species, all cavefish embryos start making eyes. But after a few hours, cells in the developing eye start dying, until the entire structure has disappeared. [Developmental biologist Misty] Riddle thinks this apparent inefficiency may be unavoidable. "The early development of the brain and the eye are completely intertwined—they happen together," she says. That means the least disruptive way for eyelessness to evolve may be to start making an eye and then get rid of it. . . .

It's easy to see why cavefish would be at a disadvantage if they were to maintain expensive tissues they aren't using. Since relatively little lives or grows in their caves, the fish are likely surviving on a meager diet of mostly bat feces and organic waste that washes in during the rainy season. Researchers keeping cavefish in labs have discovered that, genetically, the creatures are exquisitely adapted to absorbing and storing nutrients. . . .

Fats can be toxic for tissues, [evolutionary physiologist Nicolas] Rohner explains, so they are stored in fat cells. "But when these cells get too big, they can burst, which is why we often see chronic inflammation in humans and other animals that have stored a lot of fat in their tissues." Yet a 2020 study by Rohner, Krishnan and their colleagues revealed that even very well-fed cavefish had fewer signs of inflammation in their fat tissues than surface fish do. Even in their sparse cave conditions, wild cavefish can sometimes get very fat, says Riddle. This is presumably because, whenever food ends up in the cave, the fish eat as much of it as possible, since there may be nothing else for a long time to come. Intriguingly, Riddle says, their fat is usually bright yellow, because of high levels of carotenoids, the substance in the carrots that your grandmother used to tell you were good for your…eyes.

"The first thing that came to our mind, of course, was that they were accumulating these because they don't have eyes," says Riddle. In this species, such ideas can be tested: Scientists can cross surface fish (with eyes) and cavefish (without eyes) and look at what their offspring are like. When that's done, Riddle says, researchers see no link between eye presence or size and the accumulation of carotenoids. Some eyeless cavefish had fat that was practically white, indicating lower carotenoid levels. Instead, Riddle thinks these carotenoids may be another adaptation to suppress inflammation, which might be important in the wild, as cavefish are likely overeating whenever food arrives.

 CAT 2025 Slot 2 - VA RC

 All of the following statements from the passage describe adaptation in Mexican tetra cavefish EXCEPT:

 "Since relatively little lives or grows in their caves, the fish are likely surviving on a meager diet of mostly bat feces and organic waste that washes in during the rainy season."

 "It's easy to see why cavefish would be at a disadvantage if they were to maintain expensive tissues they aren't using."

 "Even in their sparse cave conditions, wild cavefish can sometimes get very fat, says Riddle."

 "'But when these cells get too big, they can burst, which is why we often see chronic inflammation in humans and other animals that have stored a lot of fat in their tissues.'"

**ANSWER:** Choice D

### Q8

"'But when these cells get too big, they can burst, which is why we often see chronic inflammation in humans and other animals that have stored a lot of fat in their tissues.'"

 CAT 2025 Slot 2 - VA RC

 Which one of the following best explains why the "apparent inefficiency" is "unavoidable"?

 Mexican tetra cavefish are similar to non-cave-dwelling variants in their early stages of development.

 The inefficiency resulting from eyelessness is compensated by enhancements like more tastebuds in Mexican tetra cavefish.

 The lack of light in the caves kills the eye cells in the developing Mexican tetra cavefish embryo.

 The caves have poor and inconsistent availability of food and nutrition for Mexican tetra cavefish.

**ANSWER:** Choice A

### Q9

Mexican tetra cavefish are similar to non-cave-dwelling variants in their early stages of development.

 CAT 2025 Slot 2 - VA RC

 Which one of the following results for the cross between surface fish (with eyes) and cavefish (without eyes) would invalidate Riddle's inference from the experiment?

 Only eyeless offspring had yellow fat.

 Some offspring with eyes had white fat.

 Some eyeless offspring had white fat.

 Some offspring with eyes had yellow fat.

**ANSWER:** Choice A

### Q10

Only eyeless offspring had yellow fat.

 CAT 2025 Slot 2 - VA RC

 On the basis of the information in the passage, what is the most likely function of carotenoids in Mexican tetra cavefish?

 To help the fat cells store nutrients.

 To render bright yellow colour to the cavefish.

 To control inflammation from the bursting of fat cells.

 To act as a substitute for eyes.

**ANSWER:** Choice C

### Q11

To control inflammation from the bursting of fat cells.

 CAT 2025 Slot 2 - VA RC

 The four sentences (labelled 1, 2, 3, and 4) given below, when properly sequenced, would yield a coherent paragraph. Decide on the proper sequencing of the order of the sentences and key in the sequence of the four numbers as your answer.

1. As books age, the cellulose and lignin in the paper begin to break down, releasing a mix of volatile organic compounds into the air.
2. Old books carry a scent that many people instantly recognize—and even love.
3. These compounds are benzaldehyde, which gives off an almond-like scent, vanillin, which smells like vanilla, ethyl hexanol (floral scent), toluene (sweet), and furfural (which has a slightly bready scent).
4. This familiar aroma isn't just dust or mildew; it's actually a result of slow chemical changes happening inside the paper and ink.

**ANSWER:** 2413

### Q12

CAT 2025 Slot 2 - VA RC

 The given sentence is missing in the paragraph below. Decide where it best fits among the options 1, 2, 3, or 4 indicated in the paragraph.

Sentence- The region's Western customers found it hard to believe that Dhaka muslin could possibly have been made by human hands – there were rumour that it was woven by mermaids, fairies and even ghosts.

Once upon the silty banks of the Meghna River, a miracle was spun — a fabric so light it was called "baft-hawa", or woven air. This was Dhaka Muslin — the world's most coveted cloth. ____(1)____. Handspun from a rare cotton called Phuti Karpas, found nowhere else on Earth, and woven with a 16-step sacred ritual — beginning with cleaning the cotton using the teeth of a river catfish! ____(2)____. Every spring, the maple-like leaves pushed up through the grey, silty soil to produce a single daffodil-yellow flower twice a year, which gave way to a snowy floret of cotton fibres. ____(3)____. Spun at dawn on boats by sharp-eyed young women, its threads were so fine the elderly could barely see them. Motifs of wildflowers, river breeze, and soul were etched into each piece — some so light, a 91-metre bolt could pass through a ring, or a 60' length fit inside a snuffbox. It draped Greek goddesses, Roman nobles, Mughal emperors, and European aristocrats. Marie Antoinette, Empress Joséphine — even Jane Austen adored its floating grace. ____(4)____.

 Option 3

 Option 4

 Option 1

 Option 2

**ANSWER:** Choice C

### Q13

Option 1

 CAT 2025 Slot 2 - VA RC

 The passage given below is followed by four summaries. Choose the option that best captures the essence of the passage.

For millennia, in the process of opening up land for agriculture, gardens, grazing and hunting, humans have created ecological "mosaics", or "patchworks": landscapes holding a mixture of habitats, like meadows, gardens and forests. These were not designed as nature reserves, but often catered to hugely diverse animal life. Research indicates that European hay meadows cultivated for animal feed were actually more successful at preserving a vast array of species than meadows explicitly cultivated for biodiversity. Studying the early Holocene, researchers have found that human presence was about as likely to increase biodiversity as reduce it. Of course, not all human-created landscapes have the same value. A paved subdivision with astroturfed lawns is very different to a village with diverse vegetable and flower gardens. But scientists continue to find evidence that the old idea of humans as antithetical to nature is also wrong-headed, and that rosy visions of thriving, human-free environments are more imaginary than real.

 In our attempts to shape the world around us to our needs, humans have often created landscapes like meadows, gardens, and forests, which support hugely diverse species, and are more successful at preserving them, than parks created specifically for this.

 In terms of preserving biodiversity, scientists are finding increasing evidence that human action is not always antithetical to nature, but often assists the preservation of meadows, landscapes, and flourishing of species.

 Studying the early Holocene and human practices over millennia, researchers say that while agricultural meadows, gardens, and forests were not explicitly designed as nature reserves, they actually preserved a vast array of species, belying the idea that humans harm nature.

 Contrary to the idea that humans always hurt nature and that it thrives in their absence, a lot of human action across history has been equally likely to increase biodiversity than reduce it, often creating varied ecological landscapes that support a vast array of species.

**ANSWER:** Choice D

### Q14

Contrary to the idea that humans always hurt nature and that it thrives in their absence, a lot of human action across history has been equally likely to increase biodiversity than reduce it, often creating varied ecological landscapes that support a vast array of species.

 CAT 2025 Slot 2 - VA RC

 The passage given below is followed by four summaries. Choose the option that best captures the essence of the passage.

In 1903, left-wing feminist Elizabeth Magie invented The Landlord's Game, the original version of what became Monopoly. It was designed as a powerful teaching tool to illustrate the dangers of monopolies and how wealth could concentrate in the hands of a few. The game featured a circular path, properties, and a "Go to Jail" space. Magie created two rule sets: one "monopolist" version where players crushed opponents through accumulation, and another, more radical "Prosperity" version, where everyone shared in the wealth, promoting fairness and equity. Years later, unemployed Charles Darrow sold a simplified version to Parker Brothers. They paid Magie only $500 for her patent—without royalties—and credited Darrow as the sole inventor. For decades, his tale of inventing the game in his basement remained the official story, while Magie's name and her original, anti-capitalist message were left in the shadows.

 Parker Brothers' capitalist intent led to them acquiring from Charles Darrow a simplified version of Elizabeth Magie's original game, transforming it into a widespread commercial success while providing her only minimal financial compensation and granting scant public recognition.

 Celebrated icons of the gaming industry, Charles Darrow and Parker Brothers, snatched the feminist icon Elizabeth Magie's original design and transformed Monopoly into a worldwide phenomenon, while barely acknowledging her.

 It is ironical that a left-wing feminist lost credit for the Landlord's Game to an unemployed man, who plagiarised and sold one version of the twin game to Parker Brothers for a meagre sum, denying her royalties.

 Only one version of Monopoly became famous because of Charles Darrow's relentless basement work, carefully refining Elizabeth Magie's original idea into an engaging and entertaining pastime that he successfully patented and sold, symbolizing what many regarded as the ultimate triumph of individual ingenuity.

**ANSWER:** Choice C

### Q15

It is ironical that a left-wing feminist lost credit for the Landlord's Game to an unemployed man, who plagiarised and sold one version of the twin game to Parker Brothers for a meagre sum, denying her royalties.

 CAT 2025 Slot 2 - VA RC

 Five jumbled sentences (labelled 1, 2, 3, 4, and 5), related to a topic, are given below. Four of them can be put together to form a coherent paragraph. Identify the odd sentence out and key in the number of that sentence as your answer.

1. Pfas are a class of about 15,000 compounds most frequently used to make products water-, stain- and grease-resistant.
2. New research suggests exposure to some common perfluoroalkyl and polyfluoroalkyl substances (Pfas) cause changes to gene activity and that these changes are linked to health problems including multiple cancers, neurological disorders and autoimmune disease.
3. These Pfas compounds are dubbed "forever chemicals" because they do not naturally break down in the environment.
4. The research may also point toward other diseases potentially caused by Pfas that have not yet been identified.
5. The findings are a major step toward determining the mechanism by which the chemicals cause disease and could help doctors identify, detect and treat health problems for those exposed to Pfas before the issues advance.

**ANSWER:** 3

### Q16

The passage below is accompanied by four questions. Based on the passage, choose the best answer for each question.

In [my book "Searches"], I chronicle how big technology companies have exploited human language for their gain. We let this happen, I argue, because we also benefit somewhat from using the products. It's a dynamic that makes us complicit in big tech's accumulation of wealth and power: we're both victims and beneficiaries. I describe this complicity, but I also enact it, through my own internet archives: my Google searches, my Amazon product reviews and, yes, my ChatGPT dialogues. . . .

People often describe chatbots' textual output as "bland" or "generic" – the linguistic equivalent of a beige office building. OpenAI's products are built to "sound like a colleague", as OpenAI puts it, using language that, coming from a person, would sound "polite", "empathetic", "kind", "rationally optimistic" and "engaging", among other qualities. OpenAI describes these strategies as helping its products seem "professional" and "approachable". This appears to be bound up with making us feel safe . . .

Trust is a challenge for artificial intelligence (AI) companies, partly because their products regularly produce falsehoods and reify sexist, racist, US-centric cultural norms. While the companies are working on these problems, they persist: OpenAI found that its latest systems generate errors at a higher rate than its previous system. In the book, I wrote about the inaccuracies and biases and also demonstrated them with the products. When I prompted Microsoft's Bing Image Creator to produce a picture of engineers and space explorers, it gave me an entirely male cast of characters; when my father asked ChatGPT to edit his writing, it transmuted his perfectly correct Indian English into American English. Those weren't flukes. Research suggests that both tendencies are widespread.

In my own ChatGPT dialogues, I wanted to enact how the product's veneer of collegial neutrality could lull us into absorbing false or biased responses without much critical engagement. Over time, ChatGPT seemed to be guiding me to write a more positive book about big tech – including editing my description of OpenAI's CEO, Sam Altman, to call him "a visionary and a pragmatist". I'm not aware of research on whether ChatGPT tends to favor big tech, OpenAI or Altman, and I can only guess why it seemed that way in our conversation. OpenAI explicitly states that its products shouldn't attempt to influence users' thinking. When I asked ChatGPT about some of the issues, it blamed biases in its training data – though I suspect my arguably leading questions played a role too. When I queried ChatGPT about its rhetoric, it responded: "The way I communicate is designed to foster trust and confidence in my responses, which can be both helpful and potentially misleading.". . .

OpenAI has its own goals, of course. Among them, it emphasizes wanting to build AI that "benefits all of humanity". But while the company is controlled by a non-profit with that mission, its funders still seek a return on their investment. That will presumably require getting people using products such as ChatGPT even more than they already are – a goal that is easier to accomplish if people see those products as trustworthy collaborators.

 CAT 2025 Slot 2 - VA RC

 All of the following statements from the passage affirm the disjunct between the claims about AI made by tech companies and what AI actually does EXCEPT:

 "In my own ChatGPT dialogues, I wanted to enact how the product's veneer of collegial neutrality could lull us into absorbing false or biased responses without much critical engagement."

 "When I prompted Microsoft's Bing Image Creator to produce a picture of engineers and space explorers, it gave me an entirely male cast of characters . . ."

 "It's a dynamic that makes us complicit in big tech's accumulation of wealth and power: we're both victims and beneficiaries."

 "I'm not aware of research on whether ChatGPT tends to favor big tech, OpenAI or Altman, and I can only guess why it seemed that way in our conversation."

**ANSWER:** Choice D

### Q17

"I'm not aware of research on whether ChatGPT tends to favor big tech, OpenAI or Altman, and I can only guess why it seemed that way in our conversation."

 CAT 2025 Slot 2 - VA RC

 The author compares AI-generated texts with "a beige office building" for all of the following reasons EXCEPT:

 AI-generated texts often exhibit a warm, polite, and collegial tone.

 AI aims to foster a feeling of trust and credibility among its users.

 AI generates generalised responses that lack specificity and nuance.

 AI tends to blame its training data when scrutinised for its biases.

**ANSWER:** Choice D

### Q18

AI tends to blame its training data when scrutinised for its biases.

 CAT 2025 Slot 2 - VA RC

 On the basis of the purpose of the examples in the passage, pick the odd one out from the following AI-generated responses mentioned in the passage:

 "Over time, ChatGPT seemed to be guiding me to write a more positive book about big tech – including editing my description of OpenAI's CEO, Sam Altman, to call him 'a visionary and a pragmatist'."

 ". . . when my father asked ChatGPT to edit his writing, it transmuted his perfectly correct Indian English into American English."

 "When I prompted Microsoft's Bing Image Creator to produce a picture of engineers and space explorers, it gave me an entirely male cast of characters . . ."

 "When I queried ChatGPT about its rhetoric, it responded: 'The way I communicate is designed to foster trust and confidence in my responses, which can be both helpful and potentially misleading'."

**ANSWER:** Choice D

### Q19

"When I queried ChatGPT about its rhetoric, it responded: 'The way I communicate is designed to foster trust and confidence in my responses, which can be both helpful and potentially misleading'."

 CAT 2025 Slot 2 - VA RC

 The author of the passage is least likely to agree with which one of the following claims?

 ChatGPT favours AI companies and their officials, like Sam Altman, in its responses.

 The neutrality of AI is motivated by economic considerations.

 When we use AI, we become accomplices to the exploitative practices of big tech companies.

 The neutrality of AI is conducive to critical thinking.

**ANSWER:** Choice D

### Q20

The neutrality of AI is conducive to critical thinking.

 The passage below is accompanied by four questions. Based on the passage, choose the best answer for each question.

Different sciences exhibit different science cultures and practices. For example, in astronomy, observation – until what is today called the new astronomy – had always been limited to what could be seen within the limits of optical light. Indeed, until early modernity the limits to optical light were also limits of what humans could themselves see within their limited and relative perceptual spectrum of human vision. With early modernity and the invention of lensed optical instruments – telescopes – astronomers could begin to observe phenomena never seen before. Magnification and resolution began to allow what was previously imperceptible to be perceived – but within the familiar limits of optical vision. Galileo, having learned of the Dutch invention of a telescope by Hans Lippershey, went on to build some hundred of his own, improving from the Dutch 3x to nearly 30x telescopes – which turn out to be the limit of magnificational power without chromatic distortion. And it was with his own telescopes that he made the observations launching early modern astronomy (phases of Venus, satellites of Jupiter, etc.). Isaac Newton's later improvement with reflecting telescopes expanded upon the magnificational-resolution capacity of optical observation; and, from Newton to the twentieth century, improvement continued on to the later very large array of light telescopes today – following the usual technological trajectory of "more-is-better" but still remaining within the limits of the light spectrum. Today's astronomy has now had the benefit of some four centuries of optical telescopy. The "new astronomy," however, opens the full known electromagnetic spectrum to observation, beginning with the accidental discovery of radio astronomy early in the twentieth century, and leading today to the diverse variety of EMS telescopes which can explore the range from gamma to radio waves. Thus, astronomy, now outfitted with new instruments, "smart" adaptive optics, very large arrays, etc., illustrates one style of instrumentally embodied science – a technoscience. Of course astronomy, with the very recent exceptions of probes to solar system bodies (Moon, Mars, Venus, asteroids), remains largely a "receptive" science, dependent upon instrumentation which can detect and receive emissions.

Contemporary biology displays a quite different instrument array and, according to Evelyn Fox-Keller, also a different scientific culture. She cites her own experience, coming from mathematical physics into microbiology, and takes account of the distinctive instrumental culture in her Making Sense of Life (2002). Here, particularly with the development of biotechnology, instrumentation is far more interventional than in the astronomy case. Microscopic instrumentation can be and often is interventional in style: "gene-splicing" and other techniques of biotechnology, while still in their infancy, are clearly part of the interventional trajectory of biological instrumentation. Yet, in both disciplines, the sciences involved are today highly instrumentalized and could not progress successfully without constant improvements upon the respective instrumental trajectories. So, minimalistically, one may conclude that the sciences are technologically, instrumentally embodied. But the styles of embodiment differ, and perhaps the last of the scientific disciplines to move into such technical embodiment is mathematics, which only contemporarily has come to rely more and more upon the computational machinery now in common use.

 CAT 2025 Slot 2 - VA RC

 None of the following statements, if true, contradicts the arguments in the passage EXCEPT:

 Isaac Newton's discovery of gravity was accomplished without the help of instruments.

 because of the relatively recent entry of computational machinery in mathematics, the field is only now beginning to develop a scientific culture.

 like telescopy, microscopy has also sought to move beyond the visible spectrum to be able to detect objects that are invisible in that spectrum.

 some scientific instruments may be classified as both receptive and interventional in their functions.

**ANSWER:** Choice B

### Q21

because of the relatively recent entry of computational machinery in mathematics, the field is only now beginning to develop a scientific culture.

 CAT 2025 Slot 2 - VA RC

 All of the following statements may be rejected as valid inferences from the passage EXCEPT:

 Isaac Newton's experiments with reflecting telescopes were the earliest versions of the "new astronomy" referred to in the passage.

 interventionist instruments, or instruments that intervene directly in scientific inquiry, are different from embodied instruments, or instruments that embody scientific inquiry.

 the author distinguishes between the receptive and interventionist uses of instruments in the sciences by comparing astronomy and biology, respectively.

 the advances in telescopy made by Newton with reflecting telescopes allowed early modern astronomers to observe the phases of Venus and the satellites of Jupiter.

**ANSWER:** Choice C

### Q22

the author distinguishes between the receptive and interventionist uses of instruments in the sciences by comparing astronomy and biology, respectively.

 CAT 2025 Slot 2 - VA RC

 Which one of the following observations is a valid conclusion to draw from the statement that "the sciences involved are today highly instrumentalised and could not progress successfully without constant improvements upon the respective instrumental trajectories"?

 The use of instruments in scientific trajectories must be respected in order to see successful progress in them.

 In both astronomy and microbiology, progress has been the consequence of improvements in the instruments they use.

 The growth of scientific technologies has led to the embodiment of progress in the trajectories of improvement.

 Highly instrumentalised work in the sciences has resulted in the progressive improvement of scientific constants.

**ANSWER:** Choice B

### Q23

In both astronomy and microbiology, progress has been the consequence of improvements in the instruments they use.

 CAT 2025 Slot 2 - VA RC

 To which one of the following instruments would the characterisations of instruments in the passage be least applicable?

 Milestone

 Scalpel

 Kitchen oven

 Saxophone

**ANSWER:** Choice A

### Q24

Milestone

 CAT 2025 Slot 2 - VA RC

 The four sentences (labelled 1, 2, 3, and 4) given below, when properly sequenced, would yield a coherent paragraph. Decide on the proper sequencing of the order of the sentences and key in the sequence of the four numbers as your answer.

1. 'Literature on screen' suggests something more capacious and defining than citation: the possibility that literary adaptations are at once cinema and literature.
2. Even though a growing number of films eligible for Academy Awards for Best Screenplay Based on Material from Another Medium borrow that material from print journalism, franchise characters, television series, comic books, video games and toys, academic studies of adaptation remain stubbornly attached to literature as cinema's natural progenitor.
3. It is as if adaptation studies, by borrowing the cultural cachet of literature, sought to claim its institutional respectability and gravitas even while insuring adaptation's enduring aesthetic and methodological subordination to literature proper.
4. Beneath this contradictory notion of film adaptations as not merely hybrid texts but texts holding dual citizenship in two modes of presentation is an even more pervasive legacy that haunts adaptation studies: the assumption that the primary context within which adaptations are to be studied is literature.

**ANSWER:** 1423
