# CAT 2022 — Slot 1 — DILR (Questions + On-page Answer Key)

Answers are on-page 2IIM **Correct Answer** labels. Not invented.

## DILR

- Source file: `2iim-html/CAT-2022-Question-Paper-Slot-1-DILR.txt`
- Page: https://online.2iim.com/CAT-question-paper/CAT-2022-Question-Paper-Slot-1-DILR/
- On-page answers found: 20
- Answer source: 2IIM on-page **Correct Answer** / **Correct Answer Choice** (not invented)

### Q1

C AT DI LR section has become increasingly tough beginning from 2015. DILR used to have distinct Data Interpretation sets and Logical reasoning puzzles. It used to be about computation and ability to read charts, graphs and tables for the Data Interpretation and Logical reasoning used to have Family tree, grid puzzles, arrangement, tournaments, cubes as some standard forms of puzzles.Since 2015 this pattern has been broken. With passing years, even the distinction between DI and LR has come down significantly. All you get in that one hour, are 8 high quality puzzles, with more than a few of them being significantly tough. Between CAT 2017 Question paper to CAT 2022 Question paper, you get to solve 90 actual CAT puzzles. This page intends to provide you just that. So, head on and crack those puzzles!

 There are 15 girls and some boys among the graduating students in a class. They are planning a get-together, which can be either a 1-day event, or a 2-day event, or a 3-day event. There are 6 singers in the class, 4 of them are boys. There are 10 dancers in the class, 4 of them are girls. No dancer in the class is a singer.

Some students are not interested in attending the get-together. Those students who are interested in attending a 3-day event are also interested in attending a 2-day event; those who are interested in attending a 2-day event are also interested in attending a 1-day event.

The following facts are also known:

1. All the girls and 80% of the boys are interested in attending a 1-day event. 60% of the boys are interested in attending a 2-day event.
2. Some of the girls are interested in attending a 1-day event, but not a 2-day event; some of the other girls are interested in attending both.
3. 70% of the boys who are interested in attending a 2-day event are neither singers nor dancers. 60% of the girls who are interested in attending a 2-day event are neither singers nor dancers.
4. No girl is interested in attending a 3-day event. All male singers and 2 of the dancers are interested in attending a 3-day event.
5. The number of singers interested in attending a 2-day event is one more than the number of dancers interested in attending a 2-day event.

 CAT 2022 Slot 1 - DI LR

 How many boys are there in the class?

**ANSWER:** 50

### Q2

CAT 2022 Slot 1 - DI LR

 Which of the following can be determined from the given information?

I. The number of boys who are interested in attending a 1-day event and are neither dancers nor singers.
II. The number of female dancers who are interested in attending a 1-day event.

 Neither I nor II

 Both I and II

 Only I

 Only II

**ANSWER:** Choice D

### Q3

Only II

 CAT 2022 Slot 1 - DI LR

 What fraction of the class are interested in attending a 2-day event?

 7/10

 9/13

 7/13

 2/3

**ANSWER:** Choice C

### Q4

7/13

 CAT 2022 Slot 1 - DI LR

 What BEST can be concluded about the number of male dancers who are interested in attending a 1-day event?

 5 or 6

 4 or 6

 5

 6

**ANSWER:** Choice A

### Q5

5 or 6

 CAT 2022 Slot 1 - DI LR

 How many female dancers are interested in attending a 2-day event?

 0

 2

 Cannot be determined

 1

**ANSWER:** Choice A

### Q6

0

Given above is the schematic map of the metro lines in a city with rectangles denoting terminal stations (e.g. A), diamonds denoting junction stations (e.g. R) and small filled-up circles denoting other stations. Each train runs either in east-west or north-south direction, but not both. All trains stop for 2 minutes at each of the junction stations on the way and for 1 minute at each of the other stations. It takes 2 minutes to reach the next station for trains going in east-west direction and 3 minutes to reach the next station for trains going in north-south direction. From each terminal station, the first train starts at 6 am; the last trains leave the terminal stations at midnight. Otherwise, during the service hours, there are metro service every 15 minutes in the north-south lines and every 10 minutes in the east-west lines. A train must rest for at least 15 minutes after completing a trip at the terminal station, before it can undertake the next trip in the reverse direction. (All questions are related to this metro service only. Assume that if someone reaches a station exactly at the time a train is supposed to leave, (s)he can catch that train.)

 CAT 2022 Slot 1 - DI LR

 If Hari is ready to board a train at 8:05 am from station M, then when is the earliest that he can reach station N?

 9:01 am

 9:13 am

 9:06 am

 9:11 am

**ANSWER:** Choice D

### Q7

9:11 am

 CAT 2022 Slot 1 - DI LR

 If Priya is ready to board a train at 10:25 am from station T, then when is the earliest that she can reach station S?

 11:22 am

 11:28 am

 11:12 am

 11:07 am

**ANSWER:** Choice C

### Q8

11:12 am

 CAT 2022 Slot 1 - DI LR

 Haripriya is expected to reach station S late. What is the latest time by which she must be ready to board at station S if she must reach station B before 1 am via station R?

 11:35 pm

 11:39 pm

 11:43 pm

 11:49 am

**ANSWER:** Choice B

### Q9

11:39 pm

 CAT 2022 Slot 1 - DI LR

 What is the minimum number of trains that are required to provide the service on the AB line (considering both north and south directions)?

**ANSWER:** 8

### Q10

CAT 2022 Slot 1 - DI LR

 What is the minimum number of trains that are required to provide the service in this city?

**ANSWER:** 48

### Q11

The management of a university hockey team was evaluating performance of four women players - Amla, Bimla, Harita and Sarita for their possible selection in the university team for next year. For this purpose, the management was looking at the number of goals scored by them in the past 8 matches, numbered 1 through 8. The four players together had scored a total of 12 goals in these matches. In the 8 matches, each of them had scored at least one goal. No two players had scored the same total number of goals.

The following facts are known about the goals scored by these four players only. All the questions refer only to the goals scored by these four players.

1. Only one goal was scored in every even numbered match.
2. Harita scored more goals than Bimla.
3. The highest goal scorer scored goals in exactly 3 matches including Match 4 and Match 8.
4. Bimla scored a goal in Match 1 and one each in three other consecutive matches.
5. An equal number of goals were scored in Match 3 and Match 7, which was different from the number of goals scored in either Match 1 or Match 5.
6. The match in which the highest number of goals was scored was unique and it was not Match 5.

 CAT 2022 Slot 1 - DI LR

 How many goals were scored in Match 7?

 3

 Cannot be determined

 2

 1

**ANSWER:** Choice D

### Q12

1

 CAT 2022 Slot 1 - DI LR

 Which of the following is the correct sequence of goals scored in matches 1, 3, 5 and 7?

 3, 1, 2, 1

 4, 1, 2, 1

 5, 1, 0, 1

 3, 2, 1, 2

**ANSWER:** Choice B

### Q13

4, 1, 2, 1

 CAT 2022 Slot 1 - DI LR

 Which of the following statement(s) is/are true?

Statement-1: Amla and Sarita never scored goals in the same match.
Statement-2: Harita and Sarita never scored goals in the same match.

 Statement-1 only

 Both the statements

 None of the statements

 Statement-2 only

**ANSWER:** Choice B

### Q14

Both the statements

 CAT 2022 Slot 1 - DI LR

 Which of the following statement(s) is/are false?

Statement-1: In every match at least one player scored a goal.
Statement-2: No two players scored goals in the same number of matches.

 None of the statements

 Statement-1 only

 Statement-2 only

 Both the statements

**ANSWER:** Choice A

### Q15

None of the statements

 CAT 2022 Slot 1 - DI LR

 If Harita scored goals in one more match as compared to Sarita, which of the following statement(s) is/are necessarily true?

Statement-1: Amla scored goals in consecutive matches.
Statement-2: Sarita scored goals in consecutive matches.

 None of the statements

 Statement-1 only

 Both the statements

 Statement-2 only

**ANSWER:** Choice A

### Q16

None of the statements

 Adhara, Bithi, Chhaya, Dhanavi, Esther, and Fathima are the interviewers in a process that awards funding for new initiatives. Every interviewer individually interviews each of the candidates individually and awards a token only if she recommends funding. A token has a face value of 2, 3, 5, 7, 11, or 13. Each interviewer awards tokens of a single face value only. Once all six interviews are over for a candidate, the candidate receives a funding that is Rs.1000 times the product of the face values of all the tokens. For example, if a candidate has tokens with face values 2, 5, and 7, then they get a funding of Rs.1000 × (2 × 5 × 7) = Rs.70,000.
 Pragnyaa, Qahira, Rasheeda, Smera, and Tantra were five candidates who received funding. The funds they received, in descending order, were Rs.390,000, Rs.210,000, Rs.165,000, Rs.77,000, and Rs.66,000.

The following additional facts are known:
 1. Fathima awarded tokens to everyone except Qahira, while Adhara awarded tokens to no one except Pragnyaa.
2. Rashida received the highest number of tokens that anyone received, but she did not receive one from Esther.
3. Bithi awarded a token to Smera but not to Qahira, while Dhanavi awarded a token to Qahira but not to Smera.

 CAT 2022 Slot 1 - DI LR

 How many tokens did Qahira receive?

**ANSWER:** 2

### Q17

CAT 2022 Slot 1 - DI LR

 Who among the following definitely received a token from Bithi but not from Dhanavi?

 Qahira

 Tantra

 Pragnyaa

 Rasheeda

**ANSWER:** Choice C

### Q18

Pragnyaa

 CAT 2022 Slot 1 - DI LR

 How many tokens did Chhaya award?

**ANSWER:** 3

### Q19

CAT 2022 Slot 1 - DI LR

 How many tokens did Smera receive?

**ANSWER:** 3

### Q20

CAT 2022 Slot 1 - DI LR

 Which of the following could be the amount of funding that Tantra received?
 (a) Rs. 66,000
 (b) Rs. 165,000

 Neither (a) nor (b)

 Only (a)

 Both (a) and (b)

 Only (b)

**ANSWER:** Choice C
