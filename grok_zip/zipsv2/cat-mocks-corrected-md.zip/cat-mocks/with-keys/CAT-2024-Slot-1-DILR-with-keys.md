# CAT 2024 — Slot 1 — DILR (Questions + On-page Answer Key)

Answers are on-page 2IIM **Correct Answer** labels. Not invented.

## DILR

- Source file: `2iim-html/CAT-2024-Question-Paper-Slot-1-DILR.txt`
- Page: https://online.2iim.com/CAT-question-paper/CAT-2024-Question-Paper-Slot-1-DILR/
- On-page answers found: 22
- Answer source: 2IIM on-page **Correct Answer** / **Correct Answer Choice** (not invented)

### Q1

Six web surfers M, N, O, P, X, and Y each had 30 stars which they distributed
 among four bloggers A, B, C, and D. The number of stars received by A and B from the six web
 surfers is shown in the figure below.

The following additional facts are known regarding the number
 of stars received by the bloggers from the surfers.

1. The numbers of stars
 received by the bloggers from the surfers were all multiples of 5 (including 0).
2. The
 total numbers of stars received by the bloggers were the same.
3. Each blogger received
 a different number of stars from M.
4. Two surfers gave all their stars to a single
 blogger.
5. D received more stars than C from Y.

 CAT 2024 Slot 1 - DI LR

 What was the total number of stars received by D?

**ANSWER:** 45

### Q2

CAT 2024 Slot 1 - DI LR

 What was the number of stars received by D from Y?

 5

 cannot be determined

 0

 10

**ANSWER:** Choice A

### Q3

5

 CAT 2024 Slot 1 - DI LR

 How many surfers distributed their stars among exactly 2 bloggers?

**ANSWER:** 2

### Q4

CAT 2024 Slot 1 - DI LR

 Which of the following can be determined with certainty?

1)The number of
 stars received by C from M
2) The number of stars received by D from O

 Neither I nor II

 Only I

 Only II

 Both I and II

**ANSWER:** Choice B

### Q5

Only I

 The chart below provides complete information about the number of countries
 visited by Dheeraj, Samantha and Nitesh, in Asia, Europe and the rest of the world
 (ROW).

The following additional facts are known about the countries visited
 by them.

1. 32 countries were visited by at least one of them.
2. USA (in
 ROW) is the only country that was visited by all three of them.
3. China (in Asia) is
 the only country that was visited by both Dheeraj and Nitesh, but not by Samantha.
4.
 France (in Europe) is the only country outside Asia, which was visited by both Dheeraj and
 Samantha, but not by Nitesh.
5. Half of the countries visited by both Samantha and
 Nitesh are in Europe.

 CAT 2024 Slot 1 - DI LR

 How many countries in Asia were visited by at least one of Dheeraj, Samantha and Nitesh?

**ANSWER:** 3

### Q6

CAT 2024 Slot 1 - DI LR

 How many countries in Europe were visited only by Nitesh?

**ANSWER:** 2

### Q7

CAT 2024 Slot 1 - DI LR

 How many countries in the ROW were visited by both Nitesh and Samantha?

**ANSWER:** 4

### Q8

CAT 2024 Slot 1 - DI LR

 How many countries in Europe were visited by exactly one of Dheeraj, Samantha and Nitesh?

 12

 14

 10

 5

**ANSWER:** Choice A

### Q9

12

 The game of QUIET is played between two teams. Six teams, numbered 1, 2, 3, 4,
 5, and 6, play in a QUIET tournament. These teams are divided equally into two groups. In
 the tournament, each team plays every other team in the same group only once, and each team
 in the other group exactly twice. The tournament has several rounds, each of which consists
 of a few games. Every team plays exactly one game in each round.

The following
 additional facts are known about the schedule of games in the tournament.
1. Each team
 played against a team from the other group in Round 8.
2. In Round 4 and Round 7, the
 match-ups, that is the pair of teams playing against each other, were identical. In Round 5
 and Round 8, the match-ups were identical.
3. Team 4 played Team 6 in both Round 1 and
 Round 2.
4. Team 1 played Team 5 ONLY once and that was in Round 2.
5. Team 3
 played Team 4 in Round 3. Team 1 played Team 6 in Round 6.
6. In Round 8, Team 3
 played Team 6, while Team 2 played Team 5.

 CAT 2024 Slot 1 - DI LR

 How many rounds were there in the tournament?

**ANSWER:** 8

### Q10

CAT 2024 Slot 1 - DI LR

 What is the number of the team that played Team 1 in Round 5?

**ANSWER:** 4

### Q11

CAT 2024 Slot 1 - DI LR

 Which team among the teams numbered 2, 3, 4, and 5 was not part of the same group?

 5

 2

 4

 3

**ANSWER:** Choice A

### Q12

5

 CAT 2024 Slot 1 - DI LR

 What is the number of the team that played Team 1 in Round 7?

**ANSWER:** 3

### Q13

CAT 2024 Slot 1 - DI LR

 What is the number of the team that played Team 6 in Round 3?

**ANSWER:** 5

### Q14

The chart below shows the price data for seven shares – A, B, C, D, E, F, and G
 as a candlestick plot for a particular day. The vertical axis shows the price of the share
 in rupees. A share whose closing price (price at the end of the day) is more than its
 opening price (price at the start of the day) is called a bullish share; otherwise, it is
 called a bearish share. All bullish and bearish shares are shown in green and red colour
 respectively.

 CAT 2024 Slot 1 - DI LR

 Daily Share Price Variability (SPV) is defined as (Day's high price - Day's low price) /
 (Average of the opening and closing prices during the day). Which among the shares A, C,
 D and F had the highest SPV on that day?

 A

 F

 D

 C

**ANSWER:** Choice C

### Q15

D

 CAT 2024 Slot 1 - DI LR

 Daily Share Price Variability (SPV) is defined as (Day's high price - Day's low price) /
 (Average of the opening and closing prices during the day). How many shares had an SPV
 greater than 0.5 on that day?

**ANSWER:** 4

### Q16

CAT 2024 Slot 1 - DI LR

 Daily loss for a share is defined as (Opening price – Closing price) / (Opening price).
 Which among the shares A, B, F and G had the highest daily loss on that day?

 B

 G

 F

 A

**ANSWER:** Choice D

### Q17

A

 CAT 2024 Slot 1 - DI LR

 What would have been the percentage wealth gain for a trader, who bought equal numbers of
 all bullish shares at opening price and sold them at their day's high?

**ANSWER:** Choice B

### Q18

Two students, Amiya and Ramya are the only candidates in an election for the
 position of class representative. Students will vote based on the intensity level of Amiya's
 and Ramya's campaigns and the type of campaigns they run. Each campaign is said to have a
 level of 1 if it is a staid campaign and a level of 2 if it is a vigorous campaign.
 Campaigns can be of two types, they can either focus on issues, or on attacking the other
 candidate.

If Amiya and Ramya both run campaigns focusing on issues, then

• The percentage of students voting in the election will be 20 times the sum of the
 levels of campaigning of the two students. For example, if Amiya and Ramya both run vigorous
 campaigns, then 20 × (2+2)%, that is, 80% of the students will vote in the
 election.
• Among voting students, the percentage of votes for each candidate will be
 proportional to the levels of their campaigns. For example, if Amiya runs a staid (i.e.,
 level 1) campaign while Ramya runs a vigorous (i.e., level 2) campaign, then Amiya will
 receive 1/3 of the votes cast, and Ramya will receive the other 2/3.

The
 above-mentioned percentages change as follows if at least one of them runs a campaign
 attacking their opponent.
• If Amiya runs a campaign attacking Ramya and Ramya runs a
 campaign focusing on issues, then 10% of the students who would have otherwise voted for
 Amiya will vote for Ramya, and another 10% who would have otherwise voted for Amiya, will
 not vote at all.
• If Ramya runs a campaign attacking Amiya and Amiya runs a campaign
 focusing on issues, then 20% of the students who would have otherwise voted for Ramya will
 vote for Amiya, and another 5% who would have otherwise voted for Ramya, will not vote at
 all.
• If both run campaigns attacking each other, then 10% of the students who would
 have otherwise voted for them had they run campaigns focusing on issues, will not vote at
 all.

 CAT 2024 Slot 1 - DI LR

 If both of them run staid campaigns attacking the other, then what percentage of students
 will vote in the election?

**ANSWER:** Choice D

### Q19

CAT 2024 Slot 1 - DI LR

 What is the minimum percentage of students who will vote in the election?

**ANSWER:** Choice B

### Q20

CAT 2024 Slot 1 - DI LR

 If Amiya runs a campaign focusing on issues, then what is the maximum percentage of votes
 that she can get?

**ANSWER:** Choice A

### Q21

CAT 2024 Slot 1 - DI LR

 If Ramya runs a campaign attacking Amiya, then what is the minimum percentage of votes
 that she is guaranteed to get?

**ANSWER:** Choice A

### Q22

CAT 2024 Slot 1 - DI LR

 What is the maximum possible voting margin with which one of the candidates can win?

**ANSWER:** Choice D
