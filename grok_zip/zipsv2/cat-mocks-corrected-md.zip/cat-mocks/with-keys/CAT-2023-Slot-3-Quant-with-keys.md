# CAT 2023 — Slot 3 — Quantitative Ability (Questions + On-page Answer Key)

Answers are on-page 2IIM **Correct Answer** labels. Not invented.

## Quantitative Ability

- Source file: `2iim-html/CAT-2023-Question-Paper-Slot-3-Quant.txt`
- Page: https://online.2iim.com/CAT-question-paper/CAT-2023-Question-Paper-Slot-3-Quant/
- On-page answers found: 22
- Answer source: 2IIM on-page **Correct Answer** / **Correct Answer Choice** (not invented)

### Q1

CAT 2023 Slot 3 - QA

 For a real number \(x\), if \(\frac{1}{2}, \frac{\log _3\left(2^x-9\right)}{\log _3 4}\), and \(\frac{\log _5\left(2^x+\frac{17}{2}\right)}{\log _5 4}\) are in an arithmetic progression, then the common difference is

 \(\log _4 7\)

 \(\log _4\left(\frac{3}{2}\right)\)

 \(\log _4\left(\frac{7}{2}\right)\)

 \(\log _4\left(\frac{23}{2}\right)\)

**ANSWER:** Choice C

### Q2

\(\log _4\left(\frac{7}{2}\right)\)

 CAT 2023 Slot 3 - QA

 Let \(n\) and \(m\) be two positive integers such that there are exactly 41 integers greater than \(8^m\) and less than \(8^n\), which can be expressed as powers of 2 . Then, the smallest possible value of \(n+m\) is

 14

 42

 16

 44

**ANSWER:** Choice C

### Q3

16

 CAT 2023 Slot 3 - QA

 For some real numbers \(a\) and \(b\), the system of equations \(x+y=4\) and \((a+5) x+\left(b^2-15\right) y=8 b\) has infinitely many solutions for \(x\) and \(y\). Then, the maximum possible value of \(a b\) is

 15

 33

 55

 25

**ANSWER:** Choice B

### Q4

33

 CAT 2023 Slot 3 - QA

 If \(x\) is a positive real number such that \(x^8+\left(\frac{1}{x}\right)^8=47\), then the value of \(x^9+\left(\frac{1}{x}\right)^9\) is

 \(40 \sqrt{5}\)

 \(36 \sqrt{5}\)

 \(30 \sqrt{5}\)

 \(34 \sqrt{5}\)

**ANSWER:** Choice D

### Q5

\(34 \sqrt{5}\)

 CAT 2023 Slot 3 - QA

 A quadratic equation \(x^2+b x+c=0\) has two real roots. If the difference between the reciprocals of the roots is \(\frac{1}{3}\), and the sum of the reciprocals of the squares of the roots is \(\frac{5}{9}\), then the largest possible value of \((b+c)\) is

**ANSWER:** 9

### Q6

CAT 2023 Slot 3 - QA

 The sum of the first two natural numbers, each having 15 factors (including 1 and the number itself), is

**ANSWER:** 468

### Q7

CAT 2023 Slot 3 - QA

 Let \(n\) be any natural number such that \(5^{n-1} \lt 3^{n+1}\). Then, the least integer value of \(m\) that satisfies \(3^{n+1} \lt 2^{n+m}\) for each such \(n\), is

**ANSWER:** 5

### Q8

CAT 2023 Slot 3 - QA

 Rahul, Rakshita and Gurmeet, working together, would have taken more than 7 days to finish a job. On the other hand, Rahul and Gurmeet, working together would have taken less than 15 days to finish the job. However, they all worked together for 6 days, followed by Rakshita, who worked alone for 3 more days to finish the job. If Rakshita had worked alone on the job then the number of days she would have taken to finish the job, cannot be

 17

 21

 16

 20

**ANSWER:** Choice B

### Q9

21

 CAT 2023 Slot 3 - QA

 Anil mixes cocoa with sugar in the ratio 3 : 2 to prepare mixture A, and coffee with sugar in the ratio 7 : 3 to prepare mixture B. He combines mixtures A and B in the ratio 2 : 3 to make a new mixture C. If he mixes C with an equal amount of milk to make a drink, then the percentage of sugar in this drink will be

 21

 24

 16

 17

**ANSWER:** Choice D

### Q10

17

 CAT 2023 Slot 3 - QA

 The population of a town in 2020 was 100000 . The population decreased by \(y \%\) from the year 2020 to 2021 , and increased by \(x \%\) from the year 2021 to 2022, where \(x\) and \(y\) are two natural numbers. If population in 2022 was greater than the population in 2020 and the difference between \(x\) and \(y\) is 10 , then the lowest possible population of the town in 2021 was

 74000

 75000

 72000

 73000

**ANSWER:** Choice D

### Q11

73000

 CAT 2023 Slot 3 - QA

 A merchant purchases a cloth at a rate of Rs.100 per meter and receives 5 cm length of cloth free for every 100 cm length of cloth purchased by him. He sells the same cloth at a rate of Rs.110 per meter but cheats his customers by giving 95 cm length of cloth for every 100 cm length of cloth purchased by the customers. If the merchant provides a 5% discount, the resulting profit earned by him is

**ANSWER:** Choice B

### Q12

CAT 2023 Slot 3 - QA

 There are three persons \(\mathrm{A}, \mathrm{B}\) and \(\mathrm{C}\) in a room. If a person \(\mathrm{D}\) joins the room, the average weight of the persons in the room reduces by \(x \mathrm{~kg}\). Instead of \(\mathrm{D}\), if person \(\mathrm{E}\) joins the room, the average weight of the persons in the room increases by \(2 x \mathrm{~kg}\). If the weight of \(\mathrm{E}\) is \(12 \mathrm{~kg}\) more than that of \(\mathrm{D}\), then the value of \(x\) is

 1.5

 2

 0.5

 1

**ANSWER:** Choice D

### Q13

1

 CAT 2023 Slot 3 - QA

 A boat takes 2 hours to travel downstream a river from port A to port B, and 3 hours to return to port A. Another boat takes a total of 6 hours to travel from port B to port A and return to port B. If the speeds of the boats and the river are constant, then the time, in hours, taken by the slower boat to travel from port A to port B is

 \(3(3-\sqrt{5})\)

 \(12(\sqrt{5}-2)\)

 \(3(3+\sqrt{5})\)

 \(3(\sqrt{5}-1)\)

**ANSWER:** Choice A

### Q14

\(3(3-\sqrt{5})\)

 CAT 2023 Slot 3 - QA

 A fruit seller has a stock of mangoes, bananas and apples with at least one fruit of each type. At the beginning of a day, the number of mangoes make up 40% of his stock. That day, he sells half of the mangoes, 96 bananas and 40% of the apples. At the end of the day, he ends up selling 50% of the fruits. The smallest possible total number of fruits in the stock at the beginning of the day is

**ANSWER:** 340

### Q15

CAT 2023 Slot 3 - QA

 The number of coins collected per week by two coin-collectors A and B are in the ratio 3 : 4. If the total number of coins collected by A in 5 weeks is a multiple of 7, and the total number of coins collected by B in 3 weeks is a multiple of 24, then the minimum possible number of coins collected by A in one week is

**ANSWER:** 42

### Q16

CAT 2023 Slot 3 - QA

 Gautam and Suhani, working together, can finish a job in 20 days. If Gautam does only 60% of his usual work on a day, Suhani must do 150% of her usual work on that day to exactly make up for it. Then, the number of days required by the faster worker to complete the job working alone is

**ANSWER:** 36

### Q17

CAT 2023 Slot 3 - QA

 Let \(\triangle A B C\) be an isosceles triangle such that \(A B\) and \(A C\) are of equal length. \(A D\) is the altitude from \(A\) on \(B C\) and \(B E\) is the altitude from \(\mathrm{B}\) on \(\mathrm{AC}\). If \(\mathrm{AD}\) and \(\mathrm{BE}\) intersect at \(\mathrm{O}\) such that \(\angle \mathrm{AOB}=105^{\circ}\), then \(\frac{A D}{B E}\) equals

 \(2 \sin 15^{\circ}\)

 \(\cos 15^{\circ}\)

 \(2 \cos 15^{\circ}\)

 \(\sin 15^{\circ}\)

**ANSWER:** Choice C

### Q18

\(2 \cos 15^{\circ}\)

 CAT 2023 Slot 3 - QA

 A rectangle with the largest possible area is drawn inside a semicircle of radius \(2 \mathrm{~cm}\). Then, the ratio of the lengths of the largest to the smallest side of this rectangle is

 \(2 : 1\)

 \(\sqrt{5} : 1\)

 \(1 : 1\)

 \(\sqrt{2} : 1\)

**ANSWER:** Choice A

### Q19

\(2 : 1\)

 CAT 2023 Slot 3 - QA

 In a regular polygon, any interior angle exceeds the exterior angle by 120 degrees. Then, the number of diagonals of this polygon is

**ANSWER:** 54

### Q20

CAT 2023 Slot 3 - QA

 The value of \(1+\left(1+\frac{1}{3}\right) \frac{1}{4}+\left(1+\frac{1}{3}+\frac{1}{9}\right) \frac{1}{16}+\left(1+\frac{1}{3}+\frac{1}{9}+\frac{1}{27}\right) \frac{1}{64}+\cdots\), is

 \(\frac{15}{13}\)

 \(\frac{16}{11}\)

 \(\frac{27}{12}\)

 \(\frac{15}{8}\)

**ANSWER:** Choice B

### Q21

\(\frac{16}{11}\)

 CAT 2023 Slot 3 - QA

 Let \(a_n=46+8 n\) and \(b_n=98+4 n\) be two sequences for natural numbers \(n \leq 100\). Then, the sum of all terms common to both the sequences is

 15000

 14900

 14602

 14798

**ANSWER:** Choice B

### Q22

14900

 CAT 2023 Slot 3 - QA

 Suppose \(f(x, y)\) is a real-valued function such that \(f(3 x+2 y, 2 x-5 y)=19 x\), for all real numbers \(x\) and \(y\). The value of \(x\) for which \(f(x, 2 x)=27\), is

**ANSWER:** 3
