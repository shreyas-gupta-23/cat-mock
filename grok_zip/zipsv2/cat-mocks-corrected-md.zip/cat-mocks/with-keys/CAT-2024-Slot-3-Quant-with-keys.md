# CAT 2024 — Slot 3 — Quantitative Ability (Questions + On-page Answer Key)

Answers are on-page 2IIM **Correct Answer** labels. Not invented.

## Quantitative Ability

- Source file: `2iim-html/CAT-2024-Question-Paper-Slot-3-Quant.txt`
- Page: https://online.2iim.com/CAT-question-paper/CAT-2024-Question-Paper-Slot-3-Quant/
- On-page answers found: 22
- Answer source: 2IIM on-page **Correct Answer** / **Correct Answer Choice** (not invented)

### Q1

CAT 2024 Question Paper | CAT QUANT

 CAT Question Paper | CAT Previous Year Paper

 CAT 2024 Slot 3 - QA - Inequalities

 The number of distinct integer solutions \((x, y)\) of the equation \(|x+y|+|x-y|=2\), is

**ANSWER:** 8

### Q2

CAT 2024 Slot 3 - QA - Linear Quadratic

 For some constant real numbers \(p, k\) and \(a\), consider
 the following system of linear equations in \(x\) and \(y\) :

 $$
 \begin{aligned}
 & p x-4 y=2 \\
 & 3 x+k y=a
 \end{aligned}
 $$

 A necessary condition for the system to have no solution for \((x, y)\), is

 \(2 a+k \neq 0\)

 \(a p-6=0\)

 \(a p+6=0\)

 \(k p+12 \neq 0\)

**ANSWER:** Choice A

### Q3

\(2 a+k \neq 0\)

 CAT 2024 Slot 3 - QA - Linear Quadratic

 If \((a+b \sqrt{3})^2=52+30 \sqrt{3}\), where \(a\) and \(b\) are natural numbers, then \(a+b\) equals

 7

 10

 8

 9

**ANSWER:** Choice C

### Q4

8

 CAT 2024 Slot 3 - QA - Geometry

 A circular plot of land is divided into two regions by a
 chord of length \(10 \sqrt{3}\) meters such that the chord subtends an angle of \(120^{\circ}\)
 at the center. Then, the area, in square meters, of the smaller region is

 \(25\left(\frac{4 \pi}{3}+\sqrt{3}\right)\)

 \(20\left(\frac{4 \pi}{3}-\sqrt{3}\right)\)

 \(25\left(\frac{4 \pi}{3}-\sqrt{3}\right)\)

 \(20\left(\frac{4 \pi}{3}+\sqrt{3}\right)\)

**ANSWER:** Choice C

### Q5

\(25\left(\frac{4 \pi}{3}-\sqrt{3}\right)\)

 CAT 2024 Slot 3 - QA - Percents Profits SICI

 In a group of 250 students, the percentage of girls was at least 44% and at most 60%. The rest of the students were boys. Each student opted for either swimming or running or both. If 50% of the boys and 80% of the girls opted for swimming while 70% of the boys and 60% of the girls opted for running, then the minimum and maximum possible number of students who opted for both swimming and running, are

 72 and 80, respectively

 75 and 90, respectively

 72 and 88, respectively

 75 and 96, respectively

**ANSWER:** Choice A

### Q6

72 and 80, respectively

 CAT 2024 Slot 3 - QA - Remainders

 If \(10^{68}\) is divided by 13 , the remainder is

 8

 9

 4

 5

**ANSWER:** Choice B

### Q7

9

 CAT 2024 Slot 3 - QA - Geometry

 The midpoints of sides AB, BC, and AC in &#9651; ABC are M, N, and P, respectively. The medians drawn from A, B, and C intersect the line segments MP, MN and NP at X, Y, and Z, respectively. If the area of &#9651; ABC is 1440 sq cm, then the area, in sq cm, of &#9651; XYZ is

**ANSWER:** 90

### Q8

CAT 2024 Slot 3 - QA - Percents Profits SICI

 After two successive increments, Gopal's salary became 187.5% of his initial salary. If the percentage of salary increase in the second increment was twice of that in the first increment, then the percentage of salary increase in the first increment was

 27.5

 30

 25

 20

**ANSWER:** Choice C

### Q9

25

 CAT 2024 Slot 3 - QA - Pipes Cisterns Work Time

 Sam can complete a job in 20 days when working alone. Mohit
 is twice as fast as Sam and thrice as fast as Ayna in the same job. They undertake a job with an
 arrangement where Sam and Mohit work together on the first day, Sam and Ayna on the second day,
 Mohit and Ayna on the third day, and this three-day pattern is repeated till the work gets
 completed. Then, the fraction of total work done by Sam is

 3/20

 3/10

 1/20

 1/5

**ANSWER:** Choice B

### Q10

3/10

 CAT 2024 Slot 3 - QA - Ratios Mixtures Averages

 A certain amount of water was poured into a 300 litre container and the remaining portion of the container was filled with milk. Then an amount of this solution was taken out from the container which was twice the volume of water that was earlier poured into it, and water was poured to refill the container again. If the resulting solution contains 72% milk, then the amount of water, in litres, that was initially poured into the container was

**ANSWER:** 30

### Q11

CAT 2024 Slot 3 - QA - Percents Profits SICI

 Aman invests Rs 4000 in a bank at a certain rate of interest, compounded annually. If the ratio of the value of the investment after 3 years to the value of the investment after 5 years is 25 : 36, then the minimum number of years required for the value of the investment to exceed Rs 20000 is

**ANSWER:** 9

### Q12

CAT 2024 Slot 3 - QA - Percents Profits SICI

 Gopi marks a price on a product in order to make 20% profit. Ravi gets 10% discount on this marked price, and thus saves Rs 15. Then, the profit, in rupees, made by Gopi by selling the product to Ravi, is

 25

 10

 15

 20

**ANSWER:** Choice B

### Q13

10

 CAT 2024 Slot 3 - QA - Ratios Mixtures Averages

 The average of three distinct real numbers is 28. If the smallest number is increased by 7 and the largest number is reduced by 10, the order of the numbers remains unchanged, and the new arithmetic mean becomes 2 more than the middle number, while the difference between the largest and the smallest numbers becomes 64. Then, the largest number in the original set of three numbers is

**ANSWER:** 70

### Q14

CAT 2024 Slot 3 - QA - Combinatorics

 The number of all positive integers up to 500 with non-repeating digits is

**ANSWER:** 378

### Q15

CAT 2024 Slot 3 - QA - Speed Time Distance Races

 A train travelled a certain distance at a uniform speed. Had the speed been 6 km per hour more, it would have needed 4 hours less. Had the speed been 6 km per hour less, it would have needed 6 hours more. The distance, in km, travelled by the train is

 780

 720

 640

 800

**ANSWER:** Choice B

### Q16

720

 CAT 2024 Slot 3 - QA - Logarithms Exponents

 If \(3^a=4,4^b=5,5^c=6,6^d=7,7^e=8\) and \(8^f=9\), then the
 value of the product abcdef is

**ANSWER:** 2

### Q17

CAT 2024 Slot 3 - QA - Progressions

 Consider the sequence \(t_1=1, t_2=-1\) and
 \(t_n=\left(\frac{n-3}{n-1}\right) t_{n-2}\) for \(n \geq 3\). Then, the value of the sum
 \(\frac{1}{t_2}+\frac{1}{t_4}+\frac{1}{t_6}+\cdots+\frac{1}{t_{2022}}+\frac{1}{t_{2024}}\), is

 -1023132

 -1022121

 -1024144

 -1026169

**ANSWER:** Choice C

### Q18

-1024144

 CAT 2024 Slot 3 - QA - Inequalities

 The number of distinct real values of \(x\), satisfying the
 equation \(\max \{x, 2\}-\min \{x, 2\}=|x+2|-|x-2|\), is

**ANSWER:** 2

### Q19

CAT 2024 Slot 3 - QA - Ratios Mixtures Averages

 Rajesh and Vimal own 20 hectares and 30 hectares of agricultural land, respectively, which are entirely covered by wheat and mustard crops. The cultivation area of wheat and mustard in the land owned by Vimal are in the ratio of 5 : 3. If the total cultivation area of wheat and mustard are in the ratio 11 : 9, then the ratio of cultivation area of wheat and mustard in the land owned by Rajesh is

 1 : 1

 7 : 9

 4 : 3

 3 : 7

**ANSWER:** Choice B

### Q20

7 : 9

 CAT 2024 Slot 3 - QA - Functions

 For any non-zero real number \(x\), let \(f(x)+2
 f\left(\frac{1}{x}\right)=3 x\). Then, the sum of all possible values of \(x\) for which
 \(f(x)=3\), is

 2

 -3

 -2

 3

**ANSWER:** Choice B

### Q21

-3

 CAT 2024 Slot 3 - QA - Geometry

 A regular octagon ABCDEFGH has sides of length 6 cm each.
 Then the area, in sq. cm , of the square \(A C E G\) is

 \(36(1+\sqrt{2})\)

 \(72(1+\sqrt{2})\)

 \(36(2+\sqrt{2})\)

 \(72(2+\sqrt{2})\)

**ANSWER:** Choice C

### Q22

\(36(2+\sqrt{2})\)

 CAT 2024 Slot 3 - QA - Logarithms Exponents

 The sum of all distinct real values of \(x\) that satisfy
 the equation \(10^x+\frac{4}{10^x}=\frac{17}{2}\), is

 \(2 \log _{10} 2\)

 \(3 \log _{10} 2\)

 \(4 \log _{10} 2\)

 \(\log _{10} 2\)

**ANSWER:** Choice A
