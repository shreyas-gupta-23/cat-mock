# CAT 2024 — Slot 1 — VARC (Questions + On-page Answer Key)

Answers are on-page 2IIM **Correct Answer** labels. Not invented.

## VARC

- Source file: `2iim-html/CAT-2024-Question-Paper-Slot-1-VARC.txt`
- Page: https://online.2iim.com/CAT-question-paper/CAT-2024-Question-Paper-Slot-1-VARC/
- On-page answers found: 24
- Answer source: 2IIM on-page **Correct Answer** / **Correct Answer Choice** (not invented)

### Q1

CAT 2024 Question Paper | CAT VARC

 CAT Question Paper | CAT Previous Year Paper

 CAT 2024 Slot 1 - VA RC

 There is a sentence that is missing in the paragraph below. Look at the paragraph and
 decide where (option 1, 2, 3, or 4) the following sentence would best
 fit.

Sentence: Comprehending a wide range of emotions, Renaissance music
 nevertheless portrayed all emotions in a balanced and moderate fashion.
 Paragraph:
 A volume of translated Italian madrigals were published in London during the year of
 1588. This sudden public interest facilitated a surge of English Madrigal writing as
 well as a spurt of other secular music writing and publication. ___(1)___. This music
 boom lasted for thirty years and was as much a golden age of music as British literature
 was with Shakespeare and Queen Elizabeth I. ___(2)___. The rebirth in both literature
 and music originated in Italy and migrated to England; the English madrigal became more
 humorous and lighter in England as compared to Italy. Renaissance music was mostly
 polyphonic in texture. ___(3)___. Extreme use of and contrasts in dynamics, rhythm, and
 tone colour do not occur. ___(4)___. The rhythms in Renaissance music tend to have a
 smooth, soft flow instead of a sharp, well-defined pulse of accents.

 Option 2

 Option 4

 Option 1

 Option 3

**ANSWER:** Choice D

### Q2

Option 3

 CAT 2024 Slot 1 - VA RC

 The passage given below is followed by four alternate summaries. Choose the option that
 best captures the essence of the passage.

Cartographers design and create
 maps to communicate information about phenomena located somewhere on our planet. In the
 past, cartographers did not worry too much about who was going to read their maps.
 Although some simple "usability" research was done—like comparing whether circle or bar
 symbols worked best—cartographers knew how to make maps. This has changed now, however,
 due to all kinds of societal and technological developments. Today, map readers are more
 demanding—mostly because of the tools they use to read maps. Cartographers, who are also
 influenced by these trends, are now more interested in seeing if their products are
 efficient, effective, and appreciated.

 New technological developments have prompted cartographers to experiment
 with their maps by applying these new innovations.

 Modern mapmakers evaluate a map's effectiveness efficiency and satisfaction
 of the user through a series of experiments.

 Today, cartographers also need to look into the usability of maps because of
 the new technological developments.

 Maps are being used for a variety of reasons and therefore map readers have
 become more demanding.

**ANSWER:** Choice C

### Q3

Today, cartographers also need to
 look into the usability of maps because of the new technological
 developments.

 CAT 2024 Slot 1 - VA RC

 Five jumbled up sentences (labelled 1, 2, 3, 4 and 5), related to a topic, are given
 below. Four of them can be put together to form a coherent paragraph. Identify the odd
 sentence and key in the number of that sentence as your answer.

 Animals have an interest in fulfilling their basic needs, but also in
 avoiding suffering, and thus we ought to extend moral consideration.

 Singer viewed himself as a utilitarian, and presents a direct moral theory
 concerning animal rights, in contrast to indirect positions, such as
 welfarist views.

 He argued for extending moral consideration to animals because, similar to
 humans, animals have certain significant interests.

 The event that publicly announced animal rights as a legitimate issue within
 contemporary philosophy was Peter Singer's Animal Liberation text in 1975.

 As such, we ought to view their interests alongside and equal to human
 interests, which results in humans having direct moral duties towards
 animals.

**ANSWER:** Choice A

### Q4

Animals have an interest in
 fulfilling their basic needs, but also in avoiding suffering, and thus
 we ought to extend moral consideration.

 The passage below is accompanied by four questions. Based on the passage,
 choose the best answer for each question.

Landing in Australia, the British
 colonists weren't much impressed with the small-bodied, slender-snooted marsupials called
 bandicoots. "Their muzzle, which is much too long, gives them an air exceedingly stupid,"
 one naturalist noted in 1805. They nicknamed one type the "zebra rat" because of its
 black-striped rump.

Silly-looking or not, though, the zebra rat—the smallest
 bandicoot, more commonly known today as the western barred bandicoot—exhibited a genius for
 survival in the harsh outback, where its ancestors had persisted for some 26 million years.
 Its births were triggered by rainfall in the bone-dry desert. It carried its
 breath-mint-size babies in a backward-facing pouch so mothers could forage for food and dig
 shallow, camouflaged shelters.

Still, these adaptations did not prepare the
 western barred bandicoot for the colonial-era transformation of its ecosystem, particularly
 the onslaught of imported British animals, from cattle and rabbits that damaged delicate
 desert vegetation to ravenous house cats that soon developed a taste for bandicoots. Several
 of the dozen-odd bandicoot species went extinct, and by the 1940s the western barred
 bandicoot, whose original range stretched across much of the continent, persisted only on
 two predator-free islands in Shark Bay, off Australia's western coast.

"Our
 isolated fauna had simply not been exposed to these predators," says Reece Pedler, an
 ecologist with the Wild Deserts conservation program.

Now Wild Deserts is using
 descendants of those few thousand island survivors, called Shark Bay bandicoots, in a new
 effort to seed a mainland bandicoot revival. They've imported 20 bandicoots to a preserve on
 the edge of the Strzelecki Desert, in the remote interior of New South Wales. This sanctuary
 is a challenging place, desolate much of the year, with one of the world's most mercurial
 rainfall patterns—relentless droughts followed by sudden drenching floods.

The
 imported bandicoots occupy two fenced "exclosures," cleared of invasive rabbits (courtesy of
 Pedler's sheepdog) and of feral cats (which slunk off once the rabbits disappeared). A third
 fenced area contains the program's Wild Training Zone, where two other rare marsupials
 (bilbies, a larger type of bandicoot, and mulgaras, a somewhat fearsome fuzzball known for
 sucking the brains out of prey) currently share terrain with controlled numbers of cats,
 learning to evade them. It's unclear whether the Shark Bay bandicoots, which are perhaps
 even more predator-naive than their now-extinct mainland bandicoot kin, will be able to make
 that kind of breakthrough.

For now, though, a recent surge of rainfall has led to
 a bandicoot joey boom, raising the Wild Deserts population to about 100, with other
 sanctuaries adding to that number. There are also signs of rebirth in the landscape itself.
 With their constant digging, the bandicoots trap moisture and allow for seed germination so
 the cattle-damaged desert can restore itself.

They have a new nickname—a
 flattering one, this time. "We call them ecosystem engineers," Pedler says.

 CAT 2024 Slot 1 - VA RC

 According to the text, the western barred bandicoots now have a flattering name because
 they have

 grown fivefold in terms of population.

 led a revival in preserving the species.

 aided in altering an arid environment.

 led to a surge and increase of rainfall.

**ANSWER:** Choice C

### Q5

aided in altering an arid
 environment.

 CAT 2024 Slot 1 - VA RC

 Which one of the following options does NOT represent the characteristics of the western
 barred bandicoot?

 Look of a rat but with a baby pouch and a slender snout

 Shallow diggers having an elongated muzzle

 Long thin nose, black striped back, pouch for joeys

 Smallest black striped marsupial that uses camouflage and dig

**ANSWER:** Choice D

### Q6

Smallest black striped marsupial
 that uses camouflage and dig

 CAT 2024 Slot 1 - VA RC

 The text uses the word ' exclosures ' because Wild
 Deserts has adopted a measure of

 restoring cattle damaged deserts to green landscapes.

 excluding animals to make the islands predator-free.

 ridding the main desert of feral cats and large bilbies.

 barring the entry of invasive species.

**ANSWER:** Choice D

### Q7

barring the entry of invasive
 species.

 CAT 2024 Slot 1 - VA RC

 Which one of the following statements provides a gist of this passage?

 The negligent attitude of the British colonists towards these bandicoots
 evidenced by the names given to them led to their annihilation.

 A type of bandicoots was nearly wiped out by invasive species but rescuers
 now pin hopes on a remnant island population.

 Marsupials are going extinct due to the colonial era transformation of the
 ecosystem which also destroyed natural vegetation.

 The onslaught of animals, such as cattle, rabbits and housecats, brought in
 by the British led to the extinction of the western barred bandicoot.

**ANSWER:** Choice B

### Q8

A type of bandicoots was nearly
 wiped out by invasive species but rescuers now pin hopes on a remnant
 island population.

 CAT 2024 Slot 1 - VA RC

 There is a sentence that is missing in the paragraph below. Look at the paragraph and
 decide where (option 1, 2, 3, or 4) the following sentence would best
 fit.

Sentence: The brain isn't organized the way you might set up your home
 office or bathroom medicine cabinet.

Paragraph: ___(1)___. You can't just
 put things anywhere you want to. The evolved architecture of the brain is haphazard and
 disjointed, and incorporates multiple systems, each of which has a mind of its own.
 ___(2)___. Evolution doesn't design things and it doesn't build systems—it
 settles on systems that, historically, conveyed a survival benefit. There is no
 overarching, grand planner engineering the systems so that they work harmoniously
 together. ___(3)___. The brain is more like a big, old house with piecemeal renovations
 done on every floor, and less like new construction. ___(4)___.

 Option 1

 Option 4

 Option 2

 Option 3

**ANSWER:** Choice A

### Q9

Option 1

 The passage below is accompanied by four questions. Based on the passage,
 choose the best answer for each question.

Oftentimes, when economists cross
 borders, they are less interested in learning from others than in invading their garden
 plots. Gary Becker, for instance, pioneered the idea of human capital. To do so, he famously
 tackled topics like crime and domesticity, applying methods honed in the study of markets to
 domains of nonmarket life. He projected economics outward into new realms: for example, by
 revealing the extent to which humans calculate marginal utilities when choosing their
 spouses or stealing from neighbors. At the same time, he did not let other ways of thinking
 enter his own economic realm: for example, he did not borrow from anthropology or history or
 let observations of nonmarket economics inform his homo economicus. Becker was a picture of
 the imperial economist in the heyday of the discipline's bravura.

Times have
 changed for the once almighty discipline. Economics has been taken to task, within and
 beyond its ramparts. Some economists have reached out, imported, borrowed, and
 collaborated—been less imperial, more open. Consider Thomas Piketty and his outreach to
 historians. The booming field of behavioral economics—the fusion of economics and social
 psychology—is another case. Having spawned active subfields, like judgment, decision-making
 and a turn to experimentation, the field aims to go beyond the caricature of Rational Man to
 explain how humans make decisions….

It is important to underscore how this flips
 the way we think about economics. For generations, economists have presumed that people have
 interests—"preferences," in the neoclassical argot—that get revealed in the course of
 peoples' choices. Interests come before actions and determine them. If you are hungry, you
 buy lunch; if you are cold, you get a sweater. If you only have so much money and can't
 afford to deal with both your growling stomach and your shivering, which need you choose to
 meet using your scarce savings reveals your preference.

Psychologists take one
 look at this simple formulation and shake their heads. Increasingly, even some mainstream
 economists have to admit that homo economicus doesn't always behave like the textbook
 maximizer; irrational behavior can't simply be waved away as extra-economic expressions of
 passions over interests, and thus the domain of other disciplines…. This is one place where
 the humanist can help the economist. If narrative economics is going to help us understand
 how rivals duke it out, who wins and who loses, we are going to need much more than lessons
 from epidemiological studies of viruses or intracranial stimuli.

Above all, we
 need politics and institutions. Shiller [the Nobel prize winning economist] connects
 perceptions of narratives to changes in behavior and thence to social outcomes. He completes
 a circle that was key to behavioral economics and brings in storytelling to make sense of
 how perceptions get framed. This cycle (perception to behavior to society) was once mediated
 or dominated by institutions: the political parties, lobby groups, and media organizations
 that played a vital role in legitimating, representing, and excluding interests. Yet
 institutions have been stripped from Shiller's account, to reveal a bare dynamic of emotions
 and economics, without the intermediating place of politics.

 CAT 2024 Slot 1 - VA RC

 In the first paragraph the author is making the point that economists like Becker

 tended to guard their discipline from poaching by academics from other
 subject areas.

 benefitted from the application of their principles and concepts to
 non-economic phenomena.

 used economics to analyse non-market behaviour, without incorporating
 perspectives from other areas of inquiry.

 had begun to borrow concepts from other disciplines but were averse to the
 latter applying economic principles.

**ANSWER:** Choice C

### Q10

used economics to analyse
 non-market behaviour, without incorporating perspectives from other
 areas of inquiry.

 CAT 2024 Slot 1 - VA RC

 "Times have changed for the once almighty discipline." We can infer from this statement
 and the associated paragraph that the author is being

 disparaging of economists' inability to precisely predict market behaviour,
 and are now borrowing from other disciplines to remedy this.

 sarcastic about how economists, who earlier shunned other disciplines, are
 now beginning to incorporate them in their analyses.

 critical of economists' openly borrowing and collaborating across
 disciplines to explain how humans make decisions.

 judgemental about the ability of economic tools to accurately manage crises
 leading to the downfall of this lofty science.

**ANSWER:** Choice B

### Q11

sarcastic about how economists, who
 earlier shunned other disciplines, are now beginning to incorporate them
 in their analyses.

 CAT 2024 Slot 1 - VA RC

 The author critiques Schiller's approach to behavioural economics for

 relying excessively on storytelling as the main influence on the formation
 of perceptions.

 denigrating the role of institutions while creating a link between
 behavioural economics and perceptions.

 linking emotions and rational behaviour without considering the mediation of
 social institutions.

 ignoring the marginal role that media and politics play in influencing
 people's behaviour.

**ANSWER:** Choice C

### Q12

linking emotions and rational
 behaviour without considering the mediation of social
 institutions.

 CAT 2024 Slot 1 - VA RC

 We can infer from the passage that the term ''homo economicus" refers to someone who

 makes rational decisions based on their own preferences.

 is not influenced by the preferences and choices of others.

 maximises their opportunities based on nonmarket choices.

 believes in borrowing and collaborating with other disciplines in their
 work.

**ANSWER:** Choice A

### Q13

makes rational decisions based on
 their own preferences.

 CAT 2024 Slot 1 - VA RC

 The passage given below is followed by four alternate summaries. Choose the option that
 best captures the essence of the passage.

Certain codes may, of course, be so
 widely distributed in a specific language community or culture, and be learned at so
 early an age, that they appear not to be constructed – the effect of an articulation
 between sign and referent – but to be 'naturally' given. Simple visual signs appear to
 have achieved a 'near-universality' in this sense: though evidence remains that even
 apparently 'natural' visual codes are culture specific. However, this does not mean that
 no codes have intervened; rather, that the codes have been profoundly naturalized. The
 operation of naturalized codes reveals not the transparency and 'naturalness' of
 language but the depth, the habituation and the near-universality of the codes in use.
 They produce apparently 'natural' recognitions. This has the (ideological) effect of
 concealing the practices of coding which are present.

 Learning linguistic and visual signs at an early age makes all such codes
 appear natural. This naturalization of codes is the effect of ideology.

 Language and visual signs are codes. However, some of the codes are so
 widespread that they not only seem naturally given but also hide the
 mechanism of coding behind the signs.

 All codes, linguistic and visual, have a natural origin but some are so
 widespread that they become universal. This is what hides the mechanism of
 coding behind signs.

 Not all codes are natural but certain codes are naturalized and made to
 appear universal. Ideology aims to hide the mechanism of coding behind
 signs.

**ANSWER:** Choice B

### Q14

Language and visual signs are
 codes. However, some of the codes are so widespread that they not only
 seem naturally given but also hide the mechanism of coding behind the
 signs.

 The passage below is accompanied by four questions. Based on the passage,
 choose the best answer for each question.

. . . [T]he idea of craftsmanship is
 not simply nostalgic. . . . Crafts require distinct skills, an all-round approach to work
 that involves the whole product, rather than individual parts, and an attitude that
 necessitates devotion to the job and a focus on the communal interest. The concept of craft
 emphasises the human touch and individual judgment.

Essentially, the crafts
 concept seems to run against the preponderant ethos of management studies which, as the
 academics note, have long prioritised efficiency and consistency. . . . Craft skills were
 portrayed as being primitive and traditionalist.

The contrast between artisanship
 and efficiency first came to the fore in the 19 th century when British
 manufacturers suddenly faced competition from across the Atlantic as firms developed the
 "American system" using standardised parts. . . . the worldwide success of the Singer sewing
 machine showed the potential of a mass-produced device. This process created its own
 reaction, first in the form of the Arts and Crafts movement of the late 19 th
 century, and then again in the "small is beautiful" movement of the 1970s. A third crafts
 movement is emerging as people become aware of the environmental impact of conventional
 industry.

There are two potential markets for those who practise crafts. The
 first stems from the existence of consumers who are willing to pay a premium price for goods
 that are deemed to be of extra quality. . . . The second market lies in those consumers who
 wish to use their purchases to support local workers, or to reduce their environmental
 impact by taking goods to craftspeople to be mended, or recycled.

For workers,
 the appeal of craftsmanship is that it allows them the autonomy to make creative choices,
 and thus makes a job far more satisfying. In that sense, it could offer hope for the overall
 labour market. Let the machines automate dull and repetitive tasks and let workers focus
 purely on their skills, judgment and imagination. As a current example, the academics cite
 the "agile" manifesto in the software sector, an industry at the heart of technological
 change. The pioneers behind the original agile manifesto promised to prioritise "individuals
 and interactions over processes and tools". By bringing together experts from different
 teams, agile working is designed to improve creativity.

But the broader question
 is whether crafts can create a lot more jobs than they do today. Demand for crafted products
 may rise but will it be easy to retrain workers in sectors that might get automated (such as
 truck drivers) to take advantage? In a world where products and services often have to pass
 through regulatory hoops, large companies will usually have the
 advantage.

History also suggests that the link between crafts and creativity is
 not automatic. Medieval craft guilds were monopolies which resisted new entrants. They were
 also highly hierarchical with young men required to spend long periods as apprentices and
 journeymen before they could set up on their own; by that time the innovative spirit may
 have been knocked out of them. Craft workers can thrive in the modern era, but only if they
 don't get too organised.

 CAT 2024 Slot 1 - VA RC

 We can infer from the passage that medieval crafts guilds resembled mass production in
 that both

 discouraged innovation by restricting entry through strict rules.

 focused excessively on product quality.

 did not necessarily promote creativity.

 did not always employ egalitarian production processes.

**ANSWER:** Choice C

### Q15

did not necessarily promote
 creativity.

 CAT 2024 Slot 1 - VA RC

 The most recent revival in interest in the crafts is a result of the emergence of all of
 the following EXCEPT:

 support for individual creations as opposed to mass-produced objects.

 a greater interest in buying locally produced goods.

 a niche market for discerning buyers of quality products.

 concerns about the environmental impact of mass production.

**ANSWER:** Choice A

### Q16

support for individual creations as
 opposed to mass-produced objects.

 CAT 2024 Slot 1 - VA RC

 The author questions the ability of crafts to create substantial employment opportunities
 presently because

 regulatory requirements could make it difficult for small crafts outfits to
 compete.

 workers made redundant by automation are unlikely to opt for crafts-related
 work.

 crafts guilds tend to resist new entrants and are unlikely to accept large
 numbers of trainees.

 the low scale of crafts production will not be able to absorb the mass of
 redundant labour.

**ANSWER:** Choice A

### Q17

regulatory requirements could make
 it difficult for small crafts outfits to compete.

 CAT 2024 Slot 1 - VA RC

 Which one of the following statements is NOT inconsistent with the views stated in the
 passage?

 Creativity in the crafts could be stifled if the market for artisan goods
 becomes too organised.

 The Arts and Crafts movement was initially inspired by the "American system"
 of production.

 The agile movement in software is a throwback to the tenets of the medieval
 crafts guilds.

 We need to support the crafts; only then can we retain the creativity
 intrinsic to their production.

**ANSWER:** Choice A

### Q18

Creativity in the crafts could be
 stifled if the market for artisan goods becomes too organised.

 The passage below is accompanied by four questions. Based on the passage,
 choose the best answer for each question.

In the summer of 2022, subscribers to
 the US streaming service HBO MAX were alarmed to discover that dozens of the platform's
 offerings – from the Covid-themed heist thriller Locked Down to the recent remake of The
 Witches – had been quietly removed from the service . . . The news seemed like vindication
 to those who had long warned that streaming was more about controlling access to the
 cultural commons than expanding it, as did reports (since denied by the show's creators)
 that Netflix had begun editing old episodes of Stranger Things to retroactively improve
 their visual effects.

What's less clear is whether the commonly prescribed cure
 for these cultural ills – a return to the material pleasures of physical media – is the
 right one. While the makers of Blu-ray discs claim they have a shelf life of 100 years, such
 statistics remain largely theoretical until they come to pass, and are dependent on storage
 conditions, not to mention the continued availability of playback equipment. The humble DVD
 has already proved far less resilient, with many early releases already beginning to
 deteriorate in quality Digital movie purchases provide even less security. Any film "bought"
 on iTunes could disappear if you move to another territory with a different rights agreement
 and try to redownload it. It's a bold new frontier in the commodification of art: the birth
 of the product recall. After a man took to Twitter to bemoan losing access to Cars 2 after
 moving from Canada to Australia, Apple clarified that users who downloaded films to their
 devices would retain permanent access to those downloads, even if they relocated to a
 hemisphere where the [content was] subject to a different set of rights agreements. Thanks
 to the company's ironclad digital rights management technology, however, such files cannot
 be moved or backed up, locking you into watching with your Apple account.

Anyone
 who does manage to acquire Digital Rights Management free (DRM-free) copies of their
 favourite films must nonetheless grapple with ever-changing file format standards, not to
 mention data decay – the gradual process by which electronic information slowly but surely
 corrupts. Only the regular migration of files from hard drive to hard drive can delay the
 inevitable, in a sisyphean battle against the ravages of digital time.

In a
 sense, none of this is new. Charlie Chaplin burned the negative of his 1926 film A Woman of
 the Sea as a tax write-off. Many more films have been lost through accident, negligence or
 plain indifference. During a heatwave in July 1937, a Fox film vault in New Jersey burned
 down, destroying a majority of the silent films produced by the studio.

Back
 then, at least, cinema was defined by its ephemerality: the sense that a film was as good as
 gone once it left your local cinema. Today, with film studios keen to stress the breadth of
 their back catalogues (or to put in Hollywood terms, the value of their IPs), audiences may
 start to wonder why those same studios seem happy to set the vault alight themselves if
 it'll help next quarter's numbers.

 CAT 2024 Slot 1 - VA RC

 Which of the following statements is suggested by the sentence "Back then, at least,
 cinema was defined by its ephemerality: the sense that a film was as good as gone once
 it left your local cinema"?

 Today, films are expected to be available for a long time, since they are no
 longer tied solely to their stay at the local cinema.

 Cinema is now no longer as ephemeral as it used to be earlier, because the
 technology used for creating and preserving films has improved manifold.

 Presently, there is no reason why film studios should remove access to films
 once they have left the local cinema.

 Around a century ago, people were more accepting of not having access to
 films once they left the local cinema.

**ANSWER:** Choice A

### Q19

Today, films are expected to be
 available for a long time, since they are no longer tied solely to their
 stay at the local cinema.

 CAT 2024 Slot 1 - VA RC

 "Netflix had begun editing old episodes of Stranger Things to retroactively improve their
 visual effects." What is the purpose of this example used in the passage?

 To show a practice that justifies the fears of people who feel streaming
 services cannot be trusted to be custodians of cultural artefacts like film.

 To show how unsubstantiated reports are leading to an increase in the level
 of distrust towards streaming services.

 To show that art in the digital age, specifically film, is no longer
 sacrosanct, and may be changed to suit changing tastes or technology.

 To show that streaming services are controlling access to the cultural
 commons rather than expanding it.

**ANSWER:** Choice A

### Q20

To show a practice that justifies
 the fears of people who feel streaming services cannot be trusted to be
 custodians of cultural artefacts like film.

 CAT 2024 Slot 1 - VA RC

 Which one of the following statements, if true, would best invalidate the main argument
 of the passage?

 Improved cloud storage services have made it possible for movie collections
 to now be preserved in perpetuity, without the need to keep migrating the
 files.

 Studios and streaming services have
 committed to giving customers perpetual and platform-independent access
 to the original digital content they have paid for.

 Recent research
 has irrefutably proven that Blu-Ray discs have a shelf life of at least
 100 years.

 When moving to a different geographical location, customers can easily use
 Virtual Private Networks (VPNs) to bypass geo-blocking and regain access to
 their content on any streaming service.

**ANSWER:** Choice B

### Q21

Studios and streaming services have
 committed to giving customers perpetual and platform-independent
 access to the original digital content they have paid for.

 CAT 2024 Slot 1 - VA RC

 Which one of the following statements about art best captures the arguments made in the
 passage?

 Works of art belong to the cultural commons and hence must remain available
 in perpetuity, irrespective of who pays for access to them.

 In the age of online subscription services, it is time to change our
 understanding of classic works of art being primarily immutable and easily
 available to the public.

 As art is increasingly created, stored and distributed digitally, access to
 it is counterintuitively likely to be made more difficult by the rapid churn
 in technology and the whims of host platforms.

 Accepting retroactive changes to works of art is dangerous because it will
 encourage creators to not put enough effort into the original attempt, given
 that they can always edit or update their work later.

**ANSWER:** Choice C

### Q22

As art is increasingly created,
 stored and distributed digitally, access to it is counterintuitively
 likely to be made more difficult by the rapid churn in technology and
 the whims of host platforms.

 CAT 2024 Slot 1 - VA RC

 The passage given below is followed by four alternate summaries. Choose the option that
 best captures the essence of the passage.

Scientific research shows that many
 animals are very intelligent and have sensory and motor abilities that dwarf ours. Dogs
 are able to detect diseases such as cancer and diabetes and warn humans of impending
 heart attacks and strokes. Elephants, whales, hippopotamuses, giraffes, and alligators
 use low-frequency sounds to communicate over long distances, often miles. Many animals
 also display wide-ranging emotions, including joy, happiness, empathy, compassion,
 grief, and even resentment and embarrassment. It's not surprising that animals share
 many emotions with us because we also share brain structures, located in the limbic
 system, that are the seat of our emotions.

 Animals can show emotions which are typically associated with humans.

 The similarity in brain structure explains why animals show emotions
 typically associated with humans.

 The advanced sensory and motor abilities of animals is the reason why they
 can display wide-ranging emotions.

 Animals are more intelligent than us in sensing danger and detecting
 diseases.

**ANSWER:** Choice B

### Q23

The similarity in brain structure
 explains why animals show emotions typically associated with
 humans.

 CAT 2024 Slot 1 - VA RC

 Five jumbled up sentences (labelled 1, 2, 3, 4 and 5), related to a topic, are given
 below. Four of them can be put together to form a coherent paragraph. Identify the odd
 sentence and key in the number of that sentence as your answer.

1. Urbanites
 also have more and better options for getting around: Uber is ubiquitous; easy-to-rent
 dockless bicycles are spreading; battery-powered scooters will be next.
2. When
 more people use buses or trains the service usually improves because public-transport
 agencies run more buses and trains.
3. Worsening services on public transport,
 terrorist attacks in some urban metros and a rise in fares have been blamed for this
 trend.
4. It seems more likely that public transport is being squeezed
 structurally as people's need to travel is diminishing as a result of smartphones,
 video-conferencing, online shopping and so on.
5. There has been a puzzling
 decline in the use of urban public transport in many countries in the west, despite the
 growth in urban populations and rising employment.

**ANSWER:** 2

### Q24

CAT 2024 Slot 1 - VA RC

 There is a sentence that is missing in the paragraph below. Look at the paragraph and
 decide where (option 1, 2, 3, or 4) the following sentence would best
 fit.

Sentence: Understanding central Asia's role helps developments make more
 sense not only across Asia but in Europe, the Americas and Africa.

Paragraph:
 The nations of the Silk Roads are sometimes called 'developing countries', but they are
 actually some of the world's most highly developed countries, the very crossroads of
 civilization, in advanced states of disrepair. ___(1)___. These countries lie at the
 centre of global affairs: they have since the beginning of history. Running across the
 spine of Asia, they form a web of connections fanning out in every direction, routes
 along which pilgrims and warriors, nomads and merchants have travelled, goods and
 produce have been bought and sold, and ideas exchanged, adapted and refined. ___(2)___
 .They have carried not only prosperity, but also death and violence, disease and
 disaster. ___(3)___. The Silk Roads are the world's central nervous system, connecting
 otherwise far-flung peoples and places…. ___(4)___. It allows us to see patterns and
 links, causes and effects that remain invisible if one looks only at Europe, or North
 America.

 Option 1

 Option 4

 Option 3

 Option 2

**ANSWER:** Choice B
