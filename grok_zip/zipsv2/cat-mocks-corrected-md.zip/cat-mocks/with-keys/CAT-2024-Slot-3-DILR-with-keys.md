# CAT 2024 — Slot 3 — DILR (Questions + On-page Answer Key)

Answers are on-page 2IIM **Correct Answer** labels. Not invented.

## DILR

- Source file: `2iim-html/CAT-2024-Question-Paper-Slot-3-DILR.txt`
- Page: https://online.2iim.com/CAT-question-paper/CAT-2024-Question-Paper-Slot-3-DILR/
- On-page answers found: 22
- Answer source: 2IIM on-page **Correct Answer** / **Correct Answer Choice** (not invented)

### Q1

The table given below shows the amount, in grams, of carbohydrate, protein, fat
 and all other nutrients, per 100 grams of nutrients in seven foodgrains. The first column
 shows the foodgrain category and the second column its codename. The table has some missing
 values.

The following additional facts are known.
1. Both the
 pseudo-cereals had higher amounts of carbohydrate as well as higher amounts of protein than
 any millet.
2. Both the cereals had higher amounts of carbohydrate than any
 pseudo-cereal.
3. All the missing values of carbohydrate amounts (in grams) for all the
 foodgrains are non-zero multiples of 5.
4. All the missing values of protein, fat and
 other nutrients amounts (in grams) for all the foodgrains are non-zero multiples of
 4.
5. P1 contained double the amount of protein that M3 contains.

 CAT 2024 Slot 3 - DI LR

 How many foodgrains had a higher amount of carbohydrate per 100 grams of nutrients than
 M1?

**ANSWER:** 5

### Q2

CAT 2024 Slot 3 - DI LR

 How many grams of protein were there in 100 grams of nutrients in M2?

**ANSWER:** 12

### Q3

CAT 2024 Slot 3 - DI LR

 How many grams of other nutrients were there in 100 grams of nutrients in M3?

**ANSWER:** 24

### Q4

CAT 2024 Slot 3 - DI LR

 What is the median of the number of grams of protein in 100 grams of nutrients among
 these food grains?

**ANSWER:** 12

### Q5

Over the top (OTT) subscribers of a platform are segregated into three
 categories: i) Kid, ii) Elder, and iii) Others. Some of the subscribers used one app and the
 others used multiple apps to access the platform. The figure below shows the percentage of
 the total number of subscribers in 2023 and 2024 who belong to the 'Kid' and 'Elder'
 categories.

The following additional facts are known about the numbers of
 subscribers.1. The total number of subscribers increased by 10% from 2023 to 2024.
2.
 In 2024, 1/2 of the subscribers from the 'Kid' category and 2/3 of the subscribers from the
 'Elder' category subscribers use one app.
3. In 2023, the number of subscribers from
 the 'Kid' category who used multiple apps was the same as the number of subscribers from the
 'Elder' category who used one app.
4. 10,000 subscribers from the 'Kid' category used
 one app and 15,000 subscribers from the 'Elder' category used multiple apps in 2023.

 CAT 2024 Slot 3 - DI LR

 How many subscribers belonged to the 'Others' category in 2024?

 Cannot be determined

 65000

 45000

 55000

**ANSWER:** Choice D

### Q6

55000

 CAT 2024 Slot 3 - DI LR

 What percentage of subscribers in the 'Kid' category used multiple apps in 2023?

**ANSWER:** Choice A

### Q7

CAT 2024 Slot 3 - DI LR

 What was the percentage increase in the number of subscribers in the 'Elder' category
 from 2023 to 2024?

**ANSWER:** Choice B

### Q8

CAT 2024 Slot 3 - DI LR

 What could be the minimum percentage of subscribers who used multiple apps in 2024?

**ANSWER:** Choice B

### Q9

The air-conditioner (AC) in a large room can be operated either in REGULAR mode
 or in POWER mode to reduce the temperature.

If the AC operates in REGULAR mode,
 then it brings down the temperature inside the room (called inside temperature) at a
 constant rate to the set temperature in 1 hour. If it operates in POWER mode, then this is
 achieved in 30 minutes.

If the AC is switched off, then the inside temperature
 rises at a constant rate so as to reach the temperature outside at the time of switching off
 in 1 hour.

The temperature outside has been falling at a constant rate from 7 pm
 onward until 3 am on a particular night. The following graph shows the inside temperature
 between 11 pm (23:00) and 2 am (2:00) that night.

The following facts are known about the AC operation that
 night.

• The AC was turned on for the first time that night at 11 pm (23:00).

• The AC setting was changed (including turning it on/off, and/or setting different
 temperatures) only at the beginning of the hour or at 30 minutes after the hour.
• The
 AC was used in POWER mode for longer duration than in REGULAR mode during this 3-hour
 period.

 CAT 2024 Slot 3 - DI LR

 How many times the AC must have been turned off between 11:01 pm and 1:59 am?

 1

 2

 cannot be determined

 0

**ANSWER:** Choice B

### Q10

2

 CAT 2024 Slot 3 - DI LR

 What was the temperature outside, in degree Celsius, at 1 am?

**ANSWER:** 34

### Q11

CAT 2024 Slot 3 - DI LR

 What was the temperature outside, in degree Celsius, at 9 pm?

**ANSWER:** 42

### Q12

CAT 2024 Slot 3 - DI LR

 What best can be concluded about the number of times the AC must have either been turned
 on or the AC temperature setting been altered between 11:01 pm and 1:59 am?

 More than 3

 Exactly 2

 Either 2 or 3

 Exactly 3

**ANSWER:** Choice D

### Q13

Exactly 3

 CAT 2024 Slot 3 - DI LR

 What was the maximum difference between temperature outside and inside temperature, in
 degree Celsius, between 11:01 pm and 1:59 am?

**ANSWER:** 10

### Q14

Out of 10 countries -- Country 1 through Country 10 -- Country 9 has the
 highest gross domestic product (GDP), and Country 10 has the highest GDP per capita. GDP per
 capita is the GDP of a country divided by its population. The table below provides the
 following data about Country 1 through Country 8 for the year 2024.

• Column 1
 gives the country's identity.
• Column 2 gives the country's GDP as a fraction of the
 GDP of Country 9.
• Column 3 gives the country's GDP per capita as a fraction of the
 GDP per capita of Country 10.
• Column 4 gives the country's annual GDP growth
 rate.
• Column 5 gives the country's annual population growth rate.

Assume that the GDP growth rates and population growth rates
 of the countries will remain constant for the next three years.

 CAT 2024 Slot 3 - DI LR

 Which one among the countries 1 through 8, has the smallest population in 2024?

 Country 3

 Country 5

 Country 8

 Country 7

**ANSWER:** Choice C

### Q15

Country 8

 CAT 2024 Slot 3 - DI LR

 The ratio of Country 4's GDP to Country 5's GDP in 2026 will be closest to

 1.032

 1.314

 0.963

 1.195

**ANSWER:** Choice D

### Q16

1.195

 CAT 2024 Slot 3 - DI LR

 Which one among the countries 1, 4, 5, and 7 will have the largest population in 2027?

 Country 4

 Country 7

 Country 1

 Country 5

**ANSWER:** Choice C

### Q17

Country 1

 CAT 2024 Slot 3 - DI LR

 For how many countries among Country 1 through Country 8 will the GDP per capita in 2027
 be lower than that in 2024?

**ANSWER:** 0

### Q18

The figure below shows a network with three parallel roads represented by
 horizontal lines R-A, R-B, and R-C and another three parallel roads represented by vertical
 lines V1, V2, and V3. The figure also shows the distance (in km) between two adjacent
 intersections. Six ATMs are placed at six of the nine road intersections. Each ATM has a
 distinct integer cash requirement (in Rs. Lakhs), and the numbers at the end of each line in
 the figure indicate the total cash requirements of all ATMs placed on the corresponding
 road. For example, the total cash requirement of the ATM(s) placed on road R-A is Rs. 22
 Lakhs.

The following additional information is known.
1. The ATMs with the
 minimum and maximum cash requirements of Rs. 7 Lakhs and Rs. 15 Lakhs are placed on the same
 road.
2. The road distance between the ATM with the second highest cash requirement and
 the ATM located at the intersection of R-C and V3 is 12 km.

 CAT 2024 Slot 3 - DI LR

 Which of the following statements is correct?

 The ATM placed at the (R-C, V2) intersection has a cash requirement of Rs. 9
 Lakhs.

 There is no ATM placed at the (R-C, V2) intersection.

 The ATM placed at the (R-C, V2) intersection has a cash requirement of Rs. 8
 Lakhs.

 The cash requirement of the ATM placed at the (R-C, V2) intersection cannot
 be uniquely determined.

**ANSWER:** Choice A

### Q19

The ATM placed at the (R-C, V2)
 intersection has a cash requirement of Rs. 9 Lakhs.

 CAT 2024 Slot 3 - DI LR

 How many ATMs have cash requirements of Rs. 10 Lakhs or more?

**ANSWER:** 3

### Q20

CAT 2024 Slot 3 - DI LR

 Which of the following two statements is/are DEFINITELY true?
A)Statement A:
 Each of R-A, R-B, and R-C has two ATMs.
B)Statement B: Each of V1, V2, and V3 has
 two ATMs.

 Both Statement A and Statement B

 Neither Statement A nor Statement B

 Only Statement A

 Only Statement B

**ANSWER:** Choice C

### Q21

Only Statement A

 CAT 2024 Slot 3 - DI LR

 What best can be said about the road distance (in km) between the ATMs having the second
 highest and the second lowest cash requirements?

 7 km

 5 km

 4 km

 Either 4 km or 7 km

**ANSWER:** Choice D

### Q22

Either 4 km or 7 km

 CAT 2024 Slot 3 - DI LR

 What is the number of ATMs whose locations and cash requirements can both be uniquely
 determined?

**ANSWER:** 3
