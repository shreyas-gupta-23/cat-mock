# CAT 2022 — Slot 2 — Quantitative Ability (Questions + On-page Answer Key)

Answers are on-page 2IIM **Correct Answer** labels. Not invented.

## Quantitative Ability

- Source file: `2iim-html/CAT-2022-Question-Paper-Slot-2-Quant.txt`
- Page: https://online.2iim.com/CAT-question-paper/CAT-2022-Question-Paper-Slot-2-Quant/
- On-page answers found: 22
- Answer source: 2IIM on-page **Correct Answer** / **Correct Answer Choice** (not invented)

### Q1

CAT 2022 Slot 2 - QA

 In triangle \(A B C\), altitudes \(A D\) and \(B E\) are drawn to the corresponding bases. If \(\angle B A C=45^{\circ}\) and \(\angle A B C=\theta\), then \(\frac{A D}{B E}\) equals

 \(\sqrt{2} \sin \theta\)

 \(\sqrt{2} \cos \theta\)

 \(\frac{(\sin \theta+\cos \theta)}{\sqrt{2}}\)

 1

**ANSWER:** Choice A

### Q2

\(\sqrt{2} \sin \theta\)

 CAT 2022 Slot 2 - QA

 Working alone, the times taken by Anu, Tanu and Manu to complete any job are in the ratio 5 : 8 : 10. They accept a job which they can finish in 4 days if they all work together for 8 hours per day. However, Anu and Tanu work together for the first 6 days, working 6 hours 40 minutes per day. Then, the number of hours that Manu will take to complete the remaining job working alone is

**ANSWER:** 6

### Q3

CAT 2022 Slot 2 - QA

 Regular polygons A and B have number of sides in the ratio 1 : 2 and interior angles in the ratio 3 : 4. Then the number of sides of B equals

**ANSWER:** 10

### Q4

CAT 2022 Slot 2 - QA

 If \(a\) and \(b\) are non-negative real numbers such that \(a+2 b=6\), then the average of the maximum and minimum possible values of \((a+b)\) is

 4

 4.5

 3.5

 3

**ANSWER:** Choice B

### Q5

4.5

 CAT 2022 Slot 2 - QA

 4200

 4400

 4300

 4350

**ANSWER:** Choice B

### Q6

4400

 CAT 2022 Slot 2 - QA

 There are two containers of the same volume, first container half-filled with sugar syrup and the second container half-filled with milk. Half the content of the first container is transferred to the second container, and then the half of this mixture is transferred back to the first container. Next, half the content of the first container is transferred back to the second container. Then the ratio of sugar syrup and milk in the second container is

 5 : 6

 5 : 4

 6 : 5

 4 : 5

**ANSWER:** Choice A

### Q7

5 : 6

 CAT 2022 Slot 2 - QA

 On day one, there are 100 particles in a laboratory experiment. On day \(n\), where \(n \geq 2\), one out of every \(n\) particles produces another particle. If the total number of particles in the laboratory experiment increases to 1000 on day \(m\), then \(m\) equals

 19

 16

 17

 18

**ANSWER:** Choice A

### Q8

19

 CAT 2022 Slot 2 - QA

 The average of a non-decreasing sequence of \(N\) numbers \(a_1, a_2, \ldots, a_N\) is 300 . If \(a_1\) is replaced by \(6 a_1\), the new average becomes 400 . Then, the number of possible values of \(a_1\) is

**ANSWER:** 14

### Q9

CAT 2022 Slot 2 - QA

 Let \(r\) and \(c\) be real numbers. If \(r\) and \(-r\) are roots of \(5 x^3+c x^2-10 x+9=0\), then \(c\) equals

 \(-\frac{9}{2}\)

 \(\frac{9}{2}\)

 \(-4\)

 \(4\)

**ANSWER:** Choice A

### Q10

\(-\frac{9}{2}\)

 CAT 2022 Slot 2 - QA

 Suppose for all integers \(x\), there are two functions \(f\) and \(g\) such that \(f(x)+f(x-1)-1=0\) and \(g(x)=x^2\). If \(f\left(x^2-x\right)=5\), then the value of the sum \(f(g(5))+g(f(5))\) is

**ANSWER:** 12

### Q11

CAT 2022 Slot 2 - QA

 In an election, there were four candidates and 80% of the registered voters casted their votes. One of the candidates received 30% of the casted votes while the other three candidates received the remaining casted votes in the proportion 1 : 2 : 3. If the winner of the election received 2512 votes more than the candidate with the second highest votes, then the number of registered voters was

 40192

 60288

 50240

 62800

**ANSWER:** Choice D

### Q12

62800

 CAT 2022 Slot 2 - QA

 The number of integers greater than 2000 that can be formed with the digits 0, 1, 2, 3, 4, 5, using each digit at most once, is

 1440

 1200

 1420

 1480

**ANSWER:** Choice A

### Q13

1440

 CAT 2022 Slot 2 - QA

 For some natural number \(n\), assume that \((15,000)\) ! is divisible by \((n !) !\). The largest possible value of \(n\) is

 5

 7

 4

 6

**ANSWER:** Choice B

### Q14

7

 CAT 2022 Slot 2 - QA

 The number of distinct integer values of \(n\) satisfying \(\frac{4-\log _2 n}{3-\log _4 n}\lt0\), is

**ANSWER:** 47

### Q15

CAT 2022 Slot 2 - QA

 In an examination, there were 75 questions. 3 marks were awarded for each correct answer, 1 mark was deducted for each wrong answer and 1 mark was awarded for each unattempted question. Rayan scored a total of 97 marks in the examination. If the number of unattempted questions was higher than the number of attempted questions, then the maximum number of correct answers that Rayan could have given in the examination is

**ANSWER:** 24

### Q16

CAT 2022 Slot 2 - QA

 Five students, including Amit, appear for an examination in which possible marks are integers between 0 and 50, both inclusive. The average marks for all the students is 38 and exactly three students got more than 32. If no two students got the same marks and Amit got the least marks among the five students, then the difference between the highest and lowest possible marks of Amit is

 21

 24

 20

 22

**ANSWER:** Choice C

### Q17

20

 CAT 2022 Slot 2 - QA

 The number of integer solutions of the equation \(\left(x^2-10\right)^{\left(x^2-3 x-10\right)}=1\) is

**ANSWER:** 4

### Q18

CAT 2022 Slot 2 - QA

 Mr. Pinto invests one-fifth of his capital at 6%, one-third at 10% and the remaining at 1%, each rate being simple interest per annum. Then, the minimum number of years required for the cumulative interest income from these investments to equal or exceed his initial capital is

**ANSWER:** 20

### Q19

CAT 2022 Slot 2 - QA

 Consider the arithmetic progression \(3,7,11, \ldots\) and let \(A_n\) denote the sum of the first \(n\) terms of this progression. Then the value of \(\frac{1}{25} \sum_{n=1}^{25} A_n\) is

 404

 442

 455

 415

**ANSWER:** Choice C

### Q20

455

 CAT 2022 Slot 2 - QA

 Let \(f(x)\) be a quadratic polynomial in \(x\) such that \(f(x) \geq 0\) for all real numbers \(x\). If \(f(2)=0\) and \(f(4)=6\), then \(f(-2)\) is equal to

 12

 36

 24

 6

**ANSWER:** Choice C

### Q21

24

 CAT 2022 Slot 2 - QA

 The length of each side of an equilateral triangle \(\mathrm{ABC}\) is \(3 \mathrm{~cm}\). Let \(\mathrm{D}\) be a point on \(\mathrm{BC}\) such that the area of triangle \(\mathrm{ADC}\) is half the area of triangle \(\mathrm{ABD}\). Then the length of \(\mathrm{AD}\), in \(\mathrm{cm}\), is

 \(\sqrt{6}\)

 \(\sqrt{5}\)

 \(\sqrt{8}\)

 \(\sqrt{7}\)

**ANSWER:** Choice D

### Q22

\(\sqrt{7}\)

 CAT 2022 Slot 2 - QA

 Two ships meet mid-ocean, and then, one ship goes south and the other ship goes west, both travelling at constant speeds. Two hours later, they are 60 km apart. If the speed of one of the ships is 6 km per hour more than the other one, then the speed, in km per hour, of the slower ship is

 12

 18

 20

 24

**ANSWER:** Choice B
