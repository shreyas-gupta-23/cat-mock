# CAT 2023 — Slot 2 — Quantitative Ability (Questions + On-page Answer Key)

Answers are on-page 2IIM **Correct Answer** labels. Not invented.

## Quantitative Ability

- Source file: `2iim-html/CAT-2023-Question-Paper-Slot-2-Quant.txt`
- Page: https://online.2iim.com/CAT-question-paper/CAT-2023-Question-Paper-Slot-2-Quant/
- On-page answers found: 22
- Answer source: 2IIM on-page **Correct Answer** / **Correct Answer Choice** (not invented)

### Q1

CAT 2023 Slot 2 - QA

 Let \(a, b, m\) and \(n\) be natural numbers such that \(a>1\) and \(b>1\). If \(a^m b^n=144^{145}\), then the largest possible value of \(n-m\) is

 580

 290

 579

 289

**ANSWER:** Choice C

### Q2

579

 CAT 2023 Slot 2 - QA

 The sum of all possible values of \(x\) satisfying the equation \(2^{4 x^2}-2^{2 x^2+x+16}+2^{2 x+30}=0\), is

 \(\frac{3}{2}\)

 \(\frac{5}{2}\)

 \(\frac{1}{2}\)

 3

**ANSWER:** Choice C

### Q3

\(\frac{1}{2}\)

 CAT 2023 Slot 2 - QA

 For any natural numbers \(m, n\), and \(k\), such that \(k\) divides both \(m+2 n\) and \(3 m+4 n, k\) must be a common divisor of

 \(2 m\) and \(3 n\)

 \(m\) and \(2 n\)

 \(2 m\) and \(n\)

 \(m\) and \(n\)

**ANSWER:** Choice B

### Q4

\(m\) and \(2 n\)

 CAT 2023 Slot 2 - QA

 Any non-zero real numbers \(x, y\) such that \(y \neq 3\) and \(\frac{x}{y} \lt \frac{x+3}{y-3}\), will satisfy the condition

 If \(y>10\), then \(-x>y\)

 If \(x \lt 0\), then \(-x \lt y\)

 If \(y \lt 0\), then \(-x \lt y\)

 \(\frac{x}{y} \lt \frac{y}{x}\)

**ANSWER:** Choice C

### Q5

If \(y \lt 0\), then \(-x \lt y\)

 CAT 2023 Slot 2 - QA

 For some positive real number \(x\), if \(\log _{\sqrt{3}}(x)+\frac{\log _x(25)}{\log _x(0.008)}=\frac{16}{3}\), then the value of \(\log _3\left(3 x^2\right)\) is

**ANSWER:** 7

### Q6

CAT 2023 Slot 2 - QA

 The number of positive integers less than 50, having exactly two distinct factors other than 1 and itself, is

**ANSWER:** 15

### Q7

CAT 2023 Slot 2 - QA

 Let \(k\) be the largest integer such that the equation \((x-1)^2+2 k x+11=0\) has no real roots. If \(y\) is a positive real number, then the least possible value of \(\frac{k}{4 y}+9 y\) is

**ANSWER:** 6

### Q8

CAT 2023 Slot 2 - QA

 In a company, 20% of the employees work in the manufacturing department. If the total salary obtained by all the manufacturing employees is one-sixth of the total salary obtained by all the employees in the company, then the ratio of the average salary obtained by the manufacturing employees to the average salary obtained by the non-manufacturing employees is

 4 : 5

 5 : 6

 5 : 4

 6 : 5

**ANSWER:** Choice A

### Q9

4 : 5

 CAT 2023 Slot 2 - QA

 Minu purchases a pair of sunglasses at Rs.1000 and sells to Kanu at 20% profit. Then, Kanu sells it back to Minu at 20% loss. Finally, Minu sells the same pair of sunglasses to Tanu. If the total profit made by Minu from all her transactions is Rs.500, then the percentage of profit made by Minu when she sold the pair of sunglasses to Tanu is

**ANSWER:** Choice B

### Q10

CAT 2023 Slot 2 - QA

 Pipes A and C are fill pipes while Pipe B is a drain pipe of a tank. Pipe B empties the full tank in one hour less than the time taken by Pipe A to fill the empty tank. When pipes A, B and C are turned on together, the empty tank is filled in two hours. If pipes B and C are turned on together when the tank is empty and Pipe B is turned off after one hour, then Pipe C takes another one hour and 15 minutes to fill the remaining tank. If Pipe A can fill the empty tank in less than five hours, then the time taken, in minutes, by Pipe C to fill the empty tank is

 90

 60

 120

 75

**ANSWER:** Choice A

### Q11

90

 CAT 2023 Slot 2 - QA

 Ravi is driving at a speed of 40 km/h on a road. Vijay is 54 meters behind Ravi and driving in the same direction as Ravi. Ashok is driving along the same road from the opposite direction at a speed of 50 km/h and is 225 meters away from Ravi. The speed, in km/h, at which Vijay should drive so that all the three cross each other at the same time, is

 58.8

 64.4

 67.2

 61.6

**ANSWER:** Choice D

### Q12

61.6

 CAT 2023 Slot 2 - QA

 Anil borrows Rs 2 lakhs at an interest rate of 8% per annum, compounded half-yearly. He repays Rs 10320 at the end of the first year and closes the loan by paying the outstanding amount at the end of the third year. Then, the total interest, in rupees, paid over the three years is nearest to

 45311

 51311

 33130

 40991

**ANSWER:** Choice B

### Q13

51311

 CAT 2023 Slot 2 - QA

 The price of a precious stone is directly proportional to the square of its weight. Sita has a precious stone weighing 18 units. If she breaks it into four pieces with each piece having distinct integer weight, then the difference between the highest and lowest possible values of the total price of the four pieces will be 288000. Then, the price of the original precious stone is

 1296000

 1944000

 972000

 1620000

**ANSWER:** Choice A

### Q14

1296000

 CAT 2023 Slot 2 - QA

 A container has 40 liters of milk. Then, 4 liters are removed from the container and replaced with 4 liters of water. This process of replacing 4 liters of the liquid in the container with an equal volume of water is continued repeatedly. The smallest number of times of doing this process, after which the volume of milk in the container becomes less than that of water, is

**ANSWER:** 7

### Q15

CAT 2023 Slot 2 - QA

 Jayant bought a certain number of white shirts at the rate of Rs 1000 per piece and a certain number of blue shirts at the rate of Rs 1125 per piece. For each shirt, he then set a fixed market price which was 25% higher than the average cost of all the shirts. He sold all the shirts at a discount of 10% and made a total profit of Rs 51000. If he bought both colors of shirts, then the maximum possible total number of shirts that he could have bought is

**ANSWER:** 407

### Q16

CAT 2023 Slot 2 - QA

 If a certain amount of money is divided equally among \(n\) persons, each one receives Rs 352 . However, if two persons receive Rs 506 each and the remaining amount is divided equally among the other persons, each of them receive less than or equal to Rs 330 . Then, the maximum possible value of \(n\) is

**ANSWER:** 16

### Q17

CAT 2023 Slot 2 - QA

 In a rectangle ABCD, AB = 9 cm and BC = 6 cm. P and Q are two points on BC such that the areas of the figures ABP, APQ, and AQCD are in geometric progression. If the area of the figure AQCD is four times the area of triangle ABP, then BP : PQ : QC is

 1 : 1 : 2

 1 : 2 : 4

 2 : 4 : 1

 1 : 2 : 1

**ANSWER:** Choice C

### Q18

2 : 4 : 1

 CAT 2023 Slot 2 - QA

 A triangle is drawn with its vertices on the circle \(C\) such that one of its sides is a diameter of \(C\) and the other two sides have their lengths in the ratio \(a: b\). If the radius of the circle is \(r\), then the area of the triangle is

 \(\frac{a b r^2}{2\left(a^2+b^2\right)}\)

 \(\frac{a b r^2}{a^2+b^2}\)

 \(\frac{4 a b r^2}{a^2+b^2}\)

 \(\frac{2 a b r^2}{a^2+b^2}\)

**ANSWER:** Choice D

### Q19

\(\frac{2 a b r^2}{a^2+b^2}\)

 CAT 2023 Slot 2 - QA

 The area of the quadrilateral bounded by the \(Y\)-axis, the line \(x=5\), and the lines \(|x-y|-|x-5|=2\), is

**ANSWER:** 45

### Q20

CAT 2023 Slot 2 - QA

 Let both the series \(a_1, a_2, a_3, \ldots\) and \(b_1, b_2, b_3 \ldots\) be in arithmetic progression such that the common differences of both the series are prime numbers. If \(a_5=b_9, a_{19}=b_{19}\) and \(b_2=0\), then \(a_{11}\) equals

 79

 83

 86

 84

**ANSWER:** Choice A

### Q21

79

 CAT 2023 Slot 2 - QA

 If \(p^2+q^2-29=2 p q-20=52-2 p q\), then the difference between the maximum and minimum possible value of \(\left(p^3-q^3\right)\) is

 486

 189

 378

 243

**ANSWER:** Choice C

### Q22

378

 CAT 2023 Slot 2 - QA

 Let \(a_n\) and \(b_n\) be two sequences such that \(a_n=13+6(n-1)\) and \(b_n=15+7(n-1)\) for all natural numbers \(n\). Then, the largest three digit integer that is common to both these sequences, is

**ANSWER:** 967
