# CAT 2022 — Slot 1 — Quantitative Ability (Questions + On-page Answer Key)

Answers are on-page 2IIM **Correct Answer** labels. Not invented.

## Quantitative Ability

- Source file: `2iim-html/CAT-2022-Question-Paper-Slot-1-Quant.txt`
- Page: https://online.2iim.com/CAT-question-paper/CAT-2022-Question-Paper-Slot-1-Quant/
- On-page answers found: 22
- Answer source: 2IIM on-page **Correct Answer** / **Correct Answer Choice** (not invented)

### Q1

CAT 2022 Slot 1 - QA

 Let ABCD be a parallelogram such that the coordinates of its three vertices A, B, C are
 (1, 1), (3, 4) and (−2, 8), respectively. Then, the coordinates of the vertex D are

 (−4, 5)

 (4, 5)

 (−3, 4)

 (0, 11)

**ANSWER:** Choice A

### Q2

(−4, 5)

 CAT 2022 Slot 1 - QA

 The number of ways of distributing 20 identical balloons among 4 children such that each
 child gets some balloons but no child gets an odd number of balloons, is

**ANSWER:** 84

### Q3

CAT 2022 Slot 1 - QA

 A mixture contains lemon juice and sugar syrup in equal proportion. If a new mixture is
 created by adding this mixture and sugar syrup in the ratio 1 : 3, then the ratio of
 lemon juice and sugar syrup in the new mixture is

 1 : 6

 1 : 4

 1 : 5

 1 : 7

**ANSWER:** Choice D

### Q4

1 : 7

 CAT 2022 Slot 1 - QA

 For natural numbers \(x, y\), and \(z\), if \(x y+y z=19\) and \(y z+x z=51\), then the
 minimum possible value of \(x y z\) is

**ANSWER:** 34

### Q5

CAT 2022 Slot 1 - QA

 Let \(a, b, c\) be non-zero real numbers such that \(b^2 \lt 4 a c\), and \(f(x)=a x^2+b
 x+c\). If the set \(S\) consists of al integers \(m\) such that \(f(m)\lt0\), then the
 set \(S\) must necessarily be

 the set of all integers

 either the empty set or the set of all integers

 the empty set

 the set of all positive integers

**ANSWER:** Choice B

### Q6

either the empty set or the set of
 all integers

 CAT 2022 Slot 1 - QA

 Trains A and B start traveling at the same time towards each other with constant speeds
 from stations X and Y, respectively. Train A reaches station Y in 10 minutes while train
 B takes 9 minutes to reach station X after meeting train A. Then the total time taken,
 in minutes, by train B to travel from station Y to station X is

 15

 12

 6

 10

**ANSWER:** Choice A

### Q7

15

 CAT 2022 Slot 1 - QA

 The average of three integers is 13 . When a natural number \(n\) is included, the
 average of these four integers remains an odd integer. The minimum possible value of
 \(n\) is

 3

 4

 5

 1

**ANSWER:** Choice C

### Q8

5

 CAT 2022 Slot 1 - QA

 Pinky is standing in a queue at a ticket counter. Suppose the ratio of the number of
 persons standing ahead of Pinky to the number of persons standing behind her in the
 queue is 3 : 5. If the total number of persons in the queue is less than 300, then the
 maximum possible number of persons standing ahead of Pinky is

**ANSWER:** 111

### Q9

CAT 2022 Slot 1 - QA

 Ankita buys 4 kg cashews, 14 kg peanuts and 6 kg almonds when the cost of 7 kg cashews is
 the same as that of 30 kg peanuts or 9 kg almonds. She mixes all the three nuts and
 mixture at this marked price and the remaining at a 20% discount on the marked price,
 buying almonds is

 1440

 1176

 1680

 2520

**ANSWER:** Choice C

### Q10

1680

 CAT 2022 Slot 1 - QA

 The largest real value of \(a\) for which the equation \(|x+a|+|x-1|=2\) has an infinite
 number of solutions for \(x\) is

 -1

 0

 1

 2

**ANSWER:** Choice C

### Q11

1

 CAT 2022 Slot 1 - QA

 A trapezium \(\text{ABCD}\) has side \(\text{AD}\) parallel to \(\text{BC}, \angle
 \text{BAD}=90^{\circ}, \text{BC}=3 \text{~cm}\) and \(\text{AD}=8 \text{~cm}\). If the
 perimeter of this trapezium is \(36 \text{~cm}\), then its area, in sq. \(\text{cm}\),
 is

**ANSWER:** 66

### Q12

CAT 2022 Slot 1 - QA

 For any real number \(x\), let \([x]\) be the largest integer less than or equal to
 \(x\). If \(\sum_{n=1}^N\left[\frac{1}{5}+\frac{n}{25}\right]=25\) then \(N\) is

**ANSWER:** 44

### Q13

CAT 2022 Slot 1 - QA

 In a village, the ratio of number of males to females is 5 : 4. The ratio of number of
 literate males to literate females is 2 : 3. The ratio of the number of illiterate males
 to illiterate females is 4 : 3. If 3600 males in the village are literate, then the
 total number of females in the village is

**ANSWER:** 43200

### Q14

CAT 2022 Slot 1 - QA

 Amal buys 110 kg of syrup and 120 kg of juice, syrup being 20% less costly than juice,
 per kg. He sells 10 kg of syrup at 10% profit and 20 kg of juice at 20% profit. Mixing
 the remaining juice and syrup, Amal sells the mixture at ₹ 308.32 per kg and makes an
 overall profit of 64%. Then, Amal's cost price for syrup, in rupees per kg, is

**ANSWER:** 160

### Q15

CAT 2022 Slot 1 - QA

 Let \(a\) and \(b\) be natural numbers. If \(a^2+a b+a=14\) and \(b^2+a b+b=28\), then
 \((2 a+b)\) equals

 7

 10

 9

 8

**ANSWER:** Choice D

### Q16

8

 CAT 2022 Slot 1 - QA

 Alex invested his savings in two parts. The simple interest earned on the first part at
 15% per annum for 4 years is the same as the simple interest earned on the second part
 at 12% per annum for 3 years. Then, the percentage of his savings invested in the first
 part is

**ANSWER:** Choice B

### Q17

CAT 2022 Slot 1 - QA

 In a class of 100 students, 73 like coffee, 80 like tea and 52 like lemonade. It may be
 possible that some students do not like any of these three drinks. Then the difference
 between the maximum and minimum possible number of students who like all the three
 drinks is

 48

 53

 47

 52

**ANSWER:** Choice C

### Q18

47

 CAT 2022 Slot 1 - QA

 For any natural number \(n\), suppose the sum of the first \(n\) terms of an arithmetic
 progression is \(\left(n+2 n^2\right)\). If the \(n^{\text {th }}\) term of the
 progression is divisible by 9 , then the smallest possible value of \(n\) is

 4

 8

 7

 9

**ANSWER:** Choice C

### Q19

7

 CAT 2022 Slot 1 - QA

 All the vertices of a rectangle lie on a circle of radius \(R\). If the perimeter of the
 rectangle is \(P\), then the area of the rectangle is

 \(\frac{P^2}{2}-2 P R\)

 \(\frac{P^2}{8}-2 R^2\)

 \(\frac{P^2}{16}-R^2\)

 \(\frac{P^2}{8}-\frac{R^2}{2}\)

**ANSWER:** Choice B

### Q20

\(\frac{P^2}{8}-2 R^2\)

 CAT 2022 Slot 1 - QA

 The average weight of students in a class increases by 600 gm when some new students join
 the class. If the average weight of the new students is 3 kg more than the average
 weight of the original students, then the ratio of the number of original students to
 the number of new students is

 1 : 2

 3 : 1

 1 : 4

 4 : 1

**ANSWER:** Choice D

### Q21

4 : 1

 CAT 2022 Slot 1 - QA

 Let \(A\) be the largest positive integer that divides all the numbers of the form
 \(3^k+4^k+5^k\), and \(B\) be the largest positive integer that divides all the numbers
 of the form \(4^k+3\left(4^k\right)+4^{k+2}\), where \(k\) is any positive integer. Then
 \((A+B)\) equals

**ANSWER:** 82

### Q22

CAT 2022 Slot 1 - QA

 Let \(0 \leq a \leq x \leq 100\) and \(f(x)=|x-a|+|x-100|+|x-a-50|\). Then the maximum
 value of \(f(x)\) becomes 100 when \(a\) is equal to

 100

 25

 0

 50

**ANSWER:** Choice D
