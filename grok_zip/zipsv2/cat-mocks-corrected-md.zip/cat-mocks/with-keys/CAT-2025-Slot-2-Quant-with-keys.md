# CAT 2025 — Slot 2 — Quantitative Ability (Questions + On-page Answer Key)

Answers are on-page 2IIM **Correct Answer** labels. Not invented.

## Quantitative Ability

- Source file: `2iim-html/CAT-2025-Question-Paper-Slot-2-Quant.txt`
- Page: https://online.2iim.com/CAT-question-paper/CAT-2025-Question-Paper-Slot-2-Quant/
- On-page answers found: 22
- Answer source: 2IIM on-page **Correct Answer** / **Correct Answer Choice** (not invented)

### Q1

CAT Question
 Paper / CAT-2025-Slot 2-Quants

 C AT 2025 Quant, unlike previous years was not dominated by
 Arithmetic. Though Arithematic was the most tested topic followed by Algebra. In Arithmetic, the
 questions were dominated by topics like Speed-time-distance , Mixture and Alligations . This year,
 there was a surprise. The questions from Geometry were relatively on the lower
 side as compared to the previous years. There were 8 TITA Qs this year. Overall this section was
 at a medium level of difficulty.

 CAT 2025 Slot 2 - QA

 If \( m \) and \( n \) are integers such that \( ( m + 2 n ) ( 2 m + n ) = 27 \), then the maximum
possible value of \( 2 m - 3 n \) is

**ANSWER:** 17

### Q2

CAT 2025 Slot 2 - QA

 If \( \log _ { 64 } x ^ { 2 } + \log _ { 8 } \sqrt { y } + 3 \log _ { 512 } ( \sqrt { y } z ) = 4 \), where \( x , y \) and \( z \) are positive real
numbers, then the minimum possible value of \( ( x + y + z ) \) is

 \( 96 \)

 \( 48 \)

 \( 36 \)

 \( 24 \)

**ANSWER:** Choice B

### Q3

\( 48 \)

 CAT 2025 Slot 2 - QA

 The average number of copies of a book sold per day by a shopkeeper is 60 in the initial seven days and 63 in the initial eight days, after the book launch. On the ninth day, she sells 11 copies less than the eighth day, and the average number of copies sold per day from second day to ninth day becomes 66. The number of copies sold on the first day of the book launch is

**ANSWER:** 49

### Q4

CAT 2025 Slot 2 - QA

 Let \( f ( x ) = \frac { x } { ( 2 x - 1 ) } \) and \( g ( x ) = \frac { x } { ( x - 1 ) } \). Then, the domain of the function
\( h ( x ) = f ( g ( x ) ) + g ( f ( x ) ) \) is all real numbers except

 \( - 1 , \frac { 1 } { 2 } \), and 1

 \( \frac { 1 } { 2 } , 1 \), and \( \frac { 3 } { 2 } \)

 \( - \frac { 1 } { 2 } , \frac { 1 } { 2 } \), and 1

 \( \frac { 1 } { 2 } \), and 1

**ANSWER:** Choice A

### Q5

\( - 1 , \frac { 1 } { 2 } \), and 1

 CAT 2025 Slot 2 - QA

 If \( 9 ^ { x ^ { 2 } + 2 x - 3 } - 4 \left( 3 ^ { x ^ { 2 } + 2 x - 2 } \right) + 27 = 0 \), then the product of all possible
values of \( x \) is

 \( 5 \)

 \( 20 \)

 \( 30 \)

 \( 15 \)

**ANSWER:** Choice B

### Q6

\( 20 \)

 CAT 2025 Slot 2 - QA

 Let ABCDEF be a regular hexagon and P and Q be the midpoints of AB and CD, respectively. Then, the ratio of the areas of trapezium PBCQ and hexagon ABCDEF is

 5 : 24

 7 : 24

 6 : 25

 6 : 19

**ANSWER:** Choice A

### Q7

5 : 24

 CAT 2025 Slot 2 - QA

 If \( a , b , c \) and \( d \) are integers such that their sum is 46 , then the minimum
possible value of \( ( a - b ) ^ { 2 } + ( a - c ) ^ { 2 } + ( a - d ) ^ { 2 } \) is

**ANSWER:** 2

### Q8

CAT 2025 Slot 2 - QA

 Let \( a _ { n } \) be the \( n ^ { \text {th } } \) term of a decreasing infinite geometric progression.
If \( a _ { 1 } + a _ { 2 } + a _ { 3 } = 52 \) and \( a _ { 1 } a _ { 2 } + a _ { 2 } a _ { 3 } + a _ { 3 } a _ { 1 } = 624 \), then the sum of
this geometric progression is

 \( 63 \)

 \( 60 \)

 \( 54 \)

 \( 57 \)

**ANSWER:** Choice C

### Q9

\( 54 \)

 CAT 2025 Slot 2 - QA

 Suppose \( a , b , c \) are three distinct natural numbers, such that \( 3 a c = 8 ( a + b ) \). Then, the smallest possible
value of \( 3 a + 2 b + c \) is

**ANSWER:** 12

### Q10

CAT 2025 Slot 2 - QA

 Two tangents drawn from a point \( P \) touch a circle with center \( O \) at points
\( Q \) and \( R \). Points \( A \) and \( B \) lie on \( P Q \) and \( P R \), respectively, such that \( A B \) is also
a tangent to the same circle. If \( \angle A O B = 50 ^ { \circ } \), then \( \angle A P B \), in degrees, equals

**ANSWER:** 80

### Q11

CAT 2025 Slot 2 - QA

 The number of divisors of \( \left( 2 ^ { 6 } \times 3 ^ { 5 } \times 5 ^ { 3 } \times 7 ^ { 2 } \right) \), which are of the form \( ( 3 r + 1 ) \), where \( r \) is a
non-negative integer, is

 \( 42 \)

 \( 36 \)

 \( 56 \)

 \( 24 \)

**ANSWER:** Choice A

### Q12

\( 42 \)

 CAT 2025 Slot 2 - QA

 Ankita is twice as efficient as Bipin, while Bipin is twice as efficient as Chandan. All three of them start together on a job, and Bipin leaves the job after 20 days. If the job got completed in 60 days, the number of days needed by Chandan to complete the job alone, is

**ANSWER:** 340

### Q13

CAT 2025 Slot 2 - QA

 The ratio of expenditures of Lakshmi and Meenakshi is 2 : 3, and the ratio of income of Lakshmi to expenditure of Meenakshi is 6 : 7. If excess of income over expenditure is saved by Lakshmi and Meenakshi, and the ratio of their savings is 4 : 9, then the ratio of their incomes is

 5 : 6

 3 : 5

 7 : 8

 2 : 1

**ANSWER:** Choice B

### Q14

3 : 5

 CAT 2025 Slot 2 - QA

 The set of all real values of \( x \) for which \( \left( x ^ { 2 } - | x + 9 | + x \right) > 0 \), is

 \( ( - \infty , - 9 ) \cup ( 9 , \infty ) \)

 \( ( - \infty , - 3 ) \cup ( 3 , \infty ) \)

 \( ( - 9 , - 3 ) \cup ( 3 , \infty ) \)

 \( ( - \infty , - 9 ) \cup ( 3 , \infty ) \)

**ANSWER:** Choice B

### Q15

\( ( - \infty , - 3 ) \cup ( 3 , \infty ) \)

 CAT 2025 Slot 2 - QA

 An item with a cost price of Rs. 1650 is sold at a certain discount on a fixed marked price to earn a profit of 20% on the cost price. If the discount was doubled, the profit would have been Rs. 110. The rate of discount, in percentage, at which the profit percentage would be equal to the rate of discount, is nearest to

 12

 14

 16

 18

**ANSWER:** Choice B

### Q16

14

 CAT 2025 Slot 2 - QA

 The equations \( 3 x ^ { 2 } - 5 x + p = 0 \) and \( 2 x ^ { 2 } - 2 x + q = 0 \) have one common
root. The sum of the other roots of these two equations is

 \( \frac { 2 } { 3 } - p + \frac { 3 } { 2 } q \)

 \( \frac { 8 } { 3 } + p + \frac { 1 } { 3 } q \)

 \( \frac { 2 } { 3 } - 2 p + \frac { 2 } { 3 } q \)

 \( \frac { 8 } { 3 } - p + \frac { 3 } { 2 } q \)

**ANSWER:** Choice D

### Q17

\( \frac { 8 } { 3 } - p + \frac { 3 } { 2 } q \)

 CAT 2025 Slot 2 - QA

 A mixture of coffee and cocoa, 16% of which is coffee, costs Rs 240 per kg. Another mixture of coffee and cocoa, of which 36% is coffee, costs Rs 320 per kg. If a new mixture of coffee and cocoa costs Rs 376 per kg, then the quantity, in kg, of coffee in 10 kg of this new mixture is

 4

 6

 2.5

 5

**ANSWER:** Choice D

### Q18

5

 CAT 2025 Slot 2 - QA

 A loan of Rs 1000 is fully repaid by two installments of Rs 530 and Rs 594, paid at the end of first and second year, respectively. If the interest is compounded annually, then the rate of interest, in percentage, is

 8

 10

 11

 9

**ANSWER:** Choice A

### Q19

8

 CAT 2025 Slot 2 - QA

 Rita and Sneha can row a boat at 5 km/h and 6 km/h in still water, respectively. In a river flowing with a constant velocity, Sneha takes 48 minutes more to row 14 km upstream than to row the same distance downstream. If Rita starts from a certain location in the river, and returns downstream to the same location, taking a total of 100 minutes, then the total distance, in km, Rita will cover is

**ANSWER:** 8

### Q20

CAT 2025 Slot 2 - QA

 The sum of digits of the number \( ( 625 ) ^ { 65 } \times ( 128 ) ^ { 36 } \), is

**ANSWER:** 25

### Q21

CAT 2025 Slot 2 - QA

 In a \( \triangle A B C \), points D and E are on the sides BC and AC , respectively. BE and
AD intersect at point T such that \( \mathrm { AD } : A T = 4 : 3 \), and \( \mathrm { BE } : \mathrm { BT } = 5 : 4 \). Point
F lies on AC such that DF is parallel to BE . Then, \( \mathrm { BD } : \mathrm { CD } \) is

 \( 9 : 4 \)

 \( 15 : 4 \)

 \( 11 : 4 \)

 \( 7 : 4 \)

**ANSWER:** Choice C

### Q22

\( 11 : 4 \)

 CAT 2025 Slot 2 - QA

 A certain amount of money was divided among Pinu, Meena, Rinu and Seema. Pinu received 20% of the total amount and Meena received 40% of the remaining amount. If Seema received 20% less than Pinu, the ratio of the amounts received by Pinu and Rinu is

 8 : 5

 5 : 8

 2 : 1

 1 : 2

**ANSWER:** Choice B
