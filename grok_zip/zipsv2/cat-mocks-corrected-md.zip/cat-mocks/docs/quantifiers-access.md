# Quantifiers TruCAT / free mocks — access notes

Fetched via WebFetch 30 Sep 2026 IST (box `curl` TLS handshake to quantifiers.in fails: unexpected EOF).

## TruCAT 10 free full-length mocks
- Marketing: https://quantifiers.in/trucat-free-cat-mock-test-2026/
- Test platform: https://quantifiers.in/cat-test-series
- Claims: 10 full mocks, ₹0, "No login wall" on marketing copy; format is an **interactive web test app** (not static PDF/HTML question dumps).
- Each mock: 68 Q, 120 min, 3 timed sections; video solutions + QA text solutions; performance analysis.
- **No question HTML/PDF found** on the landing pages — attempting the mocks requires a browser session on their app.

### How to start each mock (browser follow-up)
1. Open https://quantifiers.in/cat-test-series
2. Look for TruCAT / full-length mock list (TruCAT 1–10).
3. Click a mock to start under timed conditions.
4. If a soft gate appears despite marketing, stop — do not bypass.

## Related free PYQ PDFs on same domain
Index: https://quantifiers.in/cat-previous-year-papers/
Known public PDF pattern (search-indexed): `https://quantifiers.in/wp-content/uploads/2025/07/CAT-YYYY.pdf`
Examples confirmed indexed: CAT-2008, CAT-2012, CAT-2013.
Older years listed on index (1991–2016 era memory papers). Download status recorded in pyq-pdfs/ and INVENTORY.

## Sectionals (likely paid / app)
VARC 50 / DILR 60 / High-level packs advertised on cat-test-series — treat as platform content; not scraped.
