# Cracku free mock — Secure Form / login blocker

**Stopped here:** free CAT mocks and free sectionals require signup. Do not invent credentials or bypass.

## Primary URL (start Free Mock 1)

https://cracku.in/cat-mock-test/free-cat-mock-1

Sibling mocks (same wall):
- https://cracku.in/cat-mock-test/free-cat-mock-2
- https://cracku.in/cat-mock-test/free-cat-mock-3

Unauth start attempt: https://cracku.in/cat-mock-test/free-cat-mock-1/start → 302 back to instructions.

## How the wall appears

1. On instructions page, primary CTA:  
   - **selector:** `a#cracku-interface`  
   - **handler:** `onclick="openMockLogin()"`  
   - Label typically “Cracku Interface” / start mock.
2. Opens **`#modal-login-popup`** (`<section id="modal-login-popup">`), title text **“Mock Test Signup”**.
3. JS slug: `MOCK_LOGIN_SLUG = 'free-cat-mock-1'` (varies per mock page).

## Secure Form field refs (mobile OTP path)

| Role | Ref | Notes |
| --- | --- | --- |
| Mobile / OTP input | `input[name="whatsapplogininput"]` | `type="text"`, `maxlength="10"`, `pattern="[6-9][0-9]{9}"`, placeholder **“Enter your mobile number here”**; switches to OTP placeholder after send |
| Aria | `aria-label="Mobile number"` | same input |
| Wrapper | `.phone-input-wrapper` | |
| Submit / Send OTP | button `type="submit"` with text **“Send OTP”** | inside modal footer |
| Resend OTP | Resend control in modal (“Resend OTP in 00:30”) | |
| Change number | “Change Number” link in modal | |
| Google Sign-In container | `#mockLoginGoogleBtn` | Google GIS client; meta `google-signin-client_id` on page |
| Email signup/login | buttons `onclick="mockLoginOpenEmail()"` | text **“Signup”** / **“Login”** with Email; input placeholder becomes **“Enter your email here”** on that path |
| Close | `onclick="mockInstructionsLogin.close();"` | |

Terms/Privacy links present in modal footer (“By Continuing, you agree to cracku's Terms / Privacy Policy”).

## Alternate sitewide login

- `#getStartedBtn` with classes `login-required`, `data-logintab="login"`, `data-loginname="Signin"`
- Separate `#login-modal` / `#login_iframe` used elsewhere (downloads register flow uses `data-loginname="Download_Register"` / `"Download_PDF_Now"`)

## PDF download login (related)

Example gated full paper: https://cracku.in/downloads/22846 → 302 → https://cracku.in/downloads/22846/login  
(“Download CAT 2025 Slot 1 Question Paper by Cracku for Free” — still requires register/login.)

## What to do after Om logs in

Save each free mock’s questions + official answer key/solutions into `/workspace/cat-mocks/cracku/` (prefer post-login PDF or review page). Do not scrape paid DashCAT.
