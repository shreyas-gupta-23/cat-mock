# Access & gate notes

Folded from thin source folders (`insideiim/`, `quantifiers/`) and scratch status files.
No question banks live here — only how to reach incomplete sources and what blocked capture.

| File | Topic |
| --- | --- |
| `insideiim-access.md` | InsideIIM free sectionals — registration required; **not captured** |
| `quantifiers-access.md` | TruCAT interactive mocks — no static dump |
| `quantifiers-known-pdf-urls.md` | Older PYQ PDF URLs (download from a normal browser; box TLS failed) |
| `career-launcher-unlocked.md` | What CL Free Zone showed as unlocked (30 Sep 2026) |
| `career-launcher-catalog.md` | Topic/sectional instruction URL catalog |
| `cracku-secure-form.md` | Cracku login field refs (do not invent credentials) |
| `cracku-free-mock-3-status.md` | Mock 3 capture session notes |

For actual CL / Cracku question files, see `../career-launcher/` and `../cracku/`.
