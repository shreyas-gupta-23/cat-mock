# Quantifiers public PYQ PDF URLs (browser download)

Box TLS to quantifiers.in fails (handshake EOF), so PDFs were **not** saved locally.
WebFetch can load HTML; search indexes confirm these PDFs are public (no login).

Index page: https://quantifiers.in/cat-previous-year-papers/

## Confirmed / search-indexed direct PDFs
- https://quantifiers.in/wp-content/uploads/2025/07/CAT-2008.pdf
- https://quantifiers.in/wp-content/uploads/2025/07/CAT-2012.pdf
- https://quantifiers.in/wp-content/uploads/2025/07/CAT-2013.pdf

## Years listed on index (try same path pattern)
CAT-1991, 1997, 1998, 1999, 2001–2013, 2016 (and possibly others under `/wp-content/uploads/YYYY/MM/`).

Pattern to try in browser:
`https://quantifiers.in/wp-content/uploads/2025/07/CAT-{YEAR}.pdf`

Do not invent content if a year 404s.
