# Cracku Free CAT Mock 3 status

Completed after waiting 5.5 minutes past the cooldown. Mock 3 was submitted blank, then the Cracku review page was captured.

- Questions/options: `free-mock-3.md` — 68 entries (VARC 24, LRDI 22, Quant 22).
- Answer review: `free-mock-3-answers.md` — Cracku-exposed answer markings where available, text solutions, and scorecard.
- Scorecard: Overall 0.0, 68 skipped, current percentile 25.87; VARC 35.17, LRDI 42.01, Quant 36.43.
- No answers were invented; 25 entries did not expose a marked option in the review markup and are labeled accordingly.
